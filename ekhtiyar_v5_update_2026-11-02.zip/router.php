<?php
/**
 * موجّه خادم PHP المدمج (للتطوير المحلي فقط) — يحاكي قواعد .htaccess.
 * التشغيل:  php -S localhost:8000 -t public router.php
 */
$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$public = __DIR__ . '/public';
$file = realpath($public . $uri);

// منع الملفات المخفية
if (preg_match('#/\.#', $uri)) { http_response_code(403); exit('Forbidden'); }
// منع تنفيذ PHP داخل مجلد الرفع
if (str_starts_with($uri, '/assets/images/uploads/') && preg_match('/\.(php\d?|phtml|phar|html?|svg)$/i', $uri)) { http_response_code(403); exit('Forbidden'); }

if ($file && str_starts_with($file, $public) && is_file($file)) {
    if (str_ends_with($file, '.php')) {
        $_SERVER['SCRIPT_NAME'] = $uri;
        chdir(dirname($file));
        require $file;
        return true;
    }
    return false; // ملف ثابت
}
if ($file && is_dir($file) && is_file($file . '/index.php')) {
    $_SERVER['SCRIPT_NAME'] = rtrim($uri, '/') . '/index.php';
    require $file . '/index.php';
    return true;
}

$routes = [
    '#^/sitemap\.xml$#' => ['sitemap.php', []],
    '#^/robots\.txt$#'  => ['robots.php', []],
    '#^/service/([^/]+)/?$#' => ['service.php', ['slug']],
    '#^/work/([^/]+)/?$#' => ['work.php', ['slug']],
    '#^/category/([^/]+)/([^/]+)/?$#' => ['category.php', ['slug', 'sub']],
    '#^/category/([^/]+)/?$#' => ['category.php', ['slug']],
    '#^/blog/([^/]+)/?$#' => ['article.php', ['slug']],
    '#^/page/([^/]+)/?$#' => ['page.php', ['slug']],
    '#^/(services|specializations|search|portfolio|order|about|faq|contact|privacy|terms|login|register|account|logout|forgot|review|track|blog)/?$#' => [null, []],
];
foreach ($routes as $re => [$target, $params]) {
    if (preg_match($re, $uri, $m)) {
        $target ??= $m[1] . '.php';
        foreach ($params as $i => $p) $_GET[$p] = $m[$i + 1];
        $_SERVER['SCRIPT_NAME'] = '/' . $target;
        require $public . '/' . $target;
        return true;
    }
}
http_response_code(404);
$_SERVER['SCRIPT_NAME'] = '/404.php';
require $public . '/404.php';
