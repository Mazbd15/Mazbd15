<?php
/**
 * إعدادات التطبيق — تُقرأ من ملف .env في جذر المشروع.
 * هذا الملف خارج المجلد العام public/ ولا يمكن الوصول إليه من المتصفح.
 */
declare(strict_types=1);

define('ROOT_PATH', dirname(__DIR__));

/** قراءة ملف .env بسيط (KEY=VALUE) دون مكتبات خارجية */
(function (): void {
    $file = ROOT_PATH . '/.env';
    if (!is_file($file) || !is_readable($file)) {
        return;
    }
    foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = array_map('trim', explode('=', $line, 2));
        if (strlen($value) >= 2 && $value[0] === '"' && $value[-1] === '"') {
            $value = stripcslashes(substr($value, 1, -1)); // يفك \" و \\
        } elseif (strlen($value) >= 2 && $value[0] === "'" && $value[-1] === "'") {
            $value = substr($value, 1, -1);
        }
        if (getenv($key) === false) {
            putenv("$key=$value");
            $_ENV[$key] = $value;
        }
    }
})();

function env(string $key, $default = null)
{
    $v = $_ENV[$key] ?? getenv($key);
    if ($v === false || $v === null) {
        return $default;
    }
    $lower = strtolower((string) $v);
    if ($lower === 'true') return true;
    if ($lower === 'false') return false;
    if ($lower === 'null' || $lower === '') return $default;
    return $v;
}

/**
 * تحديد المجلد العام تلقائيًا (إصلاح v5):
 * يدعم البنيتين: المشروع كاملًا داخل public_html (مع public/)، أو نقل محتويات public/ إلى public_html
 * وبقية المشروع خارجه (بنية Hostinger الشائعة). يمكن فرضه يدويًا بـ PUBLIC_PATH في .env.
 */
function detect_public_path(): string
{
    $forced = (string) env('PUBLIC_PATH', '');
    if ($forced !== '' && is_dir($forced)) return rtrim((string) realpath($forced), '/\\');
    $script = (string) ($_SERVER['SCRIPT_FILENAME'] ?? '');
    if (PHP_SAPI !== 'cli' && $script !== '') {
        $dir = realpath(dirname($script));
        if ($dir) {
            foreach ([$dir, dirname($dir)] as $cand) { // admin/ و api/ أعمق بمستوى
                if (is_file($cand . '/index.php') && is_dir($cand . '/assets/images')) return $cand;
            }
        }
    }
    // سطر الأوامر: نبحث عن المجلد العام الذي يحتوي index.php
    foreach ([ROOT_PATH . '/public', ROOT_PATH . '/public_html', dirname(ROOT_PATH) . '/public_html'] as $cand) {
        if (is_file($cand . '/index.php') && is_dir($cand . '/assets/images')) return $cand;
    }
    return ROOT_PATH . '/public';
}
define('PUBLIC_PATH', detect_public_path());

return [
    'app' => [
        'env'       => (string) env('APP_ENV', 'production'),
        'debug'     => (bool) env('APP_DEBUG', false),
        'url'       => rtrim((string) env('APP_URL', ''), '/'),
        'pretty'    => (bool) env('PRETTY_URLS', true),
        'timezone'  => (string) env('APP_TIMEZONE', 'Asia/Riyadh'),
        'key'       => (string) env('APP_KEY', ''),
        'setup_key' => (string) env('SETUP_KEY', ''),
    ],
    'db' => [
        'host' => (string) env('DB_HOST', '127.0.0.1'),
        'port' => (int) env('DB_PORT', 3306),
        'name' => (string) env('DB_NAME', 'ikhtiyarak'),
        'user' => (string) env('DB_USER', 'root'),
        'pass' => (string) env('DB_PASS', ''),
    ],
    'uploads' => [
        'path'      => rtrim((string) (env('STORAGE_PATH', '') ?: ROOT_PATH . '/storage/uploads'), '/'),
        'max_mb'    => max(1, (int) env('UPLOAD_MAX_MB', 10)),
        'max_files' => max(1, (int) env('UPLOAD_MAX_FILES', 5)),
        // الامتدادات المسموحة لمرفقات العملاء => أنواع MIME المقبولة (يتم التحقق على الخادم)
        'allowed'   => [
            'pdf'  => ['application/pdf'],
            'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
            'doc'  => ['application/msword', 'application/CDFV2', 'application/x-ole-storage', 'application/octet-stream'],
            'jpg'  => ['image/jpeg'],
            'jpeg' => ['image/jpeg'],
            'png'  => ['image/png'],
            'dwg'  => ['image/vnd.dwg', 'application/acad', 'application/x-acad', 'application/autocad_dwg', 'image/x-dwg', 'application/dwg', 'application/x-dwg', 'application/octet-stream'],
            'dxf'  => ['image/vnd.dxf', 'application/dxf', 'text/plain', 'text/x-dxf', 'application/octet-stream'],
            'zip'  => ['application/zip', 'application/x-zip-compressed', 'multipart/x-zip'],
        ],
    ],
];
