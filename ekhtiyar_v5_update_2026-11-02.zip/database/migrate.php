<?php
/**
 * تشغيل ترقيات قاعدة البيانات من سطر الأوامر (بديل عن زر «تشغيل الترقيات» في لوحة التحكم):
 *   php database/migrate.php            ← نسخة احتياطية لقاعدة البيانات ثم تطبيق الترقيات المعلّقة
 *   php database/migrate.php --status   ← عرض الحالة فقط
 *   php database/migrate.php --rollback=NAME
 * آمن: إضافي فقط، لا يحذف بيانات، ولا يعيد التثبيت.
 */
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
require dirname(__DIR__) . '/includes/bootstrap.php';
$opt = getopt('', ['status', 'rollback:', 'no-backup']);
$applied = migrations_applied();
foreach (migrations_all() as $n => $d) echo (isset($applied[$n]) ? '[✓] ' : '[ ] ') . $n . ' — ' . ($d['title'] ?? '') . "\n";
if (isset($opt['status'])) exit(0);
if (!empty($opt['rollback'])) { print_r(migration_rollback((string) $opt['rollback'])); exit(0); }
if (!migrations_pending()) { echo "لا توجد ترقيات معلّقة.\n"; exit(0); }
if (!isset($opt['no-backup']) && function_exists('backup_create')) {
    [$ok, $msg] = backup_create('pre-migration', false);
    echo ($ok ? 'نسخة احتياطية: ' : 'تعذر إنشاء نسخة احتياطية: ') . $msg . "\n";
    if (!$ok) exit(1);
}
foreach (migrations_run() as [$st, $n, $info]) echo ($st === 'ok' ? '✓ ' : '✗ ') . "$n $info\n";
