<?php
/**
 * ترقية الإصدار 5 — إضافية فقط (لا تحذف ولا تعدّل أي بيانات موجودة):
 * آراء العملاء، مركز الرسائل، سجل حالات الطلب، المقالات والصفحات، سجل النسخ الاحتياطي،
 * سلة المحذوفات (deleted_at)، التفرعات متعددة المستويات (parent_id)، صورة الجوال ومشاهدات البنرات،
 * حالة «قيد التنفيذ» للطلبات، وإعدادات جديدة.
 */
return [
    'title' => 'الإصدار 5: آراء العملاء، الرسائل، المقالات، سلة المحذوفات، النسخ الاحتياطي، التفرعات',
    'up' => function (): void {
        $pdo = db();
        $T = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

        $pdo->exec("CREATE TABLE IF NOT EXISTS testimonials (
          id INT UNSIGNED NOT NULL AUTO_INCREMENT,
          name VARCHAR(120) NOT NULL,
          avatar VARCHAR(255) NULL,
          specialization VARCHAR(160) NULL,
          service_id INT UNSIGNED NULL,
          service_label VARCHAR(200) NULL,
          rating TINYINT UNSIGNED NOT NULL DEFAULT 5,
          body TEXT NOT NULL,
          attachment VARCHAR(255) NULL,
          theme VARCHAR(20) NOT NULL DEFAULT 'white',
          bg_image VARCHAR(255) NULL,
          bg_color VARCHAR(7) NULL,
          text_color VARCHAR(7) NULL,
          icon VARCHAR(60) NULL,
          is_verified TINYINT(1) NOT NULL DEFAULT 0,
          request_ref VARCHAR(30) NULL,
          status ENUM('pending','approved','hidden') NOT NULL DEFAULT 'pending',
          is_pinned TINYINT(1) NOT NULL DEFAULT 0,
          consent_publish TINYINT(1) NOT NULL DEFAULT 0,
          source ENUM('admin','visitor') NOT NULL DEFAULT 'visitor',
          sort_order INT NOT NULL DEFAULT 0,
          ip_hash CHAR(64) NULL,
          approved_by INT UNSIGNED NULL,
          approved_at DATETIME NULL,
          deleted_at DATETIME NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (id),
          KEY idx_t_status (status, deleted_at, is_pinned, sort_order),
          KEY idx_t_service (service_id),
          CONSTRAINT fk_t_service FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE SET NULL ON UPDATE CASCADE
        ) $T");

        $pdo->exec("CREATE TABLE IF NOT EXISTS contact_messages (
          id INT UNSIGNED NOT NULL AUTO_INCREMENT,
          name VARCHAR(120) NOT NULL,
          phone VARCHAR(40) NULL,
          email VARCHAR(190) NULL,
          subject VARCHAR(190) NULL,
          body TEXT NOT NULL,
          category VARCHAR(30) NOT NULL DEFAULT 'inquiry',
          request_ref VARCHAR(30) NULL,
          request_id INT UNSIGNED NULL,
          status ENUM('new','read','processing','done') NOT NULL DEFAULT 'new',
          internal_notes TEXT NULL,
          assigned_to INT UNSIGNED NULL,
          ip_hash CHAR(64) NULL,
          deleted_at DATETIME NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (id),
          KEY idx_m_status (status, deleted_at, created_at),
          KEY idx_m_request (request_id),
          CONSTRAINT fk_m_request FOREIGN KEY (request_id) REFERENCES requests (id) ON DELETE SET NULL ON UPDATE CASCADE,
          CONSTRAINT fk_m_assigned FOREIGN KEY (assigned_to) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
        ) $T");

        $pdo->exec("CREATE TABLE IF NOT EXISTS message_replies (
          id INT UNSIGNED NOT NULL AUTO_INCREMENT,
          message_id INT UNSIGNED NOT NULL,
          user_id INT UNSIGNED NULL,
          channel ENUM('whatsapp','email','note') NOT NULL DEFAULT 'whatsapp',
          body TEXT NOT NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (id),
          KEY idx_mr_msg (message_id, created_at),
          CONSTRAINT fk_mr_msg FOREIGN KEY (message_id) REFERENCES contact_messages (id) ON DELETE CASCADE ON UPDATE CASCADE,
          CONSTRAINT fk_mr_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
        ) $T");

        $pdo->exec("CREATE TABLE IF NOT EXISTS request_status_log (
          id INT UNSIGNED NOT NULL AUTO_INCREMENT,
          request_id INT UNSIGNED NOT NULL,
          old_status VARCHAR(30) NULL,
          new_status VARCHAR(30) NOT NULL,
          user_id INT UNSIGNED NULL,
          note VARCHAR(500) NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (id),
          KEY idx_rsl_req (request_id, created_at),
          CONSTRAINT fk_rsl_req FOREIGN KEY (request_id) REFERENCES requests (id) ON DELETE CASCADE ON UPDATE CASCADE,
          CONSTRAINT fk_rsl_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
        ) $T");

        $pdo->exec("CREATE TABLE IF NOT EXISTS posts (
          id INT UNSIGNED NOT NULL AUTO_INCREMENT,
          type ENUM('article','page') NOT NULL DEFAULT 'article',
          title VARCHAR(200) NOT NULL,
          slug VARCHAR(220) NOT NULL,
          excerpt VARCHAR(400) NULL,
          body MEDIUMTEXT NULL,
          cover_image VARCHAR(255) NULL,
          category_id INT UNSIGNED NULL,
          status ENUM('draft','published') NOT NULL DEFAULT 'draft',
          published_at DATETIME NULL,
          show_in_footer TINYINT(1) NOT NULL DEFAULT 0,
          views INT UNSIGNED NOT NULL DEFAULT 0,
          meta_title VARCHAR(190) NULL,
          meta_description VARCHAR(300) NULL,
          author_id INT UNSIGNED NULL,
          sort_order INT NOT NULL DEFAULT 0,
          deleted_at DATETIME NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (id),
          UNIQUE KEY uq_posts_type_slug (type, slug),
          KEY idx_posts_pub (type, status, deleted_at, published_at),
          CONSTRAINT fk_posts_cat FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL ON UPDATE CASCADE,
          CONSTRAINT fk_posts_author FOREIGN KEY (author_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
        ) $T");

        $pdo->exec("CREATE TABLE IF NOT EXISTS backups_log (
          id INT UNSIGNED NOT NULL AUTO_INCREMENT,
          action ENUM('create','restore','delete','download') NOT NULL,
          file_name VARCHAR(190) NOT NULL,
          file_size BIGINT UNSIGNED NULL,
          kind ENUM('manual','auto','pre-migration','pre-restore') NOT NULL DEFAULT 'manual',
          includes_files TINYINT(1) NOT NULL DEFAULT 1,
          user_id INT UNSIGNED NULL,
          note VARCHAR(500) NULL,
          created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (id),
          KEY idx_bl_date (created_at)
        ) $T");

        // سلة المحذوفات + تفرعات متعددة المستويات
        mig_add_column('categories', 'deleted_at', 'DATETIME NULL');
        mig_add_column('subcategories', 'deleted_at', 'DATETIME NULL');
        mig_add_column('subcategories', 'parent_id', 'INT UNSIGNED NULL AFTER category_id');
        mig_add_index('subcategories', 'idx_sub_parent', 'parent_id');
        mig_add_column('subcategories', 'image', 'VARCHAR(255) NULL');
        mig_add_column('subcategories', 'meta_title', 'VARCHAR(190) NULL');
        mig_add_column('subcategories', 'meta_description', 'VARCHAR(300) NULL');
        if (!mig_fk_exists('subcategories', 'fk_sub_parent')) {
            $pdo->exec('ALTER TABLE subcategories ADD CONSTRAINT fk_sub_parent FOREIGN KEY (parent_id) REFERENCES subcategories (id) ON DELETE SET NULL ON UPDATE CASCADE');
        }
        mig_add_column('services', 'deleted_at', 'DATETIME NULL');
        mig_add_column('portfolio_items', 'deleted_at', 'DATETIME NULL');
        // البنرات
        mig_add_column('banners', 'mobile_image', 'VARCHAR(255) NULL AFTER image');
        mig_add_column('banners', 'views', 'INT UNSIGNED NOT NULL DEFAULT 0 AFTER clicks');
        // حالة «قيد التنفيذ» (توسيع القائمة فقط — لا تتأثر القيم الحالية)
        $pdo->exec("ALTER TABLE requests MODIFY status ENUM('new','reviewing','awaiting_client','in_progress','completed','cancelled') NOT NULL DEFAULT 'new'");

        $sets = [
            ['testimonials_enabled', '1', 'testimonials', 'تفعيل آراء العملاء في الموقع', 'bool'],
            ['testimonials_title', 'ماذا يقول عملاؤنا', 'testimonials', 'عنوان قسم الآراء', 'text'],
            ['testimonials_subtitle', 'تجارب حقيقية من طلاب وخريجين تعاملوا معنا — تُنشر بموافقة أصحابها.', 'testimonials', 'وصف قسم الآراء', 'text'],
            ['testimonials_layout', 'slider', 'testimonials', 'طريقة العرض في الرئيسية', 'select'],
            ['testimonials_count', '6', 'testimonials', 'عدد البطاقات المعروضة في الرئيسية', 'number'],
            ['testimonials_interval', '6', 'testimonials', 'مدة انتقال السلايدر (بالثواني)', 'number'],
            ['testimonials_show_avg', '1', 'testimonials', 'إظهار متوسط التقييم العام', 'bool'],
            ['testimonials_allow_submit', '1', 'testimonials', 'السماح للعملاء بإرسال آرائهم (تُراجع قبل النشر)', 'bool'],
            ['show_home_testimonials', '1', 'sections', 'قسم «آراء العملاء»', 'bool'],
            ['show_home_articles', '1', 'sections', 'قسم «أحدث المقالات» (يظهر عند وجود مقالات)', 'bool'],
            ['banner_interval', '6', 'sections', 'مدة انتقال بنرات العروض (بالثواني)', 'number'],
            ['messages_save', '1', 'contact', 'حفظ رسائل نموذج التواصل في مركز الرسائل', 'bool'],
            ['messages_whatsapp_after', '1', 'contact', 'فتح واتساب للمرسل بعد حفظ رسالته', 'bool'],
            ['backup_keep', '10', 'advanced', 'عدد النسخ الاحتياطية المحتفظ بها', 'number'],
            ['backup_auto_days', '7', 'advanced', 'نسخة احتياطية تلقائية كل (أيام) — 0 للتعطيل', 'number'],
            ['backup_include_files', '1', 'advanced', 'تضمين الصور والملفات المرفوعة في النسخ', 'bool'],
            ['articles_enabled', '1', 'advanced', 'تفعيل المقالات والمدونة', 'bool'],
        ];
        foreach ($sets as $i => [$k, $v, $g, $l, $t]) mig_setting($k, $v, $g, $l, $t, 2000 + $i * 10);
        db_exec("UPDATE site_settings SET setting_value = '5' WHERE setting_key = 'db_version'");
    },
    'down' => function (): void {
        // تحذير: يحذف بيانات الإصدار 5 فقط (الآراء، الرسائل، المقالات، السجلات). خذ نسخة احتياطية أولًا.
        $pdo = db();
        foreach (['message_replies', 'contact_messages', 'testimonials', 'request_status_log', 'posts', 'backups_log'] as $t) $pdo->exec("DROP TABLE IF EXISTS `$t`");
        if (mig_fk_exists('subcategories', 'fk_sub_parent')) $pdo->exec('ALTER TABLE subcategories DROP FOREIGN KEY fk_sub_parent');
        foreach ([['categories', 'deleted_at'], ['subcategories', 'deleted_at'], ['subcategories', 'parent_id'], ['subcategories', 'image'], ['subcategories', 'meta_title'], ['subcategories', 'meta_description'], ['services', 'deleted_at'], ['portfolio_items', 'deleted_at'], ['banners', 'mobile_image'], ['banners', 'views']] as [$t, $c]) mig_drop_column($t, $c);
        $pdo->exec("UPDATE requests SET status = 'reviewing' WHERE status = 'in_progress'");
        $pdo->exec("ALTER TABLE requests MODIFY status ENUM('new','reviewing','awaiting_client','completed','cancelled') NOT NULL DEFAULT 'new'");
        db_exec("UPDATE site_settings SET setting_value = '4' WHERE setting_key = 'db_version'");
    },
];
