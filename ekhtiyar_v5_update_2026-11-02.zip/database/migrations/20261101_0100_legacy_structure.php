<?php
/**
 * ضمان بنية الإصدارات 2 و3 و4 للمواقع التي لم تُشغّل ملفات الترقية القديمة.
 * لكل إصدار «علامة» تُفحص أولًا، ولا يُنفذ إلا الجزء الناقص (آمن عند التكرار).
 */
return [
    'title' => 'ضمان بنية الإصدارات 2 و3 و4 (تنفيذ الأجزاء الناقصة فقط)',
    'up' => function (): void {
        $run = function (string $file): void {
            $sql = (string) file_get_contents(ROOT_PATH . '/database/' . $file);
            foreach (sql_split($sql) as $st) db()->exec($st);
        };
        if (mig_table_exists('users') && !mig_column_exists('users', 'status')) $run('upgrade_v2.sql');
        if (mig_table_exists('banners') && !mig_column_exists('banners', 'theme')) $run('upgrade_v3.sql');
        if (!mig_table_exists('portfolio_items')) $run('upgrade_v4.sql');
    },
    'down' => function (): void { /* لا تراجع: لا نحذف بنية إصدارات سابقة تعتمد عليها البيانات */ },
];
