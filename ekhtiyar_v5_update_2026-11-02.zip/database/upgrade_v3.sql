-- =====================================================================
-- ترقية قاعدة البيانات من الإصدار 2 إلى الإصدار 3 (بنرات العروض المصممة)
-- نفّذ هذا الملف مرة واحدة فقط من phpMyAdmin بعد رفع ملفات الإصدار 3.
-- (إذا كان موقعك على الإصدار 1 نفّذ upgrade_v2.sql أولًا ثم هذا الملف)
-- =====================================================================
SET NAMES utf8mb4;

ALTER TABLE banners
  MODIFY image VARCHAR(255) NULL,
  ADD COLUMN badge_text VARCHAR(40) NULL AFTER image,
  ADD COLUMN theme VARCHAR(20) NOT NULL DEFAULT 'navy' AFTER badge_text,
  ADD COLUMN icon VARCHAR(60) NULL AFTER theme;

INSERT IGNORE INTO site_settings (setting_key, setting_value, setting_group, label, input_type, sort_order) VALUES
('show_quick_picker', '1', 'home', 'إظهار قسم «ماذا تحتاج اليوم؟» في الرئيسية', 'bool', 300),
('quick_picker_title', 'ماذا تحتاج اليوم؟', 'home', 'عنوان قسم الاختيار السريع', 'text', 310);

UPDATE site_settings SET setting_value = '3' WHERE setting_key = 'db_version';
