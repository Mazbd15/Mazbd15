-- =====================================================================
-- ترقية قاعدة البيانات من الإصدار 3 إلى الإصدار 4
-- (معرض الأعمال السابقة + إعدادات تحكم شاملة + SEO)
-- نفّذ هذا الملف مرة واحدة فقط من phpMyAdmin بعد رفع ملفات الإصدار 4.
-- الترتيب للمواقع القديمة: upgrade_v2.sql ← upgrade_v3.sql ← upgrade_v4.sql
-- =====================================================================
SET NAMES utf8mb4;

ALTER TABLE site_settings
  MODIFY input_type ENUM('text','textarea','number','color','url','email','bool','image','select') NOT NULL DEFAULT 'text';

CREATE TABLE IF NOT EXISTS portfolio_items (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id      INT UNSIGNED NOT NULL,
  subcategory_id   INT UNSIGNED NULL,
  service_id       INT UNSIGNED NULL,
  title            VARCHAR(190) NOT NULL,
  slug             VARCHAR(220) NOT NULL,
  summary          VARCHAR(400) NULL,
  description      TEXT NULL,
  tools_text       VARCHAR(400) NULL COMMENT 'البرامج والأدوات مفصولة بفواصل',
  level_text       VARCHAR(120) NULL COMMENT 'مثل: مشروع تخرج، مقرر جامعي، شركة ناشئة',
  completed_at     DATE NULL,
  cover_image      VARCHAR(255) NULL,
  is_featured      TINYINT(1) NOT NULL DEFAULT 0,
  is_active        TINYINT(1) NOT NULL DEFAULT 1,
  sort_order       INT NOT NULL DEFAULT 0,
  views            INT UNSIGNED NOT NULL DEFAULT 0,
  meta_title       VARCHAR(190) NULL,
  meta_description VARCHAR(300) NULL,
  created_by       INT UNSIGNED NULL,
  updated_by       INT UNSIGNED NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_portfolio_slug (slug),
  KEY idx_pf_cat (category_id, is_active, sort_order),
  KEY idx_pf_service (service_id),
  KEY idx_pf_featured (is_active, is_featured),
  CONSTRAINT fk_pf_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_pf_sub FOREIGN KEY (subcategory_id) REFERENCES subcategories (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_pf_service FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_pf_creator FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_pf_updater FOREIGN KEY (updated_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- صور العمل (عامة) وملفاته (PDF/Word/PowerPoint... تُحفظ خارج المجلد العام وتُخدم عبر سكربت آمن)
CREATE TABLE IF NOT EXISTS portfolio_files (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  item_id        INT UNSIGNED NOT NULL,
  kind           ENUM('image','document') NOT NULL DEFAULT 'image',
  file_path      VARCHAR(255) NOT NULL COMMENT 'صورة: مسار عام | ملف: اسم مخزن عشوائي',
  original_name  VARCHAR(200) NULL,
  file_size      INT UNSIGNED NULL,
  caption        VARCHAR(255) NULL,
  is_downloadable TINYINT(1) NOT NULL DEFAULT 1,
  downloads      INT UNSIGNED NOT NULL DEFAULT 0,
  sort_order     INT NOT NULL DEFAULT 0,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pff_item (item_id, kind, sort_order),
  CONSTRAINT fk_pff_item FOREIGN KEY (item_id) REFERENCES portfolio_items (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO site_settings (setting_key, setting_value, setting_group, label, input_type, sort_order) VALUES
('default_theme','auto','theme','الوضع الافتراضي للزائر','select',1000),
('allow_dark_toggle','1','theme','إظهار زر تبديل الوضع الداكن','bool',1010),
('font_family','Cairo','theme','خط الموقع','select',1020),
('favicon_path','','theme','أيقونة المتصفح Favicon (مربعة 512×512)','image',1030),
('social_linkedin','','contact','رابط LinkedIn','url',1040),
('social_youtube','','contact','رابط YouTube','url',1050),
('social_facebook','','contact','رابط Facebook','url',1060),
('business_city','المملكة العربية السعودية','contact','المدينة / الدولة (تظهر لمحركات البحث)','text',1070),
('seo_home_title','','seo','عنوان الصفحة الرئيسية في نتائج البحث (اتركه فارغًا للافتراضي)','text',1080),
('seo_keywords','خدمات طلابية, بحوث تخرج, مشاريع تخرج هندسية, أوتوكاد, برمجة مشاريع, تصميم عروض, سيرة ذاتية, ترجمة, SPSS','seo','الكلمات المفتاحية الأساسية (مفصولة بفواصل)','textarea',1090),
('og_image_path','','seo','صورة المشاركة الافتراضية (1200×630) عند مشاركة الروابط','image',1100),
('google_verification','','seo','رمز تحقق Google Search Console (content فقط)','text',1110),
('bing_verification','','seo','رمز تحقق Bing Webmaster (content فقط)','text',1120),
('ga4_id','','seo','معرّف Google Analytics 4 (مثل G-XXXXXXX) — اختياري','text',1130),
('area_served','SA','seo','نطاق تقديم الخدمة لمحركات البحث (رمز الدولة مثل SA أو اتركه)','text',1140),
('seo_auto_descriptions','1','seo','توليد أوصاف تلقائية غنية بالكلمات للصفحات التي بلا وصف SEO','bool',1150),
('site_noindex','0','seo','منع الأرشفة مؤقتًا (للتجربة قبل الإطلاق فقط)','bool',1160),
('show_home_banners','1','sections','سلايدر العروض في الواجهة','bool',1170),
('show_home_stats','1','sections','أرقام المنصة أسفل الواجهة','bool',1180),
('show_home_categories','1','sections','قسم «الخدمات الرئيسية»','bool',1190),
('show_home_portfolio','1','sections','قسم «من أعمالنا» (يظهر عند وجود أعمال)','bool',1200),
('show_home_why','1','sections','قسم «لماذا تختارنا»','bool',1210),
('show_home_steps','1','sections','قسم «خطوات الطلب»','bool',1220),
('show_home_audience','1','sections','قسم «لمن هذه المنصة»','bool',1230),
('show_home_popular','1','sections','قسم «الأكثر طلبًا»','bool',1240),
('show_home_faq','1','sections','قسم «الأسئلة الشائعة»','bool',1250),
('show_home_cta','1','sections','دعوة الإجراء أسفل الصفحة','bool',1260),
('show_trust_strip','1','sections','شريط الثقة أعلى التذييل','bool',1270),
('show_bottom_nav','1','sections','شريط التنقل السفلي في الجوال','bool',1280),
('show_wa_float','1','sections','زر واتساب العائم','bool',1290),
('hero_tags','بحوث التخرج, AutoCAD, SPSS, PowerPoint, سيرة ذاتية, PHP','sections','كلمات «الأكثر بحثًا» في الواجهة (مفصولة بفواصل)','text',1300),
('header_cta_text','اطلب خدمتك','sections','نص زر الطلب في الهيدر','text',1310),
('portfolio_enabled','1','portfolio','تفعيل معرض الأعمال في الموقع','bool',1320),
('portfolio_title','من أعمالنا السابقة','portfolio','عنوان قسم الأعمال','text',1330),
('portfolio_subtitle','نماذج حقيقية من أعمال نفذها فريقنا — تعرّف على مستوى الجودة قبل أن تطلب.','portfolio','وصف قسم الأعمال','textarea',1340),
('portfolio_disclaimer','تُعرض الأعمال بموافقة أصحابها بعد إخفاء أي بيانات شخصية، وهي للاطلاع على مستوى الجودة فقط ولا يجوز تقديمها كعمل خاص.','portfolio','تنبيه أسفل كل عمل','textarea',1350),
('portfolio_allow_downloads','1','portfolio','السماح للزوار بتنزيل ملفات الأعمال (PDF وغيرها) المعلّمة كقابلة للتنزيل','bool',1360),
('portfolio_per_page','12','portfolio','عدد الأعمال في الصفحة','number',1370);

UPDATE site_settings SET setting_value = '4' WHERE setting_key = 'db_version';
