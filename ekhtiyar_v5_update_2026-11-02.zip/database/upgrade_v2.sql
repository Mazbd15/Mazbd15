-- =====================================================================
--  ترقية قاعدة البيانات من الإصدار 1 إلى الإصدار 2 (بدون حذف أي بيانات)
--  الإضافات: حسابات المتخصصين والزوار، موافقة الإدارة، نطاق الأقسام،
--  الصور الإعلانية، رسائل متابعة الطلبات، الإشعارات، إعدادات جديدة.
--  الاستخدام: phpMyAdmin ← استيراد هذا الملف (مرة واحدة فقط)،
--  أو تلقائيًا عبر صفحة لوحة التحكم ← «ترقية قاعدة البيانات».
-- =====================================================================
SET NAMES utf8mb4;

ALTER TABLE users
  MODIFY role ENUM('super_admin','admin','editor','specialist','member') NOT NULL DEFAULT 'member',
  ADD COLUMN status ENUM('active','pending','rejected','suspended') NOT NULL DEFAULT 'active' AFTER role,
  ADD COLUMN phone VARCHAR(30) NULL AFTER status,
  ADD COLUMN specialization VARCHAR(190) NULL AFTER phone,
  ADD COLUMN bio TEXT NULL AFTER specialization,
  ADD COLUMN review_note VARCHAR(500) NULL AFTER bio,
  ADD COLUMN approved_by INT UNSIGNED NULL AFTER review_note,
  ADD COLUMN approved_at DATETIME NULL AFTER approved_by;

UPDATE users SET status = IF(is_active = 1, 'active', 'suspended');
ALTER TABLE users DROP COLUMN is_active, ADD KEY idx_users_role_status (role, status);

ALTER TABLE requests
  ADD COLUMN member_id INT UNSIGNED NULL AFTER notes,
  ADD COLUMN assigned_to INT UNSIGNED NULL AFTER member_id,
  ADD KEY idx_requests_member (member_id, created_at),
  ADD KEY idx_requests_assigned (assigned_to, status),
  ADD CONSTRAINT fk_req_member FOREIGN KEY (member_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT fk_req_assigned FOREIGN KEY (assigned_to) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE IF NOT EXISTS user_categories (
  user_id      INT UNSIGNED NOT NULL,
  category_id  INT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, category_id),
  KEY idx_uc_category (category_id),
  CONSTRAINT fk_uc_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_uc_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS banners (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id  INT UNSIGNED NULL,
  title        VARCHAR(160) NOT NULL,
  subtitle     VARCHAR(300) NULL,
  image        VARCHAR(255) NOT NULL,
  link_url     VARCHAR(500) NULL,
  button_text  VARCHAR(60) NULL,
  starts_at    DATE NULL,
  ends_at      DATE NULL,
  is_active    TINYINT(1) NOT NULL DEFAULT 1,
  sort_order   INT NOT NULL DEFAULT 0,
  clicks       INT UNSIGNED NOT NULL DEFAULT 0,
  created_by   INT UNSIGNED NULL,
  updated_by   INT UNSIGNED NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_banners_scope (category_id, is_active, sort_order),
  CONSTRAINT fk_banner_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_banner_creator FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_banner_updater FOREIGN KEY (updated_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS request_notes (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id   INT UNSIGNED NOT NULL,
  user_id      INT UNSIGNED NULL,
  body         TEXT NOT NULL,
  is_internal  TINYINT(1) NOT NULL DEFAULT 1,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_rn_request (request_id, created_at),
  CONSTRAINT fk_rn_request FOREIGN KEY (request_id) REFERENCES requests (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_rn_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  title       VARCHAR(190) NOT NULL,
  body        VARCHAR(500) NULL,
  link        VARCHAR(300) NULL,
  read_at     DATETIME NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notif_user (user_id, read_at, created_at),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO site_settings (setting_key, setting_value, setting_group, label, input_type, sort_order) VALUES
('allow_member_signup', '1', 'general', 'السماح للزوار بإنشاء حسابات (اختياري للزائر)', 'bool', 60),
('allow_specialist_signup', '1', 'general', 'السماح بطلبات انضمام المتخصصين (تتطلب موافقة الإدارة)', 'bool', 61),
('maintenance_mode', '0', 'general', 'وضع الصيانة (يُغلق الموقع للزوار ويبقى متاحًا للإدارة)', 'bool', 62),
('maintenance_message', 'نقوم حاليًا بأعمال تطوير وتحسين، وسنعود قريبًا. يمكنك التواصل معنا عبر واتساب.', 'general', 'رسالة وضع الصيانة', 'textarea', 63),
('announcement_text', '', 'home', 'شريط الإعلان أعلى الموقع (اتركه فارغًا لإخفائه)', 'text', 5),
('announcement_link', '', 'home', 'رابط شريط الإعلان (اختياري)', 'url', 6),
('db_version', '2', 'system', 'إصدار قاعدة البيانات', 'text', 1);
UPDATE site_settings SET setting_value = '2' WHERE setting_key = 'db_version';
