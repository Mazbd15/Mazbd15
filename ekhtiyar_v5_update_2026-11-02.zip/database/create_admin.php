<?php
/**
 * إنشاء حساب مسؤول بشكل آمن من سطر الأوامر (موصى به).
 *
 * الاستخدام التفاعلي:
 *   php database/create_admin.php
 *
 * أو بالمعاملات (كلمة المرور تُطلب بشكل مخفي إن لم تُمرر):
 *   php database/create_admin.php --email=admin@example.com --name="المدير العام" --role=super_admin
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }

$GLOBALS['CONFIG'] = require dirname(__DIR__) . '/config/config.php';
require dirname(__DIR__) . '/includes/helpers.php';
require dirname(__DIR__) . '/includes/db.php';
require dirname(__DIR__) . '/includes/security.php';

$opts = getopt('', ['email::', 'name::', 'role::', 'password::']);

function ask(string $label, bool $hidden = false): string
{
    echo $label;
    if ($hidden && DIRECTORY_SEPARATOR === '/' && function_exists('shell_exec')) {
        shell_exec('stty -echo');
        $v = trim((string) fgets(STDIN));
        shell_exec('stty echo');
        echo PHP_EOL;
        return $v;
    }
    return trim((string) fgets(STDIN));
}

$email = mb_strtolower(trim((string) ($opts['email'] ?? ask('البريد الإلكتروني: '))));
$name  = trim((string) ($opts['name'] ?? ask('الاسم: '))) ?: 'المدير العام';
$role  = (string) ($opts['role'] ?? 'super_admin');
$pass  = (string) ($opts['password'] ?? ask('كلمة المرور (10 أحرف على الأقل، حروف وأرقام): ', true));

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { fwrite(STDERR, "✗ بريد إلكتروني غير صالح\n"); exit(1); }
if (!isset(role_labels()[$role])) { fwrite(STDERR, "✗ الدور يجب أن يكون: super_admin أو admin أو editor\n"); exit(1); }
if ($err = password_problems($pass)) { fwrite(STDERR, "✗ $err\n"); exit(1); }
if (!isset($opts['password'])) {
    $confirm = ask('تأكيد كلمة المرور: ', true);
    if (!hash_equals($pass, $confirm)) { fwrite(STDERR, "✗ كلمتا المرور غير متطابقتين\n"); exit(1); }
}

$existing = db_one('SELECT id FROM users WHERE email = ?', [$email]);
if ($existing) {
    db_exec("UPDATE users SET name = ?, password_hash = ?, role = ?, status = 'active' WHERE id = ?", [$name, password_hash($pass, PASSWORD_DEFAULT), $role, $existing['id']]);
    echo "✓ تم تحديث الحساب الموجود ($email)\n";
} else {
    db_insert('users', ['name' => $name, 'email' => $email, 'password_hash' => password_hash($pass, PASSWORD_DEFAULT), 'role' => $role]);
    echo "✓ تم إنشاء حساب المسؤول ($email) بدور " . role_labels()[$role] . "\n";
}
