-- =====================================================================
--  اختيارك للخدمات الطلابية — بنية قاعدة البيانات
--  MySQL 5.7+ / MariaDB 10.3+  —  الترميز: utf8mb4
-- =====================================================================
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS schema_migrations;
DROP TABLE IF EXISTS message_replies;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS testimonials;
DROP TABLE IF EXISTS request_status_log;
DROP TABLE IF EXISTS posts;
DROP TABLE IF EXISTS backups_log;
DROP TABLE IF EXISTS portfolio_files;
DROP TABLE IF EXISTS portfolio_items;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS request_notes;
DROP TABLE IF EXISTS banners;
DROP TABLE IF EXISTS user_categories;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS login_attempts;
DROP TABLE IF EXISTS request_attachments;
DROP TABLE IF EXISTS requests;
DROP TABLE IF EXISTS faqs;
DROP TABLE IF EXISTS service_files;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS subcategories;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS site_settings;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- الحسابات: الإدارة + المتخصصون (بموافقة الإدارة) + الزوار (تسجيل اختياري)
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name           VARCHAR(120) NOT NULL,
  email          VARCHAR(190) NOT NULL,
  password_hash  VARCHAR(255) NOT NULL,
  role           ENUM('super_admin','admin','editor','specialist','member') NOT NULL DEFAULT 'member',
  status         ENUM('active','pending','rejected','suspended') NOT NULL DEFAULT 'active',
  phone          VARCHAR(30) NULL,
  specialization VARCHAR(190) NULL COMMENT 'التخصص المهني للمتخصص أو الجامعي للعضو',
  bio            TEXT NULL,
  review_note    VARCHAR(500) NULL COMMENT 'ملاحظة الإدارة عند الرفض/الإيقاف',
  approved_by    INT UNSIGNED NULL,
  approved_at    DATETIME NULL,
  last_login_at  DATETIME NULL,
  last_login_ip  VARCHAR(45) NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role_status (role, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- محاولات تسجيل الدخول (للحد من محاولات التخمين)
CREATE TABLE login_attempts (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  ip_address    VARCHAR(45) NOT NULL,
  email         VARCHAR(190) NULL,
  success       TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_attempts_ip_time (ip_address, attempted_at),
  KEY idx_attempts_email_time (email, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- الأقسام الرئيسية
-- ---------------------------------------------------------------------
CREATE TABLE categories (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name               VARCHAR(160) NOT NULL,
  slug               VARCHAR(190) NOT NULL,
  icon               VARCHAR(80)  NOT NULL DEFAULT 'bi-grid',
  short_description  VARCHAR(300) NULL,
  description        TEXT NULL,
  notice             TEXT NULL COMMENT 'تنبيه يظهر في صفحة القسم وخدماته',
  image              VARCHAR(255) NULL,
  is_featured        TINYINT(1) NOT NULL DEFAULT 0,
  is_active          TINYINT(1) NOT NULL DEFAULT 1,
  sort_order         INT NOT NULL DEFAULT 0,
  meta_title         VARCHAR(190) NULL,
  meta_description   VARCHAR(300) NULL,
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categories_slug (slug),
  KEY idx_categories_active_sort (is_active, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- الأقسام الفرعية (التخصصات)
-- ---------------------------------------------------------------------
CREATE TABLE subcategories (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id   INT UNSIGNED NOT NULL,
  name          VARCHAR(160) NOT NULL,
  slug          VARCHAR(190) NOT NULL,
  icon          VARCHAR(80)  NOT NULL DEFAULT 'bi-folder2-open',
  description   TEXT NULL,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  sort_order    INT NOT NULL DEFAULT 0,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sub_cat_slug (category_id, slug),
  KEY idx_sub_active_sort (category_id, is_active, sort_order),
  CONSTRAINT fk_sub_category FOREIGN KEY (category_id)
    REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- الخدمات
-- ---------------------------------------------------------------------
CREATE TABLE services (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id        INT UNSIGNED NOT NULL,
  subcategory_id     INT UNSIGNED NULL,
  name               VARCHAR(200) NOT NULL,
  slug               VARCHAR(220) NOT NULL,
  icon               VARCHAR(80)  NULL,
  short_description  VARCHAR(400) NULL,
  description        TEXT NULL,
  includes_text      TEXT NULL COMMENT 'ماذا تشمل الخدمة — سطر لكل بند',
  requirements_text  TEXT NULL COMMENT 'المتطلبات من العميل — سطر لكل بند',
  tools_text         TEXT NULL COMMENT 'البرامج/الملفات المطلوبة — سطر لكل بند',
  duration_text      VARCHAR(160) NULL,
  price_text         VARCHAR(160) NULL COMMENT 'فارغ = يحدد بعد مراجعة المتطلبات',
  keywords           VARCHAR(500) NULL COMMENT 'كلمات بحث بديلة مفصولة بفواصل',
  image              VARCHAR(255) NULL,
  service_type       ENUM('task','consultation','subscription','training','guidance') NOT NULL DEFAULT 'task',
  is_featured        TINYINT(1) NOT NULL DEFAULT 0,
  is_popular         TINYINT(1) NOT NULL DEFAULT 0,
  is_active          TINYINT(1) NOT NULL DEFAULT 1,
  sort_order         INT NOT NULL DEFAULT 0,
  views              INT UNSIGNED NOT NULL DEFAULT 0,
  meta_title         VARCHAR(190) NULL,
  meta_description   VARCHAR(300) NULL,
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_services_slug (slug),
  KEY idx_services_cat (category_id, is_active, sort_order),
  KEY idx_services_sub (subcategory_id, is_active, sort_order),
  KEY idx_services_flags (is_active, is_popular, is_featured),
  CONSTRAINT fk_services_category FOREIGN KEY (category_id)
    REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_services_subcategory FOREIGN KEY (subcategory_id)
    REFERENCES subcategories (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- صور وملفات الخدمة (معرض)
CREATE TABLE service_files (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  service_id  INT UNSIGNED NOT NULL,
  file_path   VARCHAR(255) NOT NULL,
  file_type   ENUM('image','icon','document') NOT NULL DEFAULT 'image',
  alt_text    VARCHAR(255) NULL,
  sort_order  INT NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_sf_service (service_id, sort_order),
  CONSTRAINT fk_sf_service FOREIGN KEY (service_id)
    REFERENCES services (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- الأسئلة الشائعة (عامة / لقسم / لخدمة)
-- ---------------------------------------------------------------------
CREATE TABLE faqs (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id  INT UNSIGNED NULL,
  service_id   INT UNSIGNED NULL,
  question     VARCHAR(400) NOT NULL,
  answer       TEXT NOT NULL,
  show_on_home TINYINT(1) NOT NULL DEFAULT 0,
  is_active    TINYINT(1) NOT NULL DEFAULT 1,
  sort_order   INT NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_faqs_scope (category_id, service_id, is_active, sort_order),
  KEY idx_faqs_home (show_on_home, is_active),
  CONSTRAINT fk_faqs_category FOREIGN KEY (category_id)
    REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_faqs_service FOREIGN KEY (service_id)
    REFERENCES services (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- الطلبات (تحفظ فقط عند تفعيل الحفظ + موافقة العميل الصريحة)
-- ---------------------------------------------------------------------
CREATE TABLE requests (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  reference_code   VARCHAR(20) NOT NULL,
  customer_name    VARCHAR(120) NOT NULL,
  contact_method   ENUM('whatsapp','phone','email','telegram','other') NOT NULL DEFAULT 'whatsapp',
  contact_value    VARCHAR(190) NOT NULL,
  email            VARCHAR(190) NULL,
  category_id      INT UNSIGNED NULL,
  subcategory_id   INT UNSIGNED NULL,
  service_id       INT UNSIGNED NULL,
  service_label    VARCHAR(220) NULL COMMENT 'نسخة نصية لاسم الخدمة وقت الطلب',
  specialization   VARCHAR(190) NULL,
  description      TEXT NOT NULL,
  deadline         DATE NULL,
  software         VARCHAR(190) NULL,
  notes            TEXT NULL,
  member_id        INT UNSIGNED NULL COMMENT 'حساب الزائر إن كان مسجلًا',
  assigned_to      INT UNSIGNED NULL COMMENT 'المتخصص المسؤول عن الطلب',
  status           ENUM('new','reviewing','awaiting_client','completed','cancelled') NOT NULL DEFAULT 'new',
  admin_notes      TEXT NULL,
  consent_storage  TINYINT(1) NOT NULL DEFAULT 0,
  ip_hash          CHAR(64) NULL COMMENT 'بصمة مُجزأة للـ IP وليس العنوان نفسه',
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_requests_ref (reference_code),
  KEY idx_requests_status_date (status, created_at),
  KEY idx_requests_category (category_id, created_at),
  KEY idx_requests_iphash (ip_hash, created_at),
  KEY idx_requests_member (member_id, created_at),
  KEY idx_requests_assigned (assigned_to, status),
  CONSTRAINT fk_req_member FOREIGN KEY (member_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_req_assigned FOREIGN KEY (assigned_to)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_req_category FOREIGN KEY (category_id)
    REFERENCES categories (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_req_subcategory FOREIGN KEY (subcategory_id)
    REFERENCES subcategories (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_req_service FOREIGN KEY (service_id)
    REFERENCES services (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE request_attachments (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id     INT UNSIGNED NOT NULL,
  original_name  VARCHAR(255) NOT NULL,
  stored_name    VARCHAR(100) NOT NULL,
  mime_type      VARCHAR(120) NOT NULL,
  file_size      INT UNSIGNED NOT NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_att_stored (stored_name),
  KEY idx_att_request (request_id),
  CONSTRAINT fk_att_request FOREIGN KEY (request_id)
    REFERENCES requests (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- إعدادات الموقع (مفتاح/قيمة)
-- ---------------------------------------------------------------------
CREATE TABLE site_settings (
  setting_key    VARCHAR(100) NOT NULL,
  setting_value  TEXT NULL,
  setting_group  VARCHAR(50) NOT NULL DEFAULT 'general',
  label          VARCHAR(190) NULL,
  input_type     ENUM('text','textarea','number','color','url','email','bool','image','select') NOT NULL DEFAULT 'text',
  sort_order     INT NOT NULL DEFAULT 0,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key),
  KEY idx_settings_group (setting_group, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- سجل العمليات الإدارية
-- ---------------------------------------------------------------------
CREATE TABLE audit_logs (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id      INT UNSIGNED NULL,
  action       VARCHAR(60)  NOT NULL,
  entity_type  VARCHAR(60)  NULL,
  entity_id    INT UNSIGNED NULL,
  details      TEXT NULL,
  ip_address   VARCHAR(45) NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_user (user_id, created_at),
  KEY idx_audit_entity (entity_type, entity_id),
  KEY idx_audit_date (created_at),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id)
    REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- نطاق عمل المتخصص: الأقسام المسموح له بإدارتها
-- ---------------------------------------------------------------------
CREATE TABLE user_categories (
  user_id      INT UNSIGNED NOT NULL,
  category_id  INT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, category_id),
  KEY idx_uc_category (category_id),
  CONSTRAINT fk_uc_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_uc_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- الصور الإعلانية (بنرات) — لكل قسم أو للصفحة الرئيسية (category_id = NULL)
-- ---------------------------------------------------------------------
CREATE TABLE banners (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id  INT UNSIGNED NULL,
  title        VARCHAR(160) NOT NULL,
  subtitle     VARCHAR(300) NULL,
  image        VARCHAR(255) NULL,
  badge_text   VARCHAR(40) NULL,
  theme        VARCHAR(20) NOT NULL DEFAULT 'navy',
  icon         VARCHAR(60) NULL,
  link_url     VARCHAR(500) NULL,
  button_text  VARCHAR(60) NULL,
  starts_at    DATE NULL,
  ends_at      DATE NULL,
  is_active    TINYINT(1) NOT NULL DEFAULT 1,
  sort_order   INT NOT NULL DEFAULT 0,
  clicks       INT UNSIGNED NOT NULL DEFAULT 0,
  created_by   INT UNSIGNED NULL,
  updated_by   INT UNSIGNED NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_banners_scope (category_id, is_active, sort_order),
  CONSTRAINT fk_banner_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_banner_creator FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_banner_updater FOREIGN KEY (updated_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- رسائل متابعة الطلب (داخلية للفريق أو ظاهرة للعميل في حسابه)
-- ---------------------------------------------------------------------
CREATE TABLE request_notes (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id   INT UNSIGNED NOT NULL,
  user_id      INT UNSIGNED NULL,
  body         TEXT NOT NULL,
  is_internal  TINYINT(1) NOT NULL DEFAULT 1,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_rn_request (request_id, created_at),
  CONSTRAINT fk_rn_request FOREIGN KEY (request_id) REFERENCES requests (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_rn_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- الإشعارات داخل الموقع
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  title       VARCHAR(190) NOT NULL,
  body        VARCHAR(500) NULL,
  link        VARCHAR(300) NULL,
  read_at     DATETIME NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notif_user (user_id, read_at, created_at),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- معرض الأعمال السابقة (v4) — لكل قسم/تخصص/خدمة
-- ---------------------------------------------------------------------
CREATE TABLE portfolio_items (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_id      INT UNSIGNED NOT NULL,
  subcategory_id   INT UNSIGNED NULL,
  service_id       INT UNSIGNED NULL,
  title            VARCHAR(190) NOT NULL,
  slug             VARCHAR(220) NOT NULL,
  summary          VARCHAR(400) NULL,
  description      TEXT NULL,
  tools_text       VARCHAR(400) NULL COMMENT 'البرامج والأدوات مفصولة بفواصل',
  level_text       VARCHAR(120) NULL COMMENT 'مثل: مشروع تخرج، مقرر جامعي، شركة ناشئة',
  completed_at     DATE NULL,
  cover_image      VARCHAR(255) NULL,
  is_featured      TINYINT(1) NOT NULL DEFAULT 0,
  is_active        TINYINT(1) NOT NULL DEFAULT 1,
  sort_order       INT NOT NULL DEFAULT 0,
  views            INT UNSIGNED NOT NULL DEFAULT 0,
  meta_title       VARCHAR(190) NULL,
  meta_description VARCHAR(300) NULL,
  created_by       INT UNSIGNED NULL,
  updated_by       INT UNSIGNED NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_portfolio_slug (slug),
  KEY idx_pf_cat (category_id, is_active, sort_order),
  KEY idx_pf_service (service_id),
  KEY idx_pf_featured (is_active, is_featured),
  CONSTRAINT fk_pf_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_pf_sub FOREIGN KEY (subcategory_id) REFERENCES subcategories (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_pf_service FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_pf_creator FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_pf_updater FOREIGN KEY (updated_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- صور العمل (عامة) وملفاته (PDF/Word/PowerPoint... تُحفظ خارج المجلد العام وتُخدم عبر سكربت آمن)
CREATE TABLE portfolio_files (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  item_id        INT UNSIGNED NOT NULL,
  kind           ENUM('image','document') NOT NULL DEFAULT 'image',
  file_path      VARCHAR(255) NOT NULL COMMENT 'صورة: مسار عام | ملف: اسم مخزن عشوائي',
  original_name  VARCHAR(200) NULL,
  file_size      INT UNSIGNED NULL,
  caption        VARCHAR(255) NULL,
  is_downloadable TINYINT(1) NOT NULL DEFAULT 1,
  downloads      INT UNSIGNED NOT NULL DEFAULT 0,
  sort_order     INT NOT NULL DEFAULT 0,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pff_item (item_id, kind, sort_order),
  CONSTRAINT fk_pff_item FOREIGN KEY (item_id) REFERENCES portfolio_items (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
