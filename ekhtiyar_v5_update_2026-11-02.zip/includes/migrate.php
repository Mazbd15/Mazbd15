<?php
/**
 * نظام ترقيات قاعدة البيانات الآمن (v5)
 * - كل ترقية ملف PHP في database/migrations يعيد ['title'=>..., 'up'=>callable, 'down'=>callable].
 * - الخطوات «إضافية» فقط: إنشاء جداول/أعمدة إن لم توجد، ولا تحذف أي بيانات.
 * - تُسجّل في جدول schema_migrations، وتُنشأ نسخة احتياطية تلقائيًا قبل التشغيل (من لوحة التحكم).
 * - متوافقة مع MySQL 5.7+/8 وMariaDB (لا تعتمد على ADD COLUMN IF NOT EXISTS).
 */
declare(strict_types=1);

function mig_table_exists(string $t): bool
{
    return (bool) db_value('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?', [$t]);
}

function mig_column_exists(string $t, string $c): bool
{
    return (bool) db_value('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?', [$t, $c]);
}

function mig_index_exists(string $t, string $i): bool
{
    return (bool) db_value('SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = ? AND index_name = ?', [$t, $i]);
}

function mig_fk_exists(string $t, string $fk): bool
{
    return (bool) db_value("SELECT COUNT(*) FROM information_schema.table_constraints WHERE table_schema = DATABASE() AND table_name = ? AND constraint_name = ? AND constraint_type = 'FOREIGN KEY'", [$t, $fk]);
}

function mig_add_column(string $t, string $c, string $def): void
{
    if (mig_table_exists($t) && !mig_column_exists($t, $c)) db()->exec("ALTER TABLE `$t` ADD COLUMN `$c` $def");
}

function mig_drop_column(string $t, string $c): void
{
    if (mig_table_exists($t) && mig_column_exists($t, $c)) db()->exec("ALTER TABLE `$t` DROP COLUMN `$c`");
}

function mig_add_index(string $t, string $i, string $cols): void
{
    if (mig_table_exists($t) && !mig_index_exists($t, $i)) db()->exec("ALTER TABLE `$t` ADD KEY `$i` ($cols)");
}

function mig_setting(string $k, string $v, string $g, string $label, string $type = 'text', int $sort = 0): void
{
    db_exec('INSERT IGNORE INTO site_settings (setting_key, setting_value, setting_group, label, input_type, sort_order) VALUES (?,?,?,?,?,?)', [$k, $v, $g, $label, $type, $sort]);
}

function migrations_dir(): string
{
    return ROOT_PATH . '/database/migrations';
}

function migrations_ensure_table(): void
{
    db()->exec('CREATE TABLE IF NOT EXISTS schema_migrations (
        migration VARCHAR(120) NOT NULL, title VARCHAR(255) NULL, batch INT NOT NULL DEFAULT 1,
        applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (migration)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci');
}

/** @return array<string,array> الاسم => تعريف الترقية */
function migrations_all(): array
{
    $out = [];
    foreach (glob(migrations_dir() . '/*.php') ?: [] as $f) {
        $def = require $f;
        if (is_array($def) && isset($def['up'])) $out[basename($f, '.php')] = $def;
    }
    ksort($out);
    return $out;
}

function migrations_applied(): array
{
    try { migrations_ensure_table(); } catch (Throwable $e) { return []; }
    return array_column(db_all('SELECT * FROM schema_migrations ORDER BY migration'), null, 'migration');
}

function migrations_pending(): array
{
    $applied = migrations_applied();
    return array_diff_key(migrations_all(), $applied);
}

/** تشغيل الترقيات المعلّقة — يعيد سجلًا نصيًا */
function migrations_run(): array
{
    migrations_ensure_table();
    $log = [];
    $batch = (int) db_value('SELECT COALESCE(MAX(batch),0)+1 FROM schema_migrations');
    foreach (migrations_pending() as $name => $def) {
        try {
            ($def['up'])();
            db_exec('INSERT INTO schema_migrations (migration, title, batch) VALUES (?,?,?)', [$name, $def['title'] ?? $name, $batch]);
            $log[] = ['ok', $name, $def['title'] ?? ''];
        } catch (Throwable $e) {
            error_log('[migration] ' . $name . ': ' . $e->getMessage());
            $log[] = ['error', $name, $e->getMessage()];
            break; // نتوقف عند أول خطأ حتى لا تُطبق ترقيات تعتمد عليها
        }
    }
    return $log;
}

/** التراجع عن ترقية محددة (يُفترض أخذ نسخة احتياطية قبلها) */
function migration_rollback(string $name): array
{
    $all = migrations_all();
    if (!isset($all[$name]['down'])) return ['error', $name, 'لا يوجد مسار تراجع لهذه الترقية.'];
    try {
        ($all[$name]['down'])();
        db_exec('DELETE FROM schema_migrations WHERE migration = ?', [$name]);
        return ['ok', $name, 'تم التراجع.'];
    } catch (Throwable $e) {
        return ['error', $name, $e->getMessage()];
    }
}

/** هل بنية الإصدار 5 جاهزة؟ (لتجنب أخطاء الصفحات قبل تشغيل الترقية) */
function schema_v5(): bool
{
    static $ok = null;
    if ($ok !== null) return $ok;
    try { return $ok = (int) setting('db_version', '0') >= 5 && mig_table_exists('testimonials'); } catch (Throwable $e) { return $ok = false; }
}

/** هل يوجد العمود؟ (مع ذاكرة مؤقتة لكل طلب) */
function has_col(string $t, string $c): bool
{
    static $cache = [];
    $k = "$t.$c";
    if (!array_key_exists($k, $cache)) {
        try { $cache[$k] = mig_column_exists($t, $c); } catch (Throwable $e) { $cache[$k] = false; }
    }
    return $cache[$k];
}

/** شرط استبعاد العناصر المحذوفة (سلة المحذوفات) — فارغ قبل الترقية */
function sd(string $table, string $alias = ''): string
{
    return has_col($table, 'deleted_at') ? ' AND ' . ($alias !== '' ? $alias . '.' : '') . 'deleted_at IS NULL' : '';
}
