<?php
/**
 * النسخ الاحتياطي والاستعادة (v5)
 * - قاعدة البيانات: تصدير SQL كامل عبر PDO (لا يحتاج mysqldump — يعمل على الاستضافات المشتركة).
 * - الملفات: الصور العامة المرفوعة + ملفات storage/uploads (ZIP عبر ZipArchive، أو TAR عبر PharData).
 * - الحفظ في storage/backups (محمي بـ .htaccess وخارج المجلد العام) مع الاحتفاظ بعدد محدد.
 * - الاستعادة تنشئ نسخة «قبل الاستعادة» تلقائيًا أولًا.
 */
declare(strict_types=1);

function backup_dir(): string
{
    $d = ROOT_PATH . '/storage/backups';
    if (!is_dir($d)) @mkdir($d, 0750, true);
    if (!is_file($d . '/.htaccess')) @file_put_contents($d . '/.htaccess', "Require all denied\nDeny from all\n");
    if (!is_file($d . '/index.html')) @file_put_contents($d . '/index.html', '');
    return $d;
}

/** تصدير قاعدة البيانات إلى ملف SQL */
function backup_dump_db(string $file): void
{
    $pdo = db();
    $fh = fopen($file, 'wb');
    if (!$fh) throw new RuntimeException('تعذر إنشاء ملف النسخة.');
    fwrite($fh, "-- اختيارك — نسخة احتياطية لقاعدة البيانات\n-- " . date('c') . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\nSET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';\n\n");
    $tables = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type = 'BASE TABLE' ORDER BY table_name")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $t) {
        $create = $pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1];
        fwrite($fh, "DROP TABLE IF EXISTS `$t`;\n$create;\n\n");
        $st = $pdo->query("SELECT * FROM `$t`", PDO::FETCH_NUM);
        $batch = [];
        while ($row = $st->fetch(PDO::FETCH_NUM)) {
            $batch[] = '(' . implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string) $v), $row)) . ')';
            if (count($batch) >= 200) { fwrite($fh, "INSERT INTO `$t` VALUES\n" . implode(",\n", $batch) . ";\n"); $batch = []; }
        }
        if ($batch) fwrite($fh, "INSERT INTO `$t` VALUES\n" . implode(",\n", $batch) . ";\n");
        fwrite($fh, "\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS = 1;\n");
    fclose($fh);
}

/** المجلدات التي تشملها نسخة الملفات: [مسار مطلق، اسم داخل الأرشيف] */
function backup_file_roots(): array
{
    return [
        [PUBLIC_PATH . '/' . MEDIA_UPLOAD_BASE, 'public_uploads'],
        [ROOT_PATH . '/storage/uploads', 'storage_uploads'],
    ];
}

/**
 * إنشاء نسخة احتياطية. يعيد [ok, رسالة/اسم الملف].
 * @param string $kind manual|auto|pre-migration|pre-restore
 */
function backup_create(string $kind = 'manual', ?bool $withFiles = null): array
{
    @set_time_limit(300);
    $withFiles ??= setting('backup_include_files', '1') === '1';
    $dir = backup_dir();
    $stamp = date('Ymd-His') . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
    $sql = "$dir/db-$stamp.sql";
    try {
        backup_dump_db($sql);
        $useZip = class_exists('ZipArchive');
        $name = "backup-$kind-$stamp." . ($useZip ? 'zip' : 'tar');
        $path = "$dir/$name";
        if ($useZip) {
            $z = new ZipArchive();
            if ($z->open($path, ZipArchive::CREATE) !== true) throw new RuntimeException('تعذر إنشاء ملف ZIP.');
            $z->addFile($sql, 'database.sql');
            $z->addFromString('README.txt', "نسخة احتياطية لمنصة اختيارك\nالتاريخ: " . date('Y-m-d H:i') . "\nالنوع: $kind\nتشمل الملفات: " . ($withFiles ? 'نعم' : 'لا') . "\n");
            if ($withFiles) foreach (backup_file_roots() as [$root, $alias]) backup_add_dir_zip($z, $root, $alias);
            $z->close();
        } else {
            $tar = new PharData($path);
            $tar->addFile($sql, 'database.sql');
            if ($withFiles) foreach (backup_file_roots() as [$root, $alias]) {
                if (!is_dir($root)) continue;
                $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
                foreach ($it as $f) if ($f->isFile()) $tar->addFile($f->getPathname(), $alias . '/' . ltrim(str_replace('\\', '/', substr($f->getPathname(), strlen($root))), '/'));
            }
        }
        @unlink($sql);
        @chmod($path, 0640);
        backup_log('create', $name, (int) filesize($path), $kind, $withFiles);
        backup_prune();
        return [true, $name];
    } catch (Throwable $e) {
        @unlink($sql);
        error_log('[backup] ' . $e->getMessage());
        return [false, $e->getMessage()];
    }
}

function backup_add_dir_zip(ZipArchive $z, string $root, string $alias): void
{
    if (!is_dir($root)) return;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if (!$f->isFile()) continue;
        $rel = ltrim(str_replace('\\', '/', substr($f->getPathname(), strlen($root))), '/');
        if (str_starts_with($rel, 'thumbs/') || str_contains($rel, '/thumbs/')) continue; // المصغرات تُعاد توليدها
        $z->addFile($f->getPathname(), $alias . '/' . $rel);
    }
}

function backup_log(string $action, string $file, ?int $size, string $kind = 'manual', bool $files = true, ?string $note = null): void
{
    try {
        if (!mig_table_exists('backups_log')) return;
        db_insert('backups_log', ['action' => $action, 'file_name' => $file, 'file_size' => $size, 'kind' => in_array($kind, ['manual', 'auto', 'pre-migration', 'pre-restore'], true) ? $kind : 'manual',
            'includes_files' => $files ? 1 : 0, 'user_id' => $_SESSION['uid'] ?? null, 'note' => $note]);
    } catch (Throwable $e) {}
}

/** قائمة النسخ الموجودة (الأحدث أولًا) */
function backup_list(): array
{
    $out = [];
    foreach (glob(backup_dir() . '/backup-*.{zip,tar}', GLOB_BRACE) ?: [] as $f) {
        $out[] = ['name' => basename($f), 'size' => filesize($f), 'mtime' => filemtime($f), 'kind' => explode('-', basename($f))[1] ?? 'manual'];
    }
    usort($out, fn($a, $b) => $b['mtime'] <=> $a['mtime']);
    return $out;
}

function backup_path(string $name): ?string
{
    if (!preg_match('/^backup-[a-z\-]+-\d{8}-\d{6}-[a-f0-9]{6}\.(zip|tar)$/', $name)) return null;
    $p = backup_dir() . '/' . $name;
    return is_file($p) ? $p : null;
}

/** الاحتفاظ بآخر N نسخة (النسخ قبل الترقية/الاستعادة تُحسب ضمنها) */
function backup_prune(): void
{
    $keep = max(2, (int) setting('backup_keep', '10'));
    foreach (array_slice(backup_list(), $keep) as $b) {
        @unlink(backup_dir() . '/' . $b['name']);
        backup_log('delete', $b['name'], (int) $b['size'], 'auto', true, 'حذف تلقائي (تجاوز الحد)');
    }
}

function backup_last_time(): ?int
{
    $l = backup_list();
    return $l ? $l[0]['mtime'] : null;
}

/** نسخة تلقائية «مجدولة» تُنفّذ عند زيارة الإدارة إذا مضت المدة المحددة (لا تحتاج Cron) */
function backup_auto_maybe(): void
{
    $days = (int) setting('backup_auto_days', '7');
    if ($days <= 0) return;
    $last = 0;
    foreach (backup_list() as $b) if ($b['kind'] === 'auto') { $last = $b['mtime']; break; }
    if ($last && $last > time() - $days * 86400) return;
    $lock = backup_dir() . '/.auto.lock';
    if (is_file($lock) && filemtime($lock) > time() - 600) return; // منع التكرار المتزامن
    @touch($lock);
    backup_create('auto');
    @unlink($lock);
}

/**
 * استعادة نسخة: قاعدة البيانات (اختياري) والملفات (اختياري).
 * تُنشأ نسخة «قبل الاستعادة» أولًا. الملفات تُستخرج فقط داخل مجلدات الرفع المسموح بها.
 */
function backup_restore(string $name, bool $db = true, bool $files = true): array
{
    @set_time_limit(600);
    $path = backup_path($name);
    if (!$path) return [false, 'النسخة غير موجودة.'];
    [$ok, $pre] = backup_create('pre-restore');
    if (!$ok) return [false, 'تعذر إنشاء نسخة قبل الاستعادة: ' . $pre];
    $tmp = backup_dir() . '/restore-' . bin2hex(random_bytes(4));
    @mkdir($tmp, 0750, true);
    try {
        if (str_ends_with($name, '.zip')) {
            $z = new ZipArchive();
            if ($z->open($path) !== true) throw new RuntimeException('تعذر فتح ملف النسخة.');
            for ($i = 0; $i < $z->numFiles; $i++) {
                $entry = (string) $z->getNameIndex($i);
                if (!backup_entry_ok($entry)) continue;
                $dest = $tmp . '/' . $entry;
                if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0750, true);
                if (!str_ends_with($entry, '/')) file_put_contents($dest, $z->getFromIndex($i));
            }
            $z->close();
        } else {
            (new PharData($path))->extractTo($tmp, null, true);
        }
        $count = 0;
        if ($db) {
            $sqlFile = $tmp . '/database.sql';
            if (!is_file($sqlFile)) throw new RuntimeException('النسخة لا تحتوي قاعدة بيانات.');
            $pdo = db();
            foreach (sql_split((string) file_get_contents($sqlFile)) as $stmt) $pdo->exec($stmt);
        }
        if ($files) {
            foreach (backup_file_roots() as [$root, $alias]) {
                $src = $tmp . '/' . $alias;
                if (!is_dir($src)) continue;
                $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS));
                foreach ($it as $f) {
                    if (!$f->isFile()) continue;
                    $rel = ltrim(str_replace('\\', '/', substr($f->getPathname(), strlen($src))), '/');
                    if (str_contains($rel, '..') || preg_match('/\.(php\d?|phtml|phar|htaccess|cgi|pl|sh)$/i', $rel)) continue;
                    $dest = $root . '/' . $rel;
                    if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
                    if (@copy($f->getPathname(), $dest)) $count++;
                }
            }
        }
        backup_rmdir($tmp);
        if ($db && ($pp = backup_path($pre))) backup_log('create', $pre, (int) filesize($pp), 'pre-restore', true, 'أُعيد تسجيلها بعد استعادة قاعدة البيانات');
        backup_log('restore', $name, (int) filesize($path), 'manual', $files, 'قاعدة البيانات: ' . ($db ? 'نعم' : 'لا') . " — ملفات مستعادة: $count");
        return [true, 'تمت الاستعادة بنجاح' . ($files ? " ($count ملف)" : '') . ". نسخة ما قبل الاستعادة: $pre"];
    } catch (Throwable $e) {
        backup_rmdir($tmp);
        error_log('[restore] ' . $e->getMessage());
        return [false, 'فشلت الاستعادة: ' . $e->getMessage() . " — يمكنك الرجوع بالنسخة $pre"];
    }
}

function backup_entry_ok(string $e): bool
{
    if (str_contains($e, '..') || str_starts_with($e, '/') || str_contains($e, "\0")) return false;
    return $e === 'database.sql' || $e === 'README.txt' || str_starts_with($e, 'public_uploads/') || str_starts_with($e, 'storage_uploads/');
}

function backup_rmdir(string $dir): void
{
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
    @rmdir($dir);
}
