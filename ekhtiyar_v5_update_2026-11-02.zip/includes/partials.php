<?php
/** مكونات واجهة قابلة لإعادة الاستخدام */
declare(strict_types=1);

/** لون مميز لكل قسم لتسهيل التعرّف البصري */
function category_tone(?string $slug): string
{
    return [
        'academic' => 'sky', 'engineering' => 'gold', 'programming-it' => 'violet', 'design-media' => 'rose',
        'cv-career' => 'emerald', 'translation-docs' => 'sunset', 'training-consulting' => 'navy', 'official-guidance' => 'slate',
    ][$slug ?? ''] ?? 'navy';
}

/**
 * صورة القسم: المرفوعة من لوحة التحكم أولًا، ثم الصورة الافتراضية للقسم، وإلا null.
 * يتحقق من وجود الملف فعليًا حتى لا تظهر صورة مكسورة.
 */
function category_image(?array $c): ?string
{
    if (!$c) return null;
    $img = trim((string) ($c['image'] ?? ''));
    if ($img !== '' && !preg_match('~^(https?:)?//~i', $img)) {
        $img = ltrim($img, '/');
        if (str_starts_with($img, 'public/')) $img = substr($img, 7);
        if (is_file(PUBLIC_PATH . '/' . $img)) return $img;
    } elseif ($img !== '') {
        return $img; // رابط خارجي كامل
    }
    $slug = preg_replace('/[^a-z0-9\-]/', '', (string) ($c['slug'] ?? ''));
    foreach (['webp', 'jpg', 'png'] as $ext) {
        $def = 'assets/images/categories/' . $slug . '.' . $ext;
        if ($slug !== '' && is_file(PUBLIC_PATH . '/' . $def)) return $def;
    }
    return null;
}

function img_src(?string $path, bool $thumb = false): string
{
    return media_url($path, $thumb);
}

function render_service_card(array $s, bool $showCategory = true): string
{
    $url = route('service', ['slug' => $s['slug']]);
    $tone = category_tone($s['category_slug'] ?? null);
    $types = service_types();
    ob_start(); ?>
    <article class="service-card tone-<?= e($tone) ?> h-100">
      <div class="service-card-top">
        <span class="service-icon"><?= icon($s['icon'] ?: ($s['category_icon'] ?? 'bi-grid')) ?></span>
        <?php if (!empty($s['is_popular'])): ?><span class="badge-popular"><i class="bi bi-fire"></i> الأكثر طلبًا</span><?php endif; ?>
      </div>
      <?php if ($showCategory && !empty($s['subcategory_name'])): ?>
        <p class="service-meta"><?= e($s['subcategory_name']) ?></p>
      <?php endif; ?>
      <h3 class="service-title"><a href="<?= e($url) ?>" class="stretched-link-custom"><?= e($s['name']) ?></a></h3>
      <p class="service-excerpt"><?= e(excerpt($s['short_description'], 95)) ?></p>
      <?php if (!empty($s['duration_text']) || !empty($s['service_type'])): ?>
      <ul class="service-facts">
        <?php if (!empty($s['service_type']) && isset($types[$s['service_type']])): ?><li><i class="bi bi-bookmark"></i> <?= e($types[$s['service_type']]) ?></li><?php endif; ?>
        <?php if (!empty($s['duration_text'])): ?><li><i class="bi bi-clock"></i> <?= e(excerpt($s['duration_text'], 28)) ?></li><?php endif; ?>
      </ul>
      <?php endif; ?>
      <div class="service-card-foot">
        <span class="service-price"><i class="bi bi-tag"></i> <?= e($s['price_text'] ?: 'السعر بعد المراجعة') ?></span>
        <a class="service-more" href="<?= e($url) ?>" aria-label="تفاصيل <?= e($s['name']) ?>">التفاصيل <i class="bi bi-arrow-left-short"></i></a>
      </div>
    </article>
    <?php return (string) ob_get_clean();
}

function render_category_card(array $c): string
{
    ob_start(); ?>
    <?php $img = category_image($c); ?>
    <article class="category-card tone-<?= e(category_tone($c['slug'] ?? null)) ?><?= $img ? ' has-cover' : '' ?> h-100">
      <span class="category-glow" aria-hidden="true"></span>
      <?php if ($img): ?>
        <figure class="category-cover"><img src="<?= e(img_src($img)) ?>" alt="<?= e($c['name']) ?>" loading="lazy" width="800" height="450"></figure>
      <?php endif; ?>
      <span class="category-icon"><?= icon($c['icon']) ?></span>
      <h3 class="category-title"><a href="<?= e(route('category', ['slug' => $c['slug']])) ?>"><?= e($c['name']) ?></a></h3>
      <p class="category-desc"><?= e($c['short_description']) ?></p>
      <div class="category-stats">
        <span><i class="bi bi-diagram-3"></i> <?= (int) ($c['subs_count'] ?? 0) ?> تخصص</span>
        <span><i class="bi bi-grid-3x3-gap"></i> <?= (int) ($c['services_count'] ?? 0) ?> خدمة</span>
      </div>
      <?php if ($nw = (portfolio_counts_by_category()[(int) ($c['id'] ?? 0)] ?? 0)): ?><a class="category-works" href="<?= e(route('portfolio', ['category' => $c['slug']])) ?>"><i class="bi bi-collection"></i> <?= $nw ?> من أعمالنا</a><?php endif; ?>
      <a class="category-link" href="<?= e(route('category', ['slug' => $c['slug']])) ?>">استعرض القسم <i class="bi bi-arrow-left"></i></a>
    </article>
    <?php return (string) ob_get_clean();
}

function render_faq_accordion(array $faqs, string $id = 'faq'): string
{
    if (!$faqs) return '';
    ob_start(); ?>
    <div class="accordion faq-accordion" id="<?= e($id) ?>">
      <?php foreach ($faqs as $i => $f): ?>
        <div class="accordion-item">
          <h3 class="accordion-header">
            <button class="accordion-button<?= $i ? ' collapsed' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?= e($id) ?>-<?= (int) $f['id'] ?>" aria-expanded="<?= $i ? 'false' : 'true' ?>" aria-controls="<?= e($id) ?>-<?= (int) $f['id'] ?>">
              <?= e($f['question']) ?>
            </button>
          </h3>
          <div id="<?= e($id) ?>-<?= (int) $f['id'] ?>" class="accordion-collapse collapse<?= $i ? '' : ' show' ?>" data-bs-parent="#<?= e($id) ?>">
            <div class="accordion-body"><?= nl2br(e($f['answer'])) ?></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <?php return (string) ob_get_clean();
}

function faq_json_ld(array $faqs): array
{
    if (!$faqs) return [];
    return [[
        '@context' => 'https://schema.org', '@type' => 'FAQPage',
        'mainEntity' => array_map(fn($f) => ['@type' => 'Question', 'name' => $f['question'], 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $f['answer']]], $faqs),
    ]];
}

function render_search_box(string $value = '', string $size = 'lg', string $id = 'hero-search'): string
{
    ob_start(); ?>
    <form class="search-box search-<?= e($size) ?>" action="<?= e(route('search')) ?>" method="get" role="search" autocomplete="off" data-suggest>
      <label class="visually-hidden" for="<?= e($id) ?>">ابحث عن خدمة</label>
      <i class="bi bi-search search-icon" aria-hidden="true"></i>
      <input id="<?= e($id) ?>" type="search" name="q" value="<?= e($value) ?>" placeholder="ابحث: بحث تخرج، AutoCAD، SPSS، سيرة ذاتية، PowerPoint..." aria-autocomplete="list" aria-controls="<?= e($id) ?>-list" aria-expanded="false" maxlength="100">
      <button type="submit" class="btn btn-gold">بحث</button>
      <ul class="suggest-list" id="<?= e($id) ?>-list" role="listbox" hidden></ul>
    </form>
    <?php return (string) ob_get_clean();
}

function render_notice(?string $text, string $icon = 'bi-exclamation-triangle'): string
{
    if (!$text) return '';
    return '<div class="notice-box" role="note"><i class="bi ' . e($icon) . '"></i><p class="mb-0">' . nl2br(e($text)) . '</p></div>';
}

/** ألوان البنرات المصممة */
function banner_themes(): array
{
    return [
        'navy'    => 'كحلي ملكي',
        'gold'    => 'ذهبي',
        'sky'     => 'سماوي',
        'violet'  => 'بنفسجي',
        'emerald' => 'زمردي',
        'rose'    => 'وردي',
        'sunset'  => 'برتقالي غروب',
    ];
}

/**
 * سلايدر العروض: يدعم بنرات بصورة، أو بنرات مصممة بالألوان والأيقونات (بدون صورة).
 * $variant: hero (كبير في الرئيسية) | inline (داخل الصفحات)
 */
function render_banners(array $banners, string $id = 'ads', string $variant = 'inline'): string
{
    if (!$banners) return '';
    $multi = count($banners) > 1;
    banners_count_views($banners);
    ob_start(); ?>
    <section class="offer-slider offer-<?= e($variant) ?>" id="<?= e($id) ?>" data-slider data-interval="<?= max(2, min(30, (int) setting('banner_interval', '6'))) * 1000 ?>" aria-roledescription="carousel" aria-label="العروض والإعلانات">
      <div class="offer-track" data-track>
        <?php foreach ($banners as $i => $b):
            $href  = $b['link_url'] ? url('api/banner_click.php?id=' . (int) $b['id']) : null;
            $theme = isset(banner_themes()[$b['theme'] ?? '']) ? $b['theme'] : 'navy';
            $img   = $b['image'] ?? null; ?>
          <article class="offer-slide theme-<?= e($theme) ?><?= $img ? ' has-image' : '' ?><?= $i ? '' : ' is-active' ?>" role="group" aria-roledescription="slide" aria-label="<?= $i + 1 ?> من <?= count($banners) ?>"<?= $i ? ' aria-hidden="true"' : '' ?>>
            <?php if ($img): ?>
              <?php $mob = $b['mobile_image'] ?? null; ?>
              <picture>
                <?php if ($mob && media_exists($mob)): ?><source media="(max-width: 575.98px)" srcset="<?= e(media_url($mob)) ?>"><?php endif; ?>
                <img class="offer-bg" src="<?= e(media_url($img)) ?>" alt="" <?= $i ? 'loading="lazy"' : 'fetchpriority="high"' ?> width="1200" height="400">
              </picture>
            <?php else: ?>
              <span class="offer-deco" aria-hidden="true"><i></i><i></i><i></i></span>
              <span class="offer-icon" aria-hidden="true"><?= icon($b['icon'] ?? 'bi-stars') ?></span>
            <?php endif; ?>
            <div class="offer-body">
              <?php if (!empty($b['badge_text'])): ?><span class="offer-badge"><i class="bi bi-lightning-charge-fill"></i> <?= e($b['badge_text']) ?></span><?php endif; ?>
              <h3 class="offer-title"><?= e($b['title']) ?></h3>
              <?php if ($b['subtitle']): ?><p class="offer-text"><?= e($b['subtitle']) ?></p><?php endif; ?>
              <?php if ($href): ?><a class="btn offer-btn" href="<?= e($href) ?>"<?= $i ? ' tabindex="-1"' : '' ?>><?= e($b['button_text'] ?: 'اعرف المزيد') ?> <i class="bi bi-arrow-left"></i></a><?php endif; ?>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
      <?php if ($multi): ?>
        <button class="offer-nav prev" type="button" data-prev aria-label="العرض السابق"><i class="bi bi-chevron-right"></i></button>
        <button class="offer-nav next" type="button" data-next aria-label="العرض التالي"><i class="bi bi-chevron-left"></i></button>
        <div class="offer-dots" role="tablist" aria-label="اختر العرض">
          <?php foreach ($banners as $i => $b): ?><button type="button" role="tab" data-dot="<?= $i ?>" aria-label="العرض <?= $i + 1 ?>"<?= $i ? '' : ' class="active" aria-selected="true"' ?>><span></span></button><?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
    <?php return (string) ob_get_clean();
}

/** الاختيار السريع حسب نوع الاحتياج — يساعد الزائر الجديد على معرفة طريقه */
function quick_needs(): array
{
    return [
        ['bi-journal-text',   'بحث أو تقرير',        'بحوث تخرج، تقارير تدريب، مراجعة وتوثيق',   ['slug' => 'academic'],        'sky'],
        ['bi-pencil-square',  'واجب أو شرح مادة',     'شرح خطوة بخطوة ومراجعة الإجابات',          ['q' => 'واجب'],               'violet'],
        ['bi-buildings',      'مخططات هندسية',        'أوتوكاد، ريفيت، نمذجة، حسابات',            ['slug' => 'engineering'],     'gold'],
        ['bi-code-slash',     'برمجة وتطبيقات',       'مواقع، تطبيقات، قواعد بيانات، مشاريع',      ['slug' => 'programming-it'],  'navy'],
        ['bi-easel',          'عرض تقديمي',           'بوربوينت احترافي وإنفوجرافيك',             ['q' => 'بوربوينت'],           'rose'],
        ['bi-bar-chart-line', 'تحليل إحصائي',         'SPSS، Excel، تفسير النتائج',               ['q' => 'SPSS'],               'emerald'],
        ['bi-person-vcard',   'سيرة ذاتية ووظيفة',    'CV احترافي، LinkedIn، مقابلات',            ['slug' => 'cv-career'],       'sunset'],
        ['bi-palette',        'تصميم ومونتاج',        'شعارات، هوية، فيديو، سوشيال',              ['slug' => 'design-media'],    'rose'],
    ];
}

function render_quick_picker(): string
{
    $active = array_column(categories_active(), 'slug');
    ob_start(); ?>
    <div class="need-grid">
      <?php foreach (quick_needs() as [$ic, $t, $d, $target, $theme]):
          if (isset($target['slug']) && !in_array($target['slug'], $active, true)) continue;
          $href = isset($target['slug']) ? route('category', ['slug' => $target['slug']]) : route('search', ['q' => $target['q']]); ?>
        <a class="need-card tone-<?= e($theme) ?>" href="<?= e($href) ?>">
          <span class="need-icon"><?= icon($ic) ?></span>
          <span class="need-text"><strong><?= e($t) ?></strong><small><?= e($d) ?></small></span>
          <i class="bi bi-arrow-left-short need-go" aria-hidden="true"></i>
        </a>
      <?php endforeach; ?>
    </div>
    <?php return (string) ob_get_clean();
}

/** شريط التنقل السفلي للجوال (مثل التطبيقات) */
function render_bottom_nav(string $active = ''): string
{
    $cu = function_exists('current_user') ? current_user() : null;
    $items = [
        ['home', 'bi-house', 'bi-house-fill', 'الرئيسية', route('home')],
        ['services', 'bi-grid', 'bi-grid-fill', 'الخدمات', route('services')],
        ['order', 'bi-whatsapp', 'bi-whatsapp', 'اطلب', wa_service_link()],
        portfolio_enabled() && array_sum(portfolio_counts_by_category())
            ? ['portfolio', 'bi-collection', 'bi-collection-fill', 'أعمالنا', route('portfolio')]
            : ['search', 'bi-search', 'bi-search', 'بحث', route('search')],
        ['account', 'bi-person', 'bi-person-fill', $cu ? 'حسابي' : 'دخول', $cu ? route('account') : route('login')],
    ];
    ob_start(); ?>
    <nav class="bottom-nav d-lg-none" aria-label="التنقل السريع">
      <?php foreach ($items as [$key, $ic, $icA, $label, $href]): $on = $active === $key; ?>
        <a class="bn-item<?= $on ? ' active' : '' ?><?= $key === 'order' ? ' bn-cta' : '' ?>" href="<?= e($href) ?>"<?= $key === 'order' ? ' target="_blank" rel="noopener"' : '' ?><?= $key === 'search' ? ' data-open-search' : '' ?><?= $on ? ' aria-current="page"' : '' ?>>
          <span class="bn-ic"><i class="bi <?= $on ? $icA : $ic ?>"></i></span><span class="bn-label"><?= e($label) ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
    <?php return (string) ob_get_clean();
}

// =====================================================================
// معرض الأعمال (v4)
// =====================================================================
function render_portfolio_card(array $p, bool $showCategory = true): string
{
    $url = route('work', ['slug' => $p['slug']]);
    $cover = portfolio_cover($p);
    $tools = array_slice(csv_items($p['tools_text'] ?? ''), 0, 3);
    ob_start(); ?>
    <article class="work-card tone-<?= e(category_tone($p['category_slug'] ?? null)) ?> h-100">
      <a class="work-cover" href="<?= e($url) ?>" tabindex="-1" aria-hidden="true">
        <?php if ($cover): ?><img src="<?= e(img_src($cover)) ?>" alt="<?= e($p['title']) ?>" loading="lazy" width="640" height="480"><?php else: ?><span class="work-cover-ph"><?= icon($p['category_icon'] ?? 'bi-collection') ?></span><?php endif; ?>
        <span class="work-counts">
          <?php if ((int) ($p['images_count'] ?? 0) > 1): ?><span><i class="bi bi-images"></i> <?= (int) $p['images_count'] ?></span><?php endif; ?>
          <?php if ((int) ($p['docs_count'] ?? 0) > 0): ?><span><i class="bi bi-file-earmark-text"></i> <?= (int) $p['docs_count'] ?></span><?php endif; ?>
        </span>
        <?php if (!empty($p['is_featured'])): ?><span class="work-feat"><i class="bi bi-star-fill"></i> مميز</span><?php endif; ?>
      </a>
      <div class="work-body">
        <?php if ($showCategory): ?><p class="work-meta"><?= icon($p['category_icon'] ?? 'bi-grid') ?> <?= e($p['subcategory_name'] ?: $p['category_name']) ?></p><?php endif; ?>
        <h3 class="work-title"><a href="<?= e($url) ?>"><?= e($p['title']) ?></a></h3>
        <?php if (!empty($p['summary'])): ?><p class="work-excerpt"><?= e(excerpt($p['summary'], 100)) ?></p><?php endif; ?>
        <?php if ($tools): ?><ul class="work-tools"><?php foreach ($tools as $t): ?><li><?= e($t) ?></li><?php endforeach; ?></ul><?php endif; ?>
      </div>
    </article>
    <?php return (string) ob_get_clean();
}

/** قسم «من أعمالنا» قابل لإعادة الاستخدام في الرئيسية/القسم/الخدمة */
function render_portfolio_section(array $items, string $title, ?string $lead = null, ?string $moreUrl = null, string $id = 'portfolio-section', string $extraClass = ''): string
{
    if (!$items) return '';
    ob_start(); ?>
    <section id="<?= e($id) ?>" class="portfolio-block <?= e($extraClass) ?>">
      <header class="d-flex flex-wrap justify-content-between align-items-end gap-2 mb-3">
        <div>
          <h2 class="block-title"><i class="bi bi-collection-fill"></i> <?= e($title) ?></h2>
          <?php if ($lead): ?><p class="block-lead mb-0"><?= e($lead) ?></p><?php endif; ?>
        </div>
        <?php if ($moreUrl): ?><a class="btn btn-outline-navy btn-sm" href="<?= e($moreUrl) ?>">عرض كل الأعمال <i class="bi bi-arrow-left"></i></a><?php endif; ?>
      </header>
      <div class="row g-3 scroller-sm">
        <?php foreach ($items as $p): ?><div class="col-10 col-sm-6 col-lg-4"><?= render_portfolio_card($p) ?></div><?php endforeach; ?>
      </div>
    </section>
    <?php return (string) ob_get_clean();
}

// =====================================================================
// SEO (v4)
// =====================================================================
/** وصف تلقائي غني بالكلمات (عند غياب وصف SEO مخصص) بطول مناسب لنتائج البحث */
function seo_description(string ...$parts): string
{
    $txt = trim(preg_replace('/\s+/u', ' ', implode(' ', array_filter(array_map(fn($p) => trim(strip_tags($p)), $parts)))));
    if (mb_strlen($txt) <= 160) return $txt;
    $cut = mb_substr($txt, 0, 157);
    $sp = mb_strrpos($cut, ' ');
    return ($sp > 100 ? mb_substr($cut, 0, $sp) : $cut) . '…';
}

/** روابط الحسابات الاجتماعية المعبأة (لـ sameAs والتذييل) */
function social_links(): array
{
    $map = [
        'social_x' => ['bi-twitter-x', 'X'], 'social_instagram' => ['bi-instagram', 'Instagram'], 'social_tiktok' => ['bi-tiktok', 'TikTok'],
        'social_snapchat' => ['bi-snapchat', 'Snapchat'], 'social_telegram' => ['bi-telegram', 'Telegram'], 'social_linkedin' => ['bi-linkedin', 'LinkedIn'],
        'social_youtube' => ['bi-youtube', 'YouTube'], 'social_facebook' => ['bi-facebook', 'Facebook'],
    ];
    $out = [];
    foreach ($map as $k => [$ic, $label]) if ($u = setting($k)) $out[] = ['url' => $u, 'icon' => $ic, 'label' => $label];
    return $out;
}

/** هل القسم مفعّل في إعدادات «أقسام الواجهة»؟ */
function section_on(string $key): bool
{
    return setting('show_' . $key, '1') === '1';
}

/** الخطوط المتاحة: الاسم => [رابط Google Fonts, عائلة CSS] */
function font_choices(): array
{
    return [
        'Cairo'           => ['Cairo:wght@400;600;700;800', '"Cairo"'],
        'Tajawal'         => ['Tajawal:wght@400;500;700;800', '"Tajawal"'],
        'Almarai'         => ['Almarai:wght@400;700;800', '"Almarai"'],
        'IBM Plex Sans Arabic' => ['IBM+Plex+Sans+Arabic:wght@400;500;600;700', '"IBM Plex Sans Arabic"'],
        'Noto Kufi Arabic' => ['Noto+Kufi+Arabic:wght@400;600;700;800', '"Noto Kufi Arabic"'],
        'Readex Pro'      => ['Readex+Pro:wght@400;500;600;700', '"Readex Pro"'],
    ];
}

/** أزرار مشاركة بدون سكربتات خارجية (واتساب، X، تيليجرام، لينكدإن، نسخ الرابط) */
function render_share_buttons(string $url, string $title): string
{
    $u = rawurlencode($url); $t = rawurlencode($title);
    $links = [
        ['bi-whatsapp', 'واتساب', 'https://wa.me/?text=' . rawurlencode($title . ' ' . $url)],
        ['bi-twitter-x', 'X', "https://twitter.com/intent/tweet?url=$u&text=$t"],
        ['bi-telegram', 'تيليجرام', "https://t.me/share/url?url=$u&text=$t"],
        ['bi-linkedin', 'لينكدإن', "https://www.linkedin.com/sharing/share-offsite/?url=$u"],
    ];
    ob_start(); ?>
    <div class="share-row" aria-label="مشاركة">
      <span class="small fw-bold">مشاركة:</span>
      <?php foreach ($links as [$ic, $l, $href]): ?><a href="<?= e($href) ?>" target="_blank" rel="noopener nofollow" aria-label="مشاركة عبر <?= e($l) ?>" title="<?= e($l) ?>"><i class="bi <?= $ic ?>"></i></a><?php endforeach; ?>
      <button type="button" data-copy="<?= e($url) ?>" aria-label="نسخ الرابط" title="نسخ الرابط"><i class="bi bi-link-45deg"></i></button>
    </div>
    <?php return (string) ob_get_clean();
}

// =====================================================================
// v5: آراء العملاء
// =====================================================================

function render_stars(int $rating, string $cls = ''): string
{
    $rating = max(0, min(5, $rating));
    $h = '<span class="stars ' . e($cls) . '" role="img" aria-label="التقييم ' . $rating . ' من 5">';
    for ($i = 1; $i <= 5; $i++) $h .= '<i class="bi ' . ($i <= $rating ? 'bi-star-fill' : 'bi-star') . '" aria-hidden="true"></i>';
    return $h . '</span>';
}

/** بطاقة رأي — تُستخدم في الموقع والمعاينة في لوحة التحكم */
function render_testimonial_card(array $t): string
{
    $theme = isset(testimonial_themes()[$t['theme'] ?? '']) ? $t['theme'] : 'white';
    $style = [];
    if (!empty($t['bg_color']) && preg_match('/^#[0-9a-f]{6}$/i', $t['bg_color'])) $style[] = '--t-bg:' . $t['bg_color'];
    if (!empty($t['text_color']) && preg_match('/^#[0-9a-f]{6}$/i', $t['text_color'])) $style[] = '--t-fg:' . $t['text_color'];
    if ($theme === 'image' && !empty($t['bg_image']) && media_exists($t['bg_image'])) $style[] = "--t-img:url('" . e(media_url($t['bg_image'])) . "')";
    $icon = preg_match('/^bi-[a-z0-9\-]+$/', (string) ($t['icon'] ?? '')) ? $t['icon'] : 'bi-quote';
    $name = trim((string) $t['name']) ?: 'عميل';
    $initial = mb_substr($name, 0, 1);
    $service = $t['service_name'] ?? null ?: ($t['service_label'] ?? '');
    ob_start(); ?>
    <article class="t-card t-<?= e($theme) ?>"<?= $style ? ' style="' . e(implode(';', $style)) . '"' : '' ?>>
      <i class="bi <?= e($icon) ?> t-icon" aria-hidden="true"></i>
      <header class="t-head">
        <?php if (!empty($t['avatar']) && media_exists($t['avatar'])): ?>
          <img class="t-avatar" src="<?= e(media_url($t['avatar'], true)) ?>" alt="<?= e($name) ?>" loading="lazy" width="56" height="56">
        <?php else: ?><span class="t-avatar t-initial" aria-hidden="true"><?= e($initial) ?></span><?php endif; ?>
        <div class="t-who">
          <strong class="t-name"><?= e($name) ?><?php if (!empty($t['is_verified'])): ?> <i class="bi bi-patch-check-fill t-verified" title="عميل موثّق — تعامل معنا فعلًا" aria-label="عميل موثّق"></i><?php endif; ?></strong>
          <?php if (!empty($t['specialization'])): ?><span class="t-spec"><?= e($t['specialization']) ?></span><?php endif; ?>
        </div>
      </header>
      <?= render_stars((int) $t['rating'], 't-stars') ?>
      <blockquote class="t-body"><?= nl2br(e((string) $t['body'])) ?></blockquote>
      <footer class="t-foot">
        <?php if ($service): ?><span class="t-service"><i class="bi bi-briefcase"></i> <?= e($service) ?></span><?php endif; ?>
        <time class="t-date" datetime="<?= e(substr((string) ($t['approved_at'] ?? $t['created_at'] ?? ''), 0, 10)) ?>"><?= e(ar_date($t['approved_at'] ?? $t['created_at'] ?? null)) ?></time>
      </footer>
      <?php if (!empty($t['attachment']) && media_exists($t['attachment'])): ?>
        <a class="t-attach" href="<?= e(media_url($t['attachment'])) ?>" data-lightbox="t-<?= (int) ($t['id'] ?? 0) ?>"><img src="<?= e(media_url($t['attachment'], true)) ?>" alt="مرفق من العميل (منشور بإذنه)" loading="lazy"></a>
      <?php endif; ?>
    </article>
    <?php return (string) ob_get_clean();
}

/** قسم الآراء (شبكة أو سلايدر) مع متوسط التقييم الحقيقي */
function render_testimonials_section(array $items, array $stats, string $id = 'testimonials-section', bool $withCta = true): string
{
    if (!$items) return '';
    $layout = setting('testimonials_layout', 'slider') === 'grid' ? 'grid' : 'slider';
    $interval = max(2, min(30, (int) setting('testimonials_interval', '6'))) * 1000;
    ob_start(); ?>
    <section id="<?= e($id) ?>" class="section testimonials-section">
      <div class="container">
        <header class="section-head">
          <span class="section-kicker">آراء العملاء</span>
          <h2 class="section-title"><?= e(setting('testimonials_title', 'ماذا يقول عملاؤنا')) ?></h2>
          <p class="section-lead"><?= e(setting('testimonials_subtitle')) ?></p>
          <?php if (setting('testimonials_show_avg', '1') === '1' && $stats['count'] > 0): ?>
            <div class="t-summary"><strong><?= e(number_format($stats['avg'], 1)) ?></strong> <?= render_stars((int) round($stats['avg'])) ?> <span>من <?= (int) $stats['count'] ?> تقييم حقيقي</span></div>
          <?php endif; ?>
        </header>
        <?php if ($layout === 'grid'): ?>
          <div class="row g-4">
            <?php foreach ($items as $t): ?><div class="col-md-6 col-lg-4 reveal"><?= render_testimonial_card($t) ?></div><?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="t-slider" data-tslider data-interval="<?= $interval ?>">
            <button class="t-nav prev" type="button" data-tprev aria-label="السابق"><i class="bi bi-chevron-right"></i></button>
            <div class="t-track" data-ttrack>
              <?php foreach ($items as $t): ?><div class="t-slide"><?= render_testimonial_card($t) ?></div><?php endforeach; ?>
            </div>
            <button class="t-nav next" type="button" data-tnext aria-label="التالي"><i class="bi bi-chevron-left"></i></button>
          </div>
        <?php endif; ?>
        <?php if ($withCta && setting('testimonials_allow_submit', '1') === '1'): ?>
          <div class="text-center mt-4"><a class="btn btn-outline-navy" href="<?= e(route('review')) ?>"><i class="bi bi-chat-heart"></i> شاركنا رأيك في خدمتنا</a></div>
        <?php endif; ?>
      </div>
    </section>
    <?php return (string) ob_get_clean();
}

// =====================================================================
// v5: المقالات
// =====================================================================
function render_post_card(array $p): string
{
    $href = route('article', ['slug' => $p['slug']]);
    ob_start(); ?>
    <article class="post-card">
      <a href="<?= e($href) ?>" tabindex="-1" aria-hidden="true"><img src="<?= e(media_url($p['cover_image'], true)) ?>" alt="" loading="lazy" width="600" height="338"></a>
      <div class="post-body">
        <div class="post-meta"><?php if (!empty($p['category_name'])): ?><i class="bi bi-tag"></i> <?= e($p['category_name']) ?> · <?php endif; ?><time datetime="<?= e(substr((string) ($p['published_at'] ?? $p['created_at']), 0, 10)) ?>"><?= e(ar_date($p['published_at'] ?? $p['created_at'])) ?></time></div>
        <h3><a href="<?= e($href) ?>"><?= e($p['title']) ?></a></h3>
        <p class="small text-muted mb-0"><?= e($p['excerpt'] ?: excerpt($p['body'], 140)) ?></p>
      </div>
    </article>
    <?php return (string) ob_get_clean();
}
