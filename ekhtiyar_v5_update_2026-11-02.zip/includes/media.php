<?php
/**
 * نظام الصور الموحّد (v5)
 * - رفع آمن + تحويل إلى WebP + ضغط + تصغير الأبعاد الكبيرة + صورة مصغرة (thumbs/).
 * - روابط موحدة مع صورة افتراضية عند فقدان الملف.
 * - «حذف آمن»: لا يُحذف أي ملف ما دام مستخدمًا في أي سجل، والملف غير المستخدم يُنقل إلى
 *   storage/media_trash (قابل للاستعادة) بدل حذفه نهائيًا.
 * - تسجيل أخطاء الرفع في storage/logs/uploads.log
 */
declare(strict_types=1);

const MEDIA_UPLOAD_BASE = 'assets/images/uploads';
const MEDIA_PLACEHOLDER = 'assets/images/placeholder.svg';

function media_log(string $msg): void
{
    $dir = ROOT_PATH . '/storage/logs';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    @file_put_contents($dir . '/uploads.log', '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}

function media_max_bytes(): int
{
    return max(1, (int) env('IMAGE_MAX_MB', 8)) * 1024 * 1024;
}

/** مسار مطلق آمن داخل مجلد الرفع العام، أو null */
function media_abs(?string $rel): ?string
{
    $rel = ltrim((string) $rel, '/');
    if ($rel === '' || str_contains($rel, '..') || preg_match('~^(https?:)?//~i', $rel)) return null;
    if (str_starts_with($rel, 'public/')) $rel = substr($rel, 7);
    return PUBLIC_PATH . '/' . $rel;
}

function media_exists(?string $rel): bool
{
    $a = media_abs($rel);
    return $a !== null && is_file($a);
}

/** المسار النسبي للصورة المصغرة */
function media_thumb_rel(string $rel): string
{
    $rel = ltrim($rel, '/');
    return dirname($rel) . '/thumbs/' . pathinfo($rel, PATHINFO_FILENAME) . '.webp';
}

/** ترميز آمن لكل جزء من المسار (أسماء عربية/مسافات في الملفات القديمة) */
function media_encode(string $rel): string
{
    return implode('/', array_map('rawurlencode', explode('/', ltrim($rel, '/'))));
}

/**
 * رابط الصورة: الملف إن وُجد، وإلا البديل (صورة افتراضية). الروابط الخارجية تمر كما هي.
 * @param bool $thumb استخدام الصورة المصغرة إن توفرت
 */
function media_url(?string $rel, bool $thumb = false, ?string $fallback = MEDIA_PLACEHOLDER): string
{
    $rel = trim((string) $rel);
    if ($rel !== '' && preg_match('~^(https?:)?//~i', $rel)) return $rel;
    if ($rel !== '' && media_exists($rel)) {
        if ($thumb) {
            $t = media_thumb_rel($rel);
            if (is_file(PUBLIC_PATH . '/' . $t)) return url(media_encode($t));
        }
        return url(media_encode($rel));
    }
    return $fallback ? url($fallback) : '';
}

/** إنشاء/إعادة إنشاء الصورة المصغرة لملف موجود */
function media_make_thumb(string $rel, int $max = 600): bool
{
    $src = media_abs($rel);
    if (!$src || !is_file($src) || !function_exists('imagecreatefromstring') || !function_exists('imagewebp')) return false;
    $img = @imagecreatefromstring((string) file_get_contents($src));
    if (!$img) return false;
    $t = media_resize($img, $max);
    $dest = PUBLIC_PATH . '/' . media_thumb_rel($rel);
    if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
    imagealphablending($t, false); imagesavealpha($t, true);
    $ok = imagewebp($t, $dest, 78);
    imagedestroy($img); if ($t !== $img) @imagedestroy($t);
    if ($ok) @chmod($dest, 0644);
    return (bool) $ok;
}

/** تصغير مع الحفاظ على النسبة إن تجاوز الحد */
function media_resize($img, int $max)
{
    $w = imagesx($img); $h = imagesy($img);
    if ($w <= $max && $h <= $max) return $img;
    $r = min($max / $w, $max / $h);
    $nw = max(1, (int) round($w * $r)); $nh = max(1, (int) round($h * $r));
    $out = imagecreatetruecolor($nw, $nh);
    imagealphablending($out, false); imagesavealpha($out, true);
    imagefill($out, 0, 0, imagecolorallocatealpha($out, 0, 0, 0, 127));
    imagecopyresampled($out, $img, 0, 0, 0, 0, $nw, $nh, $w, $h);
    return $out;
}

/** تصحيح اتجاه صور الجوال (EXIF) */
function media_orient($img, string $path)
{
    if (!function_exists('exif_read_data')) return $img;
    $exif = @exif_read_data($path);
    $o = (int) ($exif['Orientation'] ?? 1);
    $map = [3 => 180, 6 => -90, 8 => 90];
    if (isset($map[$o])) { $r = imagerotate($img, $map[$o], 0); if ($r) { imagedestroy($img); return $r; } }
    return $img;
}

/**
 * رفع صورة عامة. يعيد [true, مسار نسبي] أو [false, رسالة خطأ].
 * يتحقق من الامتداد ونوع MIME والمحتوى، ويعيد ترميز الصورة (يزيل أي حمولة مخفية)،
 * ويحوّلها إلى WebP ويصغّر الأبعاد الكبيرة وينشئ صورة مصغرة.
 */
function store_public_image(array $file, string $folder): array
{
    $allowed = ['jpg' => ['image/jpeg'], 'jpeg' => ['image/jpeg'], 'png' => ['image/png'], 'webp' => ['image/webp']];
    $orig = (string) ($file['name'] ?? '');
    [$ok, $err, $ext] = validate_upload($file, $allowed, media_max_bytes());
    if (!$ok) { media_log("رفض «{$orig}» ($folder): $err"); return [false, $err]; }
    if (@getimagesize($file['tmp_name']) === false) { media_log("صورة غير صالحة «{$orig}»"); return [false, 'الصورة «' . e($orig) . '» غير صالحة أو تالفة.']; }
    $folder = preg_replace('/[^a-z]/', '', $folder) ?: 'misc';
    $dir = PUBLIC_PATH . '/' . MEDIA_UPLOAD_BASE . '/' . $folder;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) { media_log("تعذر إنشاء المجلد $dir"); return [false, 'تعذر إنشاء مجلد الرفع. راجع صلاحيات المجلدات من «صحة الموقع».']; }
    if (!is_writable($dir)) { media_log("المجلد غير قابل للكتابة $dir"); return [false, 'مجلد الصور غير قابل للكتابة (الصلاحية المطلوبة 755). راجع «صحة الموقع».']; }

    $gd = function_exists('imagecreatefromstring');
    $webp = $gd && function_exists('imagewebp');
    $outExt = $webp ? 'webp' : ($ext === 'jpeg' ? 'jpg' : $ext);
    $name = safe_filename($outExt);
    $dest = $dir . '/' . $name;
    $saved = false;
    if ($gd) {
        $img = @imagecreatefromstring((string) file_get_contents($file['tmp_name']));
        if ($img) {
            if (in_array($ext, ['jpg', 'jpeg'], true)) $img = media_orient($img, $file['tmp_name']);
            $img = media_resize($img, 2000);
            imagealphablending($img, false); imagesavealpha($img, true);
            $saved = match ($outExt) {
                'webp' => imagewebp($img, $dest, 82),
                'png'  => imagepng($img, $dest, 7),
                default => imagejpeg($img, $dest, 84),
            };
            imagedestroy($img);
        }
    }
    if (!$saved) {
        // بدون GD: نحفظ الأصل كما هو (تم التحقق منه مسبقًا) بامتداده الأصلي
        $name = safe_filename($ext === 'jpeg' ? 'jpg' : $ext);
        $dest = $dir . '/' . $name;
        if (!move_uploaded_file($file['tmp_name'], $dest) && !(PHP_SAPI === 'cli' && copy($file['tmp_name'], $dest))) {
            media_log("فشل نقل الملف «{$orig}» إلى $dest");
            return [false, 'تعذر حفظ الصورة على الخادم.'];
        }
    }
    @chmod($dest, 0644);
    $rel = MEDIA_UPLOAD_BASE . '/' . $folder . '/' . $name;
    media_make_thumb($rel);
    return [true, $rel];
}

// ---------------------------------------------------------------------
// المراجع والحذف الآمن
// ---------------------------------------------------------------------

/** كل الأعمدة التي قد تحتوي مسارات صور: [جدول، عمود، شرط إضافي] */
function media_ref_columns(): array
{
    $cols = [
        ['categories', 'image', ''], ['services', 'image', ''], ['service_files', 'file_path', ''],
        ['banners', 'image', ''], ['portfolio_items', 'cover_image', ''], ['portfolio_files', 'file_path', "kind = 'image'"],
        ['site_settings', 'setting_value', "input_type = 'image'"],
    ];
    if (function_exists('mig_column_exists')) {
        foreach ([['subcategories', 'image'], ['banners', 'mobile_image'], ['testimonials', 'avatar'], ['testimonials', 'bg_image'], ['testimonials', 'attachment'], ['posts', 'cover_image']] as [$t, $c]) {
            try { if (mig_column_exists($t, $c)) $cols[] = [$t, $c, '']; } catch (Throwable $e) {}
        }
    }
    return $cols;
}

/** عدد السجلات التي تستخدم هذا المسار */
function media_ref_count(string $rel): int
{
    $n = 0;
    foreach (media_ref_columns() as [$t, $c, $w]) {
        try { $n += (int) db_value("SELECT COUNT(*) FROM `$t` WHERE `$c` = ?" . ($w ? " AND $w" : ''), [$rel]); } catch (Throwable $e) {}
    }
    return $n;
}

/** كل المسارات المسجلة في قاعدة البيانات => [مصادرها] */
function media_all_refs(): array
{
    $out = [];
    foreach (media_ref_columns() as [$t, $c, $w]) {
        try {
            foreach (db_all("SELECT `$c` p FROM `$t` WHERE `$c` IS NOT NULL AND `$c` <> ''" . ($w ? " AND $w" : '')) as $r) {
                $p = ltrim((string) $r['p'], '/');
                if (!str_starts_with($p, 'assets/')) continue;
                $out[$p][] = "$t.$c";
            }
        } catch (Throwable $e) {}
    }
    return $out;
}

/**
 * «حذف» صورة عامة: يُؤجَّل لنهاية الطلب، ثم يُنقل الملف إلى سلة الوسائط فقط إذا لم يعد أي سجل يستخدمه.
 * (هذا يمنع فقدان صورة مستخدمة في عنصر آخر، ويسمح بالاستعادة.)
 */
function delete_public_image(?string $relPath): void
{
    static $queue = null;
    if (!$relPath || !str_starts_with(ltrim($relPath, '/'), MEDIA_UPLOAD_BASE . '/')) return;
    if ($queue === null) {
        $queue = [];
        register_shutdown_function(function () use (&$queue) {
            foreach (array_unique($queue) as $p) {
                try { if (media_ref_count($p) === 0) media_trash($p); } catch (Throwable $e) { media_log('delete check failed: ' . $e->getMessage()); }
            }
        });
    }
    $queue[] = ltrim($relPath, '/');
}

function media_trash_dir(): string
{
    $d = ROOT_PATH . '/storage/media_trash';
    if (!is_dir($d)) @mkdir($d, 0750, true);
    return $d;
}

/** نقل ملف (ومصغرته) إلى سلة الوسائط مع الحفاظ على مساره */
function media_trash(string $rel): bool
{
    $src = media_abs($rel);
    $base = realpath(PUBLIC_PATH . '/' . MEDIA_UPLOAD_BASE);
    $real = $src ? realpath($src) : false;
    if (!$real || !$base || !str_starts_with($real, $base . DIRECTORY_SEPARATOR) || !is_file($real)) return false;
    $dest = media_trash_dir() . '/' . $rel;
    if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0750, true);
    $ok = @rename($real, $dest) || (@copy($real, $dest) && @unlink($real));
    $th = PUBLIC_PATH . '/' . media_thumb_rel($rel);
    if (is_file($th)) @unlink($th);
    if ($ok) media_log("نُقل إلى سلة الوسائط: $rel");
    return $ok;
}

function media_trash_restore(string $rel): bool
{
    $rel = ltrim($rel, '/');
    if (str_contains($rel, '..') || !str_starts_with($rel, MEDIA_UPLOAD_BASE . '/')) return false;
    $src = media_trash_dir() . '/' . $rel;
    $dest = PUBLIC_PATH . '/' . $rel;
    if (!is_file($src) || is_file($dest)) return false;
    if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
    $ok = @rename($src, $dest) || (@copy($src, $dest) && @unlink($src));
    if ($ok) { @chmod($dest, 0644); media_make_thumb($rel); }
    return $ok;
}

/** قائمة ملفات مجلد (تكراري) بمسارات نسبية تبدأ بـ $prefix */
function media_scan(string $absDir, string $prefix): array
{
    $out = [];
    if (!is_dir($absDir)) return $out;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($absDir, FilesystemIterator::SKIP_DOTS));
    foreach ($it as $f) {
        if (!$f->isFile()) continue;
        $name = $f->getFilename();
        if ($name[0] === '.' ) continue;
        $rel = $prefix . '/' . ltrim(str_replace('\\', '/', substr($f->getPathname(), strlen($absDir))), '/');
        if (str_contains($rel, '/thumbs/')) continue;
        $out[$rel] = ['size' => $f->getSize(), 'mtime' => $f->getMTime()];
    }
    ksort($out);
    return $out;
}

/**
 * أماكن محتملة لملفات رُفعت لمسار خاطئ قبل الإصلاح (عندما كان المجلد العام يُحسب خطأً)
 * مثل: ‎/home/user/public/assets/images/uploads بينما الموقع يعمل من public_html.
 */
function media_misplaced_dirs(): array
{
    $cands = [ROOT_PATH . '/public/' . MEDIA_UPLOAD_BASE, ROOT_PATH . '/public_html/' . MEDIA_UPLOAD_BASE, dirname(ROOT_PATH) . '/public_html/' . MEDIA_UPLOAD_BASE];
    $real = realpath(PUBLIC_PATH . '/' . MEDIA_UPLOAD_BASE);
    $out = [];
    foreach ($cands as $c) {
        $r = realpath($c);
        if ($r && $r !== $real && is_dir($r)) $out[] = $r;
    }
    return array_values(array_unique($out));
}
