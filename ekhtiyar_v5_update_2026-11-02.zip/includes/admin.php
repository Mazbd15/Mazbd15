<?php
/** أدوات مشتركة للوحة التحكم */
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';
header('X-Robots-Tag: noindex, nofollow');
header('Cache-Control: no-store, private');

function admin_menu(): array
{
    // المفتاح => [أيقونة، العنوان، أدنى دور، المجموعة]
    return [
        'index'         => ['bi-speedometer2', 'الرئيسية', 'specialist', 'main'],
        'categories'    => ['bi-grid', 'الأقسام والتخصصات', 'specialist', 'catalog'],
        'subcategories' => ['bi-diagram-3', 'التخصصات الفرعية', 'specialist', 'catalog'],
        'services'      => ['bi-briefcase', 'الخدمات', 'specialist', 'catalog'],
        'requests'      => ['bi-inbox', 'الطلبات', 'specialist', 'clients'],
        'customers'     => ['bi-person-vcard', 'العملاء', 'editor', 'clients'],
        'testimonials'  => ['bi-chat-quote', 'آراء العملاء', 'editor', 'clients'],
        'messages'      => ['bi-envelope', 'الرسائل', 'editor', 'clients'],
        'banners'       => ['bi-images', 'البنرات الإعلانية', 'specialist', 'content'],
        'portfolio'     => ['bi-collection', 'معرض الأعمال', 'specialist', 'content'],
        'posts'         => ['bi-newspaper', 'المقالات', 'editor', 'content'],
        'pages'         => ['bi-file-earmark-richtext', 'الصفحات', 'editor', 'content'],
        'faqs'          => ['bi-question-circle', 'الأسئلة الشائعة', 'specialist', 'content'],
        'media'         => ['bi-folder2-open', 'ملفات وصور الموقع', 'editor', 'content'],
        'notifications' => ['bi-bell', 'الإشعارات', 'specialist', 'content'],
        'users'         => ['bi-people', 'المستخدمون والصلاحيات', 'admin', 'system'],
        'seo'           => ['bi-graph-up-arrow', 'تحسين محركات البحث', 'admin', 'system'],
        'settings'      => ['bi-palette', 'إعدادات الهوية والموقع', 'admin', 'system'],
        'backups'       => ['bi-cloud-arrow-down', 'النسخ الاحتياطي', 'admin', 'system'],
        'audit'         => ['bi-journal-text', 'سجل العمليات', 'admin', 'system'],
        'health'        => ['bi-heart-pulse', 'صحة الموقع', 'admin', 'system'],
        'trash'         => ['bi-trash3', 'سلة المحذوفات', 'admin', 'system'],
        'update'        => ['bi-database-gear', 'تحديث قاعدة البيانات', 'super_admin', 'system'],
    ];
}

function admin_menu_groups(): array
{
    return ['main' => '', 'catalog' => 'الكتالوج', 'clients' => 'العملاء والتواصل', 'content' => 'المحتوى', 'system' => 'الإدارة والنظام'];
}

/** صفحات تتطلب بنية v5 — تعرض رسالة بدل الخطأ إن لم تُشغّل الترقية بعد */
function require_v5(string $title, string $active, array $user): void
{
    if (schema_v5()) return;
    admin_header($title, $active, $user);
    echo '<div class="alert alert-warning"><i class="bi bi-database-exclamation"></i> هذه الميزة تحتاج تحديث قاعدة البيانات أولًا. ';
    if (role_at_least($user['role'], 'super_admin')) echo '<a class="alert-link" href="' . e(admin_url('update')) . '">تشغيل التحديث الآن (مع نسخة احتياطية تلقائية)</a>';
    else echo 'يرجى إبلاغ المدير العام.';
    echo '</div>';
    admin_footer();
    exit;
}

/** شرط SQL لرؤية الطلبات: المتخصص يرى طلبات أقسامه أو المسندة إليه */
function requests_scope_sql(array $u, string $alias = 'r'): array
{
    $scope = user_category_scope($u);
    if ($scope === null) return ['1=1', []];
    $parts = ["$alias.assigned_to = ?"];
    $params = [(int) $u['id']];
    if ($scope) {
        $parts[] = "$alias.category_id IN (" . implode(',', array_fill(0, count($scope), '?')) . ')';
        $params = array_merge($params, $scope);
    }
    return ['(' . implode(' OR ', $parts) . ')', $params];
}

function can_view_request(array $u, array $req): bool
{
    $scope = user_category_scope($u);
    if ($scope === null) return true;
    return (int) ($req['assigned_to'] ?? 0) === (int) $u['id'] || in_array((int) $req['category_id'], $scope, true);
}

/** الأقسام المسموح بها للمستخدم */
function scoped_categories(array $u): array
{
    [$w, $p] = scope_sql($u, 'id');
    return db_all("SELECT id, name FROM categories WHERE $w" . sd('categories') . " ORDER BY sort_order, id", $p);
}

/** رفض الوصول لقسم خارج نطاق المتخصص */
function deny_scope(string $back): never
{
    http_response_code(403);
    flash('danger', 'هذا القسم خارج نطاق صلاحياتك.');
    redirect($back);
}

function admin_header(string $title, string $active, array $user): void
{
    [$rw, $rp] = requests_scope_sql($user);
    $newReq = (int) db_value("SELECT COUNT(*) FROM requests r WHERE r.status = 'new' AND $rw", $rp);
    $pendingUsers = can($user, 'users.manage') ? (int) db_value("SELECT COUNT(*) FROM users WHERE status = 'pending'") : 0;
    $unread = (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$user['id']]);
    $latestNotifs = db_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 6', [$user['id']]);
    $v5 = schema_v5();
    $newMsg = $v5 && role_at_least($user['role'], 'editor') ? (int) db_value("SELECT COUNT(*) FROM contact_messages WHERE status = 'new' AND deleted_at IS NULL") : 0;
    $pendingRev = $v5 && role_at_least($user['role'], 'editor') ? (int) db_value("SELECT COUNT(*) FROM testimonials WHERE status = 'pending' AND deleted_at IS NULL") : 0;
    $pendingMig = [];
    if (role_at_least($user['role'], 'admin')) { try { $pendingMig = migrations_pending(); } catch (Throwable $e) {} }
    // نسخة تلقائية «مجدولة» عند زيارة المدير (بدون Cron)
    if ($v5 && role_at_least($user['role'], 'admin') && $active !== 'backups') { try { backup_auto_maybe(); } catch (Throwable $e) { error_log('[auto-backup] ' . $e->getMessage()); } }
    ?><!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($title) ?> | لوحة تحكم اختيارك</title>
<link rel="icon" href="<?= e(url('assets/images/logo.svg')) ?>" type="image/svg+xml">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="<?= asset('css/admin.css') ?>">
<link rel="stylesheet" href="<?= asset('css/v5.css') ?>">
<?php if ($active === 'banners'): ?><link rel="stylesheet" href="<?= asset('css/banner-preview.css') ?>"><?php endif; ?>
</head>
<body class="admin-body" data-page="<?= e($active) ?>" data-csrf="<?= e(csrf_token()) ?>" data-sort-url="<?= e(admin_url('sort')) ?>">
<aside class="admin-sidebar offcanvas-lg offcanvas-end" id="admin-sidebar" tabindex="-1">
  <div class="sidebar-brand">
    <img src="<?= e(url('assets/images/logo.svg')) ?>" alt="" width="40" height="40">
    <div><strong>اختيارك</strong><small>لوحة التحكم</small></div>
    <button type="button" class="btn-close btn-close-white d-lg-none ms-auto" data-bs-dismiss="offcanvas" data-bs-target="#admin-sidebar" aria-label="إغلاق"></button>
  </div>
  <nav class="sidebar-nav">
    <?php $grp = null; $groups = admin_menu_groups();
    foreach (admin_menu() as $key => [$ic, $label, $min, $g]): if (!role_at_least($user['role'], $min)) continue;
      if ($g !== $grp) { $grp = $g; if ($groups[$g] !== '') echo '<div class="sidebar-group">' . e($groups[$g]) . '</div>'; } ?>
      <a class="<?= $active === $key ? 'active' : '' ?>" href="<?= e(admin_url($key)) ?>"><i class="bi <?= $ic ?>"></i> <?= e($label) ?>
        <?php if ($key === 'requests' && $newReq): ?><span class="badge bg-warning text-dark ms-auto"><?= $newReq ?></span><?php endif; ?>
        <?php if ($key === 'users' && $pendingUsers): ?><span class="badge bg-danger ms-auto" title="طلبات انضمام"><?= $pendingUsers ?></span><?php endif; ?>
        <?php if ($key === 'notifications' && $unread): ?><span class="badge bg-info text-dark ms-auto"><?= $unread ?></span><?php endif; ?>
        <?php if ($key === 'messages' && $newMsg): ?><span class="badge bg-danger ms-auto" title="رسائل جديدة"><?= $newMsg ?></span><?php endif; ?>
        <?php if ($key === 'testimonials' && $pendingRev): ?><span class="badge bg-warning text-dark ms-auto" title="آراء بانتظار المراجعة"><?= $pendingRev ?></span><?php endif; ?>
        <?php if ($key === 'update' && $pendingMig): ?><span class="badge bg-danger ms-auto">!</span><?php endif; ?>
      </a>
    <?php endforeach; ?>
    <hr>
    <a href="<?= e(route('home')) ?>" target="_blank"><i class="bi bi-box-arrow-up-left"></i> عرض الموقع</a>
  </nav>
</aside>
<div class="admin-main">
  <header class="admin-topbar">
    <button class="btn btn-light d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#admin-sidebar" aria-label="القائمة"><i class="bi bi-list"></i></button>
    <h1 class="h5 mb-0"><?= e($title) ?></h1>
    <div class="dropdown ms-auto">
      <button class="btn btn-light position-relative" data-bs-toggle="dropdown" aria-label="الإشعارات"><i class="bi bi-bell"></i>
        <?php if ($unread): ?><span class="position-absolute top-0 start-0 translate-middle badge rounded-pill bg-danger"><?= $unread > 9 ? '9+' : $unread ?></span><?php endif; ?></button>
      <div class="dropdown-menu dropdown-menu-end notif-dropdown p-0">
        <div class="px-3 py-2 border-bottom fw-bold">الإشعارات</div>
        <?php if (!$latestNotifs): ?><div class="p-3 text-muted small">لا توجد إشعارات.</div><?php endif; ?>
        <?php foreach ($latestNotifs as $n): ?>
          <a class="dropdown-item notif-mini<?= $n['read_at'] ? '' : ' unread' ?>" href="<?= e(admin_url('notifications', ['open' => $n['id']])) ?>">
            <strong><?= e($n['title']) ?></strong><small><?= e(ar_date($n['created_at'], true)) ?></small></a>
        <?php endforeach; ?>
        <a class="dropdown-item text-center small border-top py-2" href="<?= e(admin_url('notifications')) ?>">عرض الكل</a>
      </div>
    </div>
    <div class="dropdown">
      <button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-person-circle"></i> <span class="d-none d-sm-inline"><?= e($user['name']) ?></span></button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><span class="dropdown-item-text small text-muted"><?= e(role_labels()[$user['role']] ?? '') ?></span></li>
        <li><a class="dropdown-item" href="<?= e(admin_url('profile')) ?>"><i class="bi bi-person-gear"></i> ملفي وكلمة المرور</a></li>
        <li><a class="dropdown-item" href="<?= e(route('account')) ?>"><i class="bi bi-person"></i> حسابي في الموقع</a></li>
        <li><hr class="dropdown-divider"></li>
        <li>
          <form method="post" action="<?= e(admin_url('logout')) ?>"><?= csrf_field() ?><button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right"></i> تسجيل الخروج</button></form>
        </li>
      </ul>
    </div>
  </header>
  <main class="admin-content">
    <?php if ($pendingMig && $active !== 'update'): ?>
      <div class="alert alert-warning d-flex align-items-center gap-2"><i class="bi bi-database-exclamation fs-5"></i>
        <div>يوجد <?= count($pendingMig) ?> تحديث لقاعدة البيانات بانتظار التطبيق (إضافات آمنة لا تحذف أي بيانات).
        <?php if (role_at_least($user['role'], 'super_admin')): ?><a class="alert-link" href="<?= e(admin_url('update')) ?>">مراجعة وتطبيق التحديث</a><?php else: ?>يرجى إبلاغ المدير العام.<?php endif; ?></div></div>
    <?php endif; ?>
    <?php foreach (get_flashes() as $f): ?>
      <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show"><?= e($f['message']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endforeach;
}

function admin_footer(): void
{
    ?>
  </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
<script src="<?= asset('js/admin.js') ?>"></script>
</body>
</html>
<?php
}

/** الجداول التي تدعم سلة المحذوفات: الجدول => [الوصف، عمود الاسم، صلاحية أدنى] */
function trash_tables(): array
{
    return [
        'categories'       => ['الأقسام', 'name', 'admin'],
        'subcategories'    => ['التخصصات', 'name', 'admin'],
        'services'         => ['الخدمات', 'name', 'editor'],
        'portfolio_items'  => ['معرض الأعمال', 'title', 'editor'],
        'testimonials'     => ['آراء العملاء', 'name', 'editor'],
        'contact_messages' => ['الرسائل', 'subject', 'editor'],
        'posts'            => ['المقالات والصفحات', 'title', 'editor'],
    ];
}

/**
 * حذف مؤقت (سلة المحذوفات): يُخفي العنصر من كل مكان دون حذف بياناته أو صوره.
 * قبل ترقية v5 (لا يوجد عمود deleted_at) يُعاد false ولا يُحذف شيء.
 */
function soft_delete(string $table, int $id): bool
{
    if (!isset(trash_tables()[$table]) || !has_col($table, 'deleted_at')) return false;
    $set = 'deleted_at = NOW()' . (has_col($table, 'is_active') ? ', is_active = 0' : '');
    db_exec("UPDATE `$table` SET $set WHERE id = ? AND deleted_at IS NULL", [$id]);
    return true;
}

function soft_restore(string $table, int $id): bool
{
    if (!isset(trash_tables()[$table]) || !has_col($table, 'deleted_at')) return false;
    $set = 'deleted_at = NULL' . (has_col($table, 'is_active') ? ', is_active = 1' : '');
    db_exec("UPDATE `$table` SET $set WHERE id = ?", [$id]);
    return true;
}

/** تبديل ترتيب عنصر مع جاره (أعلى/أسفل) ضمن نطاق محدد */
function move_item(string $table, int $id, string $dir, ?string $scopeCol = null): void
{
    $table = preg_replace('/[^a-z_]/', '', $table);
    $row = db_one("SELECT * FROM `$table` WHERE id = ?", [$id]);
    if (!$row) return;
    $scopeSql = '';
    $params = [];
    if ($scopeCol) {
        $scopeCol = preg_replace('/[^a-z_]/', '', $scopeCol);
        if ($row[$scopeCol] === null) { $scopeSql = " AND `$scopeCol` IS NULL"; }
        else { $scopeSql = " AND `$scopeCol` = ?"; $params[] = $row[$scopeCol]; }
    }
    // تطبيع الترتيب أولًا لضمان قيم فريدة
    $all = db_all("SELECT id FROM `$table` WHERE 1=1 $scopeSql ORDER BY sort_order, id", $params);
    $ids = array_column($all, 'id');
    $pos = array_search($row['id'], $ids);
    $swap = $dir === 'up' ? $pos - 1 : $pos + 1;
    if ($pos === false || $swap < 0 || $swap >= count($ids)) return;
    [$ids[$pos], $ids[$swap]] = [$ids[$swap], $ids[$pos]];
    $pdo = db();
    $pdo->beginTransaction();
    foreach ($ids as $i => $rid) db_exec("UPDATE `$table` SET sort_order = ? WHERE id = ?", [($i + 1) * 10, $rid]);
    $pdo->commit();
}

/** ترقيم الصفحات */
function paginate(int $total, int $perPage, int $page): array
{
    $pages = max(1, (int) ceil($total / $perPage));
    $page = min(max(1, $page), $pages);
    return ['page' => $page, 'pages' => $pages, 'offset' => ($page - 1) * $perPage, 'limit' => $perPage, 'total' => $total];
}

function pagination_links(array $p, array $query): string
{
    if ($p['pages'] <= 1) return '';
    $html = '<nav><ul class="pagination pagination-sm justify-content-center flex-wrap">';
    for ($i = 1; $i <= $p['pages']; $i++) {
        if ($p['pages'] > 12 && abs($i - $p['page']) > 3 && $i !== 1 && $i !== $p['pages']) {
            if (abs($i - $p['page']) === 4) $html .= '<li class="page-item disabled"><span class="page-link">…</span></li>';
            continue;
        }
        $q = http_build_query(array_merge($query, ['page' => $i]));
        $html .= '<li class="page-item' . ($i === $p['page'] ? ' active' : '') . '"><a class="page-link" href="?' . e($q) . '">' . $i . '</a></li>';
    }
    return $html . '</ul></nav>';
}

/** زر حذف بنموذج POST محمي */
function delete_button(string $action, int $id, string $confirm = 'هل أنت متأكد من الحذف؟', string $extra = ''): string
{
    return '<form method="post" class="d-inline" data-confirm="' . e($confirm) . '">' . csrf_field()
        . '<input type="hidden" name="action" value="' . e($action) . '"><input type="hidden" name="id" value="' . $id . '">' . $extra
        . '<button class="btn btn-sm btn-outline-danger" title="حذف"><i class="bi bi-trash"></i></button></form>';
}

function move_buttons(int $id): string
{
    $f = fn($dir, $ic) => '<form method="post" class="d-inline">' . csrf_field() . '<input type="hidden" name="action" value="move"><input type="hidden" name="id" value="' . $id . '"><input type="hidden" name="dir" value="' . $dir . '"><button class="btn btn-sm btn-light" title="' . ($dir === 'up' ? 'أعلى' : 'أسفل') . '"><i class="bi ' . $ic . '"></i></button></form>';
    return '<div class="btn-group">' . $f('up', 'bi-arrow-up') . $f('down', 'bi-arrow-down') . '</div>';
}

function active_badge($v): string
{
    return (int) $v ? '<span class="badge text-bg-success">مفعّل</span>' : '<span class="badge text-bg-secondary">معطّل</span>';
}

/** slug فريد في جدول */
function unique_slug(string $table, string $slug, ?int $ignoreId = null, ?string $scopeCol = null, $scopeVal = null): string
{
    $table = preg_replace('/[^a-z_]/', '', $table);
    $base = $slug !== '' ? $slug : 'item';
    $i = 1;
    while (true) {
        $sql = "SELECT COUNT(*) FROM `$table` WHERE slug = ?";
        $params = [$slug];
        if ($ignoreId) { $sql .= ' AND id <> ?'; $params[] = $ignoreId; }
        if ($scopeCol) { $sql .= ' AND `' . preg_replace('/[^a-z_]/', '', $scopeCol) . '` = ?'; $params[] = $scopeVal; }
        if ((int) db_value($sql, $params) === 0) return $slug;
        $slug = $base . '-' . (++$i);
    }
}

function icon_picker_list(): array
{
    return ['bi-mortarboard', 'bi-buildings', 'bi-code-slash', 'bi-palette', 'bi-person-badge', 'bi-translate', 'bi-lightbulb', 'bi-signpost-split',
        'bi-journal-text', 'bi-file-earmark-richtext', 'bi-pencil-square', 'bi-person-video3', 'bi-easel', 'bi-bar-chart-line', 'bi-journal-bookmark',
        'bi-bank', 'bi-cone-striped', 'bi-gear-wide-connected', 'bi-nut', 'bi-lightning-charge', 'bi-cpu', 'bi-rulers', 'bi-box', 'bi-droplet-half',
        'bi-globe2', 'bi-phone', 'bi-terminal', 'bi-database', 'bi-robot', 'bi-shield-lock', 'bi-vector-pen', 'bi-camera-reels', 'bi-badge-3d',
        'bi-images', 'bi-file-person', 'bi-briefcase', 'bi-card-text', 'bi-file-earmark-word', 'bi-laptop', 'bi-chat-square-quote', 'bi-heart-pulse',
        'bi-house-check', 'bi-grid', 'bi-folder2-open', 'bi-award', 'bi-calculator', 'bi-book', 'bi-brush', 'bi-camera', 'bi-diagram-3'];
}
