<?php
/**
 * رأس الصفحات العامة.
 * المتغيرات المتوقعة (اختيارية): $page_title, $page_description, $page_canonical, $page_image, $page_type,
 *  $breadcrumbs = [['label','url'],...], $json_ld = [ ... ], $active_nav, $body_class
 */
$siteName   = setting('site_name', 'اختيارك للخدمات الطلابية');
$tagline    = setting('site_tagline', 'اختيارك الذكي نحو التميز والنجاح');
$isHome     = ($active_nav ?? '') === 'home';
$title      = isset($page_title) && $page_title ? $page_title . ' | ' . $siteName : (setting('seo_home_title') ?: $siteName . ' — ' . $tagline);
if (mb_strlen($title) > 70 && isset($page_title) && $page_title) $title = $page_title; // عنوان طويل: نكتفي بعنوان الصفحة
$desc       = (string) ($page_description ?? '') ?: setting('site_description', '');
$canonical  = $page_canonical ?? absolute_url(ltrim(substr((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), strlen(base_path())), '/'));
$ogCustom   = setting('og_image_path', '');
$ogImage    = $page_image ?? ($ogCustom && is_file(PUBLIC_PATH . '/' . $ogCustom) ? absolute_url($ogCustom) : absolute_url('assets/images/og-cover.png'));
$favCustom  = setting('favicon_path', '');
$favicon    = $favCustom && is_file(PUBLIC_PATH . '/' . $favCustom) ? url($favCustom) : url('assets/images/logo.svg');
$fonts      = font_choices();
$fontKey    = isset($fonts[setting('font_family', 'Cairo')]) ? setting('font_family', 'Cairo') : 'Cairo';
$defTheme   = in_array(setting('default_theme', 'auto'), ['auto', 'light', 'dark'], true) ? setting('default_theme', 'auto') : 'auto';
$noindexAll = setting('site_noindex', '0') === '1';
$portfolioOn = portfolio_enabled() && array_sum(portfolio_counts_by_category()) > 0;
$logoCustom = setting('logo_path', '');
$logoSrc    = $logoCustom ? url($logoCustom) : url('assets/images/logo.svg');
$active_nav = $active_nav ?? '';
$tree       = catalog_tree();
$cPrimary   = preg_match('/^#[0-9a-f]{6}$/i', setting('color_primary', '')) ? setting('color_primary') : '#0b1f3a';
$cGold      = preg_match('/^#[0-9a-f]{6}$/i', setting('color_gold', '')) ? setting('color_gold') : '#c9a24d';
$cSky       = preg_match('/^#[0-9a-f]{6}$/i', setting('color_sky', '')) ? setting('color_sky') : '#38bdf8';
$navItems = [
    'home'            => ['الرئيسية', route('home'), 'bi-house'],
    'services'        => ['جميع الخدمات', route('services'), 'bi-grid'],
    'specializations' => ['التخصصات', route('specializations'), 'bi-diagram-3'],
    'portfolio'       => ['أعمالنا', route('portfolio'), 'bi-collection'],
    'how'             => ['كيف نعمل', route('home') . '#steps-section', 'bi-signpost-split'],
    'faq'             => ['الأسئلة الشائعة', route('faq'), 'bi-question-circle'],
    'contact'         => ['تواصل معنا', route('contact'), 'bi-chat-dots'],
];
if (!$portfolioOn) unset($navItems['portfolio']); else unset($navItems['how']);
// v5: رابط المقالات يظهر فقط عند وجود مقالات منشورة
if (function_exists('articles_enabled') && articles_enabled() && posts_count('article') > 0) {
    $navItems = array_slice($navItems, 0, count($navItems) - 2, true) + ['blog' => ['المقالات', route('blog'), 'bi-newspaper']] + array_slice($navItems, -2, null, true);
}
?><!doctype html>
<html lang="ar" dir="rtl" data-bs-theme="<?= $defTheme === 'dark' ? 'dark' : 'light' ?>" data-default-theme="<?= e($defTheme) ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($title) ?></title>
  <meta name="description" content="<?= e(excerpt($desc, 300)) ?>">
  <link rel="canonical" href="<?= e($canonical) ?>">
  <?php if ($noindexAll): ?><meta name="robots" content="noindex,nofollow"><?php elseif (!empty($noindex)): ?><meta name="robots" content="noindex,follow"><?php else: ?><meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1"><?php endif; ?>
  <?php if ($gv = setting('google_verification')): ?><meta name="google-site-verification" content="<?= e(preg_replace('/[^A-Za-z0-9_\-]/', '', $gv)) ?>"><?php endif; ?>
  <?php if ($bv = setting('bing_verification')): ?><meta name="msvalidate.01" content="<?= e(preg_replace('/[^A-Za-z0-9_\-]/', '', $bv)) ?>"><?php endif; ?>
  <?php if ($isHome && ($kw = setting('seo_keywords'))): ?><meta name="keywords" content="<?= e(implode(', ', csv_items($kw))) ?>"><?php endif; ?>
  <link rel="alternate" hreflang="ar" href="<?= e($canonical) ?>">
  <meta name="theme-color" content="<?= e($cPrimary) ?>">
  <meta property="og:type" content="<?= e($page_type ?? 'website') ?>">
  <meta property="og:site_name" content="<?= e($siteName) ?>">
  <meta property="og:locale" content="ar_SA">
  <meta property="og:title" content="<?= e($title) ?>">
  <meta property="og:description" content="<?= e(excerpt($desc, 200)) ?>">
  <meta property="og:url" content="<?= e($canonical) ?>">
  <meta property="og:image" content="<?= e($ogImage) ?>">
  <meta property="og:image:alt" content="<?= e($page_title ?? $siteName) ?>">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= e($title) ?>">
  <meta name="twitter:description" content="<?= e(excerpt($desc, 200)) ?>">
  <meta name="twitter:image" content="<?= e($ogImage) ?>">
  <link rel="icon" href="<?= e($favicon) ?>"<?= str_ends_with($favicon, '.svg') ? ' type="image/svg+xml"' : '' ?>>
  <link rel="apple-touch-icon" href="<?= e($favicon) ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=<?= $fonts[$fontKey][0] ?><?= $fontKey !== 'Tajawal' ? '&family=Tajawal:wght@400;500;700' : '' ?>&display=swap">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" integrity="sha384-dpuaG1suU0eT09tx5plTaGMLBsfDLzUCCUXOY2j/LSvXYuG6Bqs43ALlhIqAJVRb" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
  <link rel="stylesheet" href="<?= asset('css/v3.css') ?>">
  <link rel="stylesheet" href="<?= asset('css/v5.css') ?>">
  <style>:root{--ikh-navy:<?= e($cPrimary) ?>;--ikh-gold:<?= e($cGold) ?>;--ikh-sky:<?= e($cSky) ?>;--ikh-font:<?= $fonts[$fontKey][1] ?>,"Tajawal",system-ui,-apple-system,"Segoe UI",Tahoma,sans-serif;}</style>
  <script src="<?= asset('js/theme.js') ?>"></script>
  <?php if (($ga = setting('ga4_id')) && preg_match('/^G-[A-Z0-9]{4,15}$/', $ga) && !current_admin()): ?>
  <script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($ga) ?>"></script>
  <script src="<?= asset('js/ga.js') ?>" data-ga="<?= e($ga) ?>" id="ga-config"></script>
  <?php endif; ?>
  <?php
  $sameAs = array_column(social_links(), 'url');
  $org = [
      '@context' => 'https://schema.org', '@type' => 'ProfessionalService', '@id' => absolute_url() . '#organization',
      'name' => $siteName, 'alternateName' => 'اختيارك', 'slogan' => $tagline, 'description' => setting('site_description'),
      'url' => absolute_url(), 'logo' => absolute_url($logoCustom ?: 'assets/images/logo.svg'), 'image' => $ogImage,
      'telephone' => '+' . whatsapp_number(), 'priceRange' => '$$',
      'contactPoint' => ['@type' => 'ContactPoint', 'telephone' => '+' . whatsapp_number(), 'contactType' => 'customer service', 'availableLanguage' => ['Arabic', 'English']],
  ];
  if ($sameAs) $org['sameAs'] = $sameAs;
  if ($city = setting('business_city')) $org['address'] = ['@type' => 'PostalAddress', 'addressLocality' => $city, 'addressCountry' => setting('area_served', 'SA') ?: 'SA'];
  if ($area = setting('area_served')) $org['areaServed'] = $area;
  if ($em = setting('contact_email')) $org['email'] = $em;
  if ($isHome) {
      $org['hasOfferCatalog'] = ['@type' => 'OfferCatalog', 'name' => 'خدمات ' . $siteName, 'itemListElement' => array_values(array_map(fn($c) => [
          '@type' => 'OfferCatalog', 'name' => $c['name'], 'url' => absolute_url(ltrim(substr(route('category', ['slug' => $c['slug']]), strlen(base_path())), '/')),
      ], $tree))];
  }
  $ld = [$org];
  if (!empty($breadcrumbs)) {
      $items = [['@type' => 'ListItem', 'position' => 1, 'name' => 'الرئيسية', 'item' => absolute_url()]];
      foreach ($breadcrumbs as $i => $b) {
          $items[] = ['@type' => 'ListItem', 'position' => $i + 2, 'name' => $b[0]] + (!empty($b[1]) ? ['item' => absolute_url(ltrim(substr($b[1], strlen(base_path())), '/'))] : []);
      }
      $ld[] = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items];
  }
  if (!empty($json_ld)) $ld = array_merge($ld, $json_ld);
  foreach ($ld as $block): ?>
  <script type="application/ld+json"><?= json_encode($block, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
  <?php endforeach; ?>
</head>
<body class="<?= e(trim(($body_class ?? '') . (section_on('bottom_nav') ? '' : ' no-bnav'))) ?>" data-base="<?= e(base_path()) ?>" data-pretty="<?= pretty_urls() ? '1' : '0' ?>">
<a class="skip-link" href="#main-content">تخطَّ إلى المحتوى</a>
<?php if ($ann = setting('announcement_text')): $annLink = setting('announcement_link'); ?>
<div class="announce-bar" role="note" data-announce="<?= e(substr(md5($ann), 0, 8)) ?>"><div class="container"><span class="announce-pulse" aria-hidden="true"></span><i class="bi bi-megaphone-fill"></i> <?php if ($annLink): ?><a href="<?= e($annLink) ?>"><?= e($ann) ?> <i class="bi bi-arrow-left-short"></i></a><?php else: ?><span><?= e($ann) ?></span><?php endif; ?><button type="button" class="announce-close" aria-label="إخفاء الإعلان"><i class="bi bi-x-lg"></i></button></div></div>
<?php endif; ?>

<header id="site-header" class="site-header">
  <nav class="navbar navbar-expand-lg" aria-label="القائمة الرئيسية">
    <div class="container">
      <a class="navbar-brand brand" href="<?= e(route('home')) ?>">
        <img src="<?= e($logoSrc) ?>" alt="شعار <?= e($siteName) ?>" width="44" height="44">
        <span class="brand-text">
          <strong>اختيارك</strong>
          <small>للخدمات الطلابية</small>
        </span>
      </a>
      <div class="d-flex align-items-center gap-2 order-lg-last">
        <button class="btn btn-icon" type="button" data-open-search aria-label="البحث عن خدمة" title="بحث (/)"><i class="bi bi-search"></i></button>
        <?php if (setting('allow_dark_toggle', '1') === '1'): ?><button class="btn btn-icon" type="button" id="theme-toggle" aria-label="تبديل الوضع الداكن"><i class="bi bi-moon-stars"></i></button><?php endif; ?>
        <?php $cu = current_user(); if ($cu): ?>
          <div class="dropdown">
            <button class="btn btn-icon user-btn" data-bs-toggle="dropdown" aria-label="حسابي"><span><?= e(mb_substr($cu['name'], 0, 1)) ?></span><?php if ($nc = (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL', [$cu['id']])): ?><b class="dot"><?= $nc ?></b><?php endif; ?></button>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><span class="dropdown-item-text small"><strong><?= e($cu['name']) ?></strong><br><span class="text-muted"><?= e(role_labels()[$cu['role']] ?? '') ?></span></span></li>
              <li><hr class="dropdown-divider"></li>
              <?php if (in_array($cu['role'], staff_roles(), true)): ?><li><a class="dropdown-item" href="<?= e(admin_url()) ?>"><i class="bi bi-speedometer2"></i> لوحة التحكم</a></li><?php endif; ?>
              <li><a class="dropdown-item" href="<?= e(route('account')) ?>"><i class="bi bi-person"></i> حسابي وطلباتي</a></li>
              <li><a class="dropdown-item" href="<?= e(route('account', ['tab' => 'notifications'])) ?>"><i class="bi bi-bell"></i> الإشعارات<?= $nc ? ' (' . $nc . ')' : '' ?></a></li>
              <li><hr class="dropdown-divider"></li>
              <li><form method="post" action="<?= e(route('logout')) ?>"><?= csrf_field() ?><button class="dropdown-item text-danger"><i class="bi bi-box-arrow-right"></i> خروج</button></form></li>
            </ul>
          </div>
        <?php else: ?>
          <a class="btn btn-outline-navy btn-sm d-none d-sm-inline-flex" href="<?= e(route('login')) ?>"><i class="bi bi-person"></i> دخول</a>
        <?php endif; ?>
        <a class="btn btn-gold btn-sm d-none d-md-inline-flex header-cta" href="<?= e(route('order')) ?>"><i class="bi bi-lightning-charge-fill"></i> <?= e(setting('header_cta_text', 'اطلب خدمتك')) ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobile-nav" aria-controls="mobile-nav" aria-label="فتح القائمة">
          <i class="bi bi-list"></i>
        </button>
      </div>
      <div class="collapse navbar-collapse" id="main-nav">
        <ul class="navbar-nav mx-auto">
          <?php foreach ($navItems as $key => [$label, $href, $navIc]): ?>
            <?php if ($key === 'services'): ?>
              <li class="nav-item dropdown mega">
                <a class="nav-link dropdown-toggle<?= $active_nav === $key ? ' active' : '' ?>" href="<?= e($href) ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false"><?= e($label) ?></a>
                <div class="dropdown-menu mega-menu">
                  <div class="row g-2">
                    <?php foreach ($tree as $c): ?>
                      <div class="col-lg-3">
                        <a class="mega-item tone-<?= e(category_tone($c['slug'])) ?>" href="<?= e(route('category', ['slug' => $c['slug']])) ?>">
                          <span class="mega-icon"><?= icon($c['icon']) ?></span>
                          <span><?= e($c['name']) ?><small><?= count($c['subs']) ?> تخصص • <?= count($c['services']) ?> خدمة</small></span>
                        </a>
                      </div>
                    <?php endforeach; ?>
                  </div>
                  <div class="mega-footer">
                    <a href="<?= e($href) ?>"><i class="bi bi-grid"></i> عرض جميع الخدمات</a>
                    <a href="<?= e(route('specializations')) ?>"><i class="bi bi-diagram-3"></i> دليل التخصصات</a>
                    <a href="<?= e(route('order')) ?>" class="mega-cta"><i class="bi bi-lightning-charge-fill"></i> لم تجد خدمتك؟ اطلب أي شيء</a>
                  </div>
                </div>
              </li>
            <?php else: ?>
              <li class="nav-item"><a class="nav-link<?= $active_nav === $key ? ' active' : '' ?>" href="<?= e($href) ?>"<?= $active_nav === $key ? ' aria-current="page"' : '' ?>><?= e($label) ?></a></li>
            <?php endif; ?>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </nav>
</header>

<!-- قائمة الجوال -->
<aside class="offcanvas offcanvas-end mobile-nav" tabindex="-1" id="mobile-nav" aria-labelledby="mobile-nav-title">
  <div class="offcanvas-header">
    <h2 class="offcanvas-title h5" id="mobile-nav-title"><img src="<?= e($logoSrc) ?>" alt="" width="34" height="34"> اختيارك</h2>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="إغلاق"></button>
  </div>
  <div class="offcanvas-body">
    <form class="mobile-search mb-3" action="<?= e(route('search')) ?>" method="get" role="search">
      <input class="form-control" type="search" name="q" placeholder="ابحث عن خدمة..." aria-label="بحث">
    </form>
    <ul class="list-unstyled">
      <?php foreach ($navItems as $key => [$label, $href, $navIc]): ?>
        <li><a class="mobile-link<?= $active_nav === $key ? ' active' : '' ?>" href="<?= e($href) ?>"><i class="bi <?= $navIc ?>"></i> <?= e($label) ?></a></li>
      <?php endforeach; ?>
      <li><a class="mobile-link" href="<?= e(route('about')) ?>"><i class="bi bi-info-circle"></i> من نحن</a></li>
      <?php if (!$portfolioOn): ?><?php elseif (!isset($navItems['how'])): ?><li><a class="mobile-link" href="<?= e(route('home')) ?>#steps-section"><i class="bi bi-signpost-split"></i> كيف نعمل</a></li><?php endif; ?>
    </ul>
    <p class="mobile-subtitle">الأقسام</p>
    <div class="mobile-cats">
      <?php foreach ($tree as $c): ?>
        <a class="mobile-cat tone-<?= e(category_tone($c['slug'])) ?>" href="<?= e(route('category', ['slug' => $c['slug']])) ?>"><span><?= icon($c['icon']) ?></span><?= e($c['name']) ?></a>
      <?php endforeach; ?>
    </div>
    <a class="btn btn-whatsapp w-100 mt-3" href="<?= e(wa_service_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب خدمتك عبر واتساب</a>
    <?php if (current_user()): ?>
      <a class="btn btn-outline-navy w-100 mt-2" href="<?= e(route('account')) ?>"><i class="bi bi-person"></i> حسابي</a>
      <?php if (current_admin()): ?><a class="btn btn-navy w-100 mt-2" href="<?= e(admin_url()) ?>"><i class="bi bi-speedometer2"></i> لوحة التحكم</a><?php endif; ?>
    <?php else: ?>
      <a class="btn btn-outline-navy w-100 mt-2" href="<?= e(route('login')) ?>"><i class="bi bi-person"></i> تسجيل الدخول (اختياري)</a>
    <?php endif; ?>
  </div>
</aside>

<!-- البحث الشامل -->
<div class="search-overlay" id="search-overlay" role="dialog" aria-modal="true" aria-label="البحث عن خدمة" hidden>
  <div class="search-overlay-inner">
    <div class="d-flex align-items-center justify-content-between mb-3">
      <strong class="fs-5"><i class="bi bi-search text-warning"></i> عن ماذا تبحث؟</strong>
      <button type="button" class="btn btn-icon" data-close-search aria-label="إغلاق البحث"><i class="bi bi-x-lg"></i></button>
    </div>
    <?= render_search_box('', 'lg', 'overlay-search') ?>
    <p class="search-hint">جرّب: <?php foreach (['بحث تخرج', 'أوتوكاد', 'SPSS', 'سيرة ذاتية', 'بوربوينت', 'تطبيق جوال'] as $h): ?><a href="<?= e(route('search', ['q' => $h])) ?>"><?= e($h) ?></a><?php endforeach; ?></p>
    <p class="mobile-subtitle mt-3">أو تصفح الأقسام</p>
    <div class="mobile-cats">
      <?php foreach ($tree as $c): ?><a class="mobile-cat tone-<?= e(category_tone($c['slug'])) ?>" href="<?= e(route('category', ['slug' => $c['slug']])) ?>"><span><?= icon($c['icon']) ?></span><?= e($c['name']) ?></a><?php endforeach; ?>
    </div>
  </div>
</div>

<main id="main-content">
<?php if (!empty($breadcrumbs)): ?>
  <nav class="breadcrumb-bar" aria-label="مسار التنقل">
    <div class="container">
      <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="<?= e(route('home')) ?>"><i class="bi bi-house-door"></i> الرئيسية</a></li>
        <?php foreach ($breadcrumbs as $i => $b): ?>
          <?php if ($i === count($breadcrumbs) - 1 || empty($b[1])): ?>
            <li class="breadcrumb-item active" aria-current="page"><?= e($b[0]) ?></li>
          <?php else: ?>
            <li class="breadcrumb-item"><a href="<?= e($b[1]) ?>"><?= e($b[0]) ?></a></li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ol>
    </div>
  </nav>
<?php endif; ?>
<?php foreach (get_flashes() as $f): ?>
  <div class="container mt-3"><div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show" role="alert"><?= e($f['message']) ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="إغلاق"></button></div></div>
<?php endforeach; ?>
