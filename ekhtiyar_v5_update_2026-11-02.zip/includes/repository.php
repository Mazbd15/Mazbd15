<?php
/**
 * طبقة الوصول للبيانات العامة + محرك البحث.
 */
declare(strict_types=1);

function categories_active(): array
{
    static $c = null;
    return $c ??= db_all(
        'SELECT c.*, (SELECT COUNT(*) FROM services s WHERE s.category_id = c.id AND s.is_active = 1) AS services_count,
                (SELECT COUNT(*) FROM subcategories sc WHERE sc.category_id = c.id AND sc.is_active = 1) AS subs_count
         FROM categories c WHERE c.is_active = 1 ORDER BY c.sort_order, c.id'
    );
}

function category_by_slug(string $slug): ?array
{
    return db_one('SELECT * FROM categories WHERE slug = ? AND is_active = 1', [$slug]);
}

function subcategories_of(int $categoryId): array
{
    return db_all(
        'SELECT sc.*, (SELECT COUNT(*) FROM services s WHERE s.subcategory_id = sc.id AND s.is_active = 1) AS services_count
         FROM subcategories sc WHERE sc.category_id = ? AND sc.is_active = 1 ORDER BY sc.sort_order, sc.id',
        [$categoryId]
    );
}

function subcategory_by_slug(int $categoryId, string $slug): ?array
{
    return db_one('SELECT * FROM subcategories WHERE category_id = ? AND slug = ? AND is_active = 1', [$categoryId, $slug]);
}

const SERVICE_SELECT = 'SELECT s.*, c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon,
        sc.name AS subcategory_name, sc.slug AS subcategory_slug
    FROM services s
    JOIN categories c ON c.id = s.category_id AND c.is_active = 1
    LEFT JOIN subcategories sc ON sc.id = s.subcategory_id';

function services_by_category(int $categoryId, ?int $subId = null): array
{
    if ($subId) {
        return db_all(SERVICE_SELECT . ' WHERE s.is_active = 1 AND s.subcategory_id = ? ORDER BY s.sort_order, s.id', [$subId]);
    }
    return db_all(SERVICE_SELECT . ' WHERE s.is_active = 1 AND s.category_id = ? AND (sc.id IS NULL OR sc.is_active = 1) ORDER BY sc.sort_order, s.sort_order, s.id', [$categoryId]);
}

function service_by_slug(string $slug): ?array
{
    return db_one(SERVICE_SELECT . ' WHERE s.slug = ? AND s.is_active = 1 AND (sc.id IS NULL OR sc.is_active = 1)', [$slug]);
}

function services_popular(int $limit = 8): array
{
    return db_all(SERVICE_SELECT . ' WHERE s.is_active = 1 AND s.is_popular = 1 ORDER BY s.sort_order, s.views DESC LIMIT ' . (int) $limit);
}

function services_featured(int $limit = 6): array
{
    return db_all(SERVICE_SELECT . ' WHERE s.is_active = 1 AND s.is_featured = 1 ORDER BY s.sort_order LIMIT ' . (int) $limit);
}

function services_related(array $service, int $limit = 4): array
{
    $rows = db_all(
        SERVICE_SELECT . ' WHERE s.is_active = 1 AND s.id <> ? AND (s.subcategory_id <=> ? OR s.category_id = ?)
         ORDER BY (s.subcategory_id <=> ?) DESC, s.is_popular DESC, s.sort_order LIMIT ' . (int) $limit,
        [$service['id'], $service['subcategory_id'], $service['category_id'], $service['subcategory_id']]
    );
    return $rows;
}

function faqs_for(?int $categoryId = null, ?int $serviceId = null, bool $homeOnly = false, int $limit = 50): array
{
    if ($serviceId) {
        return db_all('SELECT * FROM faqs WHERE is_active = 1 AND service_id = ? ORDER BY sort_order, id LIMIT ' . (int) $limit, [$serviceId]);
    }
    if ($categoryId) {
        return db_all('SELECT * FROM faqs WHERE is_active = 1 AND category_id = ? AND service_id IS NULL ORDER BY sort_order, id LIMIT ' . (int) $limit, [$categoryId]);
    }
    $where = 'is_active = 1 AND category_id IS NULL AND service_id IS NULL' . ($homeOnly ? ' AND show_on_home = 1' : '');
    return db_all("SELECT * FROM faqs WHERE $where ORDER BY sort_order, id LIMIT " . (int) $limit);
}

/** شجرة كاملة للأقسام والتفرعات والخدمات — للقوائم ونموذج الطلب */
function catalog_tree(): array
{
    static $tree = null;
    if ($tree !== null) return $tree;
    $tree = [];
    foreach (db_all('SELECT id, name, slug, icon FROM categories WHERE is_active = 1 ORDER BY sort_order, id') as $c) {
        $tree[$c['id']] = $c + ['subs' => [], 'services' => []];
    }
    foreach (db_all('SELECT id, category_id, name, slug FROM subcategories WHERE is_active = 1 ORDER BY sort_order, id') as $s) {
        if (isset($tree[$s['category_id']])) $tree[$s['category_id']]['subs'][$s['id']] = $s + ['services' => []];
    }
    foreach (db_all('SELECT id, category_id, subcategory_id, name, slug, tools_text FROM services WHERE is_active = 1 ORDER BY sort_order, id') as $sv) {
        $cid = $sv['category_id'];
        if (!isset($tree[$cid])) continue;
        $item = ['id' => (int) $sv['id'], 'name' => $sv['name'], 'slug' => $sv['slug'], 'sub' => $sv['subcategory_id'] ? (int) $sv['subcategory_id'] : null];
        $tree[$cid]['services'][] = $item;
        if ($sv['subcategory_id'] && isset($tree[$cid]['subs'][$sv['subcategory_id']])) {
            $tree[$cid]['subs'][$sv['subcategory_id']]['services'][] = $item;
        }
    }
    return $tree;
}

function stats_public(): array
{
    return [
        'categories' => (int) db_value('SELECT COUNT(*) FROM categories WHERE is_active = 1'),
        'subs'       => (int) db_value('SELECT COUNT(*) FROM subcategories WHERE is_active = 1'),
        'services'   => (int) db_value('SELECT COUNT(*) FROM services WHERE is_active = 1'),
    ];
}

// =====================================================================
//  محرك البحث — تطبيع عربي + كلمات بديلة + ترتيب حسب الصلة
// =====================================================================

function ar_normalize(string $s): string
{
    $s = mb_strtolower($s, 'UTF-8');
    $s = preg_replace('/[\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $s); // تشكيل + تطويل
    $s = strtr($s, ['أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ٱ' => 'ا', 'ة' => 'ه', 'ى' => 'ي', 'ؤ' => 'و', 'ئ' => 'ي', '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9']);
    $s = preg_replace('/[^\p{L}\p{N}+#]+/u', ' ', $s);
    return trim(preg_replace('/\s+/u', ' ', (string) $s));
}

/** مجموعات الكلمات المترادفة الشائعة (عربي/إنجليزي/عامي) */
function search_synonyms(): array
{
    return [
        ['بحث', 'بحوث', 'ابحاث', 'research', 'رساله', 'دراسه', 'ورقه علميه', 'paper', 'thesis'],
        ['تقرير', 'تقارير', 'ريبورت', 'ربورت', 'report'],
        ['واجب', 'واجبات', 'تكليف', 'تكاليف', 'اسايمنت', 'اساينمنت', 'assignment', 'homework', 'هوم ورك'],
        ['مشروع', 'مشاريع', 'بروجكت', 'بروجيكت', 'project', 'تخرج'],
        ['عرض', 'عروض', 'بوربوينت', 'باوربوينت', 'بوربوينت', 'powerpoint', 'ppt', 'برزنتيشن', 'presentation', 'سلايدات'],
        ['اوتوكاد', 'اتوكاد', 'autocad', 'cad', 'كاد', 'dwg', 'dxf', 'رسم هندسي'],
        ['بلندر', 'blender', 'ثلاثي الابعاد', '3d', 'ثري دي', 'نمذجه', 'مجسم', 'رندر', 'render'],
        ['spss', 'اس بي اس اس', 'احصاء', 'احصائي', 'تحليل احصائي', 'تحليل بيانات'],
        ['php', 'بي اتش بي', 'mysql', 'موقع', 'مواقع', 'ويب', 'web'],
        ['cv', 'سي في', 'سيره ذاتيه', 'سيره', 'resume', 'ريزيومي'],
        ['اسمنت', 'خرسانه', 'concrete', 'انشائي', 'انشاءات', 'مدني', 'civil', 'تربه'],
        ['معماري', 'عماره', 'architecture', 'مخطط', 'مخططات', 'واجهات', 'مساقط'],
        ['صناعي', 'صناعيه', 'industrial', 'مصنع', 'مصانع', 'انتاج', 'جوده'],
        ['تصميم', 'جرافيك', 'graphic', 'شعار', 'لوجو', 'logo', 'هويه'],
        ['ترجمه', 'translation', 'ترجم', 'تدقيق', 'proofreading'],
        ['تلخيص', 'ملخص', 'ملخصات', 'summary', 'summarize'],
        ['برمجه', 'برمجي', 'كود', 'code', 'programming', 'بايثون', 'python', 'جافا', 'java'],
        ['تطبيق', 'تطبيقات', 'app', 'flutter', 'فلاتر', 'اندرويد', 'android', 'ios'],
        ['لاب', 'لابات', 'مختبر', 'مختبرات', 'lab'],
        ['شرح', 'دروس', 'درس', 'مذاكره', 'مراجعه', 'tutoring', 'خصوصي'],
        ['قاعده بيانات', 'قواعد بيانات', 'database', 'sql', 'erd', 'اكسس', 'access'],
        ['ذكاء اصطناعي', 'ai', 'تعلم الاله', 'machine learning', 'ml', 'علوم البيانات', 'data science'],
        ['شبكات', 'network', 'networks', 'امن سيبراني', 'سايبر', 'cyber', 'security'],
        ['فيديو', 'مونتاج', 'montage', 'video', 'موشن', 'motion'],
        ['نشر علمي', 'مجله', 'مجلات', 'journal', 'publication', 'محكمه'],
        ['اجازه', 'اجازه مرضيه', 'تقرير طبي', 'صحتي', 'تطعيم', 'شهاده صحيه', 'ايجار', 'عقد ايجار', 'ايجار'],
        ['كهربا', 'كهرباء', 'كهربائيه', 'electrical', 'دوائر', 'circuits', 'الكترونيات'],
        ['ميكانيكا', 'ميكانيكي', 'mechanical', 'سوليد ووركس', 'solidworks'],
    ];
}

function search_expand(string $query): array
{
    $q = ar_normalize($query);
    if ($q === '') return [];
    $terms = [$q => 3];
    foreach (explode(' ', $q) as $t) {
        if (mb_strlen($t) >= 2) $terms[$t] = max($terms[$t] ?? 0, 2);
        // إزالة "ال" التعريف
        if (mb_strlen($t) > 4 && str_starts_with($t, 'ال')) $terms[mb_substr($t, 2)] = 2;
    }
    foreach (search_synonyms() as $group) {
        $g = array_map('ar_normalize', $group);
        foreach ($g as $word) {
            $hit = false;
            foreach (array_keys($terms) as $t) {
                if ($t === $word || (mb_strlen($t) >= 3 && mb_strlen($word) >= 3 && (str_contains($t, $word) || str_contains($word, $t)))) { $hit = true; break; }
            }
            if ($hit) {
                foreach ($g as $w) $terms[$w] = max($terms[$w] ?? 0, 1);
                break;
            }
        }
    }
    return $terms;
}

/**
 * يعيد قائمة الخدمات مرتبة حسب الصلة.
 * الفلاتر: category (id), type (service_type)
 */
function search_services(string $query, array $filters = [], int $limit = 60): array
{
    $terms = search_expand($query);
    $where = 's.is_active = 1 AND (sc.id IS NULL OR sc.is_active = 1)';
    $params = [];
    if (!empty($filters['category'])) { $where .= ' AND s.category_id = ?'; $params[] = (int) $filters['category']; }
    if (!empty($filters['sub'])) { $where .= ' AND s.subcategory_id = ?'; $params[] = (int) $filters['sub']; }
    if (!empty($filters['type']) && isset(service_types()[$filters['type']])) { $where .= ' AND s.service_type = ?'; $params[] = $filters['type']; }
    $rows = db_all(SERVICE_SELECT . " WHERE $where", $params);

    if (!$terms) {
        usort($rows, fn($a, $b) => [$b['is_popular'], -$a['sort_order']] <=> [$a['is_popular'], -$b['sort_order']]);
        return array_slice($rows, 0, $limit);
    }

    $scored = [];
    foreach ($rows as $r) {
        $name = ar_normalize($r['name']);
        $kw   = ar_normalize((string) $r['keywords']);
        $sub  = ar_normalize((string) $r['subcategory_name']);
        $cat  = ar_normalize((string) $r['category_name']);
        $desc = ar_normalize($r['short_description'] . ' ' . $r['tools_text']);
        $score = 0;
        foreach ($terms as $t => $w) {
            if ($t === '') continue;
            if (str_contains($name, $t)) $score += 10 * $w + ($name === $t ? 20 : 0) + (str_starts_with($name, $t) ? 5 : 0);
            if (str_contains($kw, $t))   $score += 6 * $w;
            if (str_contains($sub, $t))  $score += 5 * $w;
            if (str_contains($cat, $t))  $score += 3 * $w;
            if (str_contains($desc, $t)) $score += 2 * $w;
        }
        if ($score > 0) {
            $score += (int) $r['is_popular'] * 2;
            $r['_score'] = $score;
            $scored[] = $r;
        }
    }
    usort($scored, fn($a, $b) => $b['_score'] <=> $a['_score'] ?: $a['sort_order'] <=> $b['sort_order']);
    return array_slice($scored, 0, $limit);
}

/** يزيد عداد المشاهدات مرة واحدة لكل جلسة */
function service_track_view(int $id): void
{
    $seen = $_SESSION['_viewed'] ?? [];
    if (in_array($id, $seen, true)) return;
    $seen[] = $id;
    $_SESSION['_viewed'] = array_slice($seen, -100);
    db_exec('UPDATE services SET views = views + 1 WHERE id = ?', [$id]);
}

/** الإعلانات النشطة لقسم معين أو للرئيسية (null) ضمن فترة العرض */
function banners_for(?int $categoryId, int $limit = 6): array
{
    $today = date('Y-m-d');
    $where = $categoryId ? 'category_id = ?' : 'category_id IS NULL';
    $params = $categoryId ? [$categoryId] : [];
    array_push($params, $today, $today);
    return db_all("SELECT * FROM banners WHERE is_active = 1 AND $where AND (starts_at IS NULL OR starts_at <= ?) AND (ends_at IS NULL OR ends_at >= ?) ORDER BY sort_order, id LIMIT " . (int) $limit, $params);
}

// =====================================================================
// معرض الأعمال (v4)
// =====================================================================
function portfolio_enabled(): bool
{
    return setting('portfolio_enabled', '1') === '1';
}

const PORTFOLIO_SELECT = 'SELECT p.*, c.name AS category_name, c.slug AS category_slug, c.icon AS category_icon,
        sc.name AS subcategory_name, sc.slug AS subcategory_slug, s.name AS service_name, s.slug AS service_slug,
        (SELECT COUNT(*) FROM portfolio_files f WHERE f.item_id = p.id AND f.kind = "image") AS images_count,
        (SELECT COUNT(*) FROM portfolio_files f WHERE f.item_id = p.id AND f.kind = "document") AS docs_count,
        (SELECT f.file_path FROM portfolio_files f WHERE f.item_id = p.id AND f.kind = "image" ORDER BY f.sort_order, f.id LIMIT 1) AS first_image
    FROM portfolio_items p
    JOIN categories c ON c.id = p.category_id AND c.is_active = 1
    LEFT JOIN subcategories sc ON sc.id = p.subcategory_id
    LEFT JOIN services s ON s.id = p.service_id';

/**
 * قائمة الأعمال المنشورة.
 * @param array $f مفاتيح: category, subcategory, service, featured, q, exclude
 */
function portfolio_list(array $f = [], int $limit = 12, int $offset = 0): array
{
    if (!portfolio_enabled()) return [];
    [$where, $params] = portfolio_where($f);
    return db_all(PORTFOLIO_SELECT . " WHERE $where ORDER BY p.is_featured DESC, p.sort_order, p.id DESC LIMIT " . (int) $limit . ' OFFSET ' . (int) $offset, $params);
}

function portfolio_count(array $f = []): int
{
    if (!portfolio_enabled()) return 0;
    [$where, $params] = portfolio_where($f);
    return (int) db_value("SELECT COUNT(*) FROM portfolio_items p JOIN categories c ON c.id = p.category_id AND c.is_active = 1 WHERE $where", $params);
}

function portfolio_where(array $f): array
{
    $w = ['p.is_active = 1'];
    $p = [];
    if (!empty($f['category']))    { $w[] = 'p.category_id = ?'; $p[] = (int) $f['category']; }
    if (!empty($f['subcategory'])) { $w[] = 'p.subcategory_id = ?'; $p[] = (int) $f['subcategory']; }
    if (!empty($f['service']))     { $w[] = 'p.service_id = ?'; $p[] = (int) $f['service']; }
    if (!empty($f['featured']))    { $w[] = 'p.is_featured = 1'; }
    if (!empty($f['exclude']))     { $w[] = 'p.id <> ?'; $p[] = (int) $f['exclude']; }
    if (!empty($f['q'])) {
        $w[] = '(p.title LIKE ? OR p.summary LIKE ? OR p.tools_text LIKE ?)';
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], (string) $f['q']) . '%';
        array_push($p, $like, $like, $like);
    }
    return [implode(' AND ', $w), $p];
}

function portfolio_by_slug(string $slug): ?array
{
    if (!portfolio_enabled()) return null;
    return db_one(PORTFOLIO_SELECT . ' WHERE p.slug = ? AND p.is_active = 1', [$slug]);
}

function portfolio_files(int $itemId, ?string $kind = null): array
{
    $sql = 'SELECT * FROM portfolio_files WHERE item_id = ?' . ($kind ? ' AND kind = ?' : '') . ' ORDER BY sort_order, id';
    return db_all($sql, $kind ? [$itemId, $kind] : [$itemId]);
}

/** صورة الغلاف: المحددة، ثم أول صورة بالمعرض، ثم صورة القسم */
function portfolio_cover(array $p): ?string
{
    foreach ([$p['cover_image'] ?? null, $p['first_image'] ?? null] as $img) {
        if ($img && is_file(PUBLIC_PATH . '/' . ltrim($img, '/'))) return $img;
    }
    return category_image(['slug' => $p['category_slug'] ?? '', 'image' => null]);
}

/** عدد الأعمال لكل قسم (لإظهار شارات وروابط) */
function portfolio_counts_by_category(): array
{
    static $c = null;
    if ($c !== null) return $c;
    if (!portfolio_enabled()) return $c = [];
    return $c = array_map('intval', array_column(db_all('SELECT category_id, COUNT(*) n FROM portfolio_items WHERE is_active = 1 GROUP BY category_id'), 'n', 'category_id'));
}

function portfolio_track_view(int $id): void
{
    $seen = $_SESSION['_pviewed'] ?? [];
    if (in_array($id, $seen, true)) return;
    $seen[] = $id;
    $_SESSION['_pviewed'] = array_slice($seen, -100);
    db_exec('UPDATE portfolio_items SET views = views + 1 WHERE id = ?', [$id]);
}

// =====================================================================
// آراء العملاء (v5) — بيانات حقيقية فقط (معتمدة ومنشورة بموافقة أصحابها)
// =====================================================================

function testimonials_enabled(): bool
{
    return function_exists('schema_v5') && schema_v5() && setting('testimonials_enabled', '1') === '1';
}

function testimonial_themes(): array
{
    return [
        'white'   => 'أبيض فاخر',
        'navy'    => 'كحلي وذهبي',
        'gradient'=> 'تدرج لوني',
        'image'   => 'صورة خلفية مرفوعة',
        'glass'   => 'زجاجي شفاف',
        'minimal' => 'بسيط',
        'pro'     => 'بطاقة تقييم احترافية',
    ];
}

/** الآراء المعتمدة: المثبتة أولًا ثم حسب الترتيب */
function testimonials_list(int $limit = 6, ?int $serviceId = null, ?int $categoryId = null): array
{
    if (!testimonials_enabled()) return [];
    $w = "t.status = 'approved' AND t.deleted_at IS NULL AND t.consent_publish = 1";
    $p = [];
    if ($serviceId) { $w .= ' AND t.service_id = ?'; $p[] = $serviceId; }
    if ($categoryId) { $w .= ' AND s.category_id = ?'; $p[] = $categoryId; }
    return db_all("SELECT t.*, s.name AS service_name, s.slug AS service_slug FROM testimonials t LEFT JOIN services s ON s.id = t.service_id
        WHERE $w ORDER BY t.is_pinned DESC, t.sort_order, t.id DESC LIMIT " . (int) $limit, $p);
}

/** متوسط التقييم وعدد الآراء المعتمدة (حقيقي) */
function testimonials_stats(?int $serviceId = null): array
{
    if (!testimonials_enabled()) return ['avg' => 0.0, 'count' => 0];
    $w = "status = 'approved' AND deleted_at IS NULL AND consent_publish = 1" . ($serviceId ? ' AND service_id = ' . (int) $serviceId : '');
    $r = db_one("SELECT AVG(rating) a, COUNT(*) n FROM testimonials WHERE $w");
    return ['avg' => round((float) ($r['a'] ?? 0), 1), 'count' => (int) ($r['n'] ?? 0)];
}

/** Schema.org: تقييمات حقيقية فقط — لا يُضاف شيء إن لم توجد آراء معتمدة */
function testimonials_json_ld(array $items, array $stats, string $itemName, string $itemType = 'Organization'): array
{
    if (!$items || $stats['count'] < 1) return [];
    $reviews = [];
    foreach (array_slice($items, 0, 10) as $t) {
        $reviews[] = ['@type' => 'Review', 'author' => ['@type' => 'Person', 'name' => $t['name']],
            'datePublished' => substr((string) ($t['approved_at'] ?: $t['created_at']), 0, 10),
            'reviewBody' => excerpt($t['body'], 300),
            'reviewRating' => ['@type' => 'Rating', 'ratingValue' => (int) $t['rating'], 'bestRating' => 5, 'worstRating' => 1]];
    }
    return [['@context' => 'https://schema.org', '@type' => $itemType, 'name' => $itemName, 'url' => absolute_url(),
        'aggregateRating' => ['@type' => 'AggregateRating', 'ratingValue' => $stats['avg'], 'reviewCount' => $stats['count'], 'bestRating' => 5, 'worstRating' => 1],
        'review' => $reviews]];
}

// =====================================================================
// الطلبات (v5): سجل تغيّر الحالة + التتبع العام
// =====================================================================

/** تسجيل تغيّر حالة طلب (لا يفشل الطلب إن لم تكن الترقية مطبقة) */
function request_log_status(int $requestId, ?string $old, string $new, ?int $userId = null, ?string $note = null): void
{
    if (!schema_v5()) return;
    try {
        db_insert('request_status_log', ['request_id' => $requestId, 'old_status' => $old, 'new_status' => $new, 'user_id' => $userId, 'note' => $note ? mb_substr($note, 0, 500) : null]);
    } catch (Throwable $e) { error_log('[status_log] ' . $e->getMessage()); }
}

/** تغيير حالة طلب مع السجل والإشعار — يعيد true إذا تغيّرت فعلًا */
function request_set_status(array $req, string $new, ?int $userId = null, ?string $note = null): bool
{
    if (!isset(request_statuses()[$new]) || $req['status'] === $new) return false;
    db_exec('UPDATE requests SET status = ? WHERE id = ?', [$new, $req['id']]);
    request_log_status((int) $req['id'], $req['status'], $new, $userId, $note);
    if (!empty($req['member_id'])) {
        notify((int) $req['member_id'], 'تحديث حالة طلبك ' . $req['reference_code'], 'الحالة الجديدة: ' . request_statuses()[$new][0], route('track', ['ref' => $req['reference_code']]));
    }
    return true;
}

function request_status_history(int $requestId): array
{
    if (!schema_v5()) return [];
    return db_all('SELECT l.*, u.name uname FROM request_status_log l LEFT JOIN users u ON u.id = l.user_id WHERE l.request_id = ? ORDER BY l.id', [$requestId]);
}

/** المراحل المعروضة للعميل في التتبع */
function request_track_steps(): array
{
    return ['new' => ['bi-inbox', 'تم الاستلام'], 'reviewing' => ['bi-search', 'قيد المراجعة'], 'awaiting_client' => ['bi-chat-dots', 'بانتظار معلومات منك'], 'in_progress' => ['bi-gear', 'قيد التنفيذ'], 'completed' => ['bi-check2-all', 'مكتمل']];
}

// =====================================================================
// المقالات والصفحات (v5)
// =====================================================================
function articles_enabled(): bool
{
    return schema_v5() && setting('articles_enabled', '1') === '1';
}

function posts_published(string $type = 'article', int $limit = 12, int $offset = 0, ?int $categoryId = null): array
{
    if (!schema_v5()) return [];
    $w = "p.type = ? AND p.status = 'published' AND p.deleted_at IS NULL AND (p.published_at IS NULL OR p.published_at <= NOW())";
    $prm = [$type];
    if ($categoryId) { $w .= ' AND p.category_id = ?'; $prm[] = $categoryId; }
    $order = $type === 'page' ? 'p.sort_order, p.id' : 'COALESCE(p.published_at, p.created_at) DESC';
    return db_all("SELECT p.*, c.name category_name, c.slug category_slug FROM posts p LEFT JOIN categories c ON c.id = p.category_id WHERE $w ORDER BY $order LIMIT " . (int) $limit . ' OFFSET ' . (int) $offset, $prm);
}

function posts_count(string $type = 'article'): int
{
    if (!schema_v5()) return 0;
    return (int) db_value("SELECT COUNT(*) FROM posts WHERE type = ? AND status = 'published' AND deleted_at IS NULL AND (published_at IS NULL OR published_at <= NOW())", [$type]);
}

function post_by_slug(string $type, string $slug): ?array
{
    if (!schema_v5()) return null;
    return db_one("SELECT p.*, c.name category_name, c.slug category_slug, u.name author_name FROM posts p LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN users u ON u.id = p.author_id
        WHERE p.type = ? AND p.slug = ? AND p.status = 'published' AND p.deleted_at IS NULL AND (p.published_at IS NULL OR p.published_at <= NOW())", [$type, $slug]);
}

function post_track_view(int $id): void
{
    $seen = $_SESSION['_postviewed'] ?? [];
    if (in_array($id, $seen, true)) return;
    $seen[] = $id;
    $_SESSION['_postviewed'] = array_slice($seen, -50);
    db_exec('UPDATE posts SET views = views + 1 WHERE id = ?', [$id]);
}

/** صفحات التذييل */
function footer_pages(): array
{
    static $p = null;
    if ($p !== null) return $p;
    if (!schema_v5()) return $p = [];
    return $p = db_all("SELECT title, slug FROM posts WHERE type = 'page' AND status = 'published' AND show_in_footer = 1 AND deleted_at IS NULL ORDER BY sort_order, id LIMIT 8");
}

/** v5: عدّ مرات ظهور البنرات (مرة لكل جلسة لكل بنر، استعلام واحد) */
function banners_count_views(array $banners): void
{
    if (PHP_SAPI === 'cli' || !has_col('banners', 'views') || current_admin()) return;
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '' || preg_match('/bot|crawl|spider|slurp|facebookexternalhit|preview/i', $ua)) return;
    $seen = $_SESSION['_bview'] ?? [];
    $ids = [];
    foreach ($banners as $b) { $id = (int) $b['id']; if (!in_array($id, $seen, true)) { $ids[] = $id; $seen[] = $id; } }
    if (!$ids) return;
    $_SESSION['_bview'] = array_slice($seen, -100);
    try { db_exec('UPDATE banners SET views = views + 1 WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids); } catch (Throwable $e) {}
}
