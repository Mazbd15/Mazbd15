<?php
/**
 * نقطة الإقلاع المشتركة لجميع الصفحات العامة ولوحة التحكم.
 */
declare(strict_types=1);

if (defined('IKH_BOOTSTRAPPED')) return;
define('IKH_BOOTSTRAPPED', true);

// قبل التثبيت: تحويل الزائر إلى معالج التثبيت
if (!is_file(dirname(__DIR__) . '/.env') && !is_file(dirname(__DIR__) . '/storage/installed.lock') && PHP_SAPI !== 'cli') {
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $base = preg_replace('#/(admin|api)/[^/]*$|/[^/]*$#', '', $script);
    $base = preg_replace('#/public$#', '', $base);
    header('Location: ' . $base . '/install.php', true, 302);
    exit;
}

$GLOBALS['CONFIG'] = require dirname(__DIR__) . '/config/config.php';
require __DIR__ . '/helpers.php';

date_default_timezone_set(config('app.timezone', 'Asia/Riyadh'));
mb_internal_encoding('UTF-8');

// ---------------------------------------------------------------------
// معالجة الأخطاء: لا نعرض تفاصيل الأخطاء للزوار في وضع الإنتاج
// ---------------------------------------------------------------------
error_reporting(E_ALL);
ini_set('display_errors', config('app.debug') ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', ROOT_PATH . '/storage/logs/php-error.log');

set_exception_handler(function (Throwable $e): void {
    error_log('[' . date('c') . '] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/html; charset=utf-8');
    }
    if (config('app.debug')) {
        echo '<pre dir="ltr">' . htmlspecialchars((string) $e, ENT_QUOTES, 'UTF-8') . '</pre>';
        return;
    }
    $f = PUBLIC_PATH . '/500.html';
    echo is_file($f) ? file_get_contents($f) : 'حدث خطأ غير متوقع. يرجى المحاولة لاحقًا.';
});

require __DIR__ . '/db.php';
require __DIR__ . '/security.php';
require __DIR__ . '/migrate.php';
require __DIR__ . '/media.php';
require __DIR__ . '/backup.php';
require __DIR__ . '/repository.php';
require __DIR__ . '/whatsapp.php';
require __DIR__ . '/partials.php';

security_headers();
start_secure_session();

// وضع الصيانة: يُغلق الموقع العام للزوار، ويبقى متاحًا لفريق العمل وصفحات الدخول ولوحة التحكم
(function (): void {
    if (PHP_SAPI === 'cli' || setting('maintenance_mode', '0') !== '1') return;
    $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $path = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    if (str_contains($path, '/admin/') || in_array($script, ['login.php', 'logout.php', 'install.php'], true) || current_admin()) return;
    http_response_code(503);
    header('Retry-After: 3600');
    require PUBLIC_PATH . '/maintenance.php';
    exit;
})();
