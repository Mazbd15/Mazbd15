<?php
/**
 * بناء رسائل واتساب الجاهزة — يتم ترميزها بـ rawurlencode لدعم العربية.
 * ملاحظة: الموقع لا يرسل أي رسالة تلقائيًا؛ المستخدم هو من يؤكد الإرسال داخل واتساب.
 */
declare(strict_types=1);

function wa_link(string $message = ''): string
{
    $link = 'https://wa.me/' . whatsapp_number();
    return $message !== '' ? $link . '?text=' . rawurlencode($message) : $link;
}

/**
 * رسالة طلب الخدمة المنظمة.
 * @param array $d مفاتيح: category, service, specialization, description, deadline, notes, software, name, reference, attachments
 */
function wa_order_message(array $d = []): string
{
    $v = fn(string $k) => trim((string) ($d[$k] ?? ''));
    $lines = [];
    $lines[] = 'السلام عليكم، أرغب في طلب خدمة من منصة ' . setting('site_name', 'اختيارك للخدمات الطلابية') . '.';
    $lines[] = '';
    if ($v('reference') !== '') $lines[] = '- رقم الطلب المرجعي: ' . $v('reference');
    if ($v('name') !== '')      $lines[] = '- الاسم: ' . $v('name');
    $lines[] = '- القسم الرئيسي: ' . $v('category');
    $lines[] = '- الخدمة المطلوبة: ' . $v('service');
    $lines[] = '- التخصص: ' . $v('specialization');
    if ($v('software') !== '')  $lines[] = '- البرنامج المطلوب: ' . $v('software');
    $lines[] = '- وصف الطلب: ' . $v('description');
    $lines[] = '- الموعد المطلوب: ' . $v('deadline');
    $att = $v('attachments');
    $lines[] = '- الملفات والمرفقات: ' . ($att !== '' ? $att : 'سأرسلها في المحادثة.');
    $lines[] = '- ملاحظات إضافية: ' . $v('notes');
    $lines[] = '';
    $lines[] = 'أرغب في معرفة السعر والمدة والمتطلبات قبل تأكيد الطلب.';
    return implode("\n", $lines);
}

/** رابط سريع لطلب خدمة محددة (يُستخدم في البطاقات وصفحة الخدمة) */
function wa_service_link(?array $service = null, ?string $categoryName = null): string
{
    if (!$service && !$categoryName) {
        return wa_link(wa_order_message());
    }
    return wa_link(wa_order_message([
        'category'       => $service['category_name'] ?? $categoryName ?? '',
        'service'        => $service['name'] ?? '',
        'specialization' => $service['subcategory_name'] ?? '',
    ]));
}

function wa_general_link(): string
{
    return wa_link('السلام عليكم، لدي استفسار حول خدمات منصة ' . setting('site_name', 'اختيارك للخدمات الطلابية') . '.');
}
