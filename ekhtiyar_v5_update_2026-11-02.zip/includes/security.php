<?php
declare(strict_types=1);

/** ترويسات أمان أساسية */
function security_headers(): void
{
    if (headers_sent()) return;
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    // Google Analytics يُسمح به فقط عند تفعيله من الإعدادات
    $ga = ' https://www.googletagmanager.com https://www.google-analytics.com';
    header("Content-Security-Policy: default-src 'self'; "
        . "script-src 'self' https://cdn.jsdelivr.net$ga; "
        . "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; "
        . "font-src 'self' data: https://fonts.gstatic.com https://cdn.jsdelivr.net; "
        . "img-src 'self' data: https:; connect-src 'self' https://*.google-analytics.com https://*.analytics.google.com; frame-ancestors 'self'; "
        . "form-action 'self'; base-uri 'self'; object-src 'none'");
}

/** جلسة آمنة: HttpOnly + SameSite + Secure عند HTTPS + تجديد دوري للمعرف */
function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    session_name('IKHSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => base_path() . '/',
        'secure'   => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();

    $now = time();
    if (!isset($_SESSION['_created'])) {
        $_SESSION['_created'] = $now;
    } elseif ($now - $_SESSION['_created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['_created'] = $now;
    }
}

// ---------------------------------------------------------------------
// CSRF
// ---------------------------------------------------------------------
function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    $sent = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    return is_string($sent) && !empty($_SESSION['_csrf']) && hash_equals($_SESSION['_csrf'], $sent);
}

function require_csrf(): void
{
    if (!csrf_valid()) {
        http_response_code(419);
        if (str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')) {
            json_response(['ok' => false, 'error' => 'انتهت صلاحية الجلسة، يرجى تحديث الصفحة والمحاولة مجددًا.'], 419);
        }
        exit('انتهت صلاحية النموذج. يرجى الرجوع وتحديث الصفحة ثم المحاولة مجددًا.');
    }
}

// ---------------------------------------------------------------------
// المصادقة والصلاحيات
// ---------------------------------------------------------------------
const LOGIN_MAX_ATTEMPTS = 5;      // محاولات فاشلة
const LOGIN_WINDOW_MINUTES = 15;   // خلال هذه المدة

/*
 * نظام الأدوار:
 *  - super_admin : مدير عام — كل الصلاحيات + المستخدمون + سجل العمليات + الحذف النهائي
 *  - admin       : مسؤول — إدارة كل المحتوى والطلبات والإعدادات واعتماد المتخصصين
 *  - editor      : محرر محتوى — تعديل كل الأقسام والخدمات والإعلانات (بدون حذف أقسام/مستخدمين)
 *  - specialist  : متخصص — بعد موافقة الإدارة؛ يدير أقسامه المحددة فقط (خدمات، إعلانات، أسئلة، طلبات)
 *  - member      : زائر مسجل (اختياري) — يتابع طلباته من حسابه فقط، لا يدخل لوحة التحكم
 */
function role_labels(): array
{
    return ['super_admin' => 'مدير عام', 'admin' => 'مسؤول', 'editor' => 'محرر محتوى', 'specialist' => 'متخصص', 'member' => 'عضو (زائر مسجل)'];
}

function staff_roles(): array
{
    return ['super_admin', 'admin', 'editor', 'specialist'];
}

function status_labels(): array
{
    return ['active' => ['مفعّل', 'success'], 'pending' => ['بانتظار الموافقة', 'warning'], 'rejected' => ['مرفوض', 'danger'], 'suspended' => ['موقوف', 'secondary']];
}

function role_at_least(string $role, string $min): bool
{
    $rank = ['member' => 0, 'specialist' => 1, 'editor' => 2, 'admin' => 3, 'super_admin' => 4];
    return ($rank[$role] ?? -1) >= ($rank[$min] ?? 99);
}

/** المستخدم الحالي (أي دور) */
function current_user(): ?array
{
    static $user = false;
    if ($user !== false) return $user;
    $id = $_SESSION['uid'] ?? null;
    if (!$id) return $user = null;
    // انتهاء الجلسة بعد ساعتين من الخمول
    if (($_SESSION['u_last'] ?? 0) < time() - 7200) {
        logout_user();
        return $user = null;
    }
    $_SESSION['u_last'] = time();
    $user = db_one("SELECT id, name, email, role, status, phone, specialization FROM users WHERE id = ? AND status = 'active'", [$id]);
    if (!$user) {
        logout_user();
        return $user = null;
    }
    return $user;
}

/** المستخدم الحالي إن كان من فريق العمل (يدخل لوحة التحكم) */
function current_admin(): ?array
{
    $u = current_user();
    return ($u && in_array($u['role'], staff_roles(), true)) ? $u : null;
}

function require_admin(?string $minRole = null): array
{
    $u = current_admin();
    if (!$u) {
        if (current_user()) { flash('warning', 'حسابك لا يملك صلاحية الدخول للوحة التحكم.'); redirect(route('account')); }
        redirect(route('login', ['next' => $_SERVER['REQUEST_URI'] ?? '']));
    }
    if ($minRole !== null && !role_at_least($u['role'], $minRole)) {
        http_response_code(403);
        flash('danger', 'ليست لديك صلاحية للوصول إلى هذه الصفحة.');
        redirect(admin_url());
    }
    return $u;
}

function require_member(): array
{
    $u = current_user();
    if (!$u) redirect(route('login', ['next' => $_SERVER['REQUEST_URI'] ?? '']));
    return $u;
}

/**
 * الأقسام التي يحق للمستخدم إدارتها.
 * يعيد null = كل الأقسام (للإدارة والمحررين)، أو مصفوفة معرفات للمتخصص.
 */
function user_category_scope(array $u): ?array
{
    if ($u['role'] !== 'specialist') return null;
    static $cache = [];
    return $cache[$u['id']] ??= array_map('intval', array_column(db_all('SELECT category_id FROM user_categories WHERE user_id = ?', [$u['id']]), 'category_id'));
}

function can_manage_category(array $u, ?int $categoryId): bool
{
    $scope = user_category_scope($u);
    if ($scope === null) return true;
    return $categoryId !== null && in_array($categoryId, $scope, true);
}

/** شرط SQL للتقييد حسب الأقسام: يعيد [sql, params] */
function scope_sql(array $u, string $column): array
{
    $scope = user_category_scope($u);
    if ($scope === null) return ['1=1', []];
    if (!$scope) return ['1=0', []];
    return [$column . ' IN (' . implode(',', array_fill(0, count($scope), '?')) . ')', $scope];
}

/** صلاحيات تفصيلية حسب الإجراء */
function can(array $u, string $ability): bool
{
    $r = $u['role'];
    return match ($ability) {
        'categories.create', 'categories.delete', 'subcategories.delete' => role_at_least($r, 'admin'),
        'categories.edit'      => role_at_least($r, 'specialist'),   // المتخصص: أقسامه فقط
        'subcategories.manage' => role_at_least($r, 'specialist'),
        'services.manage'      => role_at_least($r, 'specialist'),
        'services.delete'      => role_at_least($r, 'specialist'),   // المتخصص: داخل أقسامه
        'banners.manage'       => role_at_least($r, 'specialist'),
        'faqs.manage'          => role_at_least($r, 'specialist'),
        'faqs.general'         => role_at_least($r, 'editor'),
        'requests.view'        => role_at_least($r, 'specialist'),   // المتخصص: المسندة له أو في أقسامه
        'requests.delete', 'requests.export', 'requests.assign' => role_at_least($r, 'admin'),
        'settings'             => role_at_least($r, 'admin'),
        'users.manage'         => role_at_least($r, 'admin'),        // اعتماد المتخصصين وإدارة الأعضاء
        'users.staff'          => $r === 'super_admin',              // إنشاء/تعديل حسابات الإدارة
        'audit'                => $r === 'super_admin',
        default                => false,
    };
}

function login_locked(string $email): bool
{
    $since = date('Y-m-d H:i:s', time() - LOGIN_WINDOW_MINUTES * 60);
    $byIp = (int) db_value('SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND success = 0 AND attempted_at > ?', [client_ip(), $since]);
    $byEmail = (int) db_value('SELECT COUNT(*) FROM login_attempts WHERE email = ? AND success = 0 AND attempted_at > ?', [$email, $since]);
    return $byIp >= LOGIN_MAX_ATTEMPTS * 2 || $byEmail >= LOGIN_MAX_ATTEMPTS;
}

/** يعيد [ok, message, user|null] */
function attempt_login(string $email, string $password): array
{
    $email = mb_strtolower(trim($email));
    if (login_locked($email)) {
        return [false, 'تم إيقاف تسجيل الدخول مؤقتًا بسبب محاولات متكررة. حاول بعد ' . LOGIN_WINDOW_MINUTES . ' دقيقة.', null];
    }
    $user = db_one('SELECT * FROM users WHERE email = ? LIMIT 1', [$email]);
    // نتحقق دائمًا من كلمة مرور (حتى لو لم يوجد المستخدم) لتقليل هجمات التوقيت
    $hash = $user['password_hash'] ?? '$2y$10$usesomesillystringfore7hnbRJHxXVLeakoG8K30oukPsA.ztMG';
    $pwOk = password_verify($password, $hash) && $user;

    db_insert('login_attempts', ['ip_address' => client_ip(), 'email' => $email, 'success' => $pwOk ? 1 : 0]);
    db_exec('DELETE FROM login_attempts WHERE attempted_at < ?', [date('Y-m-d H:i:s', time() - 86400 * 7)]);

    if (!$pwOk) return [false, 'البريد الإلكتروني أو كلمة المرور غير صحيحة.', null];
    // كلمة المرور صحيحة لكن الحساب غير مفعّل: رسالة واضحة حسب الحالة
    if ($user['status'] === 'pending')   return [false, 'حسابك بانتظار موافقة الإدارة. سيتم إشعارك فور اعتماده.', null];
    if ($user['status'] === 'rejected')  return [false, 'تم رفض طلب الانضمام.' . ($user['review_note'] ? ' السبب: ' . $user['review_note'] : ''), null];
    if ($user['status'] === 'suspended') return [false, 'تم إيقاف هذا الحساب. تواصل مع الإدارة.', null];

    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_DEFAULT), $user['id']]);
    }
    login_user((int) $user['id']);
    db_exec('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?', [client_ip(), $user['id']]);
    if (in_array($user['role'], staff_roles(), true)) audit('login', 'user', (int) $user['id'], 'تسجيل دخول');
    return [true, '', $user];
}

function login_user(int $id): void
{
    session_regenerate_id(true);
    $_SESSION['uid'] = $id;
    $_SESSION['u_last'] = time();
    $_SESSION['_csrf'] = bin2hex(random_bytes(32));
}

function logout_user(): void
{
    unset($_SESSION['uid'], $_SESSION['u_last']);
    session_regenerate_id(true);
}

/** توافق مع الأسماء القديمة */
function logout_admin(): void { logout_user(); }

/** إرسال إشعار داخلي */
function notify(int $userId, string $title, ?string $body = null, ?string $link = null): void
{
    try {
        db_insert('notifications', ['user_id' => $userId, 'title' => mb_substr($title, 0, 190), 'body' => $body ? mb_substr($body, 0, 500) : null, 'link' => $link]);
    } catch (Throwable $e) {
        error_log('notify failed: ' . $e->getMessage());
    }
}

/** إشعار كل من يحمل دورًا معينًا أو أعلى */
function notify_staff(string $minRole, string $title, ?string $body = null, ?string $link = null, ?int $categoryId = null): void
{
    foreach (db_all("SELECT id, role FROM users WHERE status = 'active' AND role IN ('super_admin','admin','editor','specialist')") as $u) {
        if (!role_at_least($u['role'], $minRole)) continue;
        if ($u['role'] === 'specialist' && ($categoryId === null || !can_manage_category($u, $categoryId))) continue;
        notify((int) $u['id'], $title, $body, $link);
    }
}

/** التحقق من قوة كلمة المرور */
function password_problems(string $pw): ?string
{
    if (mb_strlen($pw) < 10) return 'يجب ألا تقل كلمة المرور عن 10 أحرف.';
    if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) return 'يجب أن تحتوي كلمة المرور على حروف وأرقام.';
    return null;
}

/** سجل العمليات الإدارية */
function audit(string $action, ?string $entity = null, ?int $entityId = null, ?string $details = null): void
{
    try {
        db_insert('audit_logs', [
            'user_id'     => $_SESSION['uid'] ?? null,
            'action'      => mb_substr($action, 0, 60),
            'entity_type' => $entity,
            'entity_id'   => $entityId,
            'details'     => $details !== null ? mb_substr($details, 0, 2000) : null,
            'ip_address'  => client_ip(),
        ]);
    } catch (Throwable $e) {
        error_log('audit failed: ' . $e->getMessage());
    }
}

// ---------------------------------------------------------------------
// تحديد معدل الطلبات العامة (بسيط بالجلسة + قاعدة البيانات)
// ---------------------------------------------------------------------
function rate_limited(string $bucket, int $max, int $seconds): bool
{
    $now = time();
    $key = '_rl_' . $bucket;
    $hits = array_filter($_SESSION[$key] ?? [], fn($t) => $t > $now - $seconds);
    if (count($hits) >= $max) {
        $_SESSION[$key] = $hits;
        return true;
    }
    $hits[] = $now;
    $_SESSION[$key] = array_values($hits);
    return false;
}

// ---------------------------------------------------------------------
// رفع الملفات بأمان
// ---------------------------------------------------------------------

/**
 * إعادة ترتيب مصفوفة $_FILES متعددة الملفات.
 */
function normalize_files(array $f): array
{
    if (!isset($f['name'])) return [];
    if (!is_array($f['name'])) return [$f];
    $out = [];
    foreach ($f['name'] as $i => $n) {
        $out[] = ['name' => $n, 'type' => $f['type'][$i] ?? '', 'tmp_name' => $f['tmp_name'][$i] ?? '', 'error' => $f['error'][$i] ?? UPLOAD_ERR_NO_FILE, 'size' => $f['size'][$i] ?? 0];
    }
    return array_values(array_filter($out, fn($x) => ($x['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE));
}

/**
 * التحقق من ملف مرفق: الخطأ، الحجم، الامتداد، نوع MIME الحقيقي، وتوقيع المحتوى.
 * يعيد [ok, error|null, ext, mime]
 */
function validate_upload(array $file, array $allowed, int $maxBytes): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $map = [UPLOAD_ERR_INI_SIZE => 'حجم الملف أكبر من المسموح.', UPLOAD_ERR_FORM_SIZE => 'حجم الملف أكبر من المسموح.', UPLOAD_ERR_PARTIAL => 'لم يكتمل رفع الملف.'];
        return [false, $map[$file['error']] ?? 'تعذر رفع الملف.', null, null];
    }
    if (!is_uploaded_file($file['tmp_name']) && PHP_SAPI !== 'cli') {
        return [false, 'ملف غير صالح.', null, null];
    }
    $size = (int) $file['size'];
    if ($size <= 0 || $size > $maxBytes) {
        return [false, 'حجم الملف «' . e($file['name']) . '» يتجاوز الحد المسموح (' . format_bytes($maxBytes) . ').', null, null];
    }
    $name = (string) $file['name'];
    // منع الامتدادات المزدوجة الخطرة مثل file.php.jpg
    if (preg_match('/\.(php\d?|phtml|phar|pl|py|cgi|sh|exe|bat|cmd|js|html?|svg|htaccess)(\.|$)/i', $name)) {
        return [false, 'نوع الملف «' . e($name) . '» غير مسموح.', null, null];
    }
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) {
        return [false, 'امتداد الملف «' . e($name) . '» غير مسموح.', null, null];
    }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string) $finfo->file($file['tmp_name']);
    if (!in_array($mime, $allowed[$ext], true)) {
        return [false, 'محتوى الملف «' . e($name) . '» لا يطابق امتداده.', null, null];
    }
    // فحص توقيعات إضافية
    $head = (string) file_get_contents($file['tmp_name'], false, null, 0, 1024);
    if (preg_match('/<\?php|<\?=|<script/i', $head) && !in_array($ext, ['zip', 'docx', 'pptx', 'xlsx', 'pdf', 'dwg'], true)) {
        return [false, 'تم رفض الملف «' . e($name) . '» لأسباب أمنية.', null, null];
    }
    if ($ext === 'dwg' && !str_starts_with($head, 'AC10') && !str_starts_with($head, 'AC1.') && !str_starts_with($head, 'AC2')) {
        return [false, 'ملف DWG غير صالح.', null, null];
    }
    if ($ext === 'pdf' && !str_starts_with($head, '%PDF')) {
        return [false, 'ملف PDF غير صالح.', null, null];
    }
    if (in_array($ext, ['zip', 'docx'], true) && !str_starts_with($head, "PK")) {
        return [false, 'ملف مضغوط غير صالح.', null, null];
    }
    if (in_array($ext, ['jpg', 'jpeg', 'png'], true) && @getimagesize($file['tmp_name']) === false) {
        return [false, 'الصورة «' . e($name) . '» غير صالحة.', null, null];
    }
    return [true, null, $ext, $mime];
}

/** اسم ملف آمن وعشوائي */
function safe_filename(string $ext): string
{
    return date('Ymd') . '_' . bin2hex(random_bytes(16)) . '.' . preg_replace('/[^a-z0-9]/', '', strtolower($ext));
}

/** اسم أصلي آمن للعرض */
function clean_original_name(string $name): string
{
    $name = preg_replace('/[^\p{L}\p{N}\s._\-()]/u', '_', basename($name));
    return mb_substr(trim((string) $name), 0, 200) ?: 'file';
}

// رفع الصور العامة وحذفها الآمن: انظر includes/media.php (نظام الصور الموحّد v5)

// =====================================================================
// ملفات معرض الأعمال (v4): تُحفظ خارج المجلد العام وتُخدم عبر portfolio_file.php
// =====================================================================
function portfolio_doc_types(): array
{
    return [
        'pdf'  => ['application/pdf'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
        'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip', 'application/octet-stream'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
        'zip'  => ['application/zip', 'application/x-zip-compressed', 'multipart/x-zip'],
        'dwg'  => ['image/vnd.dwg', 'application/acad', 'application/x-acad', 'application/autocad_dwg', 'image/x-dwg', 'application/dwg', 'application/x-dwg', 'application/octet-stream'],
    ];
}

function portfolio_storage_dir(): string
{
    $dir = config('uploads.path') . '/portfolio';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    return $dir;
}

/** يعيد [ok, stored_name|error, size] */
function store_portfolio_doc(array $file): array
{
    $max = 20 * 1024 * 1024;
    [$ok, $err, $ext] = validate_upload($file, portfolio_doc_types(), $max);
    if (!$ok) return [false, $err, 0];
    // تحقق إضافي لملفات أوفيس الحديثة (حزمة ZIP)
    if (in_array($ext, ['pptx', 'xlsx'], true)) {
        $head = (string) file_get_contents($file['tmp_name'], false, null, 0, 4);
        if (!str_starts_with($head, 'PK')) return [false, 'ملف «' . e($file['name']) . '» غير صالح.', 0];
    }
    $name = safe_filename($ext);
    $dest = portfolio_storage_dir() . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest) && !(PHP_SAPI === 'cli' && copy($file['tmp_name'], $dest))) {
        return [false, 'تعذر حفظ الملف.', 0];
    }
    @chmod($dest, 0640);
    return [true, $name, (int) filesize($dest)];
}

function delete_portfolio_doc(?string $stored): void
{
    if (!$stored || !preg_match('/^[0-9]{8}_[a-f0-9]{32}\.[a-z0-9]+$/', $stored)) return;
    $path = portfolio_storage_dir() . '/' . $stored;
    if (is_file($path)) @unlink($path);
}

/** حذف عمل بكل صوره وملفاته */
function delete_portfolio_item(int $id): void
{
    $row = db_one('SELECT * FROM portfolio_items WHERE id = ?', [$id]);
    if (!$row) return;
    foreach (db_all('SELECT * FROM portfolio_files WHERE item_id = ?', [$id]) as $f) {
        $f['kind'] === 'image' ? delete_public_image($f['file_path']) : delete_portfolio_doc($f['file_path']);
    }
    delete_public_image($row['cover_image']);
    db_exec('DELETE FROM portfolio_items WHERE id = ?', [$id]);
}
