<?php
$siteName = setting('site_name', 'اختيارك للخدمات الطلابية');
$socials = social_links();
$logoCustom = setting('logo_path', '');
?>
</main>

<footer id="site-footer" class="site-footer">
  <div class="container">
    <?php if (section_on('trust_strip')): ?>
    <ul class="trust-strip">
      <li><i class="bi bi-shield-lock"></i><span><strong>خصوصية تامة</strong><small>بياناتك وملفاتك سرية</small></span></li>
      <li><i class="bi bi-chat-heart"></i><span><strong>تواصل مباشر</strong><small>عبر واتساب في كل خطوة</small></span></li>
      <li><i class="bi bi-cash-coin"></i><span><strong>بدون دفع مسبق بالموقع</strong><small>السعر يتفق عليه بعد المراجعة</small></span></li>
      <li><i class="bi bi-alarm"></i><span><strong>التزام بالمواعيد</strong><small>موعد واقعي نلتزم به</small></span></li>
    </ul>
    <?php endif; ?>
    <div class="row g-4">
      <section class="col-lg-4" aria-labelledby="footer-about-title">
        <a class="brand brand-light mb-3" href="<?= e(route('home')) ?>">
          <img src="<?= e($logoCustom ? url($logoCustom) : url('assets/images/logo.svg')) ?>" alt="" width="46" height="46" loading="lazy">
          <span class="brand-text"><strong id="footer-about-title">اختيارك</strong><small>للخدمات الطلابية</small></span>
        </a>
        <p class="footer-about"><?= e(setting('footer_about')) ?></p>
        <p class="footer-tagline"><i class="bi bi-stars"></i> <?= e(setting('site_tagline')) ?></p>
        <div class="footer-social">
          <a href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener" aria-label="واتساب"><i class="bi bi-whatsapp"></i></a>
          <?php foreach ($socials as $so): ?>
            <a href="<?= e($so['url']) ?>" target="_blank" rel="noopener me" aria-label="<?= e($so['label']) ?>"><i class="bi <?= e($so['icon']) ?>"></i></a>
          <?php endforeach; ?>
        </div>
      </section>
      <nav class="col-6 col-lg-3" aria-label="الأقسام">
        <h3 class="footer-title">الأقسام</h3>
        <ul class="footer-links">
          <?php foreach (array_slice(catalog_tree(), 0, 8) as $c): ?>
            <li><a href="<?= e(route('category', ['slug' => $c['slug']])) ?>"><?= e($c['name']) ?></a></li>
          <?php endforeach; ?>
        </ul>
      </nav>
      <nav class="col-6 col-lg-2" aria-label="روابط مهمة">
        <h3 class="footer-title">روابط مهمة</h3>
        <ul class="footer-links">
          <li><a href="<?= e(route('services')) ?>">جميع الخدمات</a></li>
          <li><a href="<?= e(route('order')) ?>">نموذج طلب خدمة</a></li>
          <?php if (portfolio_enabled() && array_sum(portfolio_counts_by_category())): ?><li><a href="<?= e(route('portfolio')) ?>">أعمالنا السابقة</a></li><?php endif; ?>
          <li><a href="<?= e(route('about')) ?>">من نحن</a></li>
          <li><a href="<?= e(route('faq')) ?>">الأسئلة الشائعة</a></li>
          <li><a href="<?= e(route('register', ['type' => 'specialist'])) ?>">انضم كمتخصص</a></li>
          <?php if (function_exists('articles_enabled') && articles_enabled() && posts_count('article') > 0): ?><li><a href="<?= e(route('blog')) ?>">المقالات</a></li><?php endif; ?>
          <?php if (function_exists('schema_v5') && schema_v5()): ?><li><a href="<?= e(route('track')) ?>">تتبع طلبك</a></li><?php endif; ?>
          <?php foreach (function_exists('footer_pages') ? footer_pages() : [] as $fp): ?><li><a href="<?= e(route('page', ['slug' => $fp['slug']])) ?>"><?= e($fp['title']) ?></a></li><?php endforeach; ?>
          <li><a href="<?= e(route('privacy')) ?>">سياسة الخصوصية</a></li>
          <li><a href="<?= e(route('terms')) ?>">الشروط والأحكام</a></li>
        </ul>
      </nav>
      <section class="col-lg-3" aria-labelledby="footer-contact-title">
        <h3 class="footer-title" id="footer-contact-title">تواصل معنا</h3>
        <ul class="footer-contact">
          <li><i class="bi bi-whatsapp"></i> <a href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener" dir="ltr"><?= e(setting('whatsapp_display', '+' . whatsapp_number())) ?></a></li>
          <?php if ($em = setting('contact_email')): ?><li><i class="bi bi-envelope"></i> <a href="mailto:<?= e($em) ?>"><?= e($em) ?></a></li><?php endif; ?>
          <li><i class="bi bi-clock"></i> <?= e(setting('working_hours')) ?></li>
        </ul>
        <a class="btn btn-whatsapp w-100 mt-2" href="<?= e(wa_service_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب خدمتك الآن</a>
      </section>
    </div>
    <div class="footer-bottom">
      <p class="mb-1">© <?= date('Y') ?> <?= e($siteName) ?>. جميع الحقوق محفوظة.</p>
      <p class="footer-note mb-0"><?= e(setting('footer_note')) ?></p>
    </div>
  </div>
</footer>

<?php if (section_on('wa_float')): ?><a class="wa-float" href="<?= e(isset($wa_float_link) ? $wa_float_link : wa_service_link()) ?>" target="_blank" rel="noopener" aria-label="اطلب عبر واتساب">
  <i class="bi bi-whatsapp"></i><span>اطلب عبر واتساب</span>
</a><?php endif; ?>
<button class="back-top" id="back-top" type="button" aria-label="العودة للأعلى"><i class="bi bi-arrow-up"></i></button>
<?= section_on('bottom_nav') ? render_bottom_nav($active_nav ?? '') : '' ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="<?= asset('js/app.js') ?>"></script>
<?php foreach (($page_scripts ?? []) as $s): ?><script src="<?= asset($s) ?>"></script><?php endforeach; ?>
</body>
</html>
