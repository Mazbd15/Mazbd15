<?php
declare(strict_types=1);

/** اتصال PDO وحيد مع استعلامات محضرة حقيقية */
function db(?PDO $use = null): PDO
{
    static $pdo = null;
    if ($use) $pdo = $use; // يُستخدم من معالج التثبيت لتمرير اتصال جاهز
    if ($pdo instanceof PDO) return $pdo;

    $c = config('db');
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['host'], $c['port'], $c['name']);
    $pdo = new PDO($dsn, $c['user'], $c['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_STRINGIFY_FETCHES  => false,
    ]);
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    // مزامنة المنطقة الزمنية لقاعدة البيانات مع PHP (مهم لمقارنات التواريخ وتحديد محاولات الدخول)
    $pdo->exec("SET time_zone = '" . (new DateTime('now', new DateTimeZone(date_default_timezone_get())))->format('P') . "'");
    return $pdo;
}

function db_all(string $sql, array $params = []): array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function db_one(string $sql, array $params = []): ?array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row === false ? null : $row;
}

function db_value(string $sql, array $params = [])
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $v = $st->fetchColumn();
    return $v === false ? null : $v;
}

function db_exec(string $sql, array $params = []): int
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->rowCount();
}

function db_insert(string $table, array $data): int
{
    $table = preg_replace('/[^a-z_]/', '', $table);
    $cols = array_map(fn($c) => '`' . preg_replace('/[^a-z_]/', '', $c) . '`', array_keys($data));
    $ph = implode(',', array_fill(0, count($data), '?'));
    db_exec("INSERT INTO `$table` (" . implode(',', $cols) . ") VALUES ($ph)", array_values($data));
    return (int) db()->lastInsertId();
}

function db_update(string $table, array $data, int $id): int
{
    $table = preg_replace('/[^a-z_]/', '', $table);
    $sets = [];
    foreach (array_keys($data) as $c) {
        $sets[] = '`' . preg_replace('/[^a-z_]/', '', $c) . '` = ?';
    }
    $params = array_values($data);
    $params[] = $id;
    return db_exec("UPDATE `$table` SET " . implode(', ', $sets) . " WHERE id = ?", $params);
}
