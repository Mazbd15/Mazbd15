<?php
declare(strict_types=1);

/** قراءة قيمة من الإعدادات بصيغة "app.url" */
function config(string $path, $default = null)
{
    $value = $GLOBALS['CONFIG'] ?? [];
    foreach (explode('.', $path) as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) {
            return $default;
        }
        $value = $value[$segment];
    }
    return $value;
}

/** هروب HTML آمن */
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** المسار الأساسي للموقع (مثل /ikhtiyarak أو فارغ) */
function base_path(): string
{
    static $base = null;
    if ($base !== null) return $base;
    $url = config('app.url', '');
    if ($url !== '') {
        $base = rtrim((string) parse_url($url, PHP_URL_PATH), '/');
    } else {
        // استنتاج تلقائي من مسار السكربت
        $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
        $dir = rtrim(dirname($script), '/');
        if (str_ends_with($dir, '/admin') || str_ends_with($dir, '/api')) {
            $dir = rtrim(dirname($dir), '/');
        }
        $base = $dir === '.' ? '' : $dir;
    }
    return $base;
}

/** رابط مطلق داخل الموقع */
function url(string $path = ''): string
{
    $path = ltrim($path, '/');
    return base_path() . '/' . $path;
}

/** رابط كامل مع النطاق — للـ SEO و Open Graph و Sitemap */
function absolute_url(string $path = ''): string
{
    $configured = config('app.url', '');
    if ($configured !== '') {
        $origin = preg_replace('#^(https?://[^/]+).*$#i', '$1', $configured);
    } else {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        $host = preg_replace('/[^a-zA-Z0-9.\-:\[\]]/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
        $origin = ($https ? 'https' : 'http') . '://' . $host;
    }
    return $origin . url($path);
}

function asset(string $path): string
{
    $file = PUBLIC_PATH . '/assets/' . ltrim($path, '/');
    $v = is_file($file) ? substr((string) filemtime($file), -6) : '1';
    return url('assets/' . ltrim($path, '/')) . '?v=' . $v;
}

/** روابط الصفحات — تدعم الروابط الصديقة أو العادية حسب الإعداد */
function route(string $name, array $params = []): string
{
    $pretty = pretty_urls();
    switch ($name) {
        case 'home':     return url('');
        case 'services': return $pretty ? url('services') : url('services.php');
        case 'category':
            if (!empty($params['sub'])) {
                return $pretty
                    ? url('category/' . rawurlencode($params['slug']) . '/' . rawurlencode($params['sub']))
                    : url('category.php?slug=' . rawurlencode($params['slug']) . '&sub=' . rawurlencode($params['sub']));
            }
            return $pretty ? url('category/' . rawurlencode($params['slug'])) : url('category.php?slug=' . rawurlencode($params['slug']));
        case 'service':
            return $pretty ? url('service/' . rawurlencode($params['slug'])) : url('service.php?slug=' . rawurlencode($params['slug']));
        case 'search':
            $q = isset($params['q']) ? '?q=' . rawurlencode($params['q']) : '';
            return ($pretty ? url('search') : url('search.php')) . $q;
        case 'order':
            $qs = $params ? '?' . http_build_query($params) : '';
            return ($pretty ? url('order') : url('order.php')) . $qs;
        case 'about':    return $pretty ? url('about') : url('about.php');
        case 'faq':      return $pretty ? url('faq') : url('faq.php');
        case 'contact':  return $pretty ? url('contact') : url('contact.php');
        case 'privacy':  return $pretty ? url('privacy') : url('privacy.php');
        case 'terms':    return $pretty ? url('terms') : url('terms.php');
        case 'specializations': return $pretty ? url('specializations') : url('specializations.php');
        case 'portfolio':
            $qs = $params ? '?' . http_build_query(array_filter($params, fn($v) => $v !== '' && $v !== null)) : '';
            return ($pretty ? url('portfolio') : url('portfolio.php')) . ($qs === '?' ? '' : $qs);
        case 'work':
            return $pretty ? url('work/' . rawurlencode($params['slug'])) : url('work.php?slug=' . rawurlencode($params['slug']));
        case 'review':   return $pretty ? url('review') : url('review.php');
        case 'track':
            $qs = !empty($params['ref']) ? '?ref=' . rawurlencode($params['ref']) : '';
            return ($pretty ? url('track') : url('track.php')) . $qs;
        case 'blog':
            $qs = !empty($params['page']) ? '?page=' . (int) $params['page'] : '';
            return ($pretty ? url('blog') : url('blog.php')) . $qs;
        case 'article':
            return $pretty ? url('blog/' . rawurlencode($params['slug'])) : url('article.php?slug=' . rawurlencode($params['slug']));
        case 'page':
            return $pretty ? url('page/' . rawurlencode($params['slug'])) : url('page.php?slug=' . rawurlencode($params['slug']));
        case 'work_file':
            return url('portfolio_file.php?id=' . (int) $params['id']);
        case 'login':
        case 'register':
        case 'account':
        case 'logout':
        case 'forgot':
            $qs = $params ? '?' . http_build_query(array_filter($params, fn($v) => $v !== '' && $v !== null)) : '';
            return ($pretty ? url($name) : url($name . '.php')) . ($qs === '?' ? '' : $qs);
    }
    return url($name);
}

function admin_url(string $page = '', array $params = []): string
{
    $page = $page === '' ? 'index.php' : (str_ends_with($page, '.php') ? $page : $page . '.php');
    return url('admin/' . $page) . ($params ? '?' . http_build_query($params) : '');
}

/** رابط عودة آمن (داخل الموقع فقط) لمنع إعادة التوجيه المفتوح */
function safe_next(?string $next, string $fallback): string
{
    $next = (string) $next;
    if ($next === '' || !str_starts_with($next, '/') || str_starts_with($next, '//') || str_contains($next, '\\') || preg_match('/[\r\n]/', $next)) {
        return $fallback;
    }
    return $next;
}

function redirect(string $to, int $code = 302): never
{
    header('Location: ' . $to, true, $code);
    exit;
}

/** رسائل لحظية بين الطلبات */
function flash(string $type, string $message): void
{
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $f = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $f;
}

/** إعدادات الموقع من قاعدة البيانات مع تخزين مؤقت للطلب الحالي */
function setting(string $key, $default = '')
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (db()->query('SELECT setting_key, setting_value FROM site_settings') as $row) {
                $cache[$row['setting_key']] = $row['setting_value'];
            }
        } catch (Throwable $e) {
            error_log('settings load failed: ' . $e->getMessage());
        }
    }
    $v = $cache[$key] ?? null;
    return ($v === null || $v === '') ? $default : $v;
}

/** رقم واتساب بصيغة دولية أرقام فقط */
function whatsapp_number(): string
{
    return preg_replace('/\D+/', '', (string) setting('whatsapp_number', '966575996163'));
}

/** تحويل نص متعدد الأسطر إلى مصفوفة بنود */
function lines(?string $text): array
{
    if ($text === null || trim($text) === '') return [];
    $out = [];
    foreach (preg_split('/\r\n|\r|\n/', $text) as $l) {
        $l = trim(ltrim(trim($l), "-•*·"));
        if ($l !== '') $out[] = $l;
    }
    return $out;
}

/** إنشاء slug يدعم العربية */
function slugify(string $text): string
{
    $text = trim(mb_strtolower($text, 'UTF-8'));
    $text = preg_replace('/[\x{064B}-\x{065F}\x{0640}]/u', '', $text); // التشكيل والتطويل
    $text = preg_replace('/[^\p{Arabic}\p{L}\p{N}]+/u', '-', $text);
    $text = trim((string) $text, '-');
    return mb_substr($text !== '' ? $text : 'item-' . bin2hex(random_bytes(3)), 0, 180, 'UTF-8');
}

/** تقصير النص */
function excerpt(?string $text, int $len = 140): string
{
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $text)));
    return mb_strlen($text) > $len ? mb_substr($text, 0, $len) . '…' : $text;
}

function request_method(): string
{
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

function is_post(): bool
{
    return request_method() === 'POST';
}

function input(string $key, $default = '')
{
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    return is_string($v) ? trim($v) : $v;
}

function json_response(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function not_found(): never
{
    http_response_code(404);
    $f = PUBLIC_PATH . '/404.php';
    if (is_file($f)) require $f;
    else echo '<!doctype html><meta charset="utf-8"><title>404</title><p style="font-family:Tahoma;text-align:center;margin-top:20vh">الصفحة غير موجودة. <a href="' . e(url('')) . '">العودة للرئيسية</a></p>';
    exit;
}

/**
 * الروابط الصديقة تعمل فقط إذا وُجد ملف .htaccess في المجلد العام (أو خادم PHP المدمج).
 * عند غيابه نعود تلقائيًا لروابط ‎.php حتى لا تظهر صفحات 404 (إصلاح v5).
 */
function pretty_urls(): bool
{
    static $p = null;
    if ($p !== null) return $p;
    if (!(bool) config('app.pretty', true)) return $p = false;
    return $p = PHP_SAPI === 'cli-server' || PHP_SAPI === 'cli' || is_file(PUBLIC_PATH . '/.htaccess');
}

/** تقسيم ملف SQL إلى أوامر مع احترام النصوص بين علامات التنصيص */
function sql_split(string $sql): array
{
    $out = []; $buf = ''; $len = strlen($sql); $inStr = false;
    for ($i = 0; $i < $len; $i++) {
        $ch = $sql[$i];
        if (!$inStr && $ch === '-' && ($sql[$i + 1] ?? '') === '-') { while ($i < $len && $sql[$i] !== "\n") $i++; continue; }
        if ($inStr) {
            if ($ch === '\\') { $buf .= $ch . ($sql[$i + 1] ?? ''); $i++; continue; }
            if ($ch === "'") { if (($sql[$i + 1] ?? '') === "'") { $buf .= "''"; $i++; continue; } $inStr = false; }
            $buf .= $ch; continue;
        }
        if ($ch === "'") { $inStr = true; $buf .= $ch; continue; }
        if ($ch === ';') { if (trim($buf) !== '') $out[] = trim($buf); $buf = ''; continue; }
        $buf .= $ch;
    }
    if (trim($buf) !== '') $out[] = trim($buf);
    return $out;
}

/** عنوان IP للعميل (لا نثق في ترويسات البروكسي إلا إذا كانت موثوقة) */
function client_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45);
}

function ip_hash(): string
{
    return hash_hmac('sha256', client_ip(), config('app.key', 'ikh') ?: 'ikh');
}

/** أنواع رسائل التواصل */
function contact_categories(): array
{
    return ['inquiry' => 'استفسار عام', 'order' => 'بخصوص طلب', 'quote' => 'طلب عرض سعر', 'complaint' => 'شكوى أو ملاحظة', 'partnership' => 'تعاون وشراكة', 'other' => 'أخرى'];
}

function message_statuses(): array
{
    return ['new' => ['جديدة', 'danger'], 'read' => ['مقروءة', 'secondary'], 'processing' => ['قيد المعالجة', 'warning'], 'done' => ['تمت', 'success']];
}

/** تسميات ثابتة */
function request_statuses(): array
{
    $st = [
        'new'             => ['جديد', 'primary'],
        'reviewing'       => ['قيد المراجعة', 'info'],
        'awaiting_client' => ['بانتظار معلومات', 'warning'],
        'in_progress'     => ['قيد التنفيذ', 'dark'],
        'completed'       => ['مكتمل', 'success'],
        'cancelled'       => ['ملغي', 'secondary'],
    ];
    if (function_exists('schema_v5') && !schema_v5()) unset($st['in_progress']); // قبل تشغيل الترقية
    return $st;
}

function service_types(): array
{
    return [
        'task'         => 'تنفيذ ومساعدة',
        'consultation' => 'استشارة',
        'subscription' => 'اشتراك',
        'training'     => 'تدريب وشرح',
        'guidance'     => 'إرشاد وتوجيه',
    ];
}

function contact_methods(): array
{
    return ['whatsapp' => 'واتساب', 'phone' => 'اتصال هاتفي', 'email' => 'بريد إلكتروني', 'telegram' => 'تيليجرام', 'other' => 'أخرى'];
}

function format_bytes(int $bytes): string
{
    if ($bytes >= 1048576) return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024) . ' KB';
    return $bytes . ' B';
}

function ar_date(?string $dt, bool $withTime = false): string
{
    if (!$dt) return '—';
    $ts = strtotime($dt);
    return $ts ? date($withTime ? 'Y/m/d H:i' : 'Y/m/d', $ts) : '—';
}

function selected($a, $b): string
{
    return (string) $a === (string) $b ? ' selected' : '';
}

function checked($v): string
{
    return $v ? ' checked' : '';
}

/** أيقونة Bootstrap Icons آمنة (أحرف وأرقام وشرطات فقط) */
function icon(?string $name, string $extra = ''): string
{
    $name = preg_replace('/[^a-z0-9\-]/', '', (string) $name) ?: 'bi-grid';
    if (!str_starts_with($name, 'bi-')) $name = 'bi-' . $name;
    return '<i class="bi ' . $name . ($extra ? ' ' . e($extra) : '') . '" aria-hidden="true"></i>';
}

/** أيقونة حسب امتداد الملف */
function file_icon(string $ext): string
{
    return [
        'pdf' => 'bi-file-earmark-pdf text-danger', 'docx' => 'bi-file-earmark-word text-primary', 'doc' => 'bi-file-earmark-word text-primary',
        'pptx' => 'bi-file-earmark-ppt text-warning', 'xlsx' => 'bi-file-earmark-excel text-success', 'zip' => 'bi-file-earmark-zip text-secondary',
        'dwg' => 'bi-file-earmark-ruled text-info',
    ][strtolower($ext)] ?? 'bi-file-earmark';
}

/** تقسيم نص مفصول بفواصل (عربية أو إنجليزية) إلى عناصر */
function csv_items(?string $s): array
{
    return array_values(array_filter(array_map('trim', preg_split('/[,،\n]+/u', (string) $s)), fn($v) => $v !== ''));
}

/** شهر وسنة بالعربية: مارس 2026 */
function ar_month(?string $date): string
{
    if (!$date || !($t = strtotime($date))) return '';
    $m = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    return $m[(int) date('n', $t) - 1] . ' ' . date('Y', $t);
}

/**
 * تنظيف HTML المقالات والصفحات (قائمة بيضاء) لمنع XSS:
 * وسوم وخصائص محددة فقط، روابط http/https/mailto/tel أو نسبية، والصور من الموقع أو https.
 */
function safe_html(?string $html): string
{
    $html = trim((string) $html);
    if ($html === '') return '';
    if (!class_exists('DOMDocument')) return nl2br(e(strip_tags($html)));
    $allowed = ['p' => [], 'br' => [], 'h2' => [], 'h3' => [], 'h4' => [], 'strong' => [], 'b' => [], 'em' => [], 'i' => [], 'u' => [], 's' => [],
        'ul' => [], 'ol' => [], 'li' => [], 'blockquote' => [], 'hr' => [], 'code' => [], 'pre' => [], 'span' => [], 'div' => [],
        'a' => ['href', 'title', 'target'], 'img' => ['src', 'alt', 'width', 'height', 'title'],
        'table' => [], 'thead' => [], 'tbody' => [], 'tr' => [], 'th' => ['colspan', 'rowspan'], 'td' => ['colspan', 'rowspan'], 'figure' => [], 'figcaption' => []];
    $doc = new DOMDocument('1.0', 'UTF-8');
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="utf-8"?><div id="__root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET);
    libxml_clear_errors();
    $root = $doc->getElementById('__root') ?: $doc->documentElement;
    $okUrl = function (string $u, bool $img): bool {
        $u = trim($u);
        if ($u === '' || preg_match('/[\x00-\x1f]/', $u)) return false;
        if (preg_match('~^(https?:)?//~i', $u)) return (bool) preg_match('~^https?://~i', $u) || !$img;
        if (preg_match('/^[a-z][a-z0-9+.\-]*:/i', $u)) return !$img && (bool) preg_match('/^(mailto|tel):/i', $u);
        return true; // رابط نسبي
    };
    $walk = function (DOMNode $node) use (&$walk, $allowed, $okUrl, $doc): void {
        for ($i = $node->childNodes->length - 1; $i >= 0; $i--) {
            $ch = $node->childNodes->item($i);
            if ($ch instanceof DOMComment) { $node->removeChild($ch); continue; }
            if (!$ch instanceof DOMElement) continue;
            $tag = strtolower($ch->tagName);
            if (in_array($tag, ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'svg', 'math', 'link', 'meta', 'base'], true)) { $node->removeChild($ch); continue; }
            $walk($ch);
            if (!isset($allowed[$tag])) { // فك الوسم مع الإبقاء على النص
                while ($ch->firstChild) $node->insertBefore($ch->firstChild, $ch);
                $node->removeChild($ch);
                continue;
            }
            for ($a = $ch->attributes->length - 1; $a >= 0; $a--) {
                $attr = $ch->attributes->item($a);
                $name = strtolower($attr->name);
                if (!in_array($name, $allowed[$tag], true)) { $ch->removeAttribute($attr->name); continue; }
                if (($name === 'href' || $name === 'src') && !$okUrl($attr->value, $name === 'src')) $ch->removeAttribute($attr->name);
            }
            if ($tag === 'a') {
                if ($ch->getAttribute('target') !== '_blank') $ch->removeAttribute('target');
                if (preg_match('~^https?://~i', $ch->getAttribute('href'))) $ch->setAttribute('rel', 'noopener nofollow');
            }
            if ($tag === 'img') { $ch->setAttribute('loading', 'lazy'); if (!$ch->hasAttribute('alt')) $ch->setAttribute('alt', ''); }
        }
    };
    $walk($root);
    $out = '';
    foreach ($root->childNodes as $c) $out .= $doc->saveHTML($c);
    return $out;
}

/** نص عادي ← فقرات HTML (إن لم يكتب المحرر وسوم HTML) */
function text_to_html(string $txt): string
{
    if (preg_match('/<(p|h2|h3|ul|ol|div|br)\b/i', $txt)) return $txt;
    $paras = preg_split('/\R{2,}/u', trim($txt));
    return implode("\n", array_map(fn($p) => '<p>' . nl2br(e(trim($p))) . '</p>', array_filter($paras, fn($p) => trim($p) !== '')));
}
