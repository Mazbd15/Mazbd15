<?php
/**
 * نموذج إرسال رأي العميل (v5)
 * - يُحفظ الرأي «بانتظار المراجعة» ولا يظهر إلا بعد اعتماد الإدارة.
 * - موافقة صريحة على النشر، صورة اختيارية، حماية من الإغراق (honeypot + حد معدل + CSRF).
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

if (!testimonials_enabled() || setting('testimonials_allow_submit', '1') !== '1') not_found();

$errors = [];
$done = false;
$services = db_all("SELECT s.id, s.name, c.name cat FROM services s JOIN categories c ON c.id = s.category_id AND c.is_active = 1 WHERE s.is_active = 1" . sd('services', 's') . ' ORDER BY c.sort_order, s.sort_order');
$prefill = ['name' => '', 'specialization' => '', 'service_id' => (int) ($_GET['service'] ?? 0), 'rating' => 5, 'body' => '', 'request_ref' => strtoupper(trim((string) ($_GET['ref'] ?? '')))];

if (is_post()) {
    require_csrf();
    $d = [
        'name'           => mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120),
        'specialization' => mb_substr(trim((string) ($_POST['specialization'] ?? '')), 0, 160),
        'service_id'     => (int) ($_POST['service_id'] ?? 0),
        'rating'         => (int) ($_POST['rating'] ?? 0),
        'body'           => mb_substr(trim((string) ($_POST['body'] ?? '')), 0, 1500),
        'request_ref'    => mb_substr(strtoupper(trim((string) ($_POST['request_ref'] ?? ''))), 0, 30),
    ];
    $prefill = $d;
    if (trim((string) ($_POST['website'] ?? '')) !== '') {
        $done = true; // روبوت: نتظاهر بالنجاح دون حفظ
    } elseif (rate_limited('review', 3, 3600)) {
        $errors[] = 'أرسلت عدة آراء مؤخرًا. يرجى المحاولة لاحقًا.';
    } else {
        if (mb_strlen($d['name']) < 2) $errors[] = 'اكتب اسمك أو اسمًا مستعارًا.';
        if ($d['rating'] < 1 || $d['rating'] > 5) $errors[] = 'اختر التقييم من 1 إلى 5 نجوم.';
        if (mb_strlen($d['body']) < 15) $errors[] = 'اكتب رأيك بتفصيل أكثر (15 حرفًا على الأقل).';
        if (empty($_POST['consent'])) $errors[] = 'يلزم الموافقة على نشر الرأي لإرساله.';
        if ($d['service_id'] && !in_array($d['service_id'], array_map('intval', array_column($services, 'id')), true)) $d['service_id'] = 0;
        // رابط الطلب يمنح شارة «موثّق» فقط إن كان مرجعًا حقيقيًا ويُراجع من الإدارة
        $req = $d['request_ref'] !== '' ? db_one('SELECT id, service_id FROM requests WHERE reference = ?', [$d['request_ref']]) : null;
        if ($d['request_ref'] !== '' && !$req) $errors[] = 'رقم الطلب غير صحيح — يمكنك تركه فارغًا.';
        $avatar = null;
        if (!$errors && !empty($_FILES['avatar']['name'])) {
            [$ok, $res] = store_public_image($_FILES['avatar'], 'testimonials');
            if ($ok) $avatar = $res; else $errors[] = $res;
        }
        if (!$errors) {
            $id = db_insert('testimonials', [
                'name' => $d['name'], 'specialization' => $d['specialization'] ?: null,
                'service_id' => $d['service_id'] ?: ($req['service_id'] ?? null), 'rating' => $d['rating'], 'body' => $d['body'],
                'avatar' => $avatar, 'request_ref' => $req ? $d['request_ref'] : null, 'is_verified' => 0,
                'status' => 'pending', 'consent_publish' => 1, 'source' => 'visitor', 'theme' => 'white',
                'sort_order' => (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM testimonials'), 'ip_hash' => ip_hash(),
            ]);
            notify_staff('editor', 'رأي عميل جديد بانتظار المراجعة', $d['name'] . ' — ' . $d['rating'] . '/5', admin_url('testimonials', ['edit' => $id]));
            $done = true;
        }
    }
}

$page_title = 'شاركنا رأيك';
$page_description = 'شارك تجربتك مع منصة ' . setting('site_name') . ' — يُنشر رأيك بعد مراجعته وبموافقتك.';
$breadcrumbs = [['شاركنا رأيك', null]];
$noindex = true;
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero"><div class="container"><h1>شاركنا رأيك</h1><p>رأيك يساعد طلابًا آخرين على الاختيار — ويساعدنا على التحسن.</p></div></section>
<section class="section pt-4">
  <div class="container" style="max-width:760px">
    <?php if ($done): ?>
      <div class="form-card text-center">
        <span class="feature-icon mx-auto"><i class="bi bi-heart-fill"></i></span>
        <h2 class="h4 mt-3">شكرًا لك! وصلنا رأيك</h2>
        <p class="text-muted">سيظهر رأيك في الموقع بعد مراجعته من فريقنا. لا ننشر أي رأي دون موافقة صاحبه.</p>
        <a class="btn btn-navy" href="<?= e(route('home')) ?>">العودة للرئيسية</a>
      </div>
    <?php else: ?>
    <form class="form-card" method="post" enctype="multipart/form-data" action="<?= e(route('review')) ?>">
      <?= csrf_field() ?>
      <div class="hp-field" aria-hidden="true"><label>اترك هذا الحقل فارغًا<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
      <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
      <div class="row g-3">
        <div class="col-md-6"><label class="form-label" for="r-name">الاسم أو اسم مستعار *</label><input class="form-control" id="r-name" name="name" maxlength="120" required value="<?= e($prefill['name']) ?>" placeholder="مثال: سارة م."></div>
        <div class="col-md-6"><label class="form-label" for="r-spec">تخصصك (اختياري)</label><input class="form-control" id="r-spec" name="specialization" maxlength="160" value="<?= e($prefill['specialization']) ?>" placeholder="مثال: طالبة إدارة أعمال"></div>
        <div class="col-md-6"><label class="form-label" for="r-svc">الخدمة التي حصلت عليها</label>
          <select class="form-select" id="r-svc" name="service_id"><option value="">— اختر —</option>
            <?php foreach ($services as $sv): ?><option value="<?= (int) $sv['id'] ?>"<?= selected((string) $prefill['service_id'], (string) $sv['id']) ?>><?= e($sv['cat'] . ' ← ' . $sv['name']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-6"><label class="form-label" for="r-ref">رقم طلبك (اختياري)</label><input class="form-control" id="r-ref" name="request_ref" maxlength="30" dir="ltr" value="<?= e($prefill['request_ref']) ?>" placeholder="IKH-..."></div>
        <div class="col-12"><span class="form-label d-block">تقييمك *</span>
          <div class="star-input" role="radiogroup" aria-label="التقييم">
            <?php for ($i = 5; $i >= 1; $i--): ?><input type="radio" name="rating" id="rv<?= $i ?>" value="<?= $i ?>"<?= (int) $prefill['rating'] === $i ? ' checked' : '' ?> required><label for="rv<?= $i ?>" title="<?= $i ?> من 5"><i class="bi bi-star-fill"></i></label><?php endfor; ?>
          </div></div>
        <div class="col-12"><label class="form-label" for="r-body">رأيك *</label><textarea class="form-control" id="r-body" name="body" rows="5" maxlength="1500" required placeholder="كيف كانت تجربتك معنا؟"><?= e($prefill['body']) ?></textarea></div>
        <div class="col-12"><label class="form-label" for="r-av">صورتك (اختياري)</label><input class="form-control" type="file" id="r-av" name="avatar" accept="image/jpeg,image/png,image/webp"><div class="form-text">JPG/PNG/WEBP حتى <?= (int) env('IMAGE_MAX_MB', 8) ?> م.ب — تُنشر فقط إذا وافقت أدناه.</div></div>
        <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="consent" value="1" id="r-consent" required><label class="form-check-label" for="r-consent">أوافق على نشر رأيي (واسمي وصورتي إن أرفقتها) في موقع <?= e(setting('site_name')) ?> بعد مراجعته.</label></div></div>
      </div>
      <button class="btn btn-navy btn-lg mt-3"><i class="bi bi-send"></i> إرسال الرأي</button>
    </form>
    <?php endif; ?>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
