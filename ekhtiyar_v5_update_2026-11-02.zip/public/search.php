<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100);
$catId = (int) ($_GET['category'] ?? 0);
$tree = catalog_tree();
if ($catId && !isset($tree[$catId])) $catId = 0;
$results = $q !== '' ? search_services($q, ['category' => $catId], 60) : [];

// اقتراح أقسام وتخصصات مطابقة
$matchedSubs = [];
if ($q !== '') {
    $nq = ar_normalize($q);
    foreach ($tree as $c) {
        foreach ($c['subs'] as $s) {
            if ($nq !== '' && (str_contains(ar_normalize($s['name']), $nq) || str_contains(ar_normalize($c['name']), $nq))) {
                $matchedSubs[] = ['cat' => $c, 'sub' => $s];
            }
        }
    }
    $matchedSubs = array_slice($matchedSubs, 0, 6);
}
// عدّ النتائج لكل قسم
$counts = [];
foreach ($q !== '' ? search_services($q, [], 500) : [] as $r) $counts[$r['category_id']] = ($counts[$r['category_id']] ?? 0) + 1;

$active_nav = 'services';
$page_title = $q !== '' ? 'نتائج البحث عن: ' . $q : 'البحث في الخدمات';
$page_description = 'ابحث في خدمات منصة اختيارك الأكاديمية والهندسية والبرمجية والتصميمية.';
$breadcrumbs = [['البحث', null]];
$noindex = true;
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1><?= $q !== '' ? 'نتائج البحث' : 'ابحث عن خدمتك' ?></h1>
    <div class="mt-3 mx-auto" style="max-width:720px"><?= render_search_box($q, 'md', 'page-search') ?></div>
  </div>
</section>
<section class="section pt-4">
  <div class="container">
    <?php if ($q === ''): ?>
      <div class="empty-state">
        <i class="bi bi-search"></i>
        <h2>اكتب ما تبحث عنه</h2>
        <p>يمكنك البحث بالعربية أو الإنجليزية أو بالكلمات الدارجة مثل: ريبورت، اسايمنت، بوربوينت، اوتوكاد.</p>
      </div>
    <?php else: ?>
      <p class="results-summary">عثرنا على <strong><?= count($results) ?></strong> خدمة مطابقة لـ «<?= e($q) ?>»<?= $catId ? ' في ' . e($tree[$catId]['name']) : '' ?>.</p>
      <?php if ($counts): ?>
        <div class="filter-chips mb-4" aria-label="تصفية حسب القسم">
          <a class="chip<?= !$catId ? ' active' : '' ?>" href="<?= e(route('search', ['q' => $q])) ?>">الكل</a>
          <?php foreach ($tree as $cid => $c): if (empty($counts[$cid])) continue; ?>
            <a class="chip<?= $catId === $cid ? ' active' : '' ?>" href="<?= e(route('search', ['q' => $q]) . '&category=' . $cid) ?>"><?= e($c['name']) ?> <span>(<?= $counts[$cid] ?>)</span></a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <?php if ($matchedSubs): ?>
        <div class="matched-subs mb-4">
          <span class="text-muted small">تخصصات مرتبطة:</span>
          <?php foreach ($matchedSubs as $m): ?>
            <a class="chip chip-outline" href="<?= e(route('category', ['slug' => $m['cat']['slug'], 'sub' => $m['sub']['slug']])) ?>"><?= e($m['sub']['name']) ?></a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <?php if ($results): ?>
        <div class="row g-4">
          <?php foreach ($results as $s): ?><div class="col-sm-6 col-lg-4 col-xl-3"><?= render_service_card($s) ?></div><?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="empty-state">
          <i class="bi bi-emoji-neutral"></i>
          <h2>لم نجد نتائج مطابقة</h2>
          <p>جرّب كلمات أبسط أو تصفح الأقسام، أو أرسل لنا طلبك مباشرة وسنحدد الخدمة المناسبة.</p>
          <div class="d-flex gap-2 justify-content-center flex-wrap">
            <a class="btn btn-navy" href="<?= e(route('services')) ?>">تصفح جميع الخدمات</a>
            <a class="btn btn-whatsapp" href="<?= e(wa_link(wa_order_message(['service' => $q]))) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب «<?= e(excerpt($q, 30)) ?>» عبر واتساب</a>
          </div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
