<?php
/** صفحة 404 — يمكن تضمينها من not_found() أو استدعاؤها عبر ErrorDocument */
if (!function_exists('setting')) {
    require_once dirname(__DIR__) . '/includes/bootstrap.php';
    http_response_code(404);
}
$page_title = 'الصفحة غير موجودة';
$page_description = 'الصفحة المطلوبة غير موجودة.';
$noindex = true;
$breadcrumbs = [];
require ROOT_PATH . '/includes/header.php';
?>
<section class="section error-page">
  <div class="container text-center">
    <div class="error-code">404</div>
    <h1 class="h3">عذرًا، الصفحة غير موجودة</h1>
    <p class="text-muted">ربما تم نقل الصفحة أو أن الرابط غير صحيح. جرّب البحث عن الخدمة التي تحتاجها:</p>
    <div class="mx-auto my-4" style="max-width:620px"><?= render_search_box('', 'md', 'err-search') ?></div>
    <div class="d-flex gap-2 justify-content-center flex-wrap">
      <a class="btn btn-navy" href="<?= e(route('home')) ?>"><i class="bi bi-house"></i> الرئيسية</a>
      <a class="btn btn-outline-navy" href="<?= e(route('services')) ?>">جميع الخدمات</a>
      <a class="btn btn-whatsapp" href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> تواصل معنا</a>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
