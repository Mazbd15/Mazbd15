<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
if (is_post() && csrf_valid() && ($u = current_user())) {
    if (in_array($u['role'], staff_roles(), true)) audit('logout', 'user', (int) $u['id'], 'تسجيل خروج');
    logout_user();
    flash('success', 'تم تسجيل الخروج.');
}
redirect(route('home'));
