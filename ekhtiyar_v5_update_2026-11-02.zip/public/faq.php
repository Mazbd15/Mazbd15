<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
$general = faqs_for(null, null, false, 100);
$catFaqs = db_all('SELECT f.*, c.name AS category_name, c.slug AS category_slug FROM faqs f JOIN categories c ON c.id = f.category_id AND c.is_active = 1 WHERE f.is_active = 1 AND f.service_id IS NULL ORDER BY c.sort_order, f.sort_order');
$grouped = [];
foreach ($catFaqs as $f) $grouped[$f['category_name']][] = $f;
$active_nav = 'faq';
$page_title = 'الأسئلة الشائعة';
$page_description = 'إجابات الأسئلة الشائعة حول طريقة الطلب والأسعار والدفع والخصوصية والتعديلات في منصة اختيارك للخدمات الطلابية.';
$breadcrumbs = [['الأسئلة الشائعة', null]];
$json_ld = faq_json_ld(array_merge($general, $catFaqs));
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero"><div class="container"><h1>الأسئلة الشائعة</h1><p>كل ما تحتاج معرفته قبل طلب خدمتك.</p></div></section>
<section class="section pt-4">
  <div class="container" style="max-width:900px">
    <h2 class="h4 mb-3">أسئلة عامة</h2>
    <?= render_faq_accordion($general, 'faq-general') ?>
    <?php $i = 0; foreach ($grouped as $name => $list): $i++; ?>
      <h2 class="h4 mt-5 mb-3"><?= e($name) ?></h2>
      <?= render_faq_accordion($list, 'faq-cat-' . $i) ?>
    <?php endforeach; ?>
    <div class="cta-mini mt-5">
      <p class="mb-0">لديك سؤال آخر؟</p>
      <a class="btn btn-whatsapp" href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اسألنا عبر واتساب</a>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
