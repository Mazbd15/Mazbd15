<?php
/** صفحة ثابتة يديرها المسؤول (v5) */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$pg = post_by_slug('page', (string) ($_GET['slug'] ?? ''));
if (!$pg) not_found();
post_track_view((int) $pg['id']);
$page_title = $pg['meta_title'] ?: $pg['title'];
$page_description = $pg['meta_description'] ?: ($pg['excerpt'] ?: excerpt($pg['body'], 160));
$page_canonical = absolute_url(ltrim(substr(route('page', ['slug' => $pg['slug']]), strlen(base_path())), '/'));
if ($pg['cover_image'] && media_exists($pg['cover_image'])) $page_image = absolute_url($pg['cover_image']);
$breadcrumbs = [[$pg['title'], null]];
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero"><div class="container"><h1><?= e($pg['title']) ?></h1><?php if ($pg['excerpt']): ?><p><?= e($pg['excerpt']) ?></p><?php endif; ?></div></section>
<section class="section pt-4">
  <div class="container" style="max-width:860px">
    <?php if ($pg['cover_image'] && media_exists($pg['cover_image'])): ?><img class="article-cover mb-4" src="<?= e(media_url($pg['cover_image'])) ?>" alt="" width="1200" height="630"><?php endif; ?>
    <div class="article-body"><?= safe_html($pg['body']) ?></div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
