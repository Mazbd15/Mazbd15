<?php
/** صفحة الخدمة المستقلة */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$slug = (string) ($_GET['slug'] ?? '');
$service = $slug !== '' ? service_by_slug($slug) : null;
if (!$service) not_found();

service_track_view((int) $service['id']);
$category = db_one('SELECT * FROM categories WHERE id = ?', [$service['category_id']]);
$siblings = $service['subcategory_id']
    ? db_all('SELECT name, slug FROM subcategories WHERE category_id = ? AND is_active = 1 ORDER BY sort_order', [$service['category_id']])
    : [];
$faqs = faqs_for(null, (int) $service['id']);
if (!$faqs) $faqs = faqs_for((int) $service['category_id'], null, false, 4);
$related = services_related($service, 4);
$gallery = db_all('SELECT * FROM service_files WHERE service_id = ? AND file_type = "image" ORDER BY sort_order, id', [$service['id']]);
$includes = lines($service['includes_text']);
$requirements = lines($service['requirements_text']);
$tools = lines($service['tools_text']);
$waLink = wa_service_link($service);
$svcWorks = portfolio_list(['service' => $service['id']], 6);
if (count($svcWorks) < 3) {
    $ids = array_column($svcWorks, 'id');
    foreach (portfolio_list(['category' => $service['category_id'], 'subcategory' => $service['subcategory_id'] ?: 0], 6) as $w) if (!in_array($w['id'], $ids) && count($svcWorks) < 6) { $svcWorks[] = $w; $ids[] = $w['id']; }
}

$active_nav = 'services';
$page_title = $service['meta_title'] ?: $service['name'];
$page_description = $service['meta_description'] ?: (setting('seo_auto_descriptions', '1') === '1'
    ? seo_description($service['short_description'] ?: $service['name'], ($service['subcategory_name'] ? 'ضمن تخصص ' . $service['subcategory_name'] . '.' : ''), 'اطلب الآن عبر واتساب من ' . setting('site_name') . '.')
    : $service['short_description']);
$page_type = 'article';
if ($service['image']) $page_image = absolute_url($service['image']);
$breadcrumbs = [
    ['جميع الخدمات', route('services')],
    [$service['category_name'], route('category', ['slug' => $service['category_slug']])],
];
if ($service['subcategory_name']) $breadcrumbs[] = [$service['subcategory_name'], route('category', ['slug' => $service['category_slug'], 'sub' => $service['subcategory_slug']])];
$breadcrumbs[] = [$service['name'], null];
$page_canonical = absolute_url(ltrim(substr(route('service', ['slug' => $service['slug']]), strlen(base_path())), '/'));
$json_ld = faq_json_ld($faqs);
$json_ld[] = [
    '@context' => 'https://schema.org', '@type' => 'Service', 'name' => $service['name'], 'description' => $service['short_description'],
    'serviceType' => $service['subcategory_name'] ?: $service['category_name'], 'category' => $service['category_name'],
    'provider' => ['@type' => 'Organization', 'name' => setting('site_name'), 'url' => absolute_url()],
    'areaServed' => setting('area_served', 'SA') ?: 'SA', 'availableLanguage' => ['ar', 'en'], 'url' => $page_canonical,
];
if ($service['image']) $json_ld[count($json_ld) - 1]['image'] = absolute_url($service['image']);
if ($service['keywords']) $json_ld[count($json_ld) - 1]['keywords'] = $service['keywords'];
$wa_float_link = $waLink;
$body_class = 'has-sticky-order';
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero service-hero tone-<?= e(category_tone($service['category_slug'])) ?>">
  <div class="container">
    <div class="d-flex flex-wrap gap-2 mb-3">
      <a class="chip" href="<?= e(route('category', ['slug' => $service['category_slug']])) ?>"><?= icon($service['category_icon']) ?> <?= e($service['category_name']) ?></a>
      <?php if ($service['subcategory_name']): ?><a class="chip" href="<?= e(route('category', ['slug' => $service['category_slug'], 'sub' => $service['subcategory_slug']])) ?>"><?= e($service['subcategory_name']) ?></a><?php endif; ?>
      <span class="chip chip-muted"><?= e(service_types()[$service['service_type']] ?? '') ?></span>
    </div>
    <h1><?= e($service['name']) ?></h1>
    <p class="mb-0"><?= e($service['short_description']) ?></p>
    <div class="hero-actions mt-3 d-lg-none">
      <a class="btn btn-gold" href="<?= e($waLink) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب الآن</a>
      <a class="btn btn-glass" href="#order-box"><i class="bi bi-info-circle"></i> السعر والمدة</a>
    </div>
  </div>
</section>

<section class="section pt-4">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <?= render_banners(banners_for((int) $service['category_id'], 3), 'svc-ads') ?>
        <?php if ($service['image']): ?>
          <img class="service-cover" src="<?= e(media_url($service['image'])) ?>" alt="<?= e($service['name']) ?>" loading="lazy">
        <?php endif; ?>

        <article class="content-card">
          <h2><i class="bi bi-info-circle"></i> عن الخدمة</h2>
          <p><?= nl2br(e($service['description'] ?: $service['short_description'])) ?></p>
        </article>

        <?php if ($includes): ?>
        <article class="content-card">
          <h2><i class="bi bi-check2-square"></i> ماذا تشمل الخدمة؟</h2>
          <ul class="check-list"><?php foreach ($includes as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
        </article>
        <?php endif; ?>

        <div class="row g-4">
          <?php if ($requirements): ?>
          <div class="col-md-<?= $tools ? '7' : '12' ?>">
            <article class="content-card h-100">
              <h2><i class="bi bi-clipboard-check"></i> المتطلبات التي ترسلها</h2>
              <ul class="dot-list"><?php foreach ($requirements as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
            </article>
          </div>
          <?php endif; ?>
          <?php if ($tools): ?>
          <div class="col-md-<?= $requirements ? '5' : '12' ?>">
            <article class="content-card h-100">
              <h2><i class="bi bi-tools"></i> البرامج والملفات</h2>
              <div class="tool-tags"><?php foreach ($tools as $l): ?><span><?= e($l) ?></span><?php endforeach; ?></div>
            </article>
          </div>
          <?php endif; ?>
        </div>

        <?php if ($gallery): ?>
        <article class="content-card">
          <h2><i class="bi bi-images"></i> صور توضيحية</h2>
          <div class="row g-2"><?php foreach ($gallery as $g): ?><div class="col-6 col-md-4"><img class="img-fluid rounded" src="<?= e(media_url($g['file_path'], true)) ?>" alt="<?= e($g['alt_text'] ?: $service['name']) ?>" loading="lazy"></div><?php endforeach; ?></div>
        </article>
        <?php endif; ?>

        <?php if ($svcWorks): ?>
          <div class="content-card"><?= render_portfolio_section($svcWorks, 'نماذج من أعمالنا', 'أعمال مشابهة نفذناها سابقًا — اضغط لمشاهدة الصور والملفات.', route('portfolio', ['category' => $service['category_slug']]), 'svc-portfolio') ?></div>
        <?php endif; ?>

        <?= render_notice($category['notice'] ?? null, $service['category_slug'] === 'engineering' ? 'bi-cone-striped' : 'bi-info-circle') ?>

        <?php if ($faqs): ?>
          <h2 class="h4 mt-4 mb-3">الأسئلة الشائعة</h2>
          <?= render_faq_accordion($faqs, 'svc-faq') ?>
        <?php endif; ?>
      </div>

      <aside class="col-lg-4" aria-label="ملخص الطلب">
        <div class="order-box sticky-lg-top" id="order-box">
          <h2 class="h5">ملخص الخدمة</h2>
          <dl class="summary-list">
            <div><dt><i class="bi bi-tag"></i> السعر</dt><dd><?= e($service['price_text'] ?: 'يحدد بعد مراجعة المتطلبات') ?></dd></div>
            <div><dt><i class="bi bi-hourglass-split"></i> المدة التقديرية</dt><dd><?= e($service['duration_text'] ?: 'تحدد حسب حجم الطلب') ?></dd></div>
            <div><dt><i class="bi bi-diagram-3"></i> التخصص</dt><dd><?= e($service['subcategory_name'] ?: $service['category_name']) ?></dd></div>
          </dl>
          <a class="btn btn-whatsapp btn-lg w-100" href="<?= e($waLink) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب هذه الخدمة عبر واتساب</a>
          <a class="btn btn-outline-navy w-100 mt-2" href="<?= e(route('order', ['service' => $service['id']])) ?>"><i class="bi bi-ui-checks"></i> نموذج طلب مفصل مع مرفقات</a>
          <ol class="order-steps">
            <li><span>1</span> اضغط زر الطلب لتفتح محادثة واتساب</li>
            <li><span>2</span> أرسل الرسالة الجاهزة مع ملفاتك</li>
            <li><span>3</span> نرد بالسعر والمدة ثم نبدأ بعد موافقتك</li>
          </ol>
          <p class="order-note"><i class="bi bi-shield-check"></i> ستفتح محادثة واتساب برسالة جاهزة، ولن يُرسل شيء إلا بعد تأكيدك. يُتفق على السعر وطريقة الدفع بعد مراجعة الطلب.</p>
          <button class="btn btn-sm btn-light w-100" type="button" data-share data-title="<?= e($service['name']) ?>"><i class="bi bi-share"></i> مشاركة الخدمة</button>
        </div>
        <?php if (count($siblings) > 1): ?>
        <div class="side-nav mt-4">
          <h2 class="side-nav-title">تخصصات <?= e($service['category_name']) ?></h2>
          <?php foreach ($siblings as $sb): ?>
            <a class="side-link<?= $sb['slug'] === $service['subcategory_slug'] ? ' active' : '' ?>" href="<?= e(route('category', ['slug' => $service['category_slug'], 'sub' => $sb['slug']])) ?>"><?= e($sb['name']) ?></a>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </aside>
    </div>

    <?php if ($related): ?>
    <section class="mt-5" aria-labelledby="related-title">
      <h2 class="h4 mb-3" id="related-title">خدمات ذات صلة</h2>
      <div class="row g-3">
        <?php foreach ($related as $r): ?><div class="col-sm-6 col-lg-3"><?= render_service_card($r) ?></div><?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>
  </div>
</section>
<div class="sticky-order d-lg-none">
  <div><strong><?= e(excerpt($service['name'], 38)) ?></strong><small><?= e($service['price_text'] ?: 'السعر بعد المراجعة') ?></small></div>
  <a class="btn btn-whatsapp" href="<?= e($waLink) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب</a>
</div>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
