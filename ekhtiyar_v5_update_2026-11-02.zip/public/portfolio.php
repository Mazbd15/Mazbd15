<?php
/** صفحة «أعمالنا» — معرض الأعمال السابقة مع فلترة حسب القسم */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
if (!portfolio_enabled()) not_found();

$tree = catalog_tree();
$counts = portfolio_counts_by_category();
$slug = (string) ($_GET['category'] ?? '');
$cat = null;
foreach ($tree as $c) if ($c['slug'] === $slug) $cat = $c;
$q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 80);
$filters = ['category' => $cat['id'] ?? 0, 'q' => $q];
$per = max(6, min(48, (int) setting('portfolio_per_page', '12')));
$total = portfolio_count($filters);
$pages = max(1, (int) ceil($total / $per));
$page = min($pages, max(1, (int) ($_GET['page'] ?? 1)));
$works = portfolio_list($filters, $per, ($page - 1) * $per);

$pfTitle = setting('portfolio_title', 'من أعمالنا السابقة');
$active_nav = 'portfolio';
$page_title = $cat ? 'أعمال ' . $cat['name'] : 'أعمالنا ونماذج من مشاريعنا';
$page_description = $cat
    ? seo_description('نماذج من أعمالنا في ' . $cat['name'] . ':', implode('، ', array_slice(array_column($works, 'title'), 0, 4)), '— شاهد الصور والملفات واطلب عملًا مشابهًا عبر واتساب.')
    : seo_description(setting('portfolio_subtitle'), 'أعمال أكاديمية وهندسية وبرمجية وتصميمية بالصور والملفات.');
$breadcrumbs = $cat ? [['أعمالنا', route('portfolio')], [$cat['name'], null]] : [['أعمالنا', null]];
$page_canonical = absolute_url(ltrim(substr(route('portfolio', array_filter(['category' => $cat['slug'] ?? null, 'page' => $page > 1 ? $page : null])), strlen(base_path())), '/'));
if ($q !== '') $noindex = true;
if ($works && ($img = portfolio_cover($works[0]))) $page_image = preg_match('~^https?://~', $img) ? $img : absolute_url($img);
$json_ld = [[
    '@context' => 'https://schema.org', '@type' => 'CollectionPage', 'name' => $page_title, 'description' => $page_description, 'url' => $page_canonical,
    'mainEntity' => ['@type' => 'ItemList', 'numberOfItems' => $total, 'itemListElement' => array_map(fn($p, $i) => [
        '@type' => 'ListItem', 'position' => $i + 1 + ($page - 1) * $per, 'name' => $p['title'],
        'url' => absolute_url(ltrim(substr(route('work', ['slug' => $p['slug']]), strlen(base_path())), '/')),
    ], $works, array_keys($works))],
]];
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero portfolio-hero<?= $cat ? ' tone-' . e(category_tone($cat['slug'])) : ' tone-gold' ?>">
  <div class="container">
    <p class="hero-kicker mb-1"><i class="bi bi-collection-fill"></i> معرض الأعمال</p>
    <h1><?= e($cat ? 'أعمالنا في ' . $cat['name'] : $pfTitle) ?></h1>
    <p class="mb-0"><?= e(setting('portfolio_subtitle')) ?></p>
    <ul class="hero-facts"><li><i class="bi bi-collection"></i> <?= $total ?> عمل</li><li><i class="bi bi-shield-check"></i> تُعرض بموافقة أصحابها</li></ul>
  </div>
</section>

<section class="section pt-4">
  <div class="container">
    <nav class="filter-chips mb-3" aria-label="تصفية حسب القسم">
      <a class="fchip<?= !$cat ? ' active' : '' ?>" href="<?= e(route('portfolio')) ?>">الكل <span><?= array_sum($counts) ?></span></a>
      <?php foreach ($tree as $c): if (empty($counts[$c['id']])) continue; ?>
        <a class="fchip tone-<?= e(category_tone($c['slug'])) ?><?= $cat && $cat['id'] == $c['id'] ? ' active' : '' ?>" href="<?= e(route('portfolio', ['category' => $c['slug']])) ?>"><?= icon($c['icon']) ?> <?= e($c['name']) ?> <span><?= $counts[$c['id']] ?></span></a>
      <?php endforeach; ?>
    </nav>
    <form class="d-flex gap-2 mb-4" method="get" action="<?= e(route('portfolio')) ?>" role="search" style="max-width:520px">
      <?php if ($cat): ?><input type="hidden" name="category" value="<?= e($cat['slug']) ?>"><?php endif; ?>
      <input class="form-control" type="search" name="q" value="<?= e($q) ?>" placeholder="ابحث في الأعمال: أوتوكاد، بحث، شعار..." aria-label="بحث في الأعمال">
      <button class="btn btn-navy"><i class="bi bi-search"></i></button>
    </form>

    <?php if (!$works): ?>
      <div class="empty-state">
        <i class="bi bi-collection"></i>
        <h2><?= $q !== '' ? 'لا توجد أعمال مطابقة' : 'نعمل على إضافة نماذج من أعمالنا' ?></h2>
        <p>يمكنك طلب نماذج مشابهة لما تحتاجه مباشرة عبر واتساب، وسنرسل لك أمثلة مناسبة.</p>
        <a class="btn btn-whatsapp" href="<?= e(wa_link('السلام عليكم، أرغب في الاطلاع على نماذج من أعمالكم' . ($cat ? ' في ' . $cat['name'] : '') . '.')) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب نماذج عبر واتساب</a>
      </div>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($works as $p): ?><div class="col-sm-6 col-lg-4"><?= render_portfolio_card($p, !$cat) ?></div><?php endforeach; ?>
      </div>
      <?php if ($pages > 1): ?>
        <nav class="mt-4" aria-label="صفحات الأعمال"><ul class="pagination justify-content-center flex-wrap">
          <?php for ($i = 1; $i <= $pages; $i++): ?>
            <li class="page-item<?= $i === $page ? ' active' : '' ?>"><a class="page-link" href="<?= e(route('portfolio', array_filter(['category' => $cat['slug'] ?? null, 'q' => $q ?: null, 'page' => $i > 1 ? $i : null]))) ?>"><?= $i ?></a></li>
          <?php endfor; ?>
        </ul></nav>
      <?php endif; ?>
    <?php endif; ?>

    <aside class="cta-inline mt-5">
      <div><h2 class="h5 mb-1">أعجبك مستوى أعمالنا؟</h2><p class="mb-0">أرسل لنا تفاصيل طلبك وسنرد عليك بالسعر والمدة قبل أي التزام.</p></div>
      <div class="d-flex gap-2 flex-wrap"><a class="btn btn-gold" href="<?= e(route('order', $cat ? ['category' => $cat['id']] : [])) ?>"><i class="bi bi-lightning-charge-fill"></i> اطلب خدمتك</a>
        <a class="btn btn-whatsapp" href="<?= e(wa_service_link(null, $cat['name'] ?? null)) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> واتساب</a></div>
    </aside>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php';
