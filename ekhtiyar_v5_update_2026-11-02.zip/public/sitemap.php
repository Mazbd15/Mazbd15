<?php
/** خريطة الموقع الديناميكية مع صور (Google Image Sitemap) — متاحة على /sitemap.xml */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
header('Content-Type: application/xml; charset=utf-8');
header('X-Robots-Tag: noindex');
$abs = fn(string $u) => absolute_url(ltrim(substr($u, strlen(base_path())), '/'));
$img = fn(?string $p, string $title) => $p ? [['loc' => preg_match('~^https?://~', $p) ? $p : absolute_url($p), 'title' => $title]] : [];

// [loc, priority, changefreq, lastmod, images[]]
$urls = [
    [$abs(route('home')), '1.0', 'daily', null, []],
    [$abs(route('services')), '0.9', 'weekly', null, []],
    [$abs(route('specializations')), '0.8', 'weekly', null, []],
    [$abs(route('order')), '0.7', 'monthly', null, []],
    [$abs(route('about')), '0.5', 'monthly', null, []],
    [$abs(route('faq')), '0.6', 'monthly', null, []],
    [$abs(route('contact')), '0.5', 'monthly', null, []],
    [$abs(route('privacy')), '0.3', 'yearly', null, []],
    [$abs(route('terms')), '0.3', 'yearly', null, []],
];
foreach (db_all('SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order') as $c) {
    $urls[] = [$abs(route('category', ['slug' => $c['slug']])), '0.9', 'weekly', $c['updated_at'], $img(category_image($c), $c['name'])];
    foreach (db_all('SELECT slug, name, updated_at FROM subcategories WHERE category_id = ? AND is_active = 1 ORDER BY sort_order', [$c['id']]) as $s) {
        $urls[] = [$abs(route('category', ['slug' => $c['slug'], 'sub' => $s['slug']])), '0.8', 'weekly', $s['updated_at'], []];
    }
}
foreach (db_all(SERVICE_SELECT . ' WHERE s.is_active = 1 AND (sc.id IS NULL OR sc.is_active = 1) ORDER BY s.category_id, s.sort_order') as $s) {
    $imgs = $img($s['image'], $s['name']);
    foreach (db_all('SELECT file_path, alt_text FROM service_files WHERE service_id = ? AND file_type = "image" ORDER BY sort_order LIMIT 10', [$s['id']]) as $g) $imgs[] = ['loc' => absolute_url($g['file_path']), 'title' => $g['alt_text'] ?: $s['name']];
    $urls[] = [$abs(route('service', ['slug' => $s['slug']])), $s['is_popular'] ? '0.8' : '0.7', 'monthly', $s['updated_at'], $imgs];
}
if (portfolio_enabled()) {
    $urls[] = [$abs(route('portfolio')), '0.8', 'weekly', null, []];
    foreach (portfolio_counts_by_category() as $cid => $n) {
        $slug = db_value('SELECT slug FROM categories WHERE id = ?', [$cid]);
        if ($slug) $urls[] = [$abs(route('portfolio', ['category' => $slug])), '0.6', 'weekly', null, []];
    }
    foreach (portfolio_list([], 2000) as $p) {
        $imgs = [];
        if ($p['cover_image']) $imgs[] = ['loc' => absolute_url($p['cover_image']), 'title' => $p['title']];
        foreach (portfolio_files((int) $p['id'], 'image') as $g) if (count($imgs) < 20) $imgs[] = ['loc' => absolute_url($g['file_path']), 'title' => $g['caption'] ?: $p['title']];
        $urls[] = [$abs(route('work', ['slug' => $p['slug']])), $p['is_featured'] ? '0.8' : '0.7', 'monthly', $p['updated_at'], $imgs];
    }
}
// v5: المقالات والصفحات الثابتة المنشورة
if (function_exists('articles_enabled') && articles_enabled() && posts_count('article') > 0) {
    $urls[] = [$abs(route('blog')), '0.7', 'weekly', null, []];
    foreach (posts_published('article', 2000) as $p) $urls[] = [$abs(route('article', ['slug' => $p['slug']])), '0.6', 'monthly', $p['updated_at'], $p['cover_image'] ? [['loc' => absolute_url($p['cover_image']), 'title' => $p['title']]] : []];
}
foreach (function_exists('posts_published') ? posts_published('page', 200) : [] as $p) $urls[] = [$abs(route('page', ['slug' => $p['slug']])), '0.4', 'yearly', $p['updated_at'], []];
$x = fn(string $s) => htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
foreach ($urls as [$loc, $prio, $freq, $mod, $imgs]) {
    echo '  <url><loc>' . $x($loc) . '</loc>'
        . ($mod ? '<lastmod>' . date('Y-m-d', strtotime($mod)) . '</lastmod>' : '')
        . "<changefreq>$freq</changefreq><priority>$prio</priority>";
    foreach ($imgs as $im) echo '<image:image><image:loc>' . $x($im['loc']) . '</image:loc><image:title>' . $x($im['title']) . '</image:title></image:image>';
    echo "</url>\n";
}
echo '</urlset>';
