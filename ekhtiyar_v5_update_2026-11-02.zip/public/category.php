<?php
/** صفحة القسم الرئيسي أو التخصص الفرعي */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$slug = (string) ($_GET['slug'] ?? '');
$subSlug = (string) ($_GET['sub'] ?? '');
$category = $slug !== '' ? category_by_slug($slug) : null;
if (!$category) not_found();

$subs = subcategories_of((int) $category['id']);
$sub = null;
if ($subSlug !== '') {
    $sub = subcategory_by_slug((int) $category['id'], $subSlug);
    if (!$sub) not_found();
}
$services = services_by_category((int) $category['id'], $sub ? (int) $sub['id'] : null);
$faqs = $sub ? [] : faqs_for((int) $category['id']);

// تجميع الخدمات حسب التخصص في صفحة القسم
$bySub = [];
foreach ($services as $s) $bySub[(int) $s['subcategory_id']][] = $s;

$active_nav = 'services';
if ($sub) {
    $page_title = $sub['name'] . ' — ' . $category['name'];
    $page_description = ($sub['description'] ?: $sub['name']) . ' خدمات ' . $sub['name'] . ' ضمن ' . $category['name'] . ' في منصة اختيارك.';
    $breadcrumbs = [['جميع الخدمات', route('services')], [$category['name'], route('category', ['slug' => $category['slug']])], [$sub['name'], null]];
    $page_canonical = absolute_url(ltrim(substr(route('category', ['slug' => $category['slug'], 'sub' => $sub['slug']]), strlen(base_path())), '/'));
} else {
    $page_title = $category['meta_title'] ? str_replace(' | اختيارك', '', $category['meta_title']) : $category['name'];
    $page_description = $category['meta_description'] ?: $category['short_description'];
    $breadcrumbs = [['جميع الخدمات', route('services')], [$category['name'], null]];
    $page_canonical = absolute_url(ltrim(substr(route('category', ['slug' => $category['slug']]), strlen(base_path())), '/'));
}
$catWorks = portfolio_list(['category' => $category['id'], 'subcategory' => $sub['id'] ?? 0], 6);
if ($sub && !$catWorks) $catWorks = portfolio_list(['category' => $category['id']], 3);
$catWorksTotal = portfolio_count(['category' => $category['id']]);
// وصف تلقائي غني بالكلمات إن لم يُكتب وصف SEO
if (setting('seo_auto_descriptions', '1') === '1') {
    $names = implode('، ', array_slice(array_column($services, 'name'), 0, 5));
    if ($sub && !$sub['description']) $page_description = seo_description('خدمات ' . $sub['name'] . ' ضمن ' . $category['name'] . ':', $names, '— اطلب عبر واتساب.');
    elseif (!$sub && !$category['meta_description']) $page_description = seo_description($category['short_description'] ?? '', $names);
}
$json_ld = faq_json_ld($faqs);
$json_ld[] = ['@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => $sub['name'] ?? $category['name'],
    'itemListElement' => array_map(fn($s, $i) => ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $s['name'], 'url' => absolute_url(ltrim(substr(route('service', ['slug' => $s['slug']]), strlen(base_path())), '/'))], array_slice($services, 0, 50), array_keys(array_slice($services, 0, 50)))];
$wa_float_link = wa_link(wa_order_message(['category' => $category['name'], 'specialization' => $sub['name'] ?? '']));
$catImg = category_image($category);
if ($catImg) $page_image = preg_match('~^https?://~', $catImg) ? $catImg : absolute_url($catImg);
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero category-hero tone-<?= e(category_tone($category['slug'])) ?><?= $catImg ? ' has-cover' : '' ?>">
  <?php if ($catImg): ?><img class="hero-cover" src="<?= e(img_src($catImg)) ?>" alt="" aria-hidden="true" fetchpriority="high"><?php endif; ?>
  <div class="container">
    <div class="d-flex flex-column flex-md-row align-items-md-center gap-3">
      <span class="category-icon xl"><?= icon($sub['icon'] ?? $category['icon']) ?></span>
      <div>
        <?php if ($sub): ?><p class="hero-kicker mb-1"><?= e($category['name']) ?></p><?php endif; ?>
        <h1><?= e($sub['name'] ?? $category['name']) ?></h1>
        <p class="mb-0"><?= e($sub ? ($sub['description'] ?: '') : $category['short_description']) ?></p>
        <ul class="hero-facts">
          <li><i class="bi bi-briefcase"></i> <?= count($services) ?> خدمة</li>
          <?php if (!$sub): ?><li><i class="bi bi-diagram-3"></i> <?= count($subs) ?> تخصص</li><?php endif; ?>
          <li><i class="bi bi-whatsapp"></i> طلب مباشر عبر واتساب</li>
        </ul>
      </div>
    </div>
    <div class="hero-actions mt-4">
      <a class="btn btn-gold" href="<?= e($wa_float_link) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب عبر واتساب</a>
      <a class="btn btn-glass" href="<?= e(route('order', ['category' => $category['id']] + ($sub ? ['sub' => $sub['id']] : []))) ?>"><i class="bi bi-ui-checks"></i> نموذج الطلب</a>
    </div>
  </div>
</section>

<section class="section pt-4">
  <div class="container">
    <div class="row g-4">
      <aside class="col-lg-3" aria-label="تخصصات القسم">
        <div class="side-nav sticky-lg-top">
          <h2 class="side-nav-title"><?= e($category['name']) ?></h2>
          <a class="side-link<?= !$sub ? ' active' : '' ?>" href="<?= e(route('category', ['slug' => $category['slug']])) ?>">كل التخصصات <span><?= (int) array_sum(array_column($subs, 'services_count')) ?></span></a>
          <?php if ($catWorksTotal): ?><a class="side-link side-link-works" href="#cat-portfolio"><i class="bi bi-collection"></i> أعمالنا في القسم <span><?= $catWorksTotal ?></span></a><?php endif; ?>
          <?php foreach ($subs as $s): ?>
            <a class="side-link<?= $sub && (int) $sub['id'] === (int) $s['id'] ? ' active' : '' ?>" href="<?= e(route('category', ['slug' => $category['slug'], 'sub' => $s['slug']])) ?>"><?= icon($s['icon']) ?> <?= e($s['name']) ?> <span><?= (int) $s['services_count'] ?></span></a>
          <?php endforeach; ?>
        </div>
      </aside>
      <div class="col-lg-9">
        <?= render_banners(banners_for((int) $category['id']) ?: banners_for(null, 3), 'cat-ads') ?>
        <?php if (!$sub && $category['description']): ?><p class="lead-text"><?= nl2br(e($category['description'])) ?></p><?php endif; ?>
        <?= render_notice($category['notice'], $category['slug'] === 'engineering' ? 'bi-cone-striped' : 'bi-info-circle') ?>

        <div class="input-group mb-4 local-filter">
          <span class="input-group-text"><i class="bi bi-funnel"></i></span>
          <input type="search" class="form-control" placeholder="تصفية سريعة لخدمات هذه الصفحة..." data-local-filter=".service-col" aria-label="تصفية الخدمات">
        </div>

        <?php if (!$services): ?>
          <div class="empty-state"><i class="bi bi-inbox"></i><h2>لا توجد خدمات بعد</h2><p>راسلنا وسنساعدك في طلبك.</p></div>
        <?php elseif ($sub): ?>
          <div class="row g-3">
            <?php foreach ($services as $s): ?><div class="col-sm-6 col-xl-4 service-col" data-text="<?= e(ar_normalize($s['name'] . ' ' . $s['keywords'])) ?>"><?= render_service_card($s, false) ?></div><?php endforeach; ?>
          </div>
        <?php else: ?>
          <?php foreach ($subs as $s): if (empty($bySub[(int) $s['id']])) continue; ?>
            <section class="services-group" aria-labelledby="sub-<?= (int) $s['id'] ?>">
              <div class="services-group-head">
                <h2 id="sub-<?= (int) $s['id'] ?>"><?= icon($s['icon']) ?> <?= e($s['name']) ?></h2>
                <a href="<?= e(route('category', ['slug' => $category['slug'], 'sub' => $s['slug']])) ?>">صفحة التخصص <i class="bi bi-arrow-left"></i></a>
              </div>
              <div class="row g-3">
                <?php foreach ($bySub[(int) $s['id']] as $sv): ?><div class="col-sm-6 col-xl-4 service-col" data-text="<?= e(ar_normalize($sv['name'] . ' ' . $sv['keywords'])) ?>"><?= render_service_card($sv, false) ?></div><?php endforeach; ?>
              </div>
            </section>
          <?php endforeach; ?>
          <?php if (!empty($bySub[0])): ?>
            <section class="services-group"><div class="services-group-head"><h2>خدمات أخرى</h2></div>
              <div class="row g-3"><?php foreach ($bySub[0] as $sv): ?><div class="col-sm-6 col-xl-4 service-col" data-text="<?= e(ar_normalize($sv['name'])) ?>"><?= render_service_card($sv, false) ?></div><?php endforeach; ?></div>
            </section>
          <?php endif; ?>
        <?php endif; ?>
        <p class="local-empty text-muted text-center py-4" hidden>لا توجد خدمات مطابقة لعبارة التصفية.</p>

        <?php if ($catWorks): ?>
          <div class="mt-5"><?= render_portfolio_section($catWorks, 'من أعمالنا في ' . ($sub['name'] ?? $category['name']), 'نماذج منفذة بالصور والملفات — اطّلع على مستوى الجودة قبل أن تطلب.', $catWorksTotal > count($catWorks) || $sub ? route('portfolio', ['category' => $category['slug']]) : null, 'cat-portfolio') ?></div>
        <?php endif; ?>

        <?php if ($faqs): ?>
          <h2 class="h4 mt-5 mb-3">أسئلة شائعة عن <?= e($category['name']) ?></h2>
          <?= render_faq_accordion($faqs, 'cat-faq') ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
