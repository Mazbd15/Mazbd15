<?php
/**
 * التسجيل:
 *  type=member     ← حساب زائر/طالب يُفعّل فورًا (اختياري)
 *  type=specialist ← طلب انضمام متخصص بحالة «بانتظار الموافقة» حتى تعتمده الإدارة
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

if (current_user()) redirect(route('account'));

$type = ($_POST['type'] ?? $_GET['type'] ?? 'member') === 'specialist' ? 'specialist' : 'member';
$allowed = setting($type === 'specialist' ? 'allow_specialist_signup' : 'allow_member_signup', '1') === '1';
$cats = db_all('SELECT id, name, icon FROM categories WHERE is_active = 1 ORDER BY sort_order');
$errors = [];
$done = false;

if (is_post() && $allowed) {
    if (!csrf_valid()) $errors['_'] = 'انتهت صلاحية الصفحة، حاول مجددًا.';
    elseif (trim((string) ($_POST['website'] ?? '')) !== '') $errors['_'] = 'تعذر إنشاء الحساب.';
    elseif (rate_limited('register', 4, 3600)) $errors['_'] = 'محاولات كثيرة، حاول لاحقًا.';

    $d = [
        'name'  => mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120),
        'email' => mb_strtolower(trim((string) ($_POST['email'] ?? ''))),
        'phone' => mb_substr(trim((string) ($_POST['phone'] ?? '')), 0, 30),
        'spec'  => mb_substr(trim((string) ($_POST['specialization'] ?? '')), 0, 190),
        'bio'   => mb_substr(trim((string) ($_POST['bio'] ?? '')), 0, 2000),
        'cats'  => array_values(array_intersect(array_map('intval', (array) ($_POST['categories'] ?? [])), array_map('intval', array_column($cats, 'id')))),
    ];
    $pw = (string) ($_POST['password'] ?? '');
    if (!$errors) {
        if (mb_strlen($d['name']) < 3) $errors['name'] = 'اكتب اسمك (3 أحرف على الأقل).';
        if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'البريد الإلكتروني غير صالح.';
        elseif (db_value('SELECT id FROM users WHERE email = ?', [$d['email']])) $errors['email'] = 'هذا البريد مسجل مسبقًا. جرّب تسجيل الدخول.';
        if ($d['phone'] !== '' && !preg_match('/^\+?[0-9\s\-()]{8,20}$/', $d['phone'])) $errors['phone'] = 'رقم الجوال غير صالح.';
        if ($p = password_problems($pw)) $errors['password'] = $p;
        elseif (!hash_equals($pw, (string) ($_POST['password2'] ?? ''))) $errors['password2'] = 'تأكيد كلمة المرور غير مطابق.';
        if ($type === 'specialist') {
            if ($d['phone'] === '') $errors['phone'] = 'رقم الجوال مطلوب للمتخصصين.';
            if (mb_strlen($d['spec']) < 3) $errors['specialization'] = 'اكتب تخصصك المهني.';
            if (!$d['cats']) $errors['categories'] = 'اختر قسمًا واحدًا على الأقل ترغب بالعمل فيه.';
            if (mb_strlen($d['bio']) < 20) $errors['bio'] = 'اكتب نبذة عن خبرتك (20 حرفًا على الأقل).';
        }
        if (empty($_POST['terms'])) $errors['terms'] = 'يجب الموافقة على الشروط وسياسة الخصوصية.';
    }

    if (!$errors) {
        $pdo = db();
        $pdo->beginTransaction();
        $id = db_insert('users', [
            'name' => $d['name'], 'email' => $d['email'], 'password_hash' => password_hash($pw, PASSWORD_DEFAULT),
            'role' => $type, 'status' => $type === 'specialist' ? 'pending' : 'active',
            'phone' => $d['phone'] ?: null, 'specialization' => $d['spec'] ?: null, 'bio' => $type === 'specialist' ? $d['bio'] : null,
        ]);
        if ($type === 'specialist') {
            foreach ($d['cats'] as $cid) db_exec('INSERT IGNORE INTO user_categories (user_id, category_id) VALUES (?, ?)', [$id, $cid]);
        }
        $pdo->commit();
        if ($type === 'specialist') {
            notify_staff('admin', 'طلب انضمام متخصص جديد', $d['name'] . ' — ' . $d['spec'], admin_url('users', ['status' => 'pending']));
            $done = true;
        } else {
            login_user($id);
            flash('success', 'مرحبًا ' . $d['name'] . '! تم إنشاء حسابك بنجاح.');
            redirect(route('account'));
        }
    }
}

$err = fn($k) => isset($errors[$k]) ? '<div class="invalid-feedback d-block">' . e($errors[$k]) . '</div>' : '';
$inv = fn($k) => isset($errors[$k]) ? ' is-invalid' : '';
$old = fn($k) => e($_POST[$k] ?? '');
$page_title = $type === 'specialist' ? 'الانضمام كمتخصص' : 'إنشاء حساب';
$page_description = 'إنشاء حساب في منصة اختيارك للخدمات الطلابية.';
$noindex = true;
require ROOT_PATH . '/includes/header.php';
?>
<section class="section auth-section">
  <div class="container" style="max-width:820px">
    <ul class="nav nav-pills auth-tabs mb-3 justify-content-center">
      <li class="nav-item"><a class="nav-link<?= $type === 'member' ? ' active' : '' ?>" href="<?= e(route('register', ['type' => 'member'])) ?>"><i class="bi bi-person"></i> حساب طالب / زائر</a></li>
      <li class="nav-item"><a class="nav-link<?= $type === 'specialist' ? ' active' : '' ?>" href="<?= e(route('register', ['type' => 'specialist'])) ?>"><i class="bi bi-person-badge"></i> انضم كمتخصص</a></li>
    </ul>
    <div class="form-card">
      <?php if (!$allowed): ?>
        <div class="empty-state border-0"><i class="bi bi-lock"></i><h1 class="h4">التسجيل مغلق حاليًا</h1><p>يمكنك طلب الخدمات مباشرة دون حساب.</p><a class="btn btn-whatsapp" href="<?= e(wa_service_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب عبر واتساب</a></div>
      <?php elseif ($done): ?>
        <div class="text-center py-4">
          <i class="bi bi-hourglass-split display-4 text-warning"></i>
          <h1 class="h4 mt-3">تم استلام طلب انضمامك</h1>
          <p class="text-muted">ستراجع الإدارة بياناتك، وعند الموافقة يمكنك تسجيل الدخول بالبريد وكلمة المرور اللذين أدخلتهما والوصول إلى لوحة التحكم لإدارة أقسامك.</p>
          <a class="btn btn-navy" href="<?= e(route('login')) ?>">صفحة تسجيل الدخول</a>
        </div>
      <?php else: ?>
        <h1 class="h4 mb-1"><?= $type === 'specialist' ? 'طلب الانضمام كمتخصص' : 'إنشاء حساب طالب / زائر' ?></h1>
        <p class="text-muted small"><?= $type === 'specialist' ? 'بعد الإرسال يبقى الحساب «بانتظار الموافقة» حتى تعتمده الإدارة وتحدد الأقسام المسموح لك بإدارتها.' : 'الحساب اختياري — يتيح لك متابعة طلباتك ورسائل الفريق. يمكنك دائمًا الطلب كزائر.' ?></p>
        <?php if (isset($errors['_'])): ?><div class="alert alert-danger py-2"><?= e($errors['_']) ?></div><?php endif; ?>
        <form method="post" action="<?= e(route('register')) ?>" novalidate>
          <?= csrf_field() ?><input type="hidden" name="type" value="<?= e($type) ?>">
          <div class="hp-field" aria-hidden="true"><label>اتركه فارغًا<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label" for="r-name">الاسم الكامل <b class="req">*</b></label><input class="form-control<?= $inv('name') ?>" id="r-name" name="name" maxlength="120" required value="<?= $old('name') ?>" autocomplete="name"><?= $err('name') ?></div>
            <div class="col-md-6"><label class="form-label" for="r-email">البريد الإلكتروني <b class="req">*</b></label><input class="form-control<?= $inv('email') ?>" id="r-email" type="email" name="email" dir="ltr" required value="<?= $old('email') ?>" autocomplete="email"><?= $err('email') ?></div>
            <div class="col-md-6"><label class="form-label" for="r-phone">رقم الجوال / واتساب <?= $type === 'specialist' ? '<b class="req">*</b>' : '<small class="text-muted">(اختياري)</small>' ?></label><input class="form-control<?= $inv('phone') ?>" id="r-phone" name="phone" dir="ltr" placeholder="+9665xxxxxxxx" value="<?= $old('phone') ?>" autocomplete="tel"><?= $err('phone') ?></div>
            <div class="col-md-6"><label class="form-label" for="r-spec"><?= $type === 'specialist' ? 'التخصص المهني <b class="req">*</b>' : 'التخصص الجامعي <small class="text-muted">(اختياري)</small>' ?></label><input class="form-control<?= $inv('specialization') ?>" id="r-spec" name="specialization" maxlength="190" placeholder="<?= $type === 'specialist' ? 'مثال: مهندس معماري — 6 سنوات خبرة' : 'مثال: هندسة صناعية' ?>" value="<?= $old('specialization') ?>"><?= $err('specialization') ?></div>
            <?php if ($type === 'specialist'): ?>
              <div class="col-12">
                <label class="form-label">الأقسام التي ترغب بالعمل فيها <b class="req">*</b></label>
                <div class="cat-picker<?= $inv('categories') ?>">
                  <?php foreach ($cats as $c): ?>
                    <label class="cat-chip"><input type="checkbox" name="categories[]" value="<?= (int) $c['id'] ?>"<?= checked(in_array((int) $c['id'], array_map('intval', (array) ($_POST['categories'] ?? [])), true)) ?>><span><i class="bi <?= e($c['icon']) ?>"></i> <?= e($c['name']) ?></span></label>
                  <?php endforeach; ?>
                </div>
                <?= $err('categories') ?>
              </div>
              <div class="col-12"><label class="form-label" for="r-bio">نبذة عن خبرتك ومؤهلاتك <b class="req">*</b></label><textarea class="form-control<?= $inv('bio') ?>" id="r-bio" name="bio" rows="4" maxlength="2000" placeholder="المؤهل، سنوات الخبرة، البرامج التي تتقنها، أمثلة لأعمال سابقة..."><?= $old('bio') ?></textarea><?= $err('bio') ?></div>
            <?php endif; ?>
            <div class="col-md-6"><label class="form-label" for="r-pass">كلمة المرور <b class="req">*</b></label><input class="form-control<?= $inv('password') ?>" id="r-pass" type="password" name="password" dir="ltr" minlength="10" required autocomplete="new-password"><div class="form-text">10 أحرف على الأقل، حروف إنجليزية وأرقام.</div><?= $err('password') ?></div>
            <div class="col-md-6"><label class="form-label" for="r-pass2">تأكيد كلمة المرور <b class="req">*</b></label><input class="form-control<?= $inv('password2') ?>" id="r-pass2" type="password" name="password2" dir="ltr" minlength="10" required autocomplete="new-password"><?= $err('password2') ?></div>
            <div class="col-12"><label class="form-check"><input class="form-check-input<?= $inv('terms') ?>" type="checkbox" name="terms" value="1"<?= checked(!empty($_POST['terms'])) ?>> أوافق على <a href="<?= e(route('terms')) ?>" target="_blank">الشروط</a> و<a href="<?= e(route('privacy')) ?>" target="_blank">سياسة الخصوصية</a></label><?= $err('terms') ?></div>
          </div>
          <button class="btn btn-navy btn-lg w-100 mt-4"><?= $type === 'specialist' ? '<i class="bi bi-send"></i> إرسال طلب الانضمام' : '<i class="bi bi-person-check"></i> إنشاء الحساب' ?></button>
          <p class="text-center small mt-3 mb-0">لديك حساب؟ <a href="<?= e(route('login')) ?>">سجّل الدخول</a></p>
        </form>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
