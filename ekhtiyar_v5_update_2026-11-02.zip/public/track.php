<?php
/**
 * تتبع الطلب برقمه المرجعي (v5)
 * - يتطلب الرقم المرجعي + تحقق ثانٍ (آخر 4 أرقام من الجوال أو البريد المسجل) لمنع تخمين طلبات الآخرين.
 * - يعرض المراحل وسجل الحالات والملاحظات الموجهة للعميل فقط (لا تظهر الملاحظات الداخلية).
 * - صاحب الحساب المسجل يرى طلباته مباشرة دون تحقق إضافي.
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$ref = mb_substr(strtoupper(trim((string) ($_REQUEST['ref'] ?? ''))), 0, 30);
$verify = mb_substr(trim((string) ($_POST['verify'] ?? '')), 0, 190);
$req = null;
$error = null;
$cu = current_user();

/** هل بيانات التحقق مطابقة؟ */
function track_verify_ok(array $r, string $v): bool
{
    $v = trim($v);
    if ($v === '') return false;
    if (str_contains($v, '@')) {
        foreach ([$r['email'], $r['contact_value']] as $em) if ($em && hash_equals(mb_strtolower(trim((string) $em)), mb_strtolower($v))) return true;
        return false;
    }
    $digits = preg_replace('/\D+/', '', $v);
    $have = preg_replace('/\D+/', '', (string) $r['contact_value']);
    return strlen($digits) >= 4 && strlen($have) >= 4 && hash_equals(substr($have, -4), substr($digits, -4));
}

if ($ref !== '') {
    $row = db_one('SELECT r.*, c.name category_name FROM requests r LEFT JOIN categories c ON c.id = r.category_id WHERE r.reference_code = ?', [$ref]);
    $own = $row && $cu && (int) $row['member_id'] === (int) $cu['id'];
    if ($own) {
        $req = $row;
    } elseif (is_post()) {
        require_csrf();
        if (rate_limited('track', 10, 900)) $error = 'محاولات كثيرة. انتظر قليلًا ثم حاول مجددًا.';
        elseif (!$row || !track_verify_ok($row, $verify)) $error = 'لم نجد طلبًا مطابقًا. تأكد من الرقم المرجعي وآخر 4 أرقام من الجوال (أو البريد) الذي كتبته في الطلب.';
        else $req = $row;
    }
}

$steps = request_track_steps();
$history = $req ? request_status_history((int) $req['id']) : [];
$notes = $req ? db_all('SELECT n.body, n.created_at, u.name FROM request_notes n LEFT JOIN users u ON u.id = n.user_id WHERE n.request_id = ? AND n.is_internal = 0 ORDER BY n.id', [$req['id']]) : [];

$page_title = 'تتبع طلبك';
$page_description = 'تابع حالة طلبك لدى ' . setting('site_name') . ' برقمه المرجعي.';
$breadcrumbs = [['تتبع الطلب', null]];
$noindex = true;
header('X-Robots-Tag: noindex');
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero"><div class="container"><h1>تتبع طلبك</h1><p>اكتب الرقم المرجعي الذي وصلك عند إرسال الطلب (يبدأ بـ IKH).</p></div></section>
<section class="section pt-4">
  <div class="container track-card">
    <?php if (!$req): ?>
      <form class="form-card" method="post" action="<?= e(route('track')) ?>">
        <?= csrf_field() ?>
        <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label" for="t-ref">الرقم المرجعي *</label><input class="form-control mono" id="t-ref" name="ref" required maxlength="30" dir="ltr" value="<?= e($ref) ?>" placeholder="IKH-261102-AB12"></div>
          <div class="col-md-6"><label class="form-label" for="t-v">آخر 4 أرقام من جوالك أو بريدك *</label><input class="form-control" id="t-v" name="verify" required maxlength="190" dir="ltr" autocomplete="off" placeholder="1234 أو name@mail.com"></div>
        </div>
        <button class="btn btn-navy mt-3"><i class="bi bi-search"></i> عرض حالة الطلب</button>
        <p class="small text-muted mt-2 mb-0"><i class="bi bi-shield-lock"></i> نطلب التحقق الثاني لحماية خصوصية طلبك. <?php if (!$cu): ?>لديك حساب؟ <a href="<?= e(route('login', ['next' => route('account')])) ?>">سجّل الدخول</a> لرؤية كل طلباتك.<?php endif; ?></p>
      </form>
    <?php else:
      $order = array_keys($steps); $pos = array_search($req['status'], $order, true); $cancelled = $req['status'] === 'cancelled'; [$sl, $sc] = request_statuses()[$req['status']] ?? [$req['status'], 'secondary']; ?>
      <div class="form-card">
        <div class="d-flex flex-wrap gap-2 align-items-start">
          <div><h2 class="h5 mb-1"><?= e($req['service_label']) ?></h2><div class="small text-muted"><span class="mono"><?= e($req['reference_code']) ?></span> · <?= e($req['category_name'] ?? '') ?> · <?= e(ar_date($req['created_at'], true)) ?></div></div>
          <span class="badge text-bg-<?= e($sc) ?> fs-6 ms-auto"><?= e($sl) ?></span>
        </div>
        <?php if ($cancelled): ?>
          <div class="alert alert-secondary mt-3 mb-0"><i class="bi bi-x-circle"></i> تم إلغاء هذا الطلب. للاستفسار تواصل معنا عبر واتساب.</div>
        <?php else: ?>
          <ol class="track-steps">
            <?php foreach ($steps as $k => [$ic, $label]): $i = array_search($k, $order, true); ?>
              <li class="<?= $pos !== false && $i < $pos ? 'done' : ($i === $pos ? 'current' : '') ?>"><span class="dot"><i class="bi <?= $ic ?>"></i></span><?= e($label) ?></li>
            <?php endforeach; ?>
          </ol>
        <?php endif; ?>
        <?php if ($req['status'] === 'awaiting_client'): ?><div class="alert alert-warning"><i class="bi bi-chat-dots"></i> نحتاج منك معلومات إضافية لإكمال الطلب — راسلنا عبر واتساب.</div><?php endif; ?>

        <?php if ($history): ?>
          <h3 class="h6 mt-3">سجل الحالة</h3>
          <ul class="timeline small mb-3">
            <?php foreach (array_reverse($history) as $h): ?>
              <li><strong><?= e(request_statuses()[$h['new_status']][0] ?? $h['new_status']) ?></strong> <small><?= e(ar_date($h['created_at'], true)) ?></small><?php if ($h['note']): ?><div><?= e($h['note']) ?></div><?php endif; ?></li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
        <?php if ($notes): ?>
          <h3 class="h6">رسائل الفريق</h3>
          <ul class="timeline small mb-3">
            <?php foreach ($notes as $n): ?><li><strong><?= e($n['name'] ?? 'فريق العمل') ?></strong> <small><?= e(ar_date($n['created_at'], true)) ?></small><div class="pre-text"><?= nl2br(e($n['body'])) ?></div></li><?php endforeach; ?>
          </ul>
        <?php endif; ?>
        <div class="d-flex flex-wrap gap-2">
          <a class="btn btn-whatsapp" href="<?= e(wa_link('السلام عليكم، أستفسر عن طلبي رقم ' . $req['reference_code'])) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> استفسار عن الطلب</a>
          <?php if ($req['status'] === 'completed' && testimonials_enabled() && setting('testimonials_allow_submit', '1') === '1'): ?>
            <a class="btn btn-outline-navy" href="<?= e(route('review') . '?ref=' . rawurlencode($req['reference_code']) . ($req['service_id'] ? '&service=' . (int) $req['service_id'] : '')) ?>"><i class="bi bi-star"></i> قيّم الخدمة</a>
          <?php endif; ?>
          <a class="btn btn-link" href="<?= e(route('track')) ?>">تتبع طلب آخر</a>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
