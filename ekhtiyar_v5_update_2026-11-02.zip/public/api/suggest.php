<?php
/** اقتراحات البحث الفوري — GET ?q= */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';

if (request_method() !== 'GET') json_response(['ok' => false], 405);
$q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 60);
if (mb_strlen($q) < 2) json_response(['ok' => true, 'items' => []]);
if (rate_limited('suggest', 60, 60)) json_response(['ok' => false, 'error' => 'طلبات كثيرة'], 429);

$items = [];
foreach (search_services($q, [], 8) as $s) {
    $items[] = [
        'type'  => 'service',
        'name'  => $s['name'],
        'meta'  => trim(($s['subcategory_name'] ?: '') . ' • ' . $s['category_name'], ' •'),
        'url'   => route('service', ['slug' => $s['slug']]),
    ];
}
// تخصصات مطابقة
$nq = ar_normalize($q);
$subs = 0;
foreach (catalog_tree() as $c) {
    foreach ($c['subs'] as $sb) {
        if ($subs >= 3) break 2;
        if (str_contains(ar_normalize($sb['name']), $nq)) {
            $items[] = ['type' => 'sub', 'name' => $sb['name'], 'meta' => 'تخصص • ' . $c['name'], 'url' => route('category', ['slug' => $c['slug'], 'sub' => $sb['slug']])];
            $subs++;
        }
    }
}
header('Cache-Control: public, max-age=120');
json_response(['ok' => true, 'items' => $items, 'all' => route('search', ['q' => $q])]);
