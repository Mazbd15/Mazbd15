<?php
/** عدّاد نقرات الإعلان ثم التحويل لرابطه (http/https أو رابط داخلي فقط) */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
$b = db_one('SELECT id, link_url FROM banners WHERE id = ? AND is_active = 1', [(int) ($_GET['id'] ?? 0)]);
$link = (string) ($b['link_url'] ?? '');
if (!$b || !(preg_match('#^https?://#i', $link) || (str_starts_with($link, '/') && !str_starts_with($link, '//')))) redirect(route('home'));
$seen = $_SESSION['_bclick'] ?? [];
if (!in_array((int) $b['id'], $seen, true)) {
    db_exec('UPDATE banners SET clicks = clicks + 1 WHERE id = ?', [$b['id']]);
    $_SESSION['_bclick'] = array_slice(array_merge($seen, [(int) $b['id']]), -50);
}
redirect($link);
