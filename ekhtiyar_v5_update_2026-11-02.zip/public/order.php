<?php
/**
 * نموذج طلب الخدمة.
 * - GET: عرض النموذج (مع تعبئة مسبقة عبر ?service= أو ?category=&sub=)
 * - POST: التحقق ← (حفظ اختياري بموافقة العميل) ← إنشاء رسالة واتساب ← إعادة رابط واتساب
 *   يعمل عبر fetch (JSON) أو كنموذج عادي (تحويل مباشر) في حال تعطل JavaScript.
 * لا يتم إرسال أي شيء تلقائيًا إلى واتساب؛ المستخدم يؤكد الإرسال بنفسه.
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$tree = catalog_tree();
$saveEnabled = setting('save_requests', '1') === '1';
$maxMb = (int) config('uploads.max_mb', 10);
$maxFiles = (int) config('uploads.max_files', 5);
$allowedExt = array_keys(config('uploads.allowed', []));
$wantsJson = str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json');

if (is_post()) {
    $errors = [];
    if (!csrf_valid()) {
        $errors['_'] = 'انتهت صلاحية الصفحة. يرجى تحديثها والمحاولة مجددًا.';
    } elseif (rate_limited('order', 6, 600) || ($saveEnabled && (int) db_value('SELECT COUNT(*) FROM requests WHERE ip_hash = ? AND created_at > ?', [ip_hash(), date('Y-m-d H:i:s', time() - 3600)]) >= 10)) {
        $errors['_'] = 'تم إرسال طلبات كثيرة خلال فترة قصيرة. يرجى المحاولة لاحقًا أو التواصل عبر واتساب مباشرة.';
    } elseif (trim((string) ($_POST['website'] ?? '')) !== '') {
        // حقل فخ للروبوتات
        $errors['_'] = 'تعذر إرسال الطلب.';
    }

    $d = [
        'name'           => mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120),
        'contact_method' => (string) ($_POST['contact_method'] ?? 'whatsapp'),
        'contact_value'  => mb_substr(trim((string) ($_POST['contact_value'] ?? '')), 0, 190),
        'email'          => mb_substr(trim((string) ($_POST['email'] ?? '')), 0, 190),
        'category_id'    => (int) ($_POST['category_id'] ?? 0),
        'service_id'     => (int) ($_POST['service_id'] ?? 0),
        'specialization' => mb_substr(trim((string) ($_POST['specialization'] ?? '')), 0, 190),
        'description'    => mb_substr(trim((string) ($_POST['description'] ?? '')), 0, 3000),
        'deadline'       => trim((string) ($_POST['deadline'] ?? '')),
        'software'       => mb_substr(trim((string) ($_POST['software'] ?? '')), 0, 190),
        'notes'          => mb_substr(trim((string) ($_POST['notes'] ?? '')), 0, 1500),
        'privacy'        => !empty($_POST['privacy']),
        'store'          => $saveEnabled && !empty($_POST['consent_storage']),
    ];

    if (!$errors) {
        if (mb_strlen($d['name']) < 2) $errors['name'] = 'يرجى كتابة الاسم أو اسم مستعار.';
        if (!isset(contact_methods()[$d['contact_method']])) $errors['contact_method'] = 'وسيلة تواصل غير صالحة.';
        if ($d['contact_value'] === '') {
            $errors['contact_value'] = 'يرجى كتابة بيانات التواصل.';
        } elseif (in_array($d['contact_method'], ['whatsapp', 'phone'], true) && !preg_match('/^\+?[0-9\s\-()]{8,20}$/', $d['contact_value'])) {
            $errors['contact_value'] = 'رقم الجوال غير صالح.';
        } elseif ($d['contact_method'] === 'email' && !filter_var($d['contact_value'], FILTER_VALIDATE_EMAIL)) {
            $errors['contact_value'] = 'البريد الإلكتروني غير صالح.';
        }
        if ($d['email'] !== '' && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'البريد الإلكتروني غير صالح.';
        if (!isset($tree[$d['category_id']])) $errors['category_id'] = 'يرجى اختيار القسم الرئيسي.';
        $service = null;
        if ($d['service_id']) {
            $service = db_one('SELECT s.id, s.name, s.category_id, s.subcategory_id, sc.name AS sub_name FROM services s LEFT JOIN subcategories sc ON sc.id = s.subcategory_id WHERE s.id = ? AND s.is_active = 1', [$d['service_id']]);
            if (!$service || (int) $service['category_id'] !== $d['category_id']) $errors['service_id'] = 'الخدمة المختارة غير صالحة.';
        } else {
            $errors['service_id'] = 'يرجى اختيار الخدمة المطلوبة.';
        }
        if (mb_strlen($d['description']) < 10) $errors['description'] = 'يرجى وصف طلبك بشكل أوضح (10 أحرف على الأقل).';
        if ($d['deadline'] !== '') {
            $dt = DateTime::createFromFormat('Y-m-d', $d['deadline']);
            if (!$dt || $dt->format('Y-m-d') !== $d['deadline']) $errors['deadline'] = 'تاريخ غير صالح.';
            elseif ($d['deadline'] < date('Y-m-d')) $errors['deadline'] = 'الموعد النهائي يجب أن يكون اليوم أو بعده.';
        }
        if (!$d['privacy']) $errors['privacy'] = 'يجب الموافقة على سياسة الخصوصية.';
    }

    // المرفقات: تُقبل فقط عند موافقة العميل على الحفظ
    $files = normalize_files($_FILES['attachments'] ?? []);
    $validFiles = [];
    if (!$errors && $files) {
        if (!$d['store']) {
            $errors['attachments'] = 'لرفع المرفقات عبر الموقع يجب الموافقة على حفظ الطلب، أو أرسل الملفات مباشرة في محادثة واتساب.';
        } elseif (count($files) > $maxFiles) {
            $errors['attachments'] = "الحد الأقصى $maxFiles ملفات.";
        } else {
            foreach ($files as $f) {
                [$ok, $err, $ext, $mime] = validate_upload($f, config('uploads.allowed'), $maxMb * 1024 * 1024);
                if (!$ok) { $errors['attachments'] = $err; break; }
                $validFiles[] = $f + ['_ext' => $ext, '_mime' => $mime];
            }
        }
    }

    if ($errors) {
        if ($wantsJson) json_response(['ok' => false, 'errors' => $errors], 422);
        $_SESSION['_order_old'] = $_POST;
        $_SESSION['_order_errors'] = $errors;
        redirect(route('order'));
    }

    $category = $tree[$d['category_id']];
    $reference = null;
    $attachNames = [];
    if ($d['store']) {
        $pdo = db();
        $pdo->beginTransaction();
        $stored = [];
        try {
            $reference = 'IKH-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
            $reqId = db_insert('requests', [
                'reference_code' => $reference,
                'customer_name'  => $d['name'],
                'contact_method' => $d['contact_method'],
                'contact_value'  => $d['contact_value'],
                'email'          => $d['email'] ?: null,
                'category_id'    => $d['category_id'],
                'subcategory_id' => $service['subcategory_id'] ?: null,
                'service_id'     => (int) $service['id'],
                'service_label'  => $service['name'],
                'specialization' => $d['specialization'] ?: null,
                'description'    => $d['description'],
                'deadline'       => $d['deadline'] ?: null,
                'software'       => $d['software'] ?: null,
                'notes'          => $d['notes'] ?: null,
                'consent_storage'=> 1,
                'member_id'      => ($cu = current_user()) ? (int) $cu['id'] : null,
                'ip_hash'        => ip_hash(),
            ]);
            $dir = config('uploads.path') . '/requests';
            if ($validFiles && !is_dir($dir)) mkdir($dir, 0750, true);
            foreach ($validFiles as $f) {
                $name = safe_filename($f['_ext']);
                $dest = $dir . '/' . $name;
                if (!move_uploaded_file($f['tmp_name'], $dest)) throw new RuntimeException('upload move failed');
                @chmod($dest, 0640);
                $stored[] = $dest;
                $orig = clean_original_name($f['name']);
                db_insert('request_attachments', ['request_id' => $reqId, 'original_name' => $orig, 'stored_name' => $name, 'mime_type' => $f['_mime'], 'file_size' => (int) $f['size']]);
                $attachNames[] = $orig;
            }
            $pdo->commit();
            request_log_status((int) $reqId, null, 'new', null, 'تم استلام الطلب من الموقع');
            notify_staff('specialist', 'طلب جديد ' . $reference, $service['name'] . ' — ' . $d['name'], admin_url('request_view', ['id' => $reqId]), (int) $d['category_id']);
            if (!empty($cu)) notify((int) $cu['id'], 'تم استلام طلبك ' . $reference, 'يمكنك متابعة حالته من صفحة حسابي.', route('account'));
        } catch (Throwable $ex) {
            $pdo->rollBack();
            foreach ($stored as $p) @unlink($p);
            error_log('order save failed: ' . $ex->getMessage());
            $msg = 'تعذر حفظ الطلب حاليًا. يمكنك المتابعة مباشرة عبر واتساب.';
            if ($wantsJson) json_response(['ok' => false, 'errors' => ['_' => $msg]], 500);
            flash('danger', $msg);
            redirect(route('order'));
        }
    }

    $message = wa_order_message([
        'reference'      => $reference ?? '',
        'name'           => $d['name'],
        'category'       => $category['name'],
        'service'        => $service['name'],
        'specialization' => $d['specialization'] ?: ($service['sub_name'] ?? ''),
        'software'       => $d['software'],
        'description'    => $d['description'],
        'deadline'       => $d['deadline'],
        'notes'          => $d['notes'],
        'attachments'    => $attachNames ? 'تم رفع ' . count($attachNames) . ' ملف عبر الموقع (' . implode('، ', $attachNames) . ')، وسأرسل أي ملفات إضافية في المحادثة.' : '',
    ]);
    $wa = wa_link($message);
    if ($wantsJson) json_response(['ok' => true, 'whatsapp' => $wa, 'reference' => $reference, 'message' => $message]);
    redirect($wa);
}

// ---------------------------------------------------------------- GET
$old = $_SESSION['_order_old'] ?? [];
// تعبئة مسبقة لبيانات العضو المسجل
if (!$old && ($cu = current_user())) {
    $old = ['name' => $cu['name'], 'email' => $cu['email'], 'contact_value' => (string) $cu['phone'], 'specialization' => (string) $cu['specialization'], 'consent_storage' => 1];
}
$errs = $_SESSION['_order_errors'] ?? [];
unset($_SESSION['_order_old'], $_SESSION['_order_errors']);

$preService = (int) ($old['service_id'] ?? $_GET['service'] ?? 0);
$preCat = (int) ($old['category_id'] ?? $_GET['category'] ?? 0);
$preSub = (int) ($_GET['sub'] ?? 0);
if ($preService) {
    $ps = db_one('SELECT category_id, subcategory_id FROM services WHERE id = ? AND is_active = 1', [$preService]);
    if ($ps) { $preCat = (int) $ps['category_id']; $preSub = (int) $ps['subcategory_id']; } else { $preService = 0; }
}
$old_val = fn(string $k, string $def = '') => e($old[$k] ?? $def);
$err = fn(string $k) => isset($errs[$k]) ? '<div class="invalid-feedback d-block">' . e($errs[$k]) . '</div>' : '<div class="invalid-feedback"></div>';

$jsTree = [];
foreach ($tree as $c) {
    $jsTree[] = [
        'id' => (int) $c['id'], 'name' => $c['name'],
        'subs' => array_values(array_map(fn($s) => ['id' => (int) $s['id'], 'name' => $s['name']], $c['subs'])),
        'services' => array_map(fn($s) => ['id' => $s['id'], 'name' => $s['name'], 'sub' => $s['sub']], $c['services']),
    ];
}

$active_nav = '';
$page_title = 'نموذج طلب خدمة';
$page_description = 'أرسل تفاصيل طلبك واختر الخدمة المناسبة، ثم تابع الطلب وتأكيد الحجز عبر واتساب.';
$breadcrumbs = [['نموذج طلب خدمة', null]];
$page_scripts = ['js/order.js'];
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1>نموذج طلب خدمة</h1>
    <p>املأ التفاصيل وسنجهز لك رسالة واتساب منظمة. لن يُرسل شيء إلا بعد تأكيدك داخل واتساب.</p>
    <?php if (!current_user()): ?><p class="small mt-2 mb-0"><i class="bi bi-info-circle"></i> تطلب كزائر — <a class="text-warning" href="<?= e(route('login', ['next' => $_SERVER['REQUEST_URI'] ?? ''])) ?>">سجّل الدخول</a> (اختياري) لمتابعة طلبك من حسابك.</p><?php endif; ?>
  </div>
</section>

<section class="section pt-4">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <form id="order-form" class="form-card" method="post" action="<?= e(route('order')) ?>" enctype="multipart/form-data" novalidate>
          <?= csrf_field() ?>
          <div class="hp-field" aria-hidden="true"><label>اترك هذا الحقل فارغًا<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
          <div class="alert alert-danger form-alert" role="alert"<?= isset($errs['_']) ? '' : ' hidden' ?>><?= e($errs['_'] ?? '') ?></div>

          <fieldset>
            <legend><span>1</span> بيانات التواصل</legend>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label" for="o-name">الاسم أو الاسم المستعار <b class="req">*</b></label>
                <input class="form-control<?= isset($errs['name']) ? ' is-invalid' : '' ?>" id="o-name" name="name" maxlength="120" required value="<?= $old_val('name') ?>" autocomplete="name">
                <?= $err('name') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="o-email">البريد الإلكتروني <small class="text-muted">(اختياري)</small></label>
                <input class="form-control<?= isset($errs['email']) ? ' is-invalid' : '' ?>" id="o-email" name="email" type="email" maxlength="190" dir="ltr" value="<?= $old_val('email') ?>" autocomplete="email">
                <?= $err('email') ?>
              </div>
              <div class="col-md-5">
                <label class="form-label" for="o-cm">وسيلة التواصل <b class="req">*</b></label>
                <select class="form-select" id="o-cm" name="contact_method">
                  <?php foreach (contact_methods() as $k => $l): ?><option value="<?= e($k) ?>"<?= selected($old['contact_method'] ?? 'whatsapp', $k) ?>><?= e($l) ?></option><?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-7">
                <label class="form-label" for="o-cv">رقم الجوال / المعرّف <b class="req">*</b></label>
                <input class="form-control<?= isset($errs['contact_value']) ? ' is-invalid' : '' ?>" id="o-cv" name="contact_value" maxlength="190" required dir="ltr" placeholder="+9665xxxxxxxx" value="<?= $old_val('contact_value') ?>">
                <?= $err('contact_value') ?>
              </div>
            </div>
          </fieldset>

          <fieldset>
            <legend><span>2</span> الخدمة المطلوبة</legend>
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label" for="o-cat">القسم الرئيسي <b class="req">*</b></label>
                <select class="form-select<?= isset($errs['category_id']) ? ' is-invalid' : '' ?>" id="o-cat" name="category_id" required>
                  <option value="">— اختر القسم —</option>
                  <?php foreach ($tree as $c): ?><option value="<?= (int) $c['id'] ?>"<?= selected($preCat, $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?>
                </select>
                <?= $err('category_id') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="o-sub">التخصص الفرعي</label>
                <select class="form-select" id="o-sub" data-selected="<?= $preSub ?>">
                  <option value="">كل التخصصات</option>
                </select>
              </div>
              <div class="col-12">
                <label class="form-label" for="o-svc">الخدمة الفرعية <b class="req">*</b></label>
                <select class="form-select<?= isset($errs['service_id']) ? ' is-invalid' : '' ?>" id="o-svc" name="service_id" required data-selected="<?= $preService ?>">
                  <option value="">— اختر القسم أولًا —</option>
                </select>
                <?= $err('service_id') ?>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="o-spec">التخصص الجامعي أو المهني</label>
                <input class="form-control" id="o-spec" name="specialization" maxlength="190" placeholder="مثال: هندسة معمارية — مستوى رابع" value="<?= $old_val('specialization') ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label" for="o-sw">البرنامج المطلوب <small class="text-muted">(للطلبات الهندسية/البرمجية)</small></label>
                <input class="form-control" id="o-sw" name="software" maxlength="190" list="sw-list" placeholder="AutoCAD، Revit، Python..." value="<?= $old_val('software') ?>">
                <datalist id="sw-list"><?php foreach (['AutoCAD', 'Revit', 'SketchUp', 'Blender', 'Lumion', 'SolidWorks', 'SAP2000', 'ETABS', 'MATLAB', 'SPSS', 'Excel', 'PowerPoint', 'Python', 'Java', 'PHP / MySQL', 'Flutter', 'Proteus', 'Packet Tracer', 'Arena', 'Minitab'] as $sw): ?><option value="<?= e($sw) ?>"><?php endforeach; ?></datalist>
              </div>
            </div>
          </fieldset>

          <fieldset>
            <legend><span>3</span> تفاصيل الطلب</legend>
            <div class="row g-3">
              <div class="col-12">
                <label class="form-label" for="o-desc">وصف الطلب بالتفصيل <b class="req">*</b></label>
                <textarea class="form-control<?= isset($errs['description']) ? ' is-invalid' : '' ?>" id="o-desc" name="description" rows="5" maxlength="3000" required placeholder="اشرح المطلوب: الموضوع، عدد الصفحات أو اللوحات، المتطلبات الخاصة، دليل الجامعة..."><?= $old_val('description') ?></textarea>
                <div class="d-flex justify-content-between"><?= $err('description') ?><small class="text-muted char-count" data-for="o-desc">0 / 3000</small></div>
              </div>
              <div class="col-md-6">
                <label class="form-label" for="o-dl">الموعد النهائي</label>
                <input class="form-control<?= isset($errs['deadline']) ? ' is-invalid' : '' ?>" id="o-dl" name="deadline" type="date" min="<?= date('Y-m-d') ?>" value="<?= $old_val('deadline') ?>">
                <?= $err('deadline') ?>
              </div>
              <div class="col-12">
                <label class="form-label" for="o-notes">ملاحظات إضافية</label>
                <textarea class="form-control" id="o-notes" name="notes" rows="2" maxlength="1500"><?= $old_val('notes') ?></textarea>
              </div>
            </div>
          </fieldset>

          <fieldset>
            <legend><span>4</span> الملفات والموافقة</legend>
            <?php if ($saveEnabled): ?>
              <div class="form-check consent-box mb-3">
                <input class="form-check-input" type="checkbox" id="o-store" name="consent_storage" value="1"<?= checked(!empty($old['consent_storage'])) ?>>
                <label class="form-check-label" for="o-store"><strong>أوافق على حفظ بيانات طلبي ومرفقاتي لدى المنصة</strong> لتسهيل المتابعة (اختياري). بدون هذه الموافقة لن يُحفظ أي شيء، وستُرسل الملفات في محادثة واتساب.</label>
              </div>
              <div class="upload-zone<?= isset($errs['attachments']) ? ' is-invalid' : '' ?>" id="upload-zone">
                <input type="file" id="o-files" name="attachments[]" multiple accept="<?= e('.' . implode(',.', $allowedExt)) ?>" disabled>
                <label for="o-files">
                  <i class="bi bi-cloud-arrow-up"></i>
                  <strong>اسحب الملفات هنا أو اضغط للاختيار</strong>
                  <small>المسموح: <?= e(strtoupper(implode('، ', $allowedExt))) ?> — حتى <?= $maxFiles ?> ملفات، <?= $maxMb ?>MB لكل ملف</small>
                  <small class="upload-locked"><i class="bi bi-lock"></i> فعّل خيار الموافقة على الحفظ أعلاه لرفع الملفات عبر الموقع</small>
                </label>
                <ul class="file-list" id="file-list"></ul>
              </div>
              <?= isset($errs['attachments']) ? '<div class="invalid-feedback d-block">' . e($errs['attachments']) . '</div>' : '<div class="invalid-feedback" data-for="attachments"></div>' ?>
            <?php else: ?>
              <div class="notice-box"><i class="bi bi-paperclip"></i><p class="mb-0">أرسل ملفاتك ومرفقاتك مباشرة في محادثة واتساب بعد فتحها.</p></div>
            <?php endif; ?>
            <div class="form-check mt-3">
              <input class="form-check-input<?= isset($errs['privacy']) ? ' is-invalid' : '' ?>" type="checkbox" id="o-privacy" name="privacy" value="1" required<?= checked(!empty($old['privacy'])) ?>>
              <label class="form-check-label" for="o-privacy">قرأت وأوافق على <a href="<?= e(route('privacy')) ?>" target="_blank">سياسة الخصوصية</a> و<a href="<?= e(route('terms')) ?>" target="_blank">الشروط والأحكام</a> <b class="req">*</b></label>
              <?= $err('privacy') ?>
            </div>
          </fieldset>

          <div class="form-actions">
            <button type="submit" class="btn btn-whatsapp btn-lg" id="order-submit">
              <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true" hidden></span>
              <i class="bi bi-whatsapp"></i> متابعة الطلب عبر واتساب
            </button>
            <p class="small text-muted mb-0"><i class="bi bi-shield-lock"></i> لا نطلب بيانات بطاقات بنكية أو كلمات مرور. يتم الاتفاق على السعر وطريقة الدفع عبر واتساب بعد مراجعة الطلب.</p>
          </div>
        </form>

        <div class="form-card text-center order-success" id="order-success" hidden>
          <i class="bi bi-check-circle-fill text-success display-4"></i>
          <h2 class="h4 mt-2">تم تجهيز رسالتك</h2>
          <p class="mb-1">إذا لم تُفتح محادثة واتساب تلقائيًا، اضغط الزر أدناه، ثم <strong>أكّد الإرسال داخل واتساب</strong>.</p>
          <p class="small text-muted" id="order-ref"></p>
          <a class="btn btn-whatsapp btn-lg" id="order-wa-link" href="#" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> فتح واتساب وإرسال الطلب</a>
          <div class="mt-3"><button class="btn btn-link" type="button" id="order-copy"><i class="bi bi-clipboard"></i> نسخ نص الرسالة</button></div>
        </div>
      </div>

      <aside class="col-lg-4">
        <div class="order-box sticky-lg-top">
          <h2 class="h5">كيف يعمل الطلب؟</h2>
          <ol class="mini-steps">
            <li>املأ النموذج واختر الخدمة.</li>
            <li>نجهز لك رسالة واتساب منظمة بكل التفاصيل.</li>
            <li>تؤكد الإرسال من واتساب وترفق ملفاتك.</li>
            <li>نراجع الطلب ونرسل لك السعر والمدة.</li>
            <li>تؤكد الحجز وتتم مناقشة طريقة الدفع عبر واتساب.</li>
          </ol>
          <hr>
          <p class="small mb-2">تفضّل المحادثة مباشرة؟</p>
          <a class="btn btn-outline-success w-100" href="<?= e(wa_service_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> افتح واتساب برسالة فارغة الحقول</a>
        </div>
      </aside>
    </div>
  </div>
</section>
<script type="application/json" id="order-catalog"><?= json_encode($jsTree, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script type="application/json" id="order-limits"><?= json_encode(['maxFiles' => $maxFiles, 'maxMb' => $maxMb, 'ext' => $allowedExt], JSON_HEX_TAG) ?></script>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
