<?php
/** صفحة المقال (v5) */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
if (!articles_enabled()) not_found();

$post = post_by_slug('article', (string) ($_GET['slug'] ?? ''));
if (!$post) not_found();
post_track_view((int) $post['id']);
$related = array_values(array_filter(posts_published('article', 4, 0, $post['category_id'] ? (int) $post['category_id'] : null), fn($p) => (int) $p['id'] !== (int) $post['id']));
$related = array_slice($related, 0, 3);
$url = absolute_url(ltrim(substr(route('article', ['slug' => $post['slug']]), strlen(base_path())), '/'));

$active_nav = 'blog';
$page_title = $post['meta_title'] ?: $post['title'];
$page_description = $post['meta_description'] ?: ($post['excerpt'] ?: excerpt($post['body'], 160));
$page_canonical = $url;
if ($post['cover_image'] && media_exists($post['cover_image'])) $page_image = absolute_url($post['cover_image']);
$page_type = 'article';
$breadcrumbs = [['المقالات', route('blog')], [$post['title'], null]];
$json_ld = [[
    '@context' => 'https://schema.org', '@type' => 'Article', 'headline' => $post['title'], 'description' => $page_description,
    'datePublished' => date('c', strtotime($post['published_at'] ?: $post['created_at'])), 'dateModified' => date('c', strtotime($post['updated_at'])),
    'mainEntityOfPage' => $url, 'author' => ['@type' => 'Organization', 'name' => setting('site_name')],
    'publisher' => ['@type' => 'Organization', 'name' => setting('site_name'), 'logo' => ['@type' => 'ImageObject', 'url' => absolute_url(setting('logo_path', 'assets/images/logo.svg'))]],
] + (!empty($page_image) ? ['image' => $page_image] : [])];
require ROOT_PATH . '/includes/header.php';
?>
<article class="section pt-4">
  <div class="container" style="max-width:860px">
    <header class="mb-4">
      <div class="post-meta mb-2"><?php if ($post['category_name']): ?><a href="<?= e(route('category', ['slug' => $post['category_slug']])) ?>"><i class="bi bi-tag"></i> <?= e($post['category_name']) ?></a> · <?php endif; ?><time datetime="<?= e(substr((string) ($post['published_at'] ?: $post['created_at']), 0, 10)) ?>"><?= e(ar_date($post['published_at'] ?: $post['created_at'])) ?></time> · <?= (int) $post['views'] ?> مشاهدة</div>
      <h1 class="fw-bold"><?= e($post['title']) ?></h1>
      <?php if ($post['excerpt']): ?><p class="lead text-muted"><?= e($post['excerpt']) ?></p><?php endif; ?>
    </header>
    <?php if ($post['cover_image'] && media_exists($post['cover_image'])): ?><img class="article-cover mb-4" src="<?= e(media_url($post['cover_image'])) ?>" alt="<?= e($post['title']) ?>" width="1200" height="630" fetchpriority="high"><?php endif; ?>
    <div class="article-body"><?= safe_html($post['body']) ?></div>
    <div class="mt-4"><?= render_share_buttons($url, $post['title']) ?></div>
    <aside class="cta-inner mt-5 p-4 rounded-4" style="background:linear-gradient(135deg,#0b1f3a,#13315c);color:#fff">
      <div><h2 class="h5">تحتاج مساعدة في هذا الموضوع؟</h2><p class="mb-0 opacity-75">تواصل معنا وسيساعدك متخصص مناسب.</p></div>
      <div class="cta-actions"><a class="btn btn-gold" href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> تواصل عبر واتساب</a></div>
    </aside>
  </div>
</article>
<?php if ($related): ?>
<section class="section section-alt"><div class="container">
  <h2 class="section-title h4 mb-4">مقالات ذات صلة</h2>
  <div class="row g-4"><?php foreach ($related as $p): ?><div class="col-md-4"><?= render_post_card($p) ?></div><?php endforeach; ?></div>
</div></section>
<?php endif; ?>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
