<?php
/** robots.txt ديناميكي (يتضمن رابط خريطة الموقع الصحيح) — متاح على /robots.txt */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
header('Content-Type: text/plain; charset=utf-8');
$b = base_path();
echo "User-agent: *\n";
if (setting('site_noindex', '0') === '1') { echo "Disallow: /\n"; exit; }
echo "Allow: /\n";
foreach (['/admin/', '/api/', '/setup.php', '/install.php', '/search', '/search.php', '/account', '/login', '/register', '/forgot', '/portfolio_file.php', '/*?q='] as $d) echo "Disallow: $b$d\n";
echo "\nUser-agent: Googlebot-Image\nAllow: $b/assets/images/\n";
echo "\nSitemap: " . absolute_url('sitemap.xml') . "\n";
