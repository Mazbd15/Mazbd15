<?php
/**
 * معالج التثبيت — اختيارك للخدمات الطلابية
 * يعمل مرة واحدة فقط: ينشئ ملف .env، ويستورد قاعدة البيانات، وينشئ حساب المدير العام.
 * بعد نجاح التثبيت يُنشأ الملف storage/installed.lock ويتعطل المعالج نهائيًا.
 */
declare(strict_types=1);

define('ROOT_PATH', dirname(__DIR__));
$lock = ROOT_PATH . '/storage/installed.lock';
header('X-Robots-Tag: noindex, nofollow');
header('X-Frame-Options: DENY');
header('Cache-Control: no-store');

function h($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

session_name('IKHINSTALL');
session_start();
if (empty($_SESSION['tok'])) $_SESSION['tok'] = bin2hex(random_bytes(16));

// اكتشاف رابط الموقع تلقائيًا
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$host = preg_replace('/[^a-zA-Z0-9.\-:\[\]]/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
$dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
if (str_ends_with($dir, '/public')) $dir = substr($dir, 0, -7);
$detectedUrl = ($https ? 'https' : 'http') . '://' . $host . $dir;

$installed = is_file($lock);

// ---------------------------------------------------------------- فحص المتطلبات
$checks = [
    ['إصدار PHP 8.1 أو أحدث (الحالي: ' . PHP_VERSION . ')', version_compare(PHP_VERSION, '8.1.0', '>=')],
    ['امتداد PDO MySQL', extension_loaded('pdo_mysql')],
    ['امتداد mbstring', extension_loaded('mbstring')],
    ['امتداد fileinfo (فحص الملفات المرفوعة)', extension_loaded('fileinfo')],
    ['امتداد GD (اختياري — لإعادة ترميز الصور)', extension_loaded('gd'), true],
    ['مجلد storage/ قابل للكتابة', is_writable(ROOT_PATH . '/storage')],
    ['مجلد storage/uploads/requests قابل للكتابة', is_writable(ROOT_PATH . '/storage/uploads/requests')],
    ['مجلد public/assets/images/uploads قابل للكتابة', is_writable(__DIR__ . '/assets/images/uploads')],
    ['مجلد storage/uploads قابل للكتابة (ملفات معرض الأعمال)', is_writable(ROOT_PATH . '/storage/uploads')],
    ['جذر المشروع قابل للكتابة (لإنشاء ملف .env)', is_writable(ROOT_PATH), true],
];
$reqOk = true;
foreach ($checks as $c) if (!$c[1] && empty($c[2])) $reqOk = false;

/**
 * تشغيل ترقيات database/migrations على اتصال التثبيت نفسه (لا يحتاج .env).
 * تُحمَّل مكتبات المساعدة وقاعدة البيانات والترقيات فقط — دون إقلاع التطبيق كاملًا.
 */
function install_run_migrations(PDO $pdo): array
{
    $GLOBALS['CONFIG'] = $GLOBALS['CONFIG'] ?? [];
    require_once ROOT_PATH . '/includes/helpers.php';
    require_once ROOT_PATH . '/includes/db.php';
    require_once ROOT_PATH . '/includes/migrate.php';
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    db($pdo);
    return migrations_run();
}

/** تقسيم ملف SQL إلى أوامر مع احترام النصوص بين علامات التنصيص */
function split_sql(string $sql): array
{
    $out = []; $buf = ''; $len = strlen($sql); $inStr = false;
    for ($i = 0; $i < $len; $i++) {
        $ch = $sql[$i];
        if (!$inStr && $ch === '-' && ($sql[$i + 1] ?? '') === '-') { // تعليق سطري
            while ($i < $len && $sql[$i] !== "\n") $i++;
            continue;
        }
        if ($inStr) {
            if ($ch === '\\') { $buf .= $ch . ($sql[$i + 1] ?? ''); $i++; continue; }
            if ($ch === "'") {
                if (($sql[$i + 1] ?? '') === "'") { $buf .= "''"; $i++; continue; }
                $inStr = false;
            }
            $buf .= $ch;
            continue;
        }
        if ($ch === "'") { $inStr = true; $buf .= $ch; continue; }
        if ($ch === ';') { if (trim($buf) !== '') $out[] = trim($buf); $buf = ''; continue; }
        $buf .= $ch;
    }
    if (trim($buf) !== '') $out[] = trim($buf);
    return $out;
}

function env_line(string $k, string $v): string
{
    // ترميز آمن لأي رموز (\ و ") داخل القيمة
    return $k . '="' . str_replace(['\\', '"', "\r", "\n"], ['\\\\', '\\"', '', ''], $v) . '"';
}

$errors = [];
$done = false;
$envManual = null;
$old = $_POST + ['site_url' => $detectedUrl, 'db_host' => 'localhost', 'db_port' => '3306', 'whatsapp' => '966575996163'];

if (!$installed && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['tok'], (string) ($_POST['tok'] ?? ''))) $errors[] = 'انتهت صلاحية الصفحة، حدّثها وحاول مجددًا.';
    $siteUrl = rtrim(trim((string) ($_POST['site_url'] ?? '')), '/');
    $dbHost = trim((string) ($_POST['db_host'] ?? 'localhost'));
    $dbPort = (int) ($_POST['db_port'] ?? 3306) ?: 3306;
    $dbName = trim((string) ($_POST['db_name'] ?? ''));
    $dbUser = trim((string) ($_POST['db_user'] ?? ''));
    $dbPass = (string) ($_POST['db_pass'] ?? '');
    $aName = trim((string) ($_POST['admin_name'] ?? ''));
    $aEmail = mb_strtolower(trim((string) ($_POST['admin_email'] ?? '')));
    $aPass = (string) ($_POST['admin_pass'] ?? '');
    $wa = preg_replace('/\D+/', '', (string) ($_POST['whatsapp'] ?? ''));
    $overwrite = !empty($_POST['overwrite']);

    if (!$reqOk) $errors[] = 'يرجى معالجة المتطلبات غير المتوفرة أولًا.';
    if (!filter_var($siteUrl, FILTER_VALIDATE_URL) || !preg_match('#^https?://#', $siteUrl)) $errors[] = 'رابط الموقع غير صالح.';
    if ($dbName === '' || $dbUser === '') $errors[] = 'اسم قاعدة البيانات واسم المستخدم مطلوبان.';
    if (preg_match('/[\r\n]/', $dbPass . $dbUser . $dbName . $dbHost)) $errors[] = 'بيانات قاعدة البيانات لا يجب أن تحتوي أسطرًا جديدة.';
    if ($aName === '') $errors[] = 'اسم المدير مطلوب.';
    if (!filter_var($aEmail, FILTER_VALIDATE_EMAIL)) $errors[] = 'بريد المدير غير صالح.';
    if (mb_strlen($aPass) < 10 || !preg_match('/[A-Za-z]/', $aPass) || !preg_match('/\d/', $aPass)) $errors[] = 'كلمة مرور المدير: 10 أحرف على الأقل وتحتوي حروفًا إنجليزية وأرقامًا.';
    if ($aPass !== (string) ($_POST['admin_pass2'] ?? '')) $errors[] = 'تأكيد كلمة المرور غير مطابق.';
    if (strlen($wa) < 9 || strlen($wa) > 15) $errors[] = 'رقم واتساب غير صالح (صيغة دولية مثل 966575996163).';

    $pdo = null;
    if (!$errors) {
        try {
            $pdo = new PDO("mysql:host=$dbHost;port=$dbPort;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        } catch (PDOException $e) {
            $errors[] = 'تعذر الاتصال بقاعدة البيانات: تأكد من الاسم والمستخدم وكلمة المرور، وأن المستخدم مضاف للقاعدة بكامل الصلاحيات. (' . h($e->getMessage()) . ')';
        }
    }
    if (!$errors && $pdo) {
        $exists = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'users'")->fetchColumn();
        if ($exists && !$overwrite) {
            $errors[] = 'قاعدة البيانات تحتوي جداول المنصة مسبقًا. فعّل خيار «استبدال البيانات الموجودة» إذا أردت إعادة التثبيت (سيتم حذف كل البيانات الحالية).';
        }
    }
    if (!$errors && $pdo) {
        try {
            $pdo->exec('SET NAMES utf8mb4');
            foreach (['schema.sql', 'seed.sql'] as $f) {
                $sql = file_get_contents(ROOT_PATH . '/database/' . $f);
                if ($sql === false) throw new RuntimeException("الملف database/$f غير موجود");
                foreach (split_sql($sql) as $stmt) $pdo->exec($stmt);
            }
            // v5: تطبيق الترقيات الآمنة على التثبيت الجديد (جداول الآراء والرسائل والمقالات وسجل الحالات...)
            $migLog = install_run_migrations($pdo);
            foreach ($migLog as [$mst, $mname, $minfo]) if ($mst !== 'ok') throw new RuntimeException("فشل تطبيق الترقية $mname: $minfo");
            $st = $pdo->prepare('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?');
            $st->execute([$wa, 'whatsapp_number']);
            $st->execute(['+' . $wa, 'whatsapp_display']);
            $pdo->prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, "super_admin")')
                ->execute([$aName, $aEmail, password_hash($aPass, PASSWORD_DEFAULT)]);

            $env = implode("\n", [
                '# أُنشئ تلقائيًا بواسطة معالج التثبيت — ' . date('Y-m-d H:i'),
                'APP_ENV=production', 'APP_DEBUG=false',
                env_line('APP_URL', $siteUrl), 'PRETTY_URLS=true', 'APP_TIMEZONE=Asia/Riyadh',
                env_line('DB_HOST', $dbHost), 'DB_PORT=' . $dbPort, env_line('DB_NAME', $dbName), env_line('DB_USER', $dbUser), env_line('DB_PASS', $dbPass),
                'APP_KEY=' . bin2hex(random_bytes(32)), 'SETUP_KEY=', 'STORAGE_PATH=', 'UPLOAD_MAX_MB=10', 'UPLOAD_MAX_FILES=5',
            ]) . "\n";
            if (@file_put_contents(ROOT_PATH . '/.env', $env) === false) {
                $envManual = $env; // لم نتمكن من الكتابة — نعرض المحتوى للنسخ اليدوي
            } else {
                @chmod(ROOT_PATH . '/.env', 0640);
            }
            file_put_contents($lock, 'installed ' . date('c'));
            $done = true;
            $installed = true;
            session_destroy();
        } catch (Throwable $e) {
            $errors[] = 'حدث خطأ أثناء إنشاء الجداول: ' . h($e->getMessage());
        }
    }
}
?><!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>تثبيت منصة اختيارك</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;800&display=swap">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
<style>
body{font-family:Cairo,Tahoma,sans-serif;background:linear-gradient(150deg,#0b1f3a,#13315c);min-height:100vh;padding:30px 12px}
.card{max-width:820px;margin:auto;border:0;border-radius:22px;box-shadow:0 30px 70px rgba(0,0,0,.3)}
.head{background:#0b1f3a;color:#fff;border-radius:22px 22px 0 0;padding:24px;text-align:center}
.head small{color:#e3c477}
legend{font-size:1.05rem;font-weight:800;color:#13315c;border-bottom:2px solid #f1e3bf;padding-bottom:6px;margin-bottom:14px}
.btn-gold{background:linear-gradient(135deg,#e3c477,#c9a24d);border:0;color:#0b1f3a;font-weight:800}
.ok{color:#16a34a}.bad{color:#dc2626}.opt{color:#b45309}
pre{background:#0b1f3a;color:#e3c477;padding:14px;border-radius:12px;direction:ltr;text-align:left;white-space:pre-wrap}
</style>
</head>
<body>
<div class="card">
  <div class="head">
    <img src="assets/images/logo.svg" width="64" height="64" alt="">
    <h1 class="h4 mt-2 mb-0">تثبيت منصة «اختيارك للخدمات الطلابية»</h1>
    <small>اختيارك الذكي نحو التميز والنجاح</small>
  </div>
  <div class="card-body p-4">
  <?php if ($done): ?>
    <div class="alert alert-success"><strong>🎉 تم التثبيت بنجاح!</strong> تم إنشاء الجداول واستيراد الأقسام والخدمات وإنشاء حساب المدير العام.</div>
    <?php if ($envManual): ?>
      <div class="alert alert-warning">لم نتمكن من إنشاء ملف <code>.env</code> تلقائيًا. أنشئ ملفًا باسم <code>.env</code> في <strong>المجلد الرئيسي للمشروع</strong> (بجوار مجلد public) والصق فيه:</div>
      <pre><?= h($envManual) ?></pre>
    <?php endif; ?>
    <ul>
      <li>الموقع: <a href="<?= h($old['site_url']) ?>/" target="_blank"><?= h($old['site_url']) ?>/</a></li>
      <li>لوحة التحكم: <a href="<?= h($old['site_url']) ?>/admin/" target="_blank"><?= h($old['site_url']) ?>/admin/</a></li>
    </ul>
    <div class="alert alert-info small mb-0">🔒 لأمان إضافي احذف الملف <code>public/install.php</code> من الاستضافة (المعالج معطل تلقائيًا الآن).</div>
  <?php elseif ($installed): ?>
    <div class="alert alert-secondary mb-0">المنصة مثبتة مسبقًا ومعالج التثبيت معطّل. لإعادة التثبيت احذف الملف <code>storage/installed.lock</code> (تحذير: إعادة التثبيت تحذف البيانات).<br><a href="./">الذهاب للموقع</a> · <a href="admin/">لوحة التحكم</a></div>
  <?php else: ?>
    <h2 class="h6 fw-bold">1) فحص متطلبات الاستضافة</h2>
    <ul class="list-unstyled small mb-4">
      <?php foreach ($checks as $c): ?>
        <li><?= $c[1] ? '<span class="ok">✔</span>' : (!empty($c[2]) ? '<span class="opt">⚠</span>' : '<span class="bad">✘</span>') ?> <?= h($c[0]) ?></li>
      <?php endforeach; ?>
    </ul>
    <?php if (!$reqOk): ?><div class="alert alert-danger">بعض المتطلبات غير متوفرة. فعّلها من لوحة الاستضافة (Select PHP Version / صلاحيات المجلدات 755) ثم حدّث الصفحة.</div><?php endif; ?>
    <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= $er ?></div><?php endforeach; ?>

    <form method="post" autocomplete="off">
      <input type="hidden" name="tok" value="<?= h($_SESSION['tok']) ?>">
      <fieldset class="mb-4"><legend>2) قاعدة البيانات</legend>
        <p class="small text-muted">أنشئ قاعدة بيانات ومستخدمًا من لوحة الاستضافة (cPanel ← MySQL Databases) وأضف المستخدم للقاعدة بكل الصلاحيات (ALL PRIVILEGES).</p>
        <div class="row g-3">
          <div class="col-md-8"><label class="form-label">الخادم (Host)</label><input class="form-control" name="db_host" dir="ltr" required value="<?= h($old['db_host']) ?>"></div>
          <div class="col-md-4"><label class="form-label">المنفذ</label><input class="form-control" name="db_port" dir="ltr" value="<?= h($old['db_port']) ?>"></div>
          <div class="col-md-4"><label class="form-label">اسم القاعدة</label><input class="form-control" name="db_name" dir="ltr" required value="<?= h($old['db_name'] ?? '') ?>" placeholder="user_ikhtiyarak"></div>
          <div class="col-md-4"><label class="form-label">اسم المستخدم</label><input class="form-control" name="db_user" dir="ltr" required value="<?= h($old['db_user'] ?? '') ?>"></div>
          <div class="col-md-4"><label class="form-label">كلمة المرور</label><input class="form-control" type="password" name="db_pass" dir="ltr"></div>
          <div class="col-12"><label class="form-check small"><input class="form-check-input" type="checkbox" name="overwrite" value="1"> استبدال البيانات الموجودة إن كانت المنصة مثبتة في هذه القاعدة سابقًا (⚠ يحذف كل البيانات)</label></div>
        </div>
      </fieldset>
      <fieldset class="mb-4"><legend>3) إعدادات الموقع</legend>
        <div class="row g-3">
          <div class="col-md-7"><label class="form-label">رابط الموقع</label><input class="form-control" name="site_url" dir="ltr" required value="<?= h($old['site_url']) ?>"><div class="form-text">تم اكتشافه تلقائيًا — بدون شرطة في النهاية.</div></div>
          <div class="col-md-5"><label class="form-label">رقم واتساب (دولي بدون +)</label><input class="form-control" name="whatsapp" dir="ltr" required value="<?= h($old['whatsapp']) ?>"></div>
        </div>
      </fieldset>
      <fieldset class="mb-4"><legend>4) حساب المدير العام (لوحة التحكم)</legend>
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">الاسم</label><input class="form-control" name="admin_name" required value="<?= h($old['admin_name'] ?? '') ?>"></div>
          <div class="col-md-6"><label class="form-label">البريد الإلكتروني (اسم الدخول)</label><input class="form-control" type="email" name="admin_email" dir="ltr" required value="<?= h($old['admin_email'] ?? '') ?>"></div>
          <div class="col-md-6"><label class="form-label">كلمة المرور</label><input class="form-control" type="password" name="admin_pass" dir="ltr" required minlength="10" autocomplete="new-password"><div class="form-text">10 أحرف على الأقل، حروف إنجليزية وأرقام.</div></div>
          <div class="col-md-6"><label class="form-label">تأكيد كلمة المرور</label><input class="form-control" type="password" name="admin_pass2" dir="ltr" required minlength="10" autocomplete="new-password"></div>
        </div>
      </fieldset>
      <button class="btn btn-gold btn-lg w-100"<?= $reqOk ? '' : ' disabled' ?>>تثبيت المنصة الآن</button>
    </form>
  <?php endif; ?>
  </div>
</div>
</body>
</html>
