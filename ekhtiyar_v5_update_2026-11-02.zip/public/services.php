<?php
/** جميع الخدمات مع فلاتر حسب القسم والتخصص والنوع */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$tree = catalog_tree();
$catId = (int) ($_GET['category'] ?? 0);
$subId = (int) ($_GET['sub'] ?? 0);
$type  = (string) ($_GET['type'] ?? '');
$q     = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100);
if ($catId && !isset($tree[$catId])) $catId = 0;
if ($subId && (!$catId || !isset($tree[$catId]['subs'][$subId]))) $subId = 0;
if ($type !== '' && !isset(service_types()[$type])) $type = '';

$results = search_services($q, ['category' => $catId, 'sub' => $subId, 'type' => $type], 500);
// تجميع حسب القسم عند عدم وجود بحث
$grouped = [];
foreach ($results as $r) $grouped[$r['category_id']][] = $r;
if ($q === '') {
    // ترتيب المجموعات حسب ترتيب الأقسام
    $ordered = [];
    foreach ($tree as $cid => $_) if (isset($grouped[$cid])) $ordered[$cid] = $grouped[$cid];
    $grouped = $ordered;
    foreach ($grouped as &$g) usort($g, fn($a, $b) => [$a['subcategory_id'], $a['sort_order']] <=> [$b['subcategory_id'], $b['sort_order']]);
    unset($g);
}

$active_nav = 'services';
$page_title = 'جميع الخدمات';
$page_description = 'تصفح جميع خدمات منصة اختيارك: الأكاديمية والهندسية والبرمجية والتصميمية والترجمة والسيرة الذاتية، مع فلاتر حسب القسم والتخصص ونوع الخدمة.';
$breadcrumbs = [['جميع الخدمات', null]];
if ($catId || $subId || $type || $q) $noindex = true;
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1>جميع الخدمات</h1>
    <p>أكثر من <?= count(array_merge(...array_map(fn($c) => $c['services'], array_values($tree) ?: [['services' => []]]))) ?> خدمة موزعة على <?= count($tree) ?> أقسام رئيسية.</p>
  </div>
</section>

<section class="section pt-4">
  <div class="container">
    <form class="filters-bar" method="get" action="<?= e(route('services')) ?>" id="filters-form">
      <div class="row g-2 align-items-end">
        <div class="col-md-4">
          <label class="form-label small" for="f-q">بحث</label>
          <input class="form-control" id="f-q" type="search" name="q" value="<?= e($q) ?>" placeholder="اسم الخدمة أو البرنامج..." maxlength="100">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small" for="f-cat">المجال</label>
          <select class="form-select" id="f-cat" name="category" data-sub-target="#f-sub">
            <option value="">كل المجالات</option>
            <?php foreach ($tree as $c): ?><option value="<?= (int) $c['id'] ?>"<?= selected($catId, $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-2">
          <label class="form-label small" for="f-sub">التخصص</label>
          <select class="form-select" id="f-sub" name="sub" data-selected="<?= $subId ?>">
            <option value="">كل التخصصات</option>
            <?php if ($catId) foreach ($tree[$catId]['subs'] as $s): ?><option value="<?= (int) $s['id'] ?>"<?= selected($subId, $s['id']) ?>><?= e($s['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-2">
          <label class="form-label small" for="f-type">نوع الخدمة</label>
          <select class="form-select" id="f-type" name="type">
            <option value="">الكل</option>
            <?php foreach (service_types() as $k => $l): ?><option value="<?= e($k) ?>"<?= selected($type, $k) ?>><?= e($l) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-1 d-grid"><button class="btn btn-navy" type="submit"><i class="bi bi-funnel"></i><span class="d-md-none"> تصفية</span></button></div>
      </div>
      <?php if ($catId || $subId || $type || $q): ?>
        <div class="mt-2 small"><span class="text-muted"><?= count($results) ?> نتيجة</span> — <a href="<?= e(route('services')) ?>">مسح الفلاتر</a></div>
      <?php endif; ?>
    </form>
    <script type="application/json" id="catalog-data"><?= json_encode(array_values(array_map(fn($c) => ['id' => (int) $c['id'], 'subs' => array_values(array_map(fn($s) => ['id' => (int) $s['id'], 'name' => $s['name']], $c['subs']))], $tree)), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script>

    <?php if (!$results): ?>
      <div class="empty-state">
        <i class="bi bi-search"></i>
        <h2>لا توجد نتائج مطابقة</h2>
        <p>جرّب كلمات أخرى أو راسلنا مباشرة وسنساعدك في تحديد الخدمة المناسبة.</p>
        <a class="btn btn-whatsapp" href="<?= e(wa_service_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اسألنا عبر واتساب</a>
      </div>
    <?php elseif ($q !== ''): ?>
      <div class="row g-4">
        <?php foreach ($results as $s): ?><div class="col-sm-6 col-lg-4 col-xl-3"><?= render_service_card($s) ?></div><?php endforeach; ?>
      </div>
    <?php else: ?>
      <?php foreach ($grouped as $cid => $list): $c = $tree[$cid]; ?>
        <section class="services-group" aria-labelledby="grp-<?= (int) $cid ?>">
          <div class="services-group-head">
            <h2 id="grp-<?= (int) $cid ?>"><?= icon($c['icon']) ?> <?= e($c['name']) ?></h2>
            <a href="<?= e(route('category', ['slug' => $c['slug']])) ?>">صفحة القسم <i class="bi bi-arrow-left"></i></a>
          </div>
          <div class="row g-3">
            <?php foreach ($list as $s): ?><div class="col-sm-6 col-lg-4 col-xl-3"><?= render_service_card($s) ?></div><?php endforeach; ?>
          </div>
        </section>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
