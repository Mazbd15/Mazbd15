<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$categories = categories_active();
$popular    = services_popular(8);
$homeFaqs   = faqs_for(null, null, true, 6);
$stats      = stats_public();
$categoriesTop = $categories;
$homeWorks  = section_on('home_portfolio') ? portfolio_list(['featured' => 1], 6) : [];
if (section_on('home_portfolio') && count($homeWorks) < 3) {
    $ids = array_column($homeWorks, 'id');
    foreach (portfolio_list([], 6) as $w) if (!in_array($w['id'], $ids) && count($homeWorks) < 6) $homeWorks[] = $w;
}
$homeReviews = section_on('home_testimonials') ? testimonials_list(max(1, min(24, (int) setting('testimonials_count', '6')))) : [];
$homeArticles = section_on('home_articles') && articles_enabled() ? posts_published('article', 3) : [];
$reviewStats = $homeReviews ? testimonials_stats() : ['avg' => 0, 'count' => 0];
$heroTags   = csv_items(setting('hero_tags', 'بحوث التخرج, AutoCAD, SPSS, PowerPoint, سيرة ذاتية, PHP'));

$active_nav = 'home';
$page_title = '';
$page_description = setting('site_description');
if (setting('seo_auto_descriptions', '1') === '1' && mb_strlen($page_description) < 110) {
    $page_description = seo_description($page_description, 'خدمات: ' . implode('، ', array_column(array_slice($categories, 0, 5), 'name')) . '.');
}
$json_ld = faq_json_ld($homeFaqs);
$json_ld[] = ['@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => setting('site_name'), 'url' => absolute_url(),
    'potentialAction' => ['@type' => 'SearchAction', 'target' => absolute_url(ltrim(substr(route('search'), strlen(base_path())), '/')) . '?q={search_term_string}', 'query-input' => 'required name=search_term_string']];
// تقييمات حقيقية فقط (معتمدة وبموافقة أصحابها) — لا تُضاف Schema إن لم توجد آراء
$json_ld = array_merge($json_ld, testimonials_json_ld($homeReviews, $reviewStats, (string) setting('site_name'), 'EducationalOrganization'));
require ROOT_PATH . '/includes/header.php';
?>

<section id="hero-section" class="hero">
  <div class="hero-bg" aria-hidden="true"><span class="orb orb-1"></span><span class="orb orb-2"></span><span class="grid-lines"></span></div>
  <div class="container position-relative">
    <div class="row align-items-center g-4 g-lg-5">
      <div class="col-lg-6">
        <span class="hero-badge"><i class="bi bi-patch-check-fill"></i> <?= e(setting('hero_badge')) ?></span>
        <h1 class="hero-title"><?= e(setting('hero_title')) ?></h1>
        <p class="hero-subtitle"><?= e(setting('hero_subtitle')) ?></p>
        <?= render_search_box('', 'lg', 'hero-search') ?>
        <?php if ($heroTags): ?><div class="hero-tags" aria-label="عمليات بحث شائعة">
          <span class="hero-tags-label"><i class="bi bi-fire"></i> الأكثر بحثًا:</span>
          <?php foreach (array_slice($heroTags, 0, 8) as $tag): ?>
            <a href="<?= e(route('search', ['q' => $tag])) ?>"><?= e($tag) ?></a>
          <?php endforeach; ?>
        </div><?php endif; ?>
        <div class="hero-actions">
          <a class="btn btn-gold btn-lg" href="<?= e(route('order')) ?>"><i class="bi bi-lightning-charge-fill"></i> اطلب خدمتك الآن</a>
          <a class="btn btn-glass btn-lg" href="<?= e(wa_service_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> تحدث معنا</a>
        </div>
      </div>
      <div class="col-lg-6">
        <?php if (section_on('home_banners') && ($homeAds = banners_for(null, 8))): ?>
          <?= render_banners($homeAds, 'home-offers', 'hero') ?>
        <?php else: ?>
          <div class="hero-visual d-none d-lg-block" aria-hidden="true">
            <div class="hero-card hc-main"><img src="<?= e(url('assets/images/logo.svg')) ?>" alt="" width="84" height="84"><strong><?= e(setting('site_name')) ?></strong><span><?= e(setting('site_tagline')) ?></span></div>
            <div class="hero-card hc-1"><i class="bi bi-mortarboard"></i> أكاديمي</div>
            <div class="hero-card hc-2"><i class="bi bi-buildings"></i> هندسي ومعماري</div>
            <div class="hero-card hc-3"><i class="bi bi-code-slash"></i> برمجة وتقنية</div>
            <div class="hero-card hc-4"><i class="bi bi-palette"></i> تصميم</div>
          </div>
        <?php endif; ?>
      </div>
    </div>
    <?php if (section_on('home_stats')): ?>
    <ul class="hero-stats">
      <li><i class="bi bi-grid-1x2"></i><strong data-count="<?= $stats['categories'] ?>"><?= $stats['categories'] ?></strong><span>أقسام رئيسية</span></li>
      <li><i class="bi bi-diagram-3"></i><strong data-count="<?= $stats['subs'] ?>"><?= $stats['subs'] ?></strong><span>تخصص فرعي</span></li>
      <li><i class="bi bi-briefcase"></i><strong data-count="<?= $stats['services'] ?>" data-suffix="+"><?= $stats['services'] ?>+</strong><span>خدمة متاحة</span></li>
      <li><i class="bi bi-shield-check"></i><strong>100%</strong><span>خصوصية وسرية</span></li>
    </ul>
    <?php endif; ?>
  </div>
</section>

<?php if (setting('show_quick_picker', '1') === '1'): ?>
<section id="needs-section" class="section needs-section">
  <div class="container">
    <header class="section-head">
      <span class="section-kicker">ابدأ من هنا</span>
      <h2 class="section-title"><?= e(setting('quick_picker_title', 'ماذا تحتاج اليوم؟')) ?></h2>
      <p class="section-lead">اختر نوع احتياجك وسنأخذك مباشرة للخدمات المناسبة — بدون تعقيد.</p>
    </header>
    <?= render_quick_picker() ?>
    <p class="needs-help"><i class="bi bi-question-circle"></i> لست متأكدًا مما تحتاجه؟ <a href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener">اكتب لنا مشكلتك وسنقترح عليك الخدمة المناسبة</a></p>
  </div>
</section>
<?php endif; ?>

<?php if (section_on('home_categories')): ?>
<section id="categories-section" class="section section-alt">
  <div class="container">
    <header class="section-head">
      <span class="section-kicker">أقسامنا</span>
      <h2 class="section-title">الخدمات الرئيسية</h2>
      <p class="section-lead">تصنيف واضح يأخذك من القسم الرئيسي إلى التخصص ثم الخدمة التي تحتاجها بالضبط.</p>
      <ol class="path-hint" aria-label="طريقة التصفح"><li><i class="bi bi-grid"></i> القسم</li><li><i class="bi bi-diagram-3"></i> التخصص</li><li><i class="bi bi-briefcase"></i> الخدمة</li><li><i class="bi bi-whatsapp"></i> اطلب</li></ol>
    </header>
    <div class="row g-4">
      <?php foreach ($categories as $c): ?>
        <div class="col-sm-6 col-lg-3 reveal"><?= render_category_card($c) ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($homeWorks): ?>
<section id="home-portfolio-section" class="section">
  <div class="container">
    <header class="section-head d-md-flex justify-content-between align-items-end text-md-start">
      <div class="text-center text-md-end">
        <span class="section-kicker">معرض الأعمال</span>
        <h2 class="section-title mb-md-1"><?= e(setting('portfolio_title', 'من أعمالنا السابقة')) ?></h2>
        <p class="section-lead mb-md-0"><?= e(setting('portfolio_subtitle')) ?></p>
      </div>
      <a class="btn btn-outline-navy d-none d-md-inline-flex" href="<?= e(route('portfolio')) ?>">كل الأعمال <i class="bi bi-arrow-left"></i></a>
    </header>
    <div class="row g-4 scroller-sm">
      <?php foreach ($homeWorks as $w): ?><div class="col-10 col-sm-6 col-lg-4 reveal"><?= render_portfolio_card($w) ?></div><?php endforeach; ?>
    </div>
    <div class="text-center mt-4 d-md-none"><a class="btn btn-outline-navy" href="<?= e(route('portfolio')) ?>">كل الأعمال <i class="bi bi-arrow-left"></i></a></div>
  </div>
</section>
<?php endif; ?>

<?php if (section_on('home_why')): ?>
<section id="why-section" class="section">
  <div class="container">
    <header class="section-head">
      <span class="section-kicker">مميزاتنا</span>
      <h2 class="section-title"><?= e(setting('why_title', 'لماذا تختار منصتنا؟')) ?></h2>
    </header>
    <div class="row g-4 justify-content-center">
      <?php foreach ([
          ['bi-award', 'الجودة', 'فريق متخصص في كل مجال، ومراجعة دقيقة قبل التسليم.'],
          ['bi-shield-lock', 'الخصوصية', 'سرية تامة لبياناتك وملفاتك، ويمكنك استخدام اسم مستعار.'],
          ['bi-list-check', 'وضوح المتطلبات', 'نفهم طلبك جيدًا ونوضح السعر والمدة قبل أي التزام.'],
          ['bi-chat-dots', 'المتابعة', 'تواصل مستمر عبر واتساب وتحديثات طوال مراحل العمل.'],
          ['bi-alarm', 'الالتزام بالمواعيد', 'نتفق على موعد واقعي ونلتزم به.'],
      ] as [$ic, $t, $d]): ?>
        <div class="col-sm-6 col-lg reveal">
          <article class="feature-card h-100">
            <span class="feature-icon"><i class="bi <?= $ic ?>"></i></span>
            <h3><?= e($t) ?></h3>
            <p><?= e($d) ?></p>
          </article>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php endif; ?>

<?php if (section_on('home_steps')): ?>
<section id="steps-section" class="section">
  <div class="container">
    <header class="section-head">
      <span class="section-kicker">طريقة الطلب</span>
      <h2 class="section-title">أربع خطوات بسيطة</h2>
    </header>
    <ol class="steps">
      <?php foreach ([
          ['bi-hand-index-thumb', 'اختر الخدمة', 'تصفح الأقسام أو ابحث عن خدمتك.'],
          ['bi-pencil-square', 'اشرح متطلباتك', 'املأ النموذج أو اكتب التفاصيل.'],
          ['bi-cloud-arrow-up', 'أرسل الملفات', 'أرفق ملفاتك في محادثة واتساب.'],
          ['bi-whatsapp', 'أكد الحجز عبر واتساب', 'نتفق على السعر والمدة ثم نبدأ.'],
      ] as $i => [$ic, $t, $d]): ?>
        <li class="step reveal">
          <span class="step-num"><?= $i + 1 ?></span>
          <span class="step-icon"><i class="bi <?= $ic ?>"></i></span>
          <h3><?= e($t) ?></h3>
          <p><?= e($d) ?></p>
        </li>
      <?php endforeach; ?>
    </ol>
    <div class="text-center mt-4">
      <a class="btn btn-navy btn-lg" href="<?= e(route('order')) ?>"><i class="bi bi-ui-checks"></i> ابدأ نموذج الطلب</a>
    </div>
  </div>
</section>

<?php endif; ?>

<?php if (section_on('home_audience')): ?>
<section id="audience-section" class="section section-alt">
  <div class="container">
    <header class="section-head">
      <span class="section-kicker">لمن هذه المنصة؟</span>
      <h2 class="section-title">نخدمك أينما كنت في رحلتك</h2>
    </header>
    <div class="row g-3">
      <?php foreach ([
          ['bi-backpack', 'طالب جامعي', 'واجبات، تقارير، عروض، وشرح مواد بأسلوب مبسط.', 'sky'],
          ['bi-mortarboard', 'طالب تخرج', 'مشروع التخرج من الفكرة والمقترح حتى العرض النهائي.', 'gold'],
          ['bi-journal-bookmark', 'باحث دراسات عليا', 'منهجية، تحليل إحصائي، تدقيق وتوثيق علمي.', 'violet'],
          ['bi-briefcase', 'خريج وباحث عن عمل', 'سيرة ذاتية، LinkedIn، وتجهيز للمقابلات.', 'emerald'],
      ] as [$ic, $t, $d, $tone]): ?>
        <div class="col-6 col-lg-3 reveal">
          <article class="audience-card tone-<?= $tone ?>"><span class="need-icon"><i class="bi <?= $ic ?>"></i></span><h3><?= e($t) ?></h3><p><?= e($d) ?></p></article>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php endif; ?>

<?php if ($popular && section_on('home_popular')): ?>
<section id="popular-section" class="section">
  <div class="container">
    <header class="section-head d-md-flex justify-content-between align-items-end text-md-start">
      <div class="text-center text-md-end">
        <span class="section-kicker">الأكثر طلبًا</span>
        <h2 class="section-title mb-md-0">خدمات يطلبها الطلاب باستمرار</h2>
      </div>
      <a class="btn btn-outline-navy d-none d-md-inline-flex" href="<?= e(route('services')) ?>">جميع الخدمات <i class="bi bi-arrow-left"></i></a>
    </header>
    <div class="row g-4 scroller-sm">
      <?php foreach ($popular as $s): ?>
        <div class="col-sm-6 col-lg-3 reveal"><?= render_service_card($s) ?></div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4 d-md-none"><a class="btn btn-outline-navy" href="<?= e(route('services')) ?>">جميع الخدمات <i class="bi bi-arrow-left"></i></a></div>
  </div>
</section>
<?php endif; ?>

<?= render_testimonials_section($homeReviews, $reviewStats) ?>

<?php if ($homeFaqs && section_on('home_faq')): ?>
<section id="faq-section" class="section section-alt">
  <div class="container">
    <div class="row g-5">
      <div class="col-lg-4">
        <span class="section-kicker">الأسئلة الشائعة</span>
        <h2 class="section-title">إجابات سريعة لأسئلتك</h2>
        <p class="text-muted">لم تجد إجابتك؟ راسلنا مباشرة وسنرد عليك في أقرب وقت.</p>
        <a class="btn btn-whatsapp" href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اسألنا عبر واتساب</a>
        <a class="btn btn-link" href="<?= e(route('faq')) ?>">كل الأسئلة</a>
      </div>
      <div class="col-lg-8"><?= render_faq_accordion($homeFaqs, 'home-faq') ?></div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($homeArticles): ?>
<section id="articles-section" class="section">
  <div class="container">
    <header class="section-head d-md-flex justify-content-between align-items-end text-md-start">
      <div class="text-center text-md-end">
        <span class="section-kicker">المدونة</span>
        <h2 class="section-title mb-md-0">أحدث المقالات والنصائح</h2>
      </div>
      <a class="btn btn-outline-navy d-none d-md-inline-flex" href="<?= e(route('blog')) ?>">كل المقالات <i class="bi bi-arrow-left"></i></a>
    </header>
    <div class="row g-4">
      <?php foreach ($homeArticles as $p): ?><div class="col-md-4 reveal"><?= render_post_card($p) ?></div><?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (section_on('home_cta')): ?>
<section id="cta-section" class="cta">
  <div class="container">
    <div class="cta-inner">
      <div>
        <h2><?= e(setting('cta_title')) ?></h2>
        <p><?= e(setting('cta_text')) ?></p>
      </div>
      <div class="cta-actions">
        <a class="btn btn-gold btn-lg" href="<?= e(wa_service_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب عبر واتساب</a>
        <a class="btn btn-outline-light btn-lg" href="<?= e(route('order')) ?>">نموذج الطلب</a>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php require ROOT_PATH . '/includes/footer.php'; ?>
