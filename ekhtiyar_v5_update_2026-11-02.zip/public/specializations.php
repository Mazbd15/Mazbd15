<?php
/** صفحة التخصصات: شجرة كاملة للأقسام وتخصصاتها */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$tree = catalog_tree();
$active_nav = 'specializations';
$page_title = 'التخصصات';
$page_description = 'دليل التخصصات في منصة اختيارك: البحوث، المشاريع، الهندسة المعمارية والمدنية والصناعية والميكانيكية والكهربائية، البرمجة، التصميم وغيرها.';
$breadcrumbs = [['التخصصات', null]];
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container">
    <h1>دليل التخصصات</h1>
    <p>اختر مجالك ثم تخصصك للوصول إلى الخدمات المرتبطة به مباشرة.</p>
    <div class="mt-3 mx-auto" style="max-width:640px"><?= render_search_box('', 'md', 'spec-search') ?></div>
  </div>
</section>
<section class="section pt-4">
  <div class="container">
    <nav class="spec-jump" aria-label="انتقال سريع">
      <?php foreach ($tree as $c): ?><a href="#cat-<?= e($c['slug']) ?>"><?= icon($c['icon']) ?> <?= e($c['name']) ?></a><?php endforeach; ?>
    </nav>
    <?php foreach ($tree as $c): ?>
      <section class="spec-block" id="cat-<?= e($c['slug']) ?>" aria-labelledby="spec-<?= (int) $c['id'] ?>">
        <header class="spec-head">
          <span class="category-icon sm"><?= icon($c['icon']) ?></span>
          <h2 id="spec-<?= (int) $c['id'] ?>"><a href="<?= e(route('category', ['slug' => $c['slug']])) ?>"><?= e($c['name']) ?></a></h2>
          <span class="badge rounded-pill text-bg-light"><?= count($c['services']) ?> خدمة</span>
        </header>
        <div class="row g-3">
          <?php foreach ($c['subs'] as $s): ?>
            <div class="col-md-6 col-lg-4">
              <a class="spec-card" href="<?= e(route('category', ['slug' => $c['slug'], 'sub' => $s['slug']])) ?>">
                <strong><?= e($s['name']) ?></strong>
                <span><?= count($s['services']) ?> خدمة</span>
                <small><?= e(implode(' • ', array_slice(array_column($s['services'], 'name'), 0, 3))) ?><?= count($s['services']) > 3 ? ' …' : '' ?></small>
              </a>
            </div>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endforeach; ?>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
