<?php
/**
 * تنزيل/عرض آمن لملفات معرض الأعمال (PDF/Word/PowerPoint...).
 * الملفات محفوظة خارج المجلد العام ولا يمكن الوصول إليها مباشرة.
 * - الزائر: فقط ملفات الأعمال المنشورة المعلّمة «قابلة للتنزيل» وعند تفعيل الخيار من الإعدادات.
 * - فريق العمل: يمكنه المعاينة دائمًا (لمراجعة المسودات).
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$f = db_one('SELECT f.*, p.is_active AS item_active, p.category_id, p.title FROM portfolio_files f JOIN portfolio_items p ON p.id = f.item_id WHERE f.id = ? AND f.kind = "document"', [(int) ($_GET['id'] ?? 0)]);
if (!$f) not_found();

$staff = current_admin();
$public = portfolio_enabled() && (int) $f['item_active'] === 1 && (int) $f['is_downloadable'] === 1 && setting('portfolio_allow_downloads', '1') === '1';
if (!$public && !$staff) not_found();

if (!preg_match('/^[0-9]{8}_[a-f0-9]{32}\.([a-z0-9]+)$/', (string) $f['file_path'], $m)) not_found();
$ext = $m[1];
$base = realpath(portfolio_storage_dir());
$path = realpath(portfolio_storage_dir() . '/' . $f['file_path']);
if (!$base || !$path || !str_starts_with($path, $base . DIRECTORY_SEPARATOR) || !is_file($path)) not_found();

if ($public && !$staff && empty($_SESSION['_pdl'][$f['id']])) {
    $_SESSION['_pdl'][$f['id']] = 1;
    db_exec('UPDATE portfolio_files SET downloads = downloads + 1 WHERE id = ?', [$f['id']]);
}

$name = $f['original_name'] ?: ('work-' . $f['id'] . '.' . $ext);
$ascii = preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
// PDF يمكن عرضه داخل المتصفح بأمان (sandbox)، وباقي الأنواع تُنزّل
$inline = $ext === 'pdf' && ($_GET['view'] ?? '') === '1';
while (ob_get_level()) ob_end_clean();
header('Content-Type: ' . ($inline ? 'application/pdf' : 'application/octet-stream'));
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($name));
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex');
header('Cache-Control: private, max-age=3600');
header("Content-Security-Policy: default-src 'none'; plugin-types application/pdf; sandbox");
readfile($path);
exit;
