<?php
/**
 * المقالات والصفحات (v5) — نفس الملف يخدم posts.php (مقالات) و pages.php (صفحات ثابتة).
 * - مسودة/منشور، صورة غلاف (WebP)، رابط مخصص، SEO لكل عنصر، إظهار الصفحة في التذييل.
 * - المحتوى يُنظف بقائمة بيضاء عند العرض والحفظ (safe_html) لمنع XSS.
 */
declare(strict_types=1);
require_once dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('editor');
$type = (defined('POSTS_TYPE') ? POSTS_TYPE : 'article') === 'page' ? 'page' : 'article';
$key = $type === 'page' ? 'pages' : 'posts';
$label = $type === 'page' ? 'الصفحات' : 'المقالات';
$one = $type === 'page' ? 'صفحة' : 'مقال';
require_v5($label, $key, $user);

$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);
$errors = [];
$back = admin_url($key);
$cats = db_all('SELECT id, name FROM categories WHERE 1=1' . sd('categories') . ' ORDER BY sort_order');

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    $row = $id ? db_one('SELECT * FROM posts WHERE id = ? AND type = ? AND deleted_at IS NULL', [$id, $type]) : null;
    if ($id && !$row) { flash('danger', 'العنصر غير موجود.'); redirect($back); }
    if ($action === 'toggle' && $row) {
        $pub = $row['status'] === 'published' ? 'draft' : 'published';
        db_exec('UPDATE posts SET status = ?, published_at = COALESCE(published_at, ?) WHERE id = ?', [$pub, $pub === 'published' ? date('Y-m-d H:i:s') : null, $id]);
        audit($pub === 'published' ? 'publish' : 'unpublish', 'post', $id, $row['title']);
        redirect($back);
    }
    if ($action === 'move' && $row) { move_item('posts', $id, ($_POST['dir'] ?? '') === 'up' ? 'up' : 'down', 'type'); redirect($back); }
    if ($action === 'delete' && $row) {
        soft_delete('posts', $id);
        audit('trash', 'post', $id, $row['title']);
        flash('success', 'نُقل إلى سلة المحذوفات.');
        redirect($back);
    }
    if ($action === 'save') {
        $title = mb_substr(trim((string) ($_POST['title'] ?? '')), 0, 200);
        $slugIn = trim((string) ($_POST['slug'] ?? ''));
        $data = [
            'type' => $type, 'title' => $title,
            'slug' => slugify($slugIn !== '' ? $slugIn : $title),
            'excerpt' => mb_substr(trim((string) ($_POST['excerpt'] ?? '')), 0, 400) ?: null,
            'body' => safe_html(text_to_html((string) ($_POST['body'] ?? ''))),
            'category_id' => $type === 'article' ? ((int) ($_POST['category_id'] ?? 0) ?: null) : null,
            'status' => ($_POST['status'] ?? '') === 'published' ? 'published' : 'draft',
            'show_in_footer' => $type === 'page' && !empty($_POST['show_in_footer']) ? 1 : 0,
            'meta_title' => mb_substr(trim((string) ($_POST['meta_title'] ?? '')), 0, 190) ?: null,
            'meta_description' => mb_substr(trim((string) ($_POST['meta_description'] ?? '')), 0, 300) ?: null,
        ];
        $pubAt = trim((string) ($_POST['published_at'] ?? ''));
        $data['published_at'] = $pubAt !== '' && strtotime($pubAt) ? date('Y-m-d H:i:s', strtotime($pubAt)) : ($row['published_at'] ?? ($data['status'] === 'published' ? date('Y-m-d H:i:s') : null));
        if ($title === '') $errors[] = 'العنوان مطلوب.';
        if (mb_strlen(strip_tags($data['body'])) < 20) $errors[] = 'المحتوى قصير جدًا.';
        if (in_array($data['slug'], ['admin', 'api', 'assets'], true)) $errors[] = 'الرابط المختصر محجوز.';
        if (db_value('SELECT id FROM posts WHERE type = ? AND slug = ? AND id <> ?', [$type, $data['slug'], $id])) $errors[] = 'الرابط المختصر مستخدم لعنصر آخر (ربما في سلة المحذوفات).';
        $newCover = null;
        if (!$errors && !empty($_FILES['cover_image']['name'])) {
            [$ok, $res] = store_public_image($_FILES['cover_image'], 'posts');
            if ($ok) $newCover = $res; else $errors[] = $res;
        }
        if (!$errors) {
            if ($newCover) { if ($row && $row['cover_image']) delete_public_image($row['cover_image']); $data['cover_image'] = $newCover; }
            elseif (!empty($_POST['remove_cover']) && $row && $row['cover_image']) { delete_public_image($row['cover_image']); $data['cover_image'] = null; }
            if ($row) { db_update('posts', $data, $id); audit('update', 'post', $id, $title); }
            else {
                $data['author_id'] = $user['id'];
                $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM posts WHERE type = ?', [$type]);
                $id = db_insert('posts', $data);
                audit('create', 'post', $id, $title);
            }
            flash('success', 'تم الحفظ.' . ($data['status'] === 'draft' ? ' (مسودة — غير ظاهرة للزوار)' : ''));
            redirect(admin_url($key, ['edit' => $id]));
        }
        $editId = $id; $isNew = !$id; $formData = $data + ($row ?? []);
    }
}

admin_header($label, $key, $user);
if ($editId || $isNew):
    $p = $formData ?? ($editId ? db_one('SELECT * FROM posts WHERE id = ? AND type = ? AND deleted_at IS NULL', [$editId, $type]) : null)
        ?? ['title' => '', 'slug' => '', 'excerpt' => '', 'body' => '', 'category_id' => null, 'status' => 'draft', 'show_in_footer' => 0, 'meta_title' => '', 'meta_description' => '', 'cover_image' => null, 'published_at' => null];
    if ($editId && !$p) { echo '<div class="alert alert-danger">العنصر غير موجود.</div>'; admin_footer(); exit; }
    $viewUrl = !empty($p['slug']) ? route($type === 'page' ? 'page' : 'article', ['slug' => $p['slug']]) : null;
?>
  <a class="btn btn-link px-0 mb-2" href="<?= e($back) ?>"><i class="bi bi-arrow-right"></i> <?= e($label) ?></a>
  <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
    <div class="row g-3">
      <div class="col-lg-8">
        <div class="panel">
          <label class="form-label">العنوان *</label><input class="form-control form-control-lg mb-3" name="title" value="<?= e($p['title']) ?>" required maxlength="200">
          <label class="form-label">الرابط المختصر</label>
          <div class="input-group mb-3"><span class="input-group-text small mono"><?= e($type === 'page' ? '/page/' : '/blog/') ?></span><input class="form-control" name="slug" value="<?= e($p['slug']) ?>" placeholder="يُنشأ تلقائيًا من العنوان"></div>
          <label class="form-label">مقتطف قصير</label><textarea class="form-control mb-3" name="excerpt" rows="2" maxlength="400"><?= e($p['excerpt'] ?? '') ?></textarea>
          <label class="form-label">المحتوى *</label>
          <textarea class="form-control" name="body" rows="18" required dir="rtl"><?= e($p['body'] ?? '') ?></textarea>
          <div class="form-text">اكتب نصًا عاديًا (سطر فارغ = فقرة جديدة) أو HTML بسيط: &lt;h2&gt; &lt;h3&gt; &lt;p&gt; &lt;strong&gt; &lt;ul&gt;&lt;li&gt; &lt;a href&gt; &lt;img src&gt; &lt;table&gt;. أي سكربتات أو أكواد خطرة تُحذف تلقائيًا.</div>
        </div>
        <div class="panel">
          <h2 class="panel-title">محركات البحث</h2>
          <label class="form-label small">عنوان SEO (اختياري)</label><input class="form-control mb-2" name="meta_title" maxlength="190" value="<?= e($p['meta_title'] ?? '') ?>">
          <label class="form-label small">وصف SEO (اختياري — 120 إلى 160 حرفًا)</label><textarea class="form-control" name="meta_description" rows="2" maxlength="300"><?= e($p['meta_description'] ?? '') ?></textarea>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="panel">
          <label class="form-label">الحالة</label>
          <select class="form-select mb-2" name="status"><option value="draft"<?= selected($p['status'], 'draft') ?>>مسودة</option><option value="published"<?= selected($p['status'], 'published') ?>>منشور</option></select>
          <label class="form-label small">تاريخ النشر</label><input type="datetime-local" class="form-control mb-2" name="published_at" value="<?= $p['published_at'] ? e(date('Y-m-d\TH:i', strtotime($p['published_at']))) : '' ?>">
          <?php if ($type === 'article'): ?>
            <label class="form-label small">القسم المرتبط (اختياري)</label>
            <select class="form-select mb-2" name="category_id"><option value="">— عام —</option><?php foreach ($cats as $c): ?><option value="<?= (int) $c['id'] ?>"<?= selected((string) ($p['category_id'] ?? ''), (string) $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
          <?php else: ?>
            <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="show_in_footer" value="1" id="sif"<?= !empty($p['show_in_footer']) ? ' checked' : '' ?>><label class="form-check-label" for="sif">إظهار رابطها في تذييل الموقع</label></div>
          <?php endif; ?>
          <button class="btn btn-primary w-100"><i class="bi bi-check2-circle"></i> حفظ</button>
          <?php if ($viewUrl && $p['status'] === 'published'): ?><a class="btn btn-outline-secondary w-100 mt-2" href="<?= e($viewUrl) ?>" target="_blank">عرض في الموقع <i class="bi bi-box-arrow-up-left"></i></a><?php endif; ?>
        </div>
        <div class="panel">
          <h2 class="panel-title">صورة الغلاف</h2>
          <?php if (!empty($p['cover_image'])): ?><img src="<?= e(media_url($p['cover_image'], true)) ?>" alt="" class="img-fluid rounded mb-2"><div class="form-check small mb-2"><input class="form-check-input" type="checkbox" name="remove_cover" value="1" id="rmc"><label class="form-check-label" for="rmc">إزالة الصورة</label></div><?php endif; ?>
          <input type="file" class="form-control" name="cover_image" accept="image/jpeg,image/png,image/webp" data-img-preview="cover-prev">
          <div id="cover-prev" class="mt-2"></div>
          <div class="form-text">1200×630 مفضّل — تُحوّل إلى WebP تلقائيًا.</div>
        </div>
      </div>
    </div>
  </form>
<?php else:
    $q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 80);
    $w = 'p.type = ? AND p.deleted_at IS NULL'; $prm = [$type];
    if ($q !== '') { $w .= ' AND p.title LIKE ?'; $prm[] = "%$q%"; }
    $rows = db_all("SELECT p.*, c.name cat, u.name author FROM posts p LEFT JOIN categories c ON c.id = p.category_id LEFT JOIN users u ON u.id = p.author_id WHERE $w ORDER BY " . ($type === 'page' ? 'p.sort_order, p.id' : 'COALESCE(p.published_at, p.created_at) DESC') . ' LIMIT 300', $prm);
?>
  <div class="panel">
    <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
      <form class="d-flex gap-1"><input class="form-control form-control-sm" name="q" value="<?= e($q) ?>" placeholder="بحث بالعنوان"><button class="btn btn-sm btn-light"><i class="bi bi-search"></i></button></form>
      <?php if ($type === 'article' && setting('articles_enabled', '1') !== '1'): ?><span class="badge bg-warning text-dark">المدونة معطلة في الإعدادات</span><?php endif; ?>
      <a class="btn btn-primary btn-sm ms-auto" href="<?= e(admin_url($key, ['new' => 1])) ?>"><i class="bi bi-plus-lg"></i> <?= e($one) ?> جديد<?= $type === 'page' ? 'ة' : '' ?></a>
    </div>
    <?php if (!$rows): ?><div class="text-center text-muted py-4"><i class="bi bi-newspaper fs-1 d-block mb-2"></i>لا توجد <?= e($label) ?> بعد.</div><?php endif; ?>
    <div class="table-responsive"><table class="table align-middle">
      <?php foreach ($rows as $r): ?>
        <tr>
          <td style="width:70px"><img src="<?= e(media_url($r['cover_image'], true)) ?>" alt="" width="64" height="40" style="object-fit:cover" class="rounded" loading="lazy"></td>
          <td><strong><?= e($r['title']) ?></strong> <?= $r['status'] === 'published' ? '<span class="badge bg-success">منشور</span>' : '<span class="badge bg-secondary">مسودة</span>' ?><?php if ($r['show_in_footer']): ?> <span class="badge bg-light text-dark border">في التذييل</span><?php endif; ?>
            <div class="small text-muted mono"><?= e(($type === 'page' ? '/page/' : '/blog/') . $r['slug']) ?></div>
            <div class="small text-muted"><?= e($r['cat'] ?? '') ?> <?= e(ar_date($r['published_at'] ?? $r['created_at'])) ?> · <?= (int) $r['views'] ?> مشاهدة · <?= e($r['author'] ?? '') ?></div></td>
          <td class="text-end text-nowrap">
            <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-outline-<?= $r['status'] === 'published' ? 'secondary' : 'success' ?>" title="<?= $r['status'] === 'published' ? 'إلغاء النشر' : 'نشر' ?>"><i class="bi <?= $r['status'] === 'published' ? 'bi-eye-slash' : 'bi-send' ?>"></i></button></form>
            <?php if ($type === 'page'): ?><?= move_buttons((int) $r['id']) ?><?php endif; ?>
            <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url($key, ['edit' => $r['id']])) ?>"><i class="bi bi-pencil"></i></a>
            <?= delete_button('delete', (int) $r['id'], 'نقل إلى سلة المحذوفات؟') ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table></div>
  </div>
<?php endif;
admin_footer();
