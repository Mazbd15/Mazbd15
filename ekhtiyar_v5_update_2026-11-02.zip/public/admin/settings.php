<?php
/** الإعدادات: بيانات التواصل/واتساب، محتوى الرئيسية والتذييل، الألوان، الشعار */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('admin');

$groups = [
    'general'   => ['bi-sliders', 'عام', 'اسم المنصة والشعار ووضع الصيانة والتسجيل.'],
    'contact'   => ['bi-whatsapp', 'التواصل والحسابات', 'رقم واتساب والبريد وروابط الحسابات الاجتماعية (تظهر أيضًا لمحركات البحث).'],
    'home'      => ['bi-house', 'محتوى الرئيسية', 'نصوص الواجهة ودعوة الإجراء وشريط الإعلان وصفحة من نحن.'],
    'sections'  => ['bi-toggles', 'أقسام الموقع', 'إظهار/إخفاء أقسام الصفحة الرئيسية وعناصر التنقل.'],
    'portfolio' => ['bi-collection', 'معرض الأعمال', 'نصوص قسم الأعمال والسماح بتنزيل الملفات.'],
    'seo'       => ['bi-graph-up-arrow', 'محركات البحث SEO', 'العناوين والكلمات المفتاحية وصورة المشاركة والتحقق من Google وBing والتحليلات.'],
    'theme'     => ['bi-palette', 'المظهر والألوان', 'الألوان والخط والوضع الداكن وأيقونة المتصفح.'],
    'footer'    => ['bi-layout-text-window-reverse', 'التذييل', 'نبذة وملاحظة أسفل الموقع.'],
    'testimonials' => ['bi-chat-quote', 'آراء العملاء', 'عرض الآراء في الرئيسية واستقبالها من العملاء (الإدارة التفصيلية من صفحة آراء العملاء).'],
    'advanced'  => ['bi-hdd-stack', 'متقدم', 'النسخ الاحتياطي التلقائي وتفعيل المدونة.'],
];
$selectOptions = [
    'default_theme' => ['auto' => 'تلقائي حسب جهاز الزائر', 'light' => 'فاتح', 'dark' => 'داكن'],
    'font_family'   => array_combine(array_keys(font_choices()), array_keys(font_choices())),
    'testimonials_layout' => ['slider' => 'سلايدر متحرك', 'grid' => 'شبكة بطاقات'],
];
$imageFolders = ['logo_path' => 'branding', 'favicon_path' => 'branding', 'og_image_path' => 'branding'];
$imageHints = ['logo_path' => 'PNG/JPG/WEBP مربع (512×512 مفضّل). اتركه فارغًا لاستخدام الشعار الافتراضي.', 'favicon_path' => 'PNG مربع 512×512 — يظهر في تبويب المتصفح وعند الحفظ على شاشة الجوال.', 'og_image_path' => 'JPG/PNG بمقاس 1200×630 — تظهر عند مشاركة رابط الموقع في واتساب وتويتر وغيرها.'];
$tab = isset($groups[$_GET['tab'] ?? '']) ? $_GET['tab'] : 'general';
$rows = db_all('SELECT * FROM site_settings ORDER BY setting_group, sort_order');
$byGroup = [];
foreach ($rows as $r) $byGroup[$r['setting_group']][] = $r;
foreach (array_keys($groups) as $g) if (empty($byGroup[$g])) unset($groups[$g]);

if (is_post()) {
    require_csrf();
    $tab = isset($groups[$_POST['tab'] ?? '']) ? $_POST['tab'] : 'general';
    $changed = [];
    $errors = [];
    foreach ($byGroup[$tab] ?? [] as $s) {
        $k = $s['setting_key'];
        $type = $s['input_type'];
        if ($type === 'image') {
            if (!empty($_POST['remove_' . $k])) { delete_public_image($s['setting_value']); $val = ''; }
            elseif (!empty($_FILES[$k]['name'])) {
                [$ok, $res] = store_public_image($_FILES[$k], $imageFolders[$k] ?? 'branding');
                if (!$ok) { $errors[] = $s['label'] . ': ' . $res; continue; }
                delete_public_image($s['setting_value']);
                $val = $res;
            } else continue;
        } elseif ($type === 'bool') {
            $val = !empty($_POST[$k]) ? '1' : '0';
        } elseif ($type === 'select') {
            $val = (string) ($_POST[$k] ?? '');
            if (!isset($selectOptions[$k][$val])) continue;
        } else {
            $val = mb_substr(trim((string) ($_POST[$k] ?? '')), 0, $type === 'textarea' ? 5000 : 500);
            if ($val !== '') {
                if ($type === 'email' && !filter_var($val, FILTER_VALIDATE_EMAIL)) { $errors[] = $s['label'] . ': بريد غير صالح.'; continue; }
                if ($type === 'url' && (!filter_var($val, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $val))) { $errors[] = $s['label'] . ': رابط غير صالح (يجب أن يبدأ بـ https://).'; continue; }
                if ($type === 'color' && !preg_match('/^#[0-9a-f]{6}$/i', $val)) { $errors[] = $s['label'] . ': لون غير صالح.'; continue; }
                if ($type === 'number') $val = (string) max(1, min(100, (int) $val));
                if ($k === 'ga4_id' && !preg_match('/^G-[A-Z0-9]{4,15}$/', strtoupper($val))) { $errors[] = 'معرّف Google Analytics يجب أن يكون بصيغة G-XXXXXXX.'; continue; }
                if ($k === 'ga4_id') $val = strtoupper($val);
                if (in_array($k, ['google_verification', 'bing_verification'], true)) {
                    // يقبل لصق وسم meta كاملًا ويستخرج قيمة content فقط
                    if (preg_match('/content=["\']([^"\']+)["\']/i', $val, $mm)) $val = $mm[1];
                    $val = preg_replace('/[^A-Za-z0-9_\-]/', '', $val);
                }
            }
            if ($k === 'whatsapp_number') {
                $val = preg_replace('/\D+/', '', $val);
                if (strlen($val) < 9 || strlen($val) > 15) { $errors[] = 'رقم واتساب غير صالح. اكتبه بالصيغة الدولية بدون + مثل 966575996163.'; continue; }
            }
        }
        if ((string) $s['setting_value'] !== $val) {
            db_exec('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', [$val, $k]);
            $changed[] = $k;
        }
    }
    if ($changed) audit('settings', 'settings', null, implode(', ', $changed));
    foreach ($errors as $er) flash('danger', $er);
    flash($changed ? 'success' : 'info', $changed ? 'تم حفظ الإعدادات.' : 'لم تتغير أي قيمة.');
    redirect(admin_url('settings', ['tab' => $tab]));
}

admin_header('الإعدادات والمحتوى', 'settings', $user);
?>
<ul class="nav nav-tabs mb-3 flex-nowrap overflow-auto">
  <?php foreach ($groups as $k => [$ic, $l, $hint]): ?><li class="nav-item"><a class="nav-link text-nowrap<?= $tab === $k ? ' active' : '' ?>" href="<?= e(admin_url('settings', ['tab' => $k])) ?>"><i class="bi <?= $ic ?>"></i> <?= $l ?></a></li><?php endforeach; ?>
</ul>
<p class="text-muted small mb-3"><i class="bi bi-info-circle"></i> <?= e($groups[$tab][2] ?? '') ?></p>
<?php if ($tab === 'seo'): ?><div class="alert alert-info small"><i class="bi bi-graph-up-arrow"></i> لفحص جاهزية موقعك لمحركات البحث واقتراحات التحسين افتح <a href="<?= e(admin_url('seo')) ?>">أداة فحص SEO</a>.</div><?php endif; ?>
<form class="panel" method="post" enctype="multipart/form-data">
  <?= csrf_field() ?><input type="hidden" name="tab" value="<?= e($tab) ?>">
  <div class="row g-3">
  <?php foreach ($byGroup[$tab] ?? [] as $s): $k = $s['setting_key']; $v = (string) $s['setting_value']; ?>
    <div class="<?= $s['input_type'] === 'textarea' ? 'col-12' : 'col-md-6' ?>">
      <?php if ($s['input_type'] === 'bool'): ?>
        <label class="form-check form-switch mt-2"><input class="form-check-input" type="checkbox" name="<?= e($k) ?>" value="1"<?= checked($v === '1') ?>> <?= e($s['label']) ?></label>
        <?php if ($k === 'save_requests'): ?><div class="form-text">عند التفعيل يظهر للعميل خيار اختياري للموافقة على حفظ طلبه ومرفقاته. عند التعطيل تُرسل الطلبات عبر واتساب فقط دون أي حفظ.</div><?php endif; ?>
      <?php elseif ($s['input_type'] === 'textarea'): ?>
        <label class="form-label" for="s-<?= e($k) ?>"><?= e($s['label']) ?></label>
        <textarea class="form-control" id="s-<?= e($k) ?>" name="<?= e($k) ?>" rows="4"><?= e($v) ?></textarea>
      <?php elseif ($s['input_type'] === 'image'): ?>
        <label class="form-label"><?= e($s['label']) ?></label>
        <input class="form-control" type="file" name="<?= e($k) ?>" accept=".png,.jpg,.jpeg,.webp">
        <div class="form-text"><?= e($imageHints[$k] ?? 'PNG/JPG/WEBP حتى 3MB.') ?></div>
        <?php if ($v): ?><div class="mt-2 d-flex align-items-center gap-2"><img src="<?= e(url($v)) ?>" height="48" alt="" class="rounded border"><label class="small"><input type="checkbox" name="remove_<?= e($k) ?>" value="1"> إزالة والعودة للافتراضي</label></div><?php endif; ?>
      <?php elseif ($s['input_type'] === 'select'): ?>
        <label class="form-label" for="s-<?= e($k) ?>"><?= e($s['label']) ?></label>
        <select class="form-select" id="s-<?= e($k) ?>" name="<?= e($k) ?>"><?php foreach ($selectOptions[$k] ?? [] as $ov => $ol): ?><option value="<?= e($ov) ?>"<?= selected($v, $ov) ?><?= $k === 'font_family' ? ' style="font-family:\'' . e($ov) . '\'"' : '' ?>><?= e($ol) ?></option><?php endforeach; ?></select>
      <?php elseif ($s['input_type'] === 'color'): ?>
        <label class="form-label" for="s-<?= e($k) ?>"><?= e($s['label']) ?></label>
        <input class="form-control form-control-color w-100" type="color" id="s-<?= e($k) ?>" name="<?= e($k) ?>" value="<?= e($v ?: '#000000') ?>">
      <?php else: ?>
        <label class="form-label" for="s-<?= e($k) ?>"><?= e($s['label']) ?></label>
        <input class="form-control" id="s-<?= e($k) ?>" type="<?= in_array($s['input_type'], ['email', 'url', 'number'], true) ? $s['input_type'] : 'text' ?>" name="<?= e($k) ?>" value="<?= e($v) ?>"<?= in_array($s['input_type'], ['email', 'url'], true) || $k === 'whatsapp_number' ? ' dir="ltr"' : '' ?>>
        <?php if ($k === 'whatsapp_number'): ?><div class="form-text">صيغة دولية بدون + أو 00، مثال: 966575996163. يُستخدم في جميع أزرار واتساب.</div><?php endif; ?>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
  </div>
  <?php if ($tab === 'contact'): ?>
    <div class="alert alert-light border mt-3 mb-0 small">رابط الاختبار الحالي: <a href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener" dir="ltr"><?= e('https://wa.me/' . whatsapp_number()) ?></a></div>
  <?php endif; ?>
  <div class="mt-4"><button class="btn btn-primary"><i class="bi bi-check2"></i> حفظ الإعدادات</button></div>
</form>
<?php admin_footer();
