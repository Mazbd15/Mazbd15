<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$cats = scoped_categories($user);
$catMap = array_column($cats, 'name', 'id');
$filterCat = (int) ($_GET['category'] ?? 0);
$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);
$errors = [];
$back = admin_url('subcategories', $filterCat ? ['category' => $filterCat] : []);

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    if ($id) {
        $own = db_value('SELECT category_id FROM subcategories WHERE id = ?', [$id]);
        if ($own === null || $own === false || !can_manage_category($user, (int) $own)) deny_scope($back);
    }
    if ($action === 'move') { move_item('subcategories', $id, $_POST['dir'] === 'up' ? 'up' : 'down', 'category_id'); redirect($back); }
    if ($action === 'toggle') { db_exec('UPDATE subcategories SET is_active = 1 - is_active WHERE id = ?', [$id]); audit('toggle', 'subcategory', $id); redirect($back); }
    if ($action === 'delete') {
        if (!can($user, 'subcategories.delete')) { flash('danger', 'الحذف يتطلب صلاحية مسؤول.'); redirect($back); }
        $row = db_one('SELECT * FROM subcategories WHERE id = ?', [$id]);
        if ($row) {
            $n = (int) db_value('SELECT COUNT(*) FROM services WHERE subcategory_id = ?' . sd('services'), [$id]);
            $kids = has_col('subcategories', 'parent_id') ? (int) db_value('SELECT COUNT(*) FROM subcategories WHERE parent_id = ?' . sd('subcategories'), [$id]) : 0;
            if ($n > 0 || $kids > 0) {
                flash('warning', "لا يمكن حذف «{$row['name']}» لأنه يحتوي على $n خدمة و$kids تخصص فرعي. انقلها إلى تخصص آخر أولًا أو عطّله.");
            } elseif (soft_delete('subcategories', $id)) {
                audit('trash', 'subcategory', $id, $row['name']);
                flash('success', 'نُقل التخصص إلى سلة المحذوفات.');
            } else {
                flash('warning', 'سلة المحذوفات تحتاج تحديث قاعدة البيانات أولًا — لم يُحذف شيء.');
            }
        }
        redirect($back);
    }
    if ($action === 'save') {
        $data = [
            'category_id' => (int) ($_POST['category_id'] ?? 0),
            'name'        => mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 160),
            'slug'        => trim((string) ($_POST['slug'] ?? '')),
            'icon'        => preg_replace('/[^a-z0-9\-]/', '', (string) ($_POST['icon'] ?? '')) ?: 'bi-folder2-open',
            'description' => trim((string) ($_POST['description'] ?? '')) ?: null,
            'is_active'   => !empty($_POST['is_active']) ? 1 : 0,
        ];
        $v5sub = has_col('subcategories', 'parent_id');
        if ($v5sub) {
            $data['parent_id'] = (int) ($_POST['parent_id'] ?? 0) ?: null;
            $data['meta_title'] = mb_substr(trim((string) ($_POST['meta_title'] ?? '')), 0, 190) ?: null;
            $data['meta_description'] = mb_substr(trim((string) ($_POST['meta_description'] ?? '')), 0, 300) ?: null;
            if ($data['parent_id']) {
                $par = db_one('SELECT id, category_id, parent_id FROM subcategories WHERE id = ?' . sd('subcategories'), [$data['parent_id']]);
                if (!$par || (int) $par['category_id'] !== $data['category_id']) $errors[] = 'التخصص الأب يجب أن يكون في نفس القسم الرئيسي.';
                // منع الحلقات: لا يكون الأب هو العنصر نفسه أو أحد فروعه
                $walk = $par; $guard = 0;
                while ($walk && $guard++ < 20) {
                    if ($id && (int) $walk['id'] === $id) { $errors[] = 'لا يمكن جعل التخصص تابعًا لنفسه أو لأحد فروعه.'; break; }
                    $walk = $walk['parent_id'] ? db_one('SELECT id, parent_id FROM subcategories WHERE id = ?', [$walk['parent_id']]) : null;
                }
            }
        }
        if ($data['name'] === '') $errors[] = 'الاسم مطلوب.';
        if (!isset($catMap[$data['category_id']])) $errors[] = 'اختر القسم الرئيسي.';
        $oldRow = $id ? db_one('SELECT * FROM subcategories WHERE id = ?', [$id]) : null;
        if (!$errors && $v5sub && !empty($_FILES['image']['name'])) {
            [$ok, $res] = store_public_image($_FILES['image'], 'subcategories');
            if ($ok) $data['image'] = $res; else $errors[] = $res;
        }
        if (!$errors && $v5sub) {
            if (!empty($data['image']) && $oldRow && $oldRow['image']) delete_public_image($oldRow['image']);
            elseif (empty($data['image']) && !empty($_POST['remove_image']) && $oldRow && $oldRow['image']) { delete_public_image($oldRow['image']); $data['image'] = null; }
        }
        if (!$errors) {
            $data['slug'] = unique_slug('subcategories', slugify($data['slug'] ?: $data['name']), $id ?: null, 'category_id', $data['category_id']);
            if ($id) {
                $old = db_one('SELECT category_id FROM subcategories WHERE id = ?', [$id]);
                db_update('subcategories', $data, $id);
                // عند نقل التخصص لقسم آخر ننقل خدماته معه للحفاظ على تناسق البيانات
                if ($old && (int) $old['category_id'] !== $data['category_id']) {
                    db_exec('UPDATE services SET category_id = ? WHERE subcategory_id = ?', [$data['category_id'], $id]);
                    // الفروع التابعة تنتقل مع أبيها
                    if ($v5sub) db_exec('UPDATE subcategories SET category_id = ? WHERE parent_id = ?', [$data['category_id'], $id]);
                }
                audit('update', 'subcategory', $id, $data['name']);
            } else {
                $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM subcategories WHERE category_id = ?', [$data['category_id']]);
                $id = db_insert('subcategories', $data);
                audit('create', 'subcategory', $id, $data['name']);
            }
            flash('success', 'تم الحفظ بنجاح.');
            redirect(admin_url('subcategories', ['category' => $data['category_id']]));
        }
        if (!empty($data['image']) && $errors) delete_public_image($data['image']);
        $editId = $id; $isNew = !$id; $formData = $data + ['image' => $oldRow['image'] ?? null];
    }
}

[$sw, $sp] = scope_sql($user, 's.category_id');
$where = 'WHERE ' . $sw . ($filterCat ? ' AND s.category_id = ' . $filterCat : '');
$where .= sd('subcategories', 's');
$hasParent = has_col('subcategories', 'parent_id');
$rows = db_all("SELECT s.*, c.name AS cat, " . ($hasParent ? "p.name AS parent_name, " : "") . "(SELECT COUNT(*) FROM services v WHERE v.subcategory_id = s.id" . sd('services', 'v') . ") svcs FROM subcategories s JOIN categories c ON c.id = s.category_id " . ($hasParent ? "LEFT JOIN subcategories p ON p.id = s.parent_id " : "") . "$where ORDER BY c.sort_order, " . ($hasParent ? "COALESCE(p.sort_order, s.sort_order), COALESCE(s.parent_id, s.id), s.parent_id IS NOT NULL, " : "") . "s.sort_order, s.id", $sp);
if ($editId) { $own = db_value('SELECT category_id FROM subcategories WHERE id = ?', [$editId]); if (!$own || !can_manage_category($user, (int) $own)) deny_scope($back); }
$edit = $formData ?? ($editId ? db_one('SELECT * FROM subcategories WHERE id = ?', [$editId]) : null);

admin_header('الأقسام الفرعية (التخصصات)', 'subcategories', $user);
if ($editId || $isNew):
    $s = $edit ?? ['category_id' => $filterCat, 'name' => '', 'slug' => '', 'icon' => 'bi-folder2-open', 'description' => '', 'is_active' => 1];
    ?>
    <div class="panel">
      <h2 class="panel-title"><?= $editId ? 'تعديل التخصص' : 'إضافة تخصص فرعي' ?></h2>
      <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">القسم الرئيسي *</label><select class="form-select" name="category_id" required><option value="">—</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($s['category_id'], $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-6"><label class="form-label">اسم التخصص *</label><input class="form-control" name="name" required maxlength="160" value="<?= e($s['name']) ?>"></div>
          <div class="col-md-6"><label class="form-label">الرابط (slug)</label><input class="form-control" name="slug" value="<?= e($s['slug']) ?>" placeholder="تلقائي"></div>
          <div class="col-md-6"><label class="form-label">الأيقونة</label><div class="input-group"><span class="input-group-text"><i class="bi <?= e($s['icon']) ?>" data-icon-preview></i></span><input class="form-control" name="icon" list="icons" value="<?= e($s['icon']) ?>" data-icon-input dir="ltr"></div>
            <datalist id="icons"><?php foreach (icon_picker_list() as $ic): ?><option value="<?= $ic ?>"><?php endforeach; ?></datalist></div>
          <div class="col-12"><label class="form-label">الوصف</label><textarea class="form-control" name="description" rows="3"><?= e($s['description']) ?></textarea></div>
          <?php if (has_col('subcategories', 'parent_id')):
              $parents = db_all('SELECT id, category_id, parent_id, name FROM subcategories WHERE id <> ?' . sd('subcategories') . ' ORDER BY sort_order, id', [(int) $editId]); ?>
          <div class="col-md-6"><label class="form-label">تابع لتخصص (اختياري — للتفرعات متعددة المستويات)</label>
            <select class="form-select" name="parent_id" id="sub-parent" data-selected="<?= (int) ($s['parent_id'] ?? 0) ?>">
              <option value="">— مستوى أول تحت القسم —</option>
              <?php foreach ($parents as $pp): ?><option value="<?= (int) $pp['id'] ?>" data-cat="<?= (int) $pp['category_id'] ?>"<?= selected((string) ($s['parent_id'] ?? ''), (string) $pp['id']) ?>><?= $pp['parent_id'] ? '— ' : '' ?><?= e($pp['name']) ?></option><?php endforeach; ?>
            </select><div class="form-text">تظهر فقط تخصصات القسم المختار.</div></div>
          <div class="col-md-6"><label class="form-label">صورة التخصص</label>
            <?php if (!empty($s['image'])): ?><img src="<?= e(media_url($s['image'], true)) ?>" alt="" class="img-thumbnail d-block mb-1" style="max-height:80px"><label class="small"><input type="checkbox" name="remove_image" value="1"> إزالة الصورة</label><?php endif; ?>
            <input type="file" class="form-control" name="image" accept="image/jpeg,image/png,image/webp" data-img-preview="sub-img-prev"><div id="sub-img-prev" class="mt-1"></div></div>
          <div class="col-md-6"><label class="form-label">عنوان SEO</label><input class="form-control" name="meta_title" maxlength="190" value="<?= e($s['meta_title'] ?? '') ?>"></div>
          <div class="col-md-6"><label class="form-label">وصف SEO</label><input class="form-control" name="meta_description" maxlength="300" value="<?= e($s['meta_description'] ?? '') ?>"></div>
          <?php endif; ?>
          <div class="col-12"><label class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1"<?= checked($s['is_active']) ?>> مفعّل</label></div>
        </div>
        <div class="mt-4 d-flex gap-2"><button class="btn btn-primary"><i class="bi bi-check2"></i> حفظ</button><a class="btn btn-light" href="<?= e($back) ?>">إلغاء</a></div>
      </form>
    </div>
<?php else: ?>
    <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
      <form class="d-flex gap-2" method="get">
        <select class="form-select" name="category" data-autosubmit><option value="">كل الأقسام</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($filterCat, $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
      </form>
      <a class="btn btn-primary" href="<?= e(admin_url('subcategories', ['new' => 1, 'category' => $filterCat ?: null])) ?>"><i class="bi bi-plus-lg"></i> تخصص جديد</a>
    </div>
    <div class="panel p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
      <thead><tr><?php if ($filterCat): ?><th>الترتيب</th><?php endif; ?><th>التخصص</th><th>القسم الرئيسي</th><th>الخدمات</th><th>الحالة</th><th class="text-end">إجراءات</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <?php if ($filterCat): ?><td><?= move_buttons((int) $r['id']) ?></td><?php endif; ?>
          <td><?php if (!empty($r['parent_id'])): ?><span class="text-muted ms-2">↳</span><?php endif; ?><?php if (!empty($r['image'])): ?><img src="<?= e(media_url($r['image'], true)) ?>" alt="" width="28" height="28" class="rounded me-1" style="object-fit:cover" loading="lazy"><?php else: ?><i class="bi <?= e($r['icon']) ?> text-warning"></i><?php endif; ?> <strong><?= e($r['name']) ?></strong><?php if (!empty($r['parent_name'])): ?> <small class="text-muted">(تابع لـ <?= e($r['parent_name']) ?>)</small><?php endif; ?></td>
          <td class="small"><?= e($r['cat']) ?></td>
          <td><a href="<?= e(admin_url('services', ['sub' => $r['id']])) ?>"><?= (int) $r['svcs'] ?></a></td>
          <td><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-link p-0"><?= active_badge($r['is_active']) ?></button></form></td>
          <td class="text-end text-nowrap">
            <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('subcategories', ['edit' => $r['id'], 'category' => $filterCat ?: null])) ?>"><i class="bi bi-pencil"></i></a>
            <?php if (can($user, 'subcategories.delete')) echo delete_button('delete', (int) $r['id'], 'حذف «' . $r['name'] . '»؟'); ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div></div>
    <?php if (!$filterCat): ?><p class="small text-muted mt-2">اختر قسمًا رئيسيًا لتفعيل أزرار الترتيب.</p><?php endif; ?>
<?php endif;
admin_footer();
