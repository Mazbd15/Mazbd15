<?php
/**
 * أداة فحص SEO: نقاط جاهزية الموقع لمحركات البحث + مشكلات قابلة للإصلاح بضغطة + معاينة نتيجة Google + روابط التقديم.
 * ملاحظة صادقة: لا يمكن لأي موقع ضمان «المركز الأول» في Google؛ هذه الأداة تحقق كل ما بيدك تقنيًا ومحتوائيًا.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('admin');

// إصلاح سريع: توليد أوصاف SEO وعناوين للخدمات/الأقسام الناقصة
if (is_post()) {
    require_csrf();
    $act = (string) ($_POST['action'] ?? '');
    $n = 0;
    if ($act === 'fill_services') {
        foreach (db_all(SERVICE_SELECT . " WHERE (s.meta_description IS NULL OR s.meta_description = '')") as $s) {
            $d = seo_description($s['short_description'] ?: $s['name'], $s['subcategory_name'] ? 'ضمن تخصص ' . $s['subcategory_name'] . '.' : '', 'اطلب الآن عبر واتساب من ' . setting('site_name') . '.');
            db_exec('UPDATE services SET meta_description = ? WHERE id = ?', [mb_substr($d, 0, 300), $s['id']]); $n++;
        }
    } elseif ($act === 'fill_categories') {
        foreach (db_all("SELECT * FROM categories WHERE meta_description IS NULL OR meta_description = '' OR meta_title IS NULL OR meta_title = ''") as $c) {
            $names = implode('، ', array_column(db_all('SELECT name FROM services WHERE category_id = ? AND is_active = 1 ORDER BY is_popular DESC, sort_order LIMIT 4', [$c['id']]), 'name'));
            db_exec('UPDATE categories SET meta_title = COALESCE(NULLIF(meta_title, ""), ?), meta_description = COALESCE(NULLIF(meta_description, ""), ?) WHERE id = ?',
                [mb_substr($c['name'] . ' | ' . setting('site_name'), 0, 190), mb_substr(seo_description($c['short_description'] ?: $c['name'], $names), 0, 300), $c['id']]); $n++;
        }
    } elseif ($act === 'fill_alts') {
        $n += db_exec("UPDATE portfolio_files f JOIN portfolio_items p ON p.id = f.item_id SET f.caption = p.title WHERE f.kind = 'image' AND (f.caption IS NULL OR f.caption = '')");
    }
    audit('seo_fix', 'seo', null, "$act ($n)");
    flash('success', $n ? "تم تحسين $n عنصرًا تلقائيًا. يمكنك تعديل أي منها يدويًا لاحقًا." : 'لا توجد عناصر تحتاج إصلاحًا.');
    redirect(admin_url('seo'));
}

$siteUrl = (string) config('app.url', '');
$isHttps = str_starts_with($siteUrl, 'https://');
$svcTotal = (int) db_value('SELECT COUNT(*) FROM services WHERE is_active = 1');
$svcNoDesc = (int) db_value("SELECT COUNT(*) FROM services WHERE is_active = 1 AND (meta_description IS NULL OR meta_description = '')");
$svcShortText = (int) db_value("SELECT COUNT(*) FROM services WHERE is_active = 1 AND CHAR_LENGTH(COALESCE(description,'')) < 120");
$svcNoKw = (int) db_value("SELECT COUNT(*) FROM services WHERE is_active = 1 AND (keywords IS NULL OR keywords = '')");
$catNoMeta = (int) db_value("SELECT COUNT(*) FROM categories WHERE is_active = 1 AND (meta_description IS NULL OR meta_description = '' OR meta_title IS NULL OR meta_title = '')");
$pfTotal = (int) db_value('SELECT COUNT(*) FROM portfolio_items WHERE is_active = 1');
$pfImgs = (int) db_value("SELECT COUNT(*) FROM portfolio_files f JOIN portfolio_items p ON p.id = f.item_id WHERE p.is_active = 1 AND f.kind = 'image'");
$pfNoAlt = (int) db_value("SELECT COUNT(*) FROM portfolio_files f JOIN portfolio_items p ON p.id = f.item_id WHERE p.is_active = 1 AND f.kind = 'image' AND (f.caption IS NULL OR f.caption = '')");
$pfShort = (int) db_value("SELECT COUNT(*) FROM portfolio_items WHERE is_active = 1 AND CHAR_LENGTH(COALESCE(description,'')) < 150");
$catsWithWorks = count(portfolio_counts_by_category());
$catsTotal = (int) db_value('SELECT COUNT(*) FROM categories WHERE is_active = 1');
$faqs = (int) db_value('SELECT COUNT(*) FROM faqs WHERE is_active = 1');
$socials = count(social_links());
$desc = setting('site_description');

// [الوزن, ناجح؟, العنوان, الشرح/الحل, رابط الإصلاح أو إجراء]
$checks = [
    'تقني' => [
        [10, setting('site_noindex', '0') !== '1', 'الموقع مسموح بأرشفته', 'خيار «منع الأرشفة مؤقتًا» مفعّل — عطّله قبل الإطلاق وإلا لن يظهر الموقع في Google.', admin_url('settings', ['tab' => 'seo'])],
        [8, $siteUrl !== '' && !str_contains($siteUrl, 'localhost'), 'رابط الموقع الرسمي مضبوط (APP_URL)', 'اضبط APP_URL في ملف .env على نطاقك الحقيقي لتصبح الروابط الأساسية وخريطة الموقع صحيحة.', null],
        [8, $isHttps, 'الموقع يعمل بشهادة HTTPS', 'فعّل SSL مجانًا من لوحة الاستضافة (Let\'s Encrypt) ثم اجعل APP_URL يبدأ بـ https:// وفعّل سطر فرض HTTPS في public/.htaccess.', null],
        [6, (bool) config('app.pretty', true), 'روابط صديقة لمحركات البحث', 'فعّل PRETTY_URLS=true في .env.', null],
        [6, setting('google_verification') !== '', 'ربط Google Search Console', 'أضف موقعك في Search Console، اختر التحقق بوسم HTML، والصق الرمز في الإعدادات ← SEO، ثم قدّم خريطة الموقع.', admin_url('settings', ['tab' => 'seo'])],
        [3, setting('bing_verification') !== '', 'ربط Bing Webmaster Tools', 'يغطي Bing وYahoo وDuckDuckGo وChatGPT Search. الصق رمز التحقق في الإعدادات.', admin_url('settings', ['tab' => 'seo'])],
        [4, true, 'خريطة موقع بالصور + robots.txt + بيانات منظمة Schema', 'متوفرة تلقائيًا: Organization/ProfessionalService، Service، CreativeWork، FAQ، Breadcrumb، SearchAction.', null],
    ],
    'المحتوى' => [
        [7, mb_strlen($desc) >= 110 && mb_strlen($desc) <= 170, 'وصف الموقع بطول مثالي (110–170 حرفًا)', 'الحالي: ' . mb_strlen($desc) . ' حرفًا. اكتب جملة تشرح ما تقدمه ومن تخدم مع أهم الكلمات.', admin_url('settings', ['tab' => 'general'])],
        [8, $svcNoDesc === 0, 'كل الخدمات لها وصف SEO', "$svcNoDesc من $svcTotal خدمة بدون وصف مخصص (يُولّد تلقائيًا عند العرض، لكن الأفضل حفظه).", 'fill_services'],
        [5, $catNoMeta === 0, 'كل الأقسام لها عنوان ووصف SEO', "$catNoMeta قسم ينقصه عنوان أو وصف.", 'fill_categories'],
        [6, $svcShortText <= $svcTotal * 0.3, 'محتوى نصي كافٍ في صفحات الخدمات', "$svcShortText خدمة وصفها التفصيلي أقل من 120 حرفًا. Google يفضّل الصفحات التي تشرح الخدمة بعمق (300+ كلمة للأهم).", admin_url('services')],
        [4, $svcNoKw <= $svcTotal * 0.2, 'كلمات بحث بديلة للخدمات', "$svcNoKw خدمة بدون كلمات بديلة (مثل: ريبورت، اسايمنت) — تحسّن البحث الداخلي وتغطية الكلمات العامية.", admin_url('services')],
        [4, $faqs >= 10, 'أسئلة شائعة كافية (10+)', "لديك $faqs سؤالًا. الأسئلة تظهر كنتائج غنية وتجيب عن عمليات بحث «كيف/كم/هل».", admin_url('faqs')],
    ],
    'الصور ومعرض الأعمال' => [
        [8, $pfTotal >= 6, 'معرض أعمال فعّال (6 أعمال أو أكثر)', "لديك $pfTotal عملًا منشورًا. كل عمل صفحة جديدة قابلة للظهور في البحث وبحث الصور.", admin_url('portfolio')],
        [5, $catsTotal > 0 && $catsWithWorks >= min(4, $catsTotal), 'أعمال موزعة على الأقسام', "$catsWithWorks من $catsTotal أقسام فيها أعمال.", admin_url('portfolio')],
        [4, $pfImgs === 0 || $pfNoAlt === 0, 'كل صور الأعمال لها وصف (ALT)', "$pfNoAlt صورة بلا وصف — الوصف يساعد Google Images على فهمها.", 'fill_alts'],
        [3, $pfTotal === 0 || $pfShort <= $pfTotal * 0.3, 'أوصاف غنية للأعمال', "$pfShort عملًا وصفه أقل من 150 حرفًا.", admin_url('portfolio')],
        [3, setting('og_image_path') !== '', 'صورة مشاركة مخصصة', 'ارفع صورة 1200×630 تحمل شعارك لتظهر عند مشاركة الروابط.', admin_url('settings', ['tab' => 'seo'])],
    ],
    'الثقة والانتشار' => [
        [4, $socials >= 2, 'حسابات اجتماعية مربوطة (2+)', "لديك $socials. تُضاف تلقائيًا إلى sameAs ليربط Google علامتك بحساباتك.", admin_url('settings', ['tab' => 'contact'])],
        [3, setting('contact_email') !== '', 'بريد تواصل ظاهر', 'يزيد الثقة لدى الزوار ومحركات البحث.', admin_url('settings', ['tab' => 'contact'])],
        [2, setting('ga4_id') !== '', 'تحليلات Google Analytics 4', 'لقياس الزيارات ونقرات واتساب ومعرفة الكلمات التي تجلب العملاء.', admin_url('settings', ['tab' => 'seo'])],
    ],
];
$total = 0; $got = 0;
foreach ($checks as $grp) foreach ($grp as [$w, $ok]) { $total += $w; if ($ok) $got += $w; }
$score = (int) round($got / max(1, $total) * 100);
$color = $score >= 80 ? '#16a34a' : ($score >= 55 ? '#f59e0b' : '#dc2626');
$homeTitle = setting('seo_home_title') ?: setting('site_name') . ' — ' . setting('site_tagline');
$topSearched = db_all('SELECT name, slug, views FROM services WHERE is_active = 1 ORDER BY views DESC LIMIT 8');
$sitemap = absolute_url('sitemap.xml');

admin_header('محركات البحث SEO', 'seo', $user);
?>
<div class="row g-3 mb-3">
  <div class="col-lg-4">
    <div class="panel h-100 text-center">
      <h2 class="panel-title">نقاط جاهزية SEO</h2>
      <div class="seo-score mx-auto my-3" style="--p:<?= $score ?>;--sc:<?= $color ?>"><span style="color:<?= $color ?>"><?= $score ?></span></div>
      <p class="mb-1 fw-bold"><?= $score >= 80 ? 'ممتاز — الموقع جاهز تقنيًا' : ($score >= 55 ? 'جيد — بقيت خطوات مهمة' : 'يحتاج تحسينات أساسية') ?></p>
      <p class="small text-muted mb-0">النقاط تقيس ما بيدك. الترتيب في Google يعتمد أيضًا على عمر النطاق والمنافسة والروابط الخارجية والوقت (عادةً 2–6 أشهر).</p>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="panel h-100">
      <h2 class="panel-title">معاينة ظهورك في Google</h2>
      <div class="serp-preview border rounded p-3">
        <div class="serp-url"><?= e(preg_replace('#^https?://#', '', $siteUrl ?: 'example.com')) ?></div>
        <div class="serp-title"><?= e(mb_strimwidth($homeTitle, 0, 62, '…')) ?></div>
        <div class="serp-desc"><?= e(mb_strimwidth($desc, 0, 165, '…')) ?></div>
      </div>
      <div class="small text-muted mt-2">العنوان: <?= mb_strlen($homeTitle) ?> حرفًا (المثالي حتى 60) • الوصف: <?= mb_strlen($desc) ?> حرفًا (المثالي 120–160)</div>
      <h3 class="h6 mt-3">التقديم لمحركات البحث</h3>
      <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-sm btn-outline-primary" href="https://search.google.com/search-console" target="_blank" rel="noopener"><i class="bi bi-google"></i> Google Search Console</a>
        <a class="btn btn-sm btn-outline-primary" href="https://www.bing.com/webmasters" target="_blank" rel="noopener"><i class="bi bi-microsoft"></i> Bing Webmaster</a>
        <a class="btn btn-sm btn-outline-secondary" href="<?= e($sitemap) ?>" target="_blank"><i class="bi bi-diagram-3"></i> خريطة الموقع</a>
        <a class="btn btn-sm btn-outline-secondary" href="<?= e(absolute_url('robots.txt')) ?>" target="_blank"><i class="bi bi-robot"></i> robots.txt</a>
        <a class="btn btn-sm btn-outline-secondary" href="https://search.google.com/test/rich-results?url=<?= e(rawurlencode(absolute_url())) ?>" target="_blank" rel="noopener"><i class="bi bi-stars"></i> اختبار النتائج الغنية</a>
        <a class="btn btn-sm btn-outline-secondary" href="https://pagespeed.web.dev/analysis?url=<?= e(rawurlencode(absolute_url())) ?>" target="_blank" rel="noopener"><i class="bi bi-speedometer"></i> سرعة الصفحة</a>
      </div>
      <div class="input-group input-group-sm mt-2"><span class="input-group-text">رابط خريطة الموقع للتقديم</span><input class="form-control" value="<?= e($sitemap) ?>" readonly dir="ltr"></div>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <?php foreach ($checks as $grp => $items): ?>
      <div class="panel mb-3">
        <h2 class="panel-title"><?= e($grp) ?></h2>
        <?php foreach ($items as [$w, $ok, $title, $hint, $fix]): ?>
          <div class="check-row">
            <i class="bi <?= $ok ? 'bi-check-circle-fill text-success' : 'bi-exclamation-circle-fill text-warning' ?>"></i>
            <div class="flex-grow-1"><strong><?= e($title) ?></strong><?php if (!$ok): ?><div class="small text-muted"><?= e($hint) ?></div><?php endif; ?></div>
            <?php if (!$ok && $fix): ?>
              <?php if (str_starts_with($fix, 'fill_')): ?>
                <form method="post" data-confirm="سيتم توليد النصوص الناقصة تلقائيًا (لن يُستبدل أي نص مكتوب). متابعة؟"><?= csrf_field() ?><input type="hidden" name="action" value="<?= e($fix) ?>"><button class="btn btn-sm btn-warning text-nowrap"><i class="bi bi-magic"></i> إصلاح تلقائي</button></form>
              <?php else: ?><a class="btn btn-sm btn-outline-primary text-nowrap" href="<?= e($fix) ?>">إصلاح</a><?php endif; ?>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="col-lg-4">
    <div class="panel mb-3">
      <h2 class="panel-title"><i class="bi bi-lightbulb text-warning"></i> خطة الوصول للصفحة الأولى</h2>
      <ol class="small ps-3 mb-0">
        <li class="mb-2"><strong>اربط Search Console</strong> وقدّم خريطة الموقع في أول يوم.</li>
        <li class="mb-2"><strong>أنشئ ملف Google Business Profile</strong> باسم المنصة ورابط الموقع وواتساب — أقوى عامل للبحث المحلي.</li>
        <li class="mb-2"><strong>أضف عملًا جديدًا أسبوعيًا</strong> في معرض الأعمال بوصف 150+ كلمة وصور واضحة — كل عمل صفحة جديدة تُفهرس.</li>
        <li class="mb-2"><strong>ركّز على كلمات محددة</strong> مثل «مشروع تخرج هندسة مدنية أوتوكاد» بدل «خدمات طلابية» العامة.</li>
        <li class="mb-2"><strong>وسّع وصف أهم 20 خدمة</strong> (ماذا تشمل، لمن، أمثلة، أسئلة) — المحتوى العميق يتفوق.</li>
        <li class="mb-2"><strong>انشر روابط الأعمال</strong> في حساباتك (X، تيليجرام، لينكدإن) — الروابط والزيارات ترفع الثقة.</li>
        <li class="mb-0"><strong>اطلب من العملاء الراضين</strong> تقييمًا على Google Business.</li>
      </ol>
    </div>
    <div class="panel">
      <h2 class="panel-title">الخدمات الأكثر زيارة</h2>
      <?php if (!$topSearched || !(int) $topSearched[0]['views']): ?><p class="small text-muted mb-0">لا توجد زيارات مسجلة بعد.</p><?php endif; ?>
      <ul class="list-unstyled small mb-0">
        <?php foreach ($topSearched as $t): if (!(int) $t['views']) continue; ?>
          <li class="d-flex justify-content-between py-1 border-bottom"><a href="<?= e(route('service', ['slug' => $t['slug']])) ?>" target="_blank" class="text-truncate me-2"><?= e($t['name']) ?></a><span class="badge text-bg-light"><?= (int) $t['views'] ?></span></li>
        <?php endforeach; ?>
      </ul>
      <p class="small text-muted mt-2 mb-0">ركّز على تحسين وصف وصور هذه الخدمات أولًا.</p>
    </div>
  </div>
</div>
<?php admin_footer();
