<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$cats = scoped_categories($user);
$isSpec = user_category_scope($user) !== null;
$f = [
    'status'   => (string) ($_GET['status'] ?? ''),
    'category' => (int) ($_GET['category'] ?? 0),
    'from'     => (string) ($_GET['from'] ?? ''),
    'to'       => (string) ($_GET['to'] ?? ''),
    'q'        => mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100),
    'mine'     => !empty($_GET['mine']) ? '1' : '',
];
$validDate = fn($d) => $d !== '' && ($x = DateTime::createFromFormat('Y-m-d', $d)) && $x->format('Y-m-d') === $d;

[$rsw, $rsp] = requests_scope_sql($user);
$where = [$rsw]; $params = $rsp;
if ($f['mine']) { $where[] = 'r.assigned_to = ?'; $params[] = $user['id']; }
if (isset(request_statuses()[$f['status']])) { $where[] = 'r.status = ?'; $params[] = $f['status']; }
if ($f['category']) { $where[] = 'r.category_id = ?'; $params[] = $f['category']; }
if ($validDate($f['from'])) { $where[] = 'r.created_at >= ?'; $params[] = $f['from'] . ' 00:00:00'; }
if ($validDate($f['to'])) { $where[] = 'r.created_at <= ?'; $params[] = $f['to'] . ' 23:59:59'; }
if ($f['q'] !== '') { $where[] = '(r.reference_code LIKE ? OR r.customer_name LIKE ? OR r.contact_value LIKE ? OR r.service_label LIKE ?)'; array_push($params, "%{$f['q']}%", "%{$f['q']}%", "%{$f['q']}%", "%{$f['q']}%"); }
$w = implode(' AND ', $where);
$query = array_filter($f);

// تصدير CSV
if (($_GET['export'] ?? '') === 'csv' && can($user, 'requests.export')) {
    $rows = db_all("SELECT r.*, c.name AS category_name, (SELECT COUNT(*) FROM request_attachments a WHERE a.request_id = r.id) att FROM requests r LEFT JOIN categories c ON c.id = r.category_id WHERE $w ORDER BY r.created_at DESC", $params);
    audit('export_csv', 'request', null, count($rows) . ' طلب');
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="requests_' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF"); // BOM لدعم العربية في Excel
    // منع حقن الصيغ في Excel
    $safe = fn($v) => is_string($v) && $v !== '' && in_array($v[0], ['=', '+', '-', '@', "\t", "\r"], true) ? "'" . $v : $v;
    fputcsv($out, ['المرجع', 'التاريخ', 'الحالة', 'العميل', 'وسيلة التواصل', 'بيانات التواصل', 'البريد', 'القسم', 'الخدمة', 'التخصص', 'الموعد النهائي', 'البرنامج', 'الوصف', 'ملاحظات العميل', 'ملاحظات الإدارة', 'عدد المرفقات'], ',', '"', '');
    foreach ($rows as $r) {
        fputcsv($out, array_map($safe, [$r['reference_code'], $r['created_at'], request_statuses()[$r['status']][0], $r['customer_name'], contact_methods()[$r['contact_method']] ?? '', $r['contact_value'], $r['email'], $r['category_name'], $r['service_label'], $r['specialization'], $r['deadline'], $r['software'], $r['description'], $r['notes'], $r['admin_notes'], $r['att']]), ',', '"', '');
    }
    fclose($out);
    exit;
}

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    $req = db_one('SELECT * FROM requests WHERE id = ?', [$id]);
    if (!$req || !can_view_request($user, $req)) { flash('danger', 'لا تملك صلاحية على هذا الطلب.'); redirect(admin_url('requests', $query)); }
    if ($action === 'delete' && !can($user, 'requests.delete')) { flash('danger', 'حذف الطلبات للمسؤولين فقط.'); redirect(admin_url('requests', $query)); }
    if ($action === 'status' && isset(request_statuses()[$_POST['status'] ?? ''])) {
        if (request_set_status($req, $_POST['status'], (int) $user['id'])) audit('status', 'request', $id, $_POST['status']);
        flash('success', 'تم تحديث الحالة.');
    }
    if ($action === 'delete') {
        $atts = db_all('SELECT stored_name FROM request_attachments WHERE request_id = ?', [$id]);
        foreach ($atts as $a) {
            $p = config('uploads.path') . '/requests/' . basename($a['stored_name']);
            if (is_file($p)) @unlink($p);
        }
        db_exec('DELETE FROM requests WHERE id = ?', [$id]);
        audit('delete', 'request', $id, 'حذف الطلب ومرفقاته');
        flash('success', 'تم حذف الطلب ومرفقاته نهائيًا.');
    }
    redirect(admin_url('requests', $query));
}

$total = (int) db_value("SELECT COUNT(*) FROM requests r WHERE $w", $params);
$p = paginate($total, 25, (int) ($_GET['page'] ?? 1));
$rows = db_all("SELECT r.*, c.name AS category_name, u.name AS assignee, (SELECT COUNT(*) FROM request_attachments a WHERE a.request_id = r.id) att FROM requests r LEFT JOIN categories c ON c.id = r.category_id LEFT JOIN users u ON u.id = r.assigned_to WHERE $w ORDER BY r.created_at DESC LIMIT {$p['limit']} OFFSET {$p['offset']}", $params);

admin_header('الطلبات', 'requests', $user);
if (setting('save_requests', '1') !== '1'): ?>
  <div class="alert alert-info"><i class="bi bi-info-circle"></i> حفظ الطلبات معطّل حاليًا من الإعدادات؛ الطلبات الجديدة تُرسل عبر واتساب فقط.</div>
<?php endif; ?>
<form class="panel mb-3" method="get">
  <div class="row g-2 align-items-end">
    <div class="col-md-3"><label class="form-label small">بحث</label><input class="form-control" name="q" value="<?= e($f['q']) ?>" placeholder="المرجع، الاسم، الرقم، الخدمة"></div>
    <div class="col-6 col-md-2"><label class="form-label small">الحالة</label><select class="form-select" name="status"><option value="">الكل</option><?php foreach (request_statuses() as $k => [$l]): ?><option value="<?= $k ?>"<?= selected($f['status'], $k) ?>><?= $l ?></option><?php endforeach; ?></select></div>
    <div class="col-6 col-md-2"><label class="form-label small">القسم</label><select class="form-select" name="category"><option value="">الكل</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($f['category'], $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
    <div class="col-6 col-md-2"><label class="form-label small">من تاريخ</label><input class="form-control" type="date" name="from" value="<?= e($f['from']) ?>"></div>
    <div class="col-6 col-md-2"><label class="form-label small">إلى تاريخ</label><input class="form-control" type="date" name="to" value="<?= e($f['to']) ?>"></div>
    <div class="col-12 col-md-auto"><label class="form-check small mb-2"><input class="form-check-input" type="checkbox" name="mine" value="1"<?= checked($f['mine']) ?>> المسندة إليّ فقط</label></div>
    <div class="col-md-1 d-grid"><button class="btn btn-secondary"><i class="bi bi-funnel"></i></button></div>
  </div>
</form>
<div class="d-flex justify-content-between align-items-center mb-2">
  <p class="text-muted mb-0"><?= $total ?> طلب<?= $query ? ' — <a href="' . e(admin_url('requests')) . '">مسح الفلاتر</a>' : '' ?></p>
  <?php if (can($user, 'requests.export')): ?><a class="btn btn-outline-success" href="<?= e(admin_url('requests', $query + ['export' => 'csv'])) ?>"><i class="bi bi-filetype-csv"></i> تصدير CSV</a><?php endif; ?>
</div>
<div class="panel p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
  <thead><tr><th>المرجع</th><th>العميل</th><th>الخدمة</th><th>الموعد</th><th>مرفقات</th><th>الحالة</th><th>التاريخ</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><a class="fw-bold" href="<?= e(admin_url('request_view', ['id' => $r['id']])) ?>"><?= e($r['reference_code']) ?></a></td>
      <td><?= e($r['customer_name']) ?><br><small class="text-muted" dir="ltr"><?= e($r['contact_value']) ?></small></td>
      <td class="small"><?= e(excerpt($r['service_label'], 45)) ?><br><span class="text-muted"><?= e($r['category_name'] ?? '—') ?></span>
        <?php if ($r['assignee']): ?><br><span class="badge text-bg-light"><i class="bi bi-person-check"></i> <?= e($r['assignee']) ?></span><?php endif; ?></td>
      <td class="small"><?= ar_date($r['deadline']) ?></td>
      <td><?= $r['att'] ? '<span class="badge text-bg-light"><i class="bi bi-paperclip"></i> ' . (int) $r['att'] . '</span>' : '—' ?></td>
      <td>
        <form method="post" class="d-flex"><?= csrf_field() ?><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
          <select class="form-select form-select-sm status-select status-<?= e($r['status']) ?>" name="status" data-autosubmit><?php foreach (request_statuses() as $k => [$l]): ?><option value="<?= $k ?>"<?= selected($r['status'], $k) ?>><?= $l ?></option><?php endforeach; ?></select>
        </form>
      </td>
      <td class="small text-muted"><?= ar_date($r['created_at'], true) ?></td>
      <td><a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('request_view', ['id' => $r['id']])) ?>"><i class="bi bi-eye"></i></a></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-5"><i class="bi bi-inbox fs-2 d-block"></i>لا توجد طلبات مسجلة<?= $query ? ' مطابقة للفلاتر' : '' ?>.</td></tr><?php endif; ?>
  </tbody>
</table></div></div>
<?= pagination_links($p, $query) ?>
<?php admin_footer();
