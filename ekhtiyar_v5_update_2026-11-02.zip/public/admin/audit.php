<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('super_admin');

$fUser = (int) ($_GET['user'] ?? 0);
$fEntity = preg_replace('/[^a-z_]/', '', (string) ($_GET['entity'] ?? ''));
$where = ['1=1']; $params = [];
if ($fUser) { $where[] = 'a.user_id = ?'; $params[] = $fUser; }
if ($fEntity) { $where[] = 'a.entity_type = ?'; $params[] = $fEntity; }
$w = implode(' AND ', $where);
$total = (int) db_value("SELECT COUNT(*) FROM audit_logs a WHERE $w", $params);
$p = paginate($total, 50, (int) ($_GET['page'] ?? 1));
$rows = db_all("SELECT a.*, u.name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE $w ORDER BY a.id DESC LIMIT {$p['limit']} OFFSET {$p['offset']}", $params);
$users = db_all('SELECT id, name FROM users ORDER BY name');
$entities = ['category' => 'الأقسام', 'subcategory' => 'التفرعات', 'service' => 'الخدمات', 'faq' => 'الأسئلة', 'request' => 'الطلبات', 'settings' => 'الإعدادات', 'user' => 'المستخدمون'];
$actions = ['create' => 'إنشاء', 'update' => 'تعديل', 'delete' => 'حذف', 'toggle' => 'تفعيل/تعطيل', 'login' => 'دخول', 'logout' => 'خروج', 'status' => 'تغيير حالة', 'settings' => 'إعدادات', 'download' => 'تنزيل مرفق', 'export_csv' => 'تصدير CSV', 'popular' => 'الأكثر طلبًا', 'featured' => 'تمييز', 'setup' => 'إعداد أولي', 'password_change' => 'تغيير كلمة المرور'];

admin_header('سجل العمليات الإدارية', 'audit', $user);
?>
<form class="panel mb-3 d-flex flex-wrap gap-2" method="get">
  <select class="form-select w-auto" name="user"><option value="">كل المستخدمين</option><?php foreach ($users as $u): ?><option value="<?= $u['id'] ?>"<?= selected($fUser, $u['id']) ?>><?= e($u['name']) ?></option><?php endforeach; ?></select>
  <select class="form-select w-auto" name="entity"><option value="">كل العناصر</option><?php foreach ($entities as $k => $l): ?><option value="<?= $k ?>"<?= selected($fEntity, $k) ?>><?= $l ?></option><?php endforeach; ?></select>
  <button class="btn btn-secondary"><i class="bi bi-funnel"></i> تصفية</button>
</form>
<div class="panel p-0"><div class="table-responsive"><table class="table table-sm align-middle mb-0">
  <thead><tr><th>الوقت</th><th>المستخدم</th><th>العملية</th><th>العنصر</th><th>التفاصيل</th><th>IP</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="small text-nowrap"><?= ar_date($r['created_at'], true) ?></td>
      <td class="small"><?= e($r['name'] ?? '—') ?></td>
      <td><span class="badge text-bg-light"><?= e($actions[$r['action']] ?? $r['action']) ?></span></td>
      <td class="small"><?= e($entities[$r['entity_type'] ?? ''] ?? ($r['entity_type'] ?? '')) ?><?= $r['entity_id'] ? ' #' . (int) $r['entity_id'] : '' ?></td>
      <td class="small"><?= e(excerpt($r['details'], 80)) ?></td>
      <td class="small text-muted" dir="ltr"><?= e($r['ip_address']) ?></td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="6" class="text-center text-muted py-4">لا توجد عمليات مسجلة.</td></tr><?php endif; ?>
  </tbody>
</table></div></div>
<?= pagination_links($p, array_filter(['user' => $fUser ?: null, 'entity' => $fEntity ?: null])) ?>
<?php admin_footer();
