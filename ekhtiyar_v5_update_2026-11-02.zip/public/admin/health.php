<?php
/**
 * مركز صحة الموقع
 * - فحوص: قاعدة البيانات، PHP والإضافات، صلاحيات المجلدات، الصور المسجلة مقابل الفعلية، الصور المفقودة،
 *   الملفات اليتيمة، مجلدات رفع في مسار خاطئ، سجل الرفع، آخر أخطاء PHP، المساحة، آخر نسخة احتياطية.
 * - لا إصلاح تلقائي مدمّر: كل إصلاح يعرض معاينة ويتطلب تأكيد المدير، ولا يحذف نهائيًا (اليتيمة تُنقل لسلة الوسائط).
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('admin');

/** فحص الصور: [registered, files, missing, orphans, foundElsewhere] */
function health_media_scan(): array
{
    $refs = media_all_refs();
    $files = media_scan(PUBLIC_PATH . '/' . MEDIA_UPLOAD_BASE, MEDIA_UPLOAD_BASE);
    $missing = [];
    foreach ($refs as $rel => $src) {
        if (!str_starts_with($rel, 'assets/')) continue;
        if (!is_file(PUBLIC_PATH . '/' . $rel)) $missing[$rel] = $src;
    }
    $orphans = array_diff_key($files, $refs);
    // البحث عن الملفات المفقودة في المواقع الخاطئة المحتملة (رفع سابق لمسار غير منشور)
    $elsewhere = [];
    $dirs = media_misplaced_dirs();
    foreach ($missing as $rel => $_) {
        $sub = substr($rel, strlen(MEDIA_UPLOAD_BASE));
        foreach ($dirs as $d) if (is_file($d . $sub)) { $elsewhere[$rel] = $d . $sub; break; }
    }
    return [$refs, $files, $missing, $orphans, $elsewhere];
}

function health_tail(string $file, int $lines = 40): string
{
    if (!is_file($file) || !is_readable($file)) return '';
    $size = filesize($file);
    $fh = fopen($file, 'rb');
    fseek($fh, max(0, $size - 24000));
    $data = (string) fread($fh, 24000);
    fclose($fh);
    $arr = preg_split('/\r?\n/', trim($data));
    return implode("\n", array_slice($arr, -$lines));
}

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    [, , $missing, $orphans, $elsewhere] = health_media_scan();
    $sel = array_map('strval', (array) ($_POST['sel'] ?? []));
    if (!$sel) { flash('warning', 'لم تحدد أي عنصر.'); redirect(admin_url('health', ['scan' => 1])); }
    $n = 0;
    if ($action === 'relocate') {
        // نسخ (وليس نقل) الملفات من المسار الخاطئ إلى المجلد العام الصحيح، دون الكتابة فوق أي ملف
        foreach ($sel as $rel) {
            if (!isset($elsewhere[$rel])) continue;
            $dest = PUBLIC_PATH . '/' . $rel;
            if (is_file($dest)) continue;
            if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
            if (@copy($elsewhere[$rel], $dest)) { @chmod($dest, 0644); media_make_thumb($rel); $n++; }
        }
        media_log("استعادة $n صورة من مسار خاطئ إلى المجلد العام (مركز الصحة)");
        audit('repair', 'media', null, "relocate $n");
        flash('success', "تم نسخ $n ملف إلى مكانه الصحيح. الملفات الأصلية لم تُحذف.");
    } elseif ($action === 'trash_orphans') {
        foreach ($sel as $rel) if (isset($orphans[$rel]) && media_ref_count($rel) === 0 && media_trash($rel)) $n++;
        audit('repair', 'media', null, "trash orphans $n");
        flash('success', "نُقل $n ملف غير مستخدم إلى سلة الوسائط (يمكن استعادته من سلة المحذوفات).");
    } elseif ($action === 'thumbs') {
        foreach ($sel as $rel) if (str_starts_with($rel, MEDIA_UPLOAD_BASE . '/') && !str_contains($rel, '..') && media_make_thumb($rel)) $n++;
        flash('success', "تم توليد $n صورة مصغرة.");
    }
    redirect(admin_url('health', ['scan' => 1]));
}

// -------------------- الفحوص --------------------
$checks = [];
$add = function (string $group, string $label, string $state, string $info = '') use (&$checks) { $checks[$group][] = [$label, $state, $info]; };

try { $ver = (string) db_value('SELECT VERSION()'); $add('الخادم', 'الاتصال بقاعدة البيانات', 'ok', $ver); }
catch (Throwable $e) { $add('الخادم', 'الاتصال بقاعدة البيانات', 'bad', 'فشل'); }
$add('الخادم', 'إصدار PHP', version_compare(PHP_VERSION, '8.1', '>=') ? 'ok' : 'bad', PHP_VERSION . ' (المطلوب 8.1+)');
foreach (['pdo_mysql' => 'قاعدة البيانات', 'mbstring' => 'النصوص العربية', 'fileinfo' => 'فحص نوع الملفات', 'gd' => 'معالجة الصور', 'zip' => 'النسخ الاحتياطي ZIP'] as $ext => $why)
    $add('الخادم', "إضافة $ext", extension_loaded($ext) ? 'ok' : ($ext === 'zip' || $ext === 'gd' ? 'warn' : 'bad'), $why);
$add('الخادم', 'دعم WebP', function_exists('imagewebp') ? 'ok' : 'warn', function_exists('imagewebp') ? 'تُحوَّل الصور إلى WebP' : 'تُحفظ الصور بصيغتها الأصلية');
$add('الخادم', 'HTTPS', (($_SERVER['HTTPS'] ?? '') === 'on' || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') ? 'ok' : 'warn', (string) config('app.url'));
$add('الخادم', 'وضع التصحيح (debug)', config('app.debug') ? 'warn' : 'ok', config('app.debug') ? 'مفعّل — أوقفه في الإنتاج' : 'متوقف');
$pending = migrations_pending();
$add('الخادم', 'تحديثات قاعدة البيانات', $pending ? 'warn' : 'ok', $pending ? count($pending) . ' معلّقة' : 'محدّثة — v' . setting('db_version', '?'));

$add('المسارات', 'المجلد العام المكتشف', is_file(PUBLIC_PATH . '/index.php') ? 'ok' : 'bad', PUBLIC_PATH);
$add('المسارات', 'روابط مختصرة (.htaccess في المجلد العام)', is_file(PUBLIC_PATH . '/.htaccess') ? 'ok' : 'warn', is_file(PUBLIC_PATH . '/.htaccess') ? 'موجود' : 'غير موجود — الموقع يستخدم روابط .php تلقائيًا. انسخ config/htaccess.public.txt إلى ' . basename(PUBLIC_PATH) . '/.htaccess');
foreach ([PUBLIC_PATH . '/' . MEDIA_UPLOAD_BASE => 'مجلد الصور المرفوعة', ROOT_PATH . '/storage/uploads' => 'مرفقات الطلبات والملفات', ROOT_PATH . '/storage/logs' => 'السجلات', ROOT_PATH . '/storage/backups' => 'النسخ الاحتياطية', ROOT_PATH . '/storage/media_trash' => 'سلة الوسائط'] as $dir => $label) {
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $w = is_dir($dir) && is_writable($dir);
    $add('المسارات', $label, $w ? 'ok' : 'bad', str_replace(ROOT_PATH, '', $dir) . ($w ? ' — قابل للكتابة (' . substr(sprintf('%o', fileperms($dir)), -4) . ')' : ' — غير قابل للكتابة'));
}
$sb = ROOT_PATH . '/storage/.htaccess';
$add('المسارات', 'حماية مجلد storage', (is_file($sb) || !str_starts_with(ROOT_PATH . '/storage', PUBLIC_PATH)) ? 'ok' : 'warn', 'خارج المجلد العام أو محمي بـ .htaccess');

$free = @disk_free_space(ROOT_PATH);
$add('التخزين', 'المساحة الحرة', $free === false ? 'warn' : ($free < 200 * 1048576 ? 'bad' : 'ok'), $free === false ? 'غير متاح' : round($free / 1073741824, 2) . ' ج.ب');
$last = backup_last_time();
$add('التخزين', 'آخر نسخة احتياطية', !$last ? 'bad' : ($last < time() - 14 * 86400 ? 'warn' : 'ok'), $last ? ar_date(date('Y-m-d H:i:s', $last), true) : 'لا توجد — أنشئ نسخة من صفحة النسخ الاحتياطي');

$scan = isset($_GET['scan']);
if ($scan) {
    [$refs, $files, $missing, $orphans, $elsewhere] = health_media_scan();
    $noThumb = [];
    foreach ($files as $rel => $_) if (preg_match('/\.(jpe?g|png|webp|gif)$/i', $rel) && !is_file(PUBLIC_PATH . '/' . media_thumb_rel($rel))) $noThumb[] = $rel;
    $add('الصور', 'صور مسجلة في قاعدة البيانات', 'ok', (string) count($refs));
    $add('الصور', 'ملفات فعلية في مجلد الرفع', 'ok', (string) count($files));
    $add('الصور', 'صور مفقودة (رابط بلا ملف)', $missing ? 'bad' : 'ok', count($missing) . ($elsewhere ? ' — منها ' . count($elsewhere) . ' موجودة في مسار خاطئ ويمكن استعادتها' : ''));
    $add('الصور', 'ملفات يتيمة (غير مستخدمة)', $orphans ? 'warn' : 'ok', (string) count($orphans));
    $add('الصور', 'صور بلا مصغرات', $noThumb ? 'warn' : 'ok', (string) count($noThumb));
    $mis = media_misplaced_dirs();
    $add('الصور', 'مجلدات رفع في مسار غير منشور', $mis ? 'warn' : 'ok', $mis ? implode(' ، ', $mis) : 'لا يوجد');
    audit('scan', 'health', null, 'missing=' . count($missing) . ' orphans=' . count($orphans));
}

$phpLog = health_tail(ROOT_PATH . '/storage/logs/php-error.log', 30);
$upLog = health_tail(ROOT_PATH . '/storage/logs/uploads.log', 20);
$icons = ['ok' => 'bi-check-circle-fill health-ok', 'warn' => 'bi-exclamation-triangle-fill health-warn', 'bad' => 'bi-x-octagon-fill health-bad'];
$counts = ['ok' => 0, 'warn' => 0, 'bad' => 0];
foreach ($checks as $g) foreach ($g as $c) $counts[$c[1]]++;

admin_header('صحة الموقع', 'health', $user);
?>
<div class="d-flex flex-wrap gap-2 align-items-center mb-3">
  <span class="badge bg-success fs-6"><?= $counts['ok'] ?> سليم</span>
  <span class="badge bg-warning text-dark fs-6"><?= $counts['warn'] ?> تنبيه</span>
  <span class="badge bg-danger fs-6"><?= $counts['bad'] ?> مشكلة</span>
  <a class="btn btn-primary ms-auto" href="<?= e(admin_url('health', ['scan' => 1])) ?>"><i class="bi bi-search"></i> فحص شامل (يشمل الصور)</a>
</div>
<div class="row g-3">
  <?php foreach ($checks as $group => $rows): ?>
    <div class="col-lg-6"><div class="panel h-100">
      <h2 class="panel-title"><?= e($group) ?></h2>
      <?php foreach ($rows as [$label, $st, $info]): ?>
        <div class="health-row"><i class="bi <?= $icons[$st] ?>"></i><strong class="small"><?= e($label) ?></strong><span class="small text-muted ms-auto text-break" style="max-width:60%"><?= e($info) ?></span></div>
      <?php endforeach; ?>
      <?php if ($group === 'الصور' || ($group === 'التخزين' && !$scan)): ?>
        <?php if (!$scan): ?><p class="small text-muted mt-2 mb-0">اضغط «فحص شامل» لفحص الصور المسجلة والمفقودة واليتيمة.</p><?php endif; ?>
      <?php endif; ?>
    </div></div>
  <?php endforeach; ?>
</div>

<?php if ($scan): ?>
  <?php if ($elsewhere): ?>
  <div class="panel mt-3">
    <h2 class="panel-title text-success"><i class="bi bi-magic"></i> صور مفقودة يمكن استعادتها (<?= count($elsewhere) ?>)</h2>
    <p class="small text-muted">هذه الصور رُفعت سابقًا إلى مجلد غير منشور بسبب مسار خاطئ. الإصلاح ينسخها إلى المجلد العام الصحيح فقط، ولا يحذف الأصل ولا يكتب فوق أي ملف.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="relocate">
      <div class="table-responsive" style="max-height:340px"><table class="table table-sm small">
        <tr><th><input type="checkbox" class="form-check-input" data-check-all="rel" checked></th><th>المسار المطلوب</th><th>موجود في</th><th>مستخدم في</th></tr>
        <?php foreach ($elsewhere as $rel => $from): ?>
          <tr><td><input type="checkbox" class="form-check-input" name="sel[]" value="<?= e($rel) ?>" data-group="rel" checked></td><td class="mono"><?= e($rel) ?></td><td class="mono"><?= e($from) ?></td><td><?= e(implode('، ', array_unique($missing[$rel]))) ?></td></tr>
        <?php endforeach; ?>
      </table></div>
      <button class="btn btn-success" data-confirm="نسخ الملفات المحددة إلى المجلد العام؟"><i class="bi bi-check2-all"></i> تأكيد الاستعادة</button>
    </form>
  </div>
  <?php endif; ?>

  <?php if ($missing): ?>
  <div class="panel mt-3">
    <h2 class="panel-title text-danger">صور مفقودة (<?= count($missing) ?>)</h2>
    <p class="small text-muted">تظهر هذه العناصر بالصورة الافتراضية للزوار. لإصلاحها ارفع صورة جديدة من صفحة العنصر — لن تُفقد بياناته.</p>
    <div class="table-responsive" style="max-height:300px"><table class="table table-sm small">
      <?php foreach ($missing as $rel => $src): ?><tr><td class="mono"><?= e($rel) ?></td><td><?= e(implode('، ', array_unique($src))) ?></td><td><?= isset($elsewhere[$rel]) ? '<span class="badge bg-success">قابلة للاستعادة</span>' : '' ?></td></tr><?php endforeach; ?>
    </table></div>
  </div>
  <?php endif; ?>

  <?php if ($orphans): ?>
  <div class="panel mt-3">
    <h2 class="panel-title">ملفات غير مستخدمة (<?= count($orphans) ?>)</h2>
    <p class="small text-muted">ملفات في مجلد الرفع لا يشير إليها أي سجل. لن يُحذف شيء تلقائيًا؛ يمكنك نقل المحدد إلى سلة الوسائط (قابل للاستعادة).</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="trash_orphans">
      <div class="row g-2" style="max-height:420px;overflow:auto">
        <?php foreach ($orphans as $rel => $info): ?>
          <div class="col-6 col-md-3 col-xl-2"><label class="border rounded p-1 d-block small text-center h-100">
            <img src="<?= e(media_url($rel, true)) ?>" alt="" loading="lazy" class="img-fluid rounded mb-1" style="height:80px;object-fit:cover;width:100%">
            <input type="checkbox" class="form-check-input" name="sel[]" value="<?= e($rel) ?>" data-group="orph">
            <span class="d-block text-truncate mono" title="<?= e($rel) ?>"><?= e(basename($rel)) ?></span><span class="text-muted"><?= round($info['size'] / 1024) ?> ك.ب</span></label></div>
        <?php endforeach; ?>
      </div>
      <div class="mt-2 d-flex gap-2"><label class="small"><input type="checkbox" class="form-check-input" data-check-all="orph"> تحديد الكل</label>
        <button class="btn btn-outline-danger btn-sm ms-auto" data-confirm="نقل الملفات المحددة إلى سلة الوسائط؟"><i class="bi bi-trash"></i> نقل المحدد للسلة</button></div>
    </form>
  </div>
  <?php endif; ?>

  <?php if ($noThumb): ?>
  <div class="panel mt-3">
    <h2 class="panel-title">صور بلا مصغرات (<?= count($noThumb) ?>)</h2>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="thumbs">
      <?php foreach (array_slice($noThumb, 0, 300) as $rel): ?><input type="hidden" name="sel[]" value="<?= e($rel) ?>"><?php endforeach; ?>
      <button class="btn btn-outline-primary btn-sm"><i class="bi bi-images"></i> توليد المصغرات (<?= min(300, count($noThumb)) ?>)</button>
    </form>
  </div>
  <?php endif; ?>
<?php endif; ?>

<div class="row g-3 mt-1">
  <div class="col-lg-6"><div class="panel">
    <h2 class="panel-title">آخر أخطاء PHP</h2>
    <?= $phpLog !== '' ? '<div class="log-box mono">' . e($phpLog) . '</div>' : '<p class="text-muted small mb-0">لا توجد أخطاء مسجلة.</p>' ?>
  </div></div>
  <div class="col-lg-6"><div class="panel">
    <h2 class="panel-title">سجل رفع الصور</h2>
    <?= $upLog !== '' ? '<div class="log-box mono">' . e($upLog) . '</div>' : '<p class="text-muted small mb-0">لا توجد عمليات مسجلة.</p>' ?>
  </div></div>
</div>
<?php admin_footer();
