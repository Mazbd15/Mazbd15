<?php
/**
 * إدارة آراء العملاء (v5)
 * - إضافة/تعديل/اعتماد/إخفاء/تثبيت/ترتيب/حذف مؤقت.
 * - قوالب وخلفيات البطاقات + ألوان وأيقونة مخصصة + معاينة مباشرة قبل النشر.
 * - الآراء المرسلة من الزوار تبقى «بانتظار المراجعة» حتى تعتمدها الإدارة.
 * - لا تُنشر صورة العميل أو مرفقاته إلا بموافقته (consent_publish).
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('editor');
require_v5('آراء العملاء', 'testimonials', $user);

$tab = (string) ($_GET['status'] ?? 'all');
$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);
$errors = [];
$back = admin_url('testimonials', $tab !== 'all' ? ['status' => $tab] : []);
$themes = testimonial_themes();
$services = db_all("SELECT s.id, s.name, c.name cat FROM services s JOIN categories c ON c.id = s.category_id WHERE s.is_active = 1" . sd('services', 's') . ' ORDER BY c.sort_order, s.sort_order');

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    $row = $id ? db_one('SELECT * FROM testimonials WHERE id = ? AND deleted_at IS NULL', [$id]) : null;
    if ($id && !$row) { flash('danger', 'الرأي غير موجود.'); redirect($back); }

    if ($action === 'approve' && $row) {
        if (!$row['consent_publish']) { flash('warning', 'لا يمكن نشر رأي بدون موافقة صاحبه على النشر. عدّل الرأي وأكد وجود الموافقة.'); redirect($back); }
        db_exec("UPDATE testimonials SET status = 'approved', approved_by = ?, approved_at = COALESCE(approved_at, NOW()) WHERE id = ?", [$user['id'], $id]);
        audit('approve', 'testimonial', $id, $row['name']);
        flash('success', 'تم اعتماد الرأي ونشره.');
    } elseif ($action === 'hide' && $row) {
        db_exec("UPDATE testimonials SET status = 'hidden' WHERE id = ?", [$id]);
        audit('hide', 'testimonial', $id, $row['name']);
        flash('success', 'تم إخفاء الرأي.');
    } elseif ($action === 'pin' && $row) {
        db_exec('UPDATE testimonials SET is_pinned = 1 - is_pinned WHERE id = ?', [$id]);
    } elseif ($action === 'move' && $row) {
        move_item('testimonials', $id, ($_POST['dir'] ?? '') === 'up' ? 'up' : 'down');
    } elseif ($action === 'delete' && $row) {
        soft_delete('testimonials', $id);
        audit('trash', 'testimonial', $id, $row['name']);
        flash('success', 'نُقل الرأي إلى سلة المحذوفات.');
    } elseif ($action === 'settings') {
        $map = ['testimonials_enabled' => 'bool', 'testimonials_show_avg' => 'bool', 'testimonials_allow_submit' => 'bool', 'show_home_testimonials' => 'bool',
                'testimonials_title' => 'text', 'testimonials_subtitle' => 'text', 'testimonials_layout' => 'layout', 'testimonials_count' => 'int', 'testimonials_interval' => 'int'];
        foreach ($map as $k => $type) {
            $v = match ($type) {
                'bool'   => !empty($_POST[$k]) ? '1' : '0',
                'int'    => (string) max(1, min($k === 'testimonials_count' ? 24 : 30, (int) ($_POST[$k] ?? 6))),
                'layout' => ($_POST[$k] ?? '') === 'grid' ? 'grid' : 'slider',
                default  => mb_substr(trim((string) ($_POST[$k] ?? '')), 0, 300),
            };
            db_exec('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', [$v, $k]);
        }
        audit('update', 'settings', null, 'testimonials');
        flash('success', 'تم حفظ إعدادات قسم الآراء.');
    } elseif ($action === 'save') {
        $data = [
            'name'           => mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120),
            'specialization' => mb_substr(trim((string) ($_POST['specialization'] ?? '')), 0, 160) ?: null,
            'service_id'     => (int) ($_POST['service_id'] ?? 0) ?: null,
            'service_label'  => mb_substr(trim((string) ($_POST['service_label'] ?? '')), 0, 200) ?: null,
            'rating'         => max(1, min(5, (int) ($_POST['rating'] ?? 5))),
            'body'           => mb_substr(trim((string) ($_POST['body'] ?? '')), 0, 2000),
            'theme'          => isset($themes[$_POST['theme'] ?? '']) ? $_POST['theme'] : 'white',
            'bg_color'       => preg_match('/^#[0-9a-f]{6}$/i', (string) ($_POST['bg_color'] ?? '')) && !empty($_POST['use_colors']) ? $_POST['bg_color'] : null,
            'text_color'     => preg_match('/^#[0-9a-f]{6}$/i', (string) ($_POST['text_color'] ?? '')) && !empty($_POST['use_colors']) ? $_POST['text_color'] : null,
            'icon'           => preg_match('/^bi-[a-z0-9\-]+$/', (string) ($_POST['icon'] ?? '')) ? $_POST['icon'] : null,
            'is_verified'    => !empty($_POST['is_verified']) ? 1 : 0,
            'request_ref'    => mb_substr(strtoupper(trim((string) ($_POST['request_ref'] ?? ''))), 0, 30) ?: null,
            'consent_publish'=> !empty($_POST['consent_publish']) ? 1 : 0,
            'is_pinned'      => !empty($_POST['is_pinned']) ? 1 : 0,
            'status'         => in_array($_POST['status'] ?? '', ['pending', 'approved', 'hidden'], true) ? $_POST['status'] : 'pending',
        ];
        if ($data['name'] === '') $errors[] = 'اسم العميل (أو اسمه المستعار) مطلوب.';
        if (mb_strlen($data['body']) < 10) $errors[] = 'نص الرأي قصير جدًا.';
        if ($data['status'] === 'approved' && !$data['consent_publish']) $errors[] = 'لا يمكن النشر بدون موافقة العميل على النشر.';
        if ($data['request_ref'] && !db_value('SELECT id FROM requests WHERE reference = ?', [$data['request_ref']])) $errors[] = 'رقم الطلب المرجعي غير موجود — اتركه فارغًا أو صححه.';
        if ($data['is_verified'] && !$data['request_ref'] && !($row['is_verified'] ?? 0)) $errors[] = 'شارة «عميل موثّق» تتطلب ربط الرأي برقم طلب حقيقي.';

        // الصور: الصورة الشخصية والخلفية والمرفق (لا يُحذف القديم إلا عند الاستبدال، وبحذف آمن)
        $uploads = [];
        foreach (['avatar' => 'testimonials', 'bg_image' => 'testimonials', 'attachment' => 'testimonials'] as $field => $folder) {
            if (!empty($_FILES[$field]['name'])) {
                [$ok, $res] = store_public_image($_FILES[$field], $folder);
                if ($ok) $uploads[$field] = $res; else $errors[] = $res;
            }
        }
        if (!$errors) {
            foreach ($uploads as $field => $path) { if ($row && $row[$field]) delete_public_image($row[$field]); $data[$field] = $path; }
            foreach (['avatar', 'bg_image', 'attachment'] as $field) {
                if (!empty($_POST['remove_' . $field]) && $row && $row[$field] && !isset($uploads[$field])) { delete_public_image($row[$field]); $data[$field] = null; }
            }
            if ($data['status'] === 'approved') { $data['approved_by'] = $user['id']; if (!($row['approved_at'] ?? null)) $data['approved_at'] = date('Y-m-d H:i:s'); }
            if ($row) { db_update('testimonials', $data, $id); audit('update', 'testimonial', $id, $data['name']); }
            else {
                $data['source'] = 'admin';
                $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM testimonials');
                $id = db_insert('testimonials', $data);
                audit('create', 'testimonial', $id, $data['name']);
            }
            flash('success', 'تم حفظ الرأي.');
            redirect(admin_url('testimonials', ['edit' => $id]));
        }
        foreach ($uploads as $p) delete_public_image($p);
        $editId = $id; $isNew = !$id; $formData = $data + ($row ?? []);
    }
    if (!$errors) redirect($back);
}

$stats = db_one("SELECT COUNT(*) total, SUM(status='approved') approved, SUM(status='pending') pending, SUM(status='hidden') hidden,
    AVG(CASE WHEN status='approved' THEN rating END) avg FROM testimonials WHERE deleted_at IS NULL");

admin_header('إدارة آراء العملاء', 'testimonials', $user);

if ($editId || $isNew):
    $t = $formData ?? ($editId ? db_one('SELECT * FROM testimonials WHERE id = ? AND deleted_at IS NULL', [$editId]) : null)
        ?? ['name' => '', 'specialization' => '', 'service_id' => null, 'service_label' => '', 'rating' => 5, 'body' => '', 'theme' => 'white', 'bg_color' => null, 'text_color' => null,
            'icon' => 'bi-quote', 'is_verified' => 0, 'request_ref' => '', 'consent_publish' => 0, 'is_pinned' => 0, 'status' => 'pending', 'avatar' => null, 'bg_image' => null, 'attachment' => null, 'source' => 'admin', 'created_at' => date('Y-m-d H:i:s')];
    if ($editId && !$t) { echo '<div class="alert alert-danger">الرأي غير موجود.</div>'; admin_footer(); exit; }
    $previewData = $t;
    if (!empty($t['service_id'])) foreach ($services as $sv) if ((int) $sv['id'] === (int) $t['service_id']) $previewData['service_name'] = $sv['name'];
?>
  <a class="btn btn-link px-0 mb-2" href="<?= e($back) ?>"><i class="bi bi-arrow-right"></i> العودة للقائمة</a>
  <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
  <?php if (($t['source'] ?? '') === 'visitor'): ?><div class="alert alert-info py-2"><i class="bi bi-person-check"></i> هذا الرأي أرسله العميل بنفسه من الموقع<?= !empty($t['consent_publish']) ? ' ووافق على نشره.' : ' ولم يوافق على النشر — لا يمكن نشره.' ?></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" id="t-form">
    <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
    <div class="row g-3">
      <div class="col-lg-7">
        <div class="panel">
          <h2 class="panel-title">بيانات الرأي</h2>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">الاسم أو الاسم المستعار *</label><input class="form-control" name="name" value="<?= e($t['name']) ?>" required maxlength="120" data-pv="name"></div>
            <div class="col-md-6"><label class="form-label">التخصص / الصفة</label><input class="form-control" name="specialization" value="<?= e($t['specialization'] ?? '') ?>" maxlength="160" placeholder="مثال: طالب هندسة مدنية" data-pv="spec"></div>
            <div class="col-md-6"><label class="form-label">الخدمة</label>
              <select class="form-select" name="service_id" data-pv="service"><option value="">— بدون —</option>
                <?php foreach ($services as $sv): ?><option value="<?= (int) $sv['id'] ?>"<?= selected((string) ($t['service_id'] ?? ''), (string) $sv['id']) ?>><?= e($sv['cat'] . ' ← ' . $sv['name']) ?></option><?php endforeach; ?>
              </select></div>
            <div class="col-md-6"><label class="form-label">أو اسم خدمة حر</label><input class="form-control" name="service_label" value="<?= e($t['service_label'] ?? '') ?>" maxlength="200" data-pv="service_label"></div>
            <div class="col-12"><label class="form-label">التقييم</label>
              <div class="star-input" id="rating-input">
                <?php for ($i = 5; $i >= 1; $i--): ?><input type="radio" name="rating" id="r<?= $i ?>" value="<?= $i ?>"<?= (int) $t['rating'] === $i ? ' checked' : '' ?>><label for="r<?= $i ?>" title="<?= $i ?> نجوم"><i class="bi bi-star-fill"></i></label><?php endfor; ?>
              </div></div>
            <div class="col-12"><label class="form-label">نص الرأي *</label><textarea class="form-control" name="body" rows="5" maxlength="2000" required data-pv="body"><?= e($t['body']) ?></textarea></div>
            <div class="col-md-6"><label class="form-label">رقم الطلب المرتبط (للتوثيق)</label><input class="form-control mono" name="request_ref" value="<?= e($t['request_ref'] ?? '') ?>" placeholder="IKH-..."></div>
            <div class="col-md-6 d-flex flex-column justify-content-end gap-1">
              <div class="form-check"><input class="form-check-input" type="checkbox" name="is_verified" value="1" id="iv"<?= !empty($t['is_verified']) ? ' checked' : '' ?> data-pv="verified"><label class="form-check-label" for="iv">شارة «عميل موثّق» (تعامل معنا فعلًا)</label></div>
              <div class="form-check"><input class="form-check-input" type="checkbox" name="is_pinned" value="1" id="ip"<?= !empty($t['is_pinned']) ? ' checked' : '' ?>><label class="form-check-label" for="ip">تثبيت في المقدمة</label></div>
            </div>
          </div>
        </div>
        <div class="panel">
          <h2 class="panel-title">الصور (بموافقة العميل)</h2>
          <div class="row g-3">
            <?php foreach (['avatar' => 'الصورة الشخصية', 'attachment' => 'مرفق/لقطة (اختياري)', 'bg_image' => 'صورة خلفية البطاقة (لقالب «صورة»)'] as $f => $lbl): ?>
              <div class="col-md-4">
                <label class="form-label small"><?= e($lbl) ?></label>
                <?php if (!empty($t[$f])): ?><img src="<?= e(media_url($t[$f], true)) ?>" alt="" class="img-thumbnail d-block mb-1" style="max-height:90px">
                  <div class="form-check small"><input class="form-check-input" type="checkbox" name="remove_<?= $f ?>" value="1" id="rm<?= $f ?>"><label class="form-check-label" for="rm<?= $f ?>">إزالة</label></div><?php endif; ?>
                <input type="file" class="form-control form-control-sm" name="<?= $f ?>" accept="image/jpeg,image/png,image/webp" data-preview-file="<?= $f ?>">
              </div>
            <?php endforeach; ?>
          </div>
          <div class="form-text">JPG/PNG/WEBP — تُحوَّل إلى WebP وتُضغط تلقائيًا. الصورة القديمة لا تُحذف إلا عند استبدالها، ولا تُحذف إن كانت مستخدمة في مكان آخر.</div>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="panel position-sticky" style="top:80px">
          <h2 class="panel-title">التصميم والمعاينة</h2>
          <label class="form-label">قالب البطاقة</label>
          <select class="form-select mb-2" name="theme" data-pv="theme">
            <?php foreach ($themes as $k => $l): ?><option value="<?= e($k) ?>"<?= selected($t['theme'] ?? 'white', $k) ?>><?= e($l) ?></option><?php endforeach; ?>
          </select>
          <div class="row g-2 mb-2 align-items-end">
            <div class="col-auto form-check ms-1"><input class="form-check-input" type="checkbox" name="use_colors" value="1" id="uc"<?= !empty($t['bg_color']) || !empty($t['text_color']) ? ' checked' : '' ?> data-pv="use_colors"><label class="form-check-label small" for="uc">ألوان مخصصة</label></div>
            <div class="col"><label class="form-label small mb-0">الخلفية</label><input type="color" class="form-control form-control-color w-100" name="bg_color" value="<?= e($t['bg_color'] ?: '#0b1f3a') ?>" data-pv="bg"></div>
            <div class="col"><label class="form-label small mb-0">النص</label><input type="color" class="form-control form-control-color w-100" name="text_color" value="<?= e($t['text_color'] ?: '#ffffff') ?>" data-pv="fg"></div>
          </div>
          <label class="form-label small">الأيقونة</label>
          <select class="form-select form-select-sm mb-3" name="icon" data-pv="icon">
            <?php foreach (['bi-quote' => 'علامة اقتباس', 'bi-chat-quote' => 'فقاعة اقتباس', 'bi-heart-fill' => 'قلب', 'bi-award' => 'وسام', 'bi-mortarboard' => 'قبعة تخرج', 'bi-stars' => 'نجوم', 'bi-hand-thumbs-up' => 'إعجاب', 'bi-patch-check' => 'توثيق'] as $ic => $il): ?>
              <option value="<?= $ic ?>"<?= selected($t['icon'] ?? 'bi-quote', $ic) ?>><?= e($il) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="t-preview-wrap mb-3" id="t-preview" data-themes='<?= e(json_encode(array_keys($themes))) ?>'><?= render_testimonial_card($previewData) ?></div>
          <label class="form-label">الحالة</label>
          <select class="form-select mb-2" name="status">
            <option value="pending"<?= selected($t['status'], 'pending') ?>>بانتظار المراجعة</option>
            <option value="approved"<?= selected($t['status'], 'approved') ?>>معتمد ومنشور</option>
            <option value="hidden"<?= selected($t['status'], 'hidden') ?>>مخفي</option>
          </select>
          <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="consent_publish" value="1" id="cp"<?= !empty($t['consent_publish']) ? ' checked' : '' ?>><label class="form-check-label" for="cp"><strong>العميل وافق على نشر رأيه</strong> (وصورته/مرفقه إن وُجدا)</label></div>
          <button class="btn btn-primary w-100"><i class="bi bi-check2-circle"></i> حفظ</button>
        </div>
      </div>
    </div>
  </form>
<?php else:
    $where = 't.deleted_at IS NULL';
    $params = [];
    if (in_array($tab, ['pending', 'approved', 'hidden'], true)) { $where .= ' AND t.status = ?'; $params[] = $tab; }
    $q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 80);
    if ($q !== '') { $where .= ' AND (t.name LIKE ? OR t.body LIKE ?)'; $params[] = "%$q%"; $params[] = "%$q%"; }
    $rows = db_all("SELECT t.*, s.name service_name FROM testimonials t LEFT JOIN services s ON s.id = t.service_id WHERE $where ORDER BY t.status = 'pending' DESC, t.is_pinned DESC, t.sort_order, t.id DESC LIMIT 200", $params);
    $stLabels = ['pending' => ['بانتظار المراجعة', 'warning text-dark'], 'approved' => ['منشور', 'success'], 'hidden' => ['مخفي', 'secondary']];
?>
  <div class="row g-3 mb-3">
    <?php foreach ([['bi-chat-quote', 'إجمالي الآراء', (int) $stats['total']], ['bi-check2-circle', 'منشورة', (int) $stats['approved']], ['bi-hourglass-split', 'بانتظار المراجعة', (int) $stats['pending']], ['bi-star-half', 'متوسط التقييم', $stats['avg'] ? number_format((float) $stats['avg'], 1) . ' / 5' : '—']] as [$ic, $lb, $v]): ?>
      <div class="col-6 col-lg-3"><div class="panel py-3 mb-0 d-flex align-items-center gap-2"><i class="bi <?= $ic ?> fs-3 text-warning"></i><div><div class="small text-muted"><?= e($lb) ?></div><strong class="fs-5"><?= e((string) $v) ?></strong></div></div></div>
    <?php endforeach; ?>
  </div>
  <div class="row g-3">
    <div class="col-xl-8">
      <div class="panel">
        <div class="d-flex flex-wrap gap-2 align-items-center mb-3">
          <ul class="nav nav-pills">
            <?php foreach (['all' => 'الكل', 'pending' => 'بانتظار المراجعة', 'approved' => 'منشورة', 'hidden' => 'مخفية'] as $k => $l): ?>
              <li class="nav-item"><a class="nav-link py-1<?= $tab === $k ? ' active' : '' ?>" href="<?= e(admin_url('testimonials', $k === 'all' ? [] : ['status' => $k])) ?>"><?= e($l) ?></a></li>
            <?php endforeach; ?>
          </ul>
          <form class="d-flex gap-1 ms-auto"><?php if ($tab !== 'all'): ?><input type="hidden" name="status" value="<?= e($tab) ?>"><?php endif; ?><input class="form-control form-control-sm" name="q" value="<?= e($q) ?>" placeholder="بحث"><button class="btn btn-sm btn-light"><i class="bi bi-search"></i></button></form>
          <a class="btn btn-primary btn-sm" href="<?= e(admin_url('testimonials', ['new' => 1])) ?>"><i class="bi bi-plus-lg"></i> إضافة رأي</a>
        </div>
        <?php if (!$rows): ?><div class="text-center text-muted py-4"><i class="bi bi-chat-quote fs-1 d-block mb-2"></i>لا توجد آراء هنا بعد. أضف آراء عملائك الحقيقية (بموافقتهم) أو فعّل استقبال الآراء من الموقع.</div><?php endif; ?>
        <div class="table-responsive"><table class="table align-middle">
          <?php foreach ($rows as $r): [$sl, $sc] = $stLabels[$r['status']]; ?>
            <tr>
              <td style="width:46px"><?php if ($r['avatar']): ?><img src="<?= e(media_url($r['avatar'], true)) ?>" alt="" width="40" height="40" class="rounded-circle" style="object-fit:cover" loading="lazy"><?php else: ?><span class="t-avatar t-initial" style="width:40px;height:40px;font-size:1rem"><?= e(mb_substr($r['name'], 0, 1)) ?></span><?php endif; ?></td>
              <td>
                <strong><?= e($r['name']) ?></strong> <?php if ($r['is_verified']): ?><i class="bi bi-patch-check-fill text-primary" title="موثّق"></i><?php endif; ?><?php if ($r['is_pinned']): ?> <i class="bi bi-pin-angle-fill text-warning" title="مثبت"></i><?php endif; ?>
                <span class="badge bg-<?= $sc ?>"><?= $sl ?></span><?php if ($r['source'] === 'visitor'): ?> <span class="badge bg-light text-dark border">من الموقع</span><?php endif; ?><?php if (!$r['consent_publish']): ?> <span class="badge bg-danger-subtle text-danger">بدون موافقة نشر</span><?php endif; ?>
                <div><?= render_stars((int) $r['rating']) ?> <small class="text-muted"><?= e($r['service_name'] ?: ($r['service_label'] ?? '')) ?> — <?= e(ar_date($r['created_at'])) ?> — <?= e($themes[$r['theme']] ?? '') ?></small></div>
                <div class="small text-muted"><?= e(excerpt($r['body'], 130)) ?></div>
              </td>
              <td class="text-end text-nowrap">
                <?php if ($r['status'] !== 'approved'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="approve"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-success" title="اعتماد ونشر"><i class="bi bi-check-lg"></i></button></form><?php endif; ?>
                <?php if ($r['status'] === 'approved'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="hide"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-outline-secondary" title="إخفاء"><i class="bi bi-eye-slash"></i></button></form><?php endif; ?>
                <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="pin"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-outline-warning" title="تثبيت"><i class="bi bi-pin-angle"></i></button></form>
                <?= move_buttons((int) $r['id']) ?>
                <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('testimonials', ['edit' => $r['id']])) ?>" title="تعديل"><i class="bi bi-pencil"></i></a>
                <?= delete_button('delete', (int) $r['id'], 'نقل الرأي إلى سلة المحذوفات؟') ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </table></div>
      </div>
    </div>
    <div class="col-xl-4">
      <div class="panel">
        <h2 class="panel-title">إعدادات القسم</h2>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="settings">
          <?php foreach (['testimonials_enabled' => 'تفعيل آراء العملاء في الموقع', 'show_home_testimonials' => 'إظهار القسم في الصفحة الرئيسية', 'testimonials_show_avg' => 'إظهار متوسط التقييم الحقيقي', 'testimonials_allow_submit' => 'السماح للعملاء بإرسال آرائهم (تُراجع قبل النشر)'] as $k => $l): ?>
            <div class="form-check form-switch mb-2"><input class="form-check-input" type="checkbox" name="<?= $k ?>" value="1" id="<?= $k ?>"<?= setting($k, '1') === '1' ? ' checked' : '' ?>><label class="form-check-label small" for="<?= $k ?>"><?= e($l) ?></label></div>
          <?php endforeach; ?>
          <label class="form-label small mt-2">عنوان القسم</label><input class="form-control form-control-sm mb-2" name="testimonials_title" value="<?= e(setting('testimonials_title')) ?>">
          <label class="form-label small">الوصف</label><textarea class="form-control form-control-sm mb-2" name="testimonials_subtitle" rows="2"><?= e(setting('testimonials_subtitle')) ?></textarea>
          <div class="row g-2">
            <div class="col-12"><label class="form-label small">طريقة العرض</label><select class="form-select form-select-sm" name="testimonials_layout"><option value="slider"<?= selected(setting('testimonials_layout', 'slider'), 'slider') ?>>سلايدر متحرك</option><option value="grid"<?= selected(setting('testimonials_layout', 'slider'), 'grid') ?>>شبكة بطاقات</option></select></div>
            <div class="col-6"><label class="form-label small">العدد في الرئيسية</label><input type="number" class="form-control form-control-sm" name="testimonials_count" min="1" max="24" value="<?= (int) setting('testimonials_count', '6') ?>"></div>
            <div class="col-6"><label class="form-label small">مدة الانتقال (ث)</label><input type="number" class="form-control form-control-sm" name="testimonials_interval" min="2" max="30" value="<?= (int) setting('testimonials_interval', '6') ?>"></div>
          </div>
          <button class="btn btn-primary btn-sm w-100 mt-3">حفظ الإعدادات</button>
        </form>
        <hr>
        <p class="small text-muted mb-1"><i class="bi bi-shield-check"></i> تُعرض في الموقع الآراء المعتمدة والموافَق على نشرها فقط، ويُحسب متوسط التقييم وبيانات Schema منها فقط — لا آراء وهمية.</p>
        <a class="small" href="<?= e(route('review')) ?>" target="_blank">رابط نموذج إرسال الرأي للعملاء <i class="bi bi-box-arrow-up-left"></i></a>
      </div>
    </div>
  </div>
<?php endif;
admin_footer();
