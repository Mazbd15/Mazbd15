<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
if (is_post() && csrf_valid() && ($u = current_user())) {
    audit('logout', 'user', (int) $u['id'], 'تسجيل خروج');
    logout_user();
}
redirect(route('login'));
