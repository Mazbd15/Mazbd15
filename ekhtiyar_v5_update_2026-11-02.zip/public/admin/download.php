<?php
/** تنزيل آمن لمرفقات الطلبات (للإدارة وللمتخصص المسؤول عن الطلب) — الملفات خارج المجلد العام */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$att = db_one('SELECT a.*, r.category_id, r.assigned_to FROM request_attachments a JOIN requests r ON r.id = a.request_id WHERE a.id = ?', [(int) ($_GET['id'] ?? 0)]);
if (!$att) { http_response_code(404); exit('الملف غير موجود'); }
if (!can_view_request($user, $att)) { http_response_code(403); exit('لا تملك صلاحية تنزيل هذا الملف'); }

$base = realpath(config('uploads.path') . '/requests');
$path = realpath(config('uploads.path') . '/requests/' . basename($att['stored_name']));
if (!$base || !$path || !str_starts_with($path, $base . DIRECTORY_SEPARATOR) || !is_file($path)) {
    http_response_code(404); exit('الملف غير موجود');
}
audit('download', 'request', (int) $att['request_id'], $att['original_name']);

$name = $att['original_name'];
$ascii = preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
while (ob_get_level()) ob_end_clean();
header('Content-Type: application/octet-stream'); // إجبار التنزيل وعدم العرض داخل المتصفح
header('Content-Disposition: attachment; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($name));
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header("Content-Security-Policy: default-src 'none'; sandbox");
readfile($path);
exit;
