<?php
/**
 * ترتيب بالسحب والإفلات (v5) — نقطة AJAX واحدة لكل القوائم.
 * محمية بـ CSRF (ترويسة X-CSRF-Token) والصلاحيات ونطاق أقسام المتخصص.
 * تعيد توزيع قيم الترتيب الحالية للعناصر المرسلة فقط (آمن مع الفلاتر والترقيم).
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = current_admin();
if (!$user) json_response(['ok' => false, 'error' => 'انتهت الجلسة، سجّل الدخول مجددًا.'], 401);
if (!is_post() || !csrf_valid()) json_response(['ok' => false, 'error' => 'انتهت صلاحية الصفحة، حدّثها ثم أعد المحاولة.'], 419);

// مفتاح الصفحة => [الجدول، عمود النطاق، أدنى دور، عمود القسم للتحقق]
$map = [
    'categories'    => ['categories', null, 'admin', 'id'],
    'subcategories' => ['subcategories', 'category_id', 'specialist', 'category_id'],
    'services'      => ['services', 'subcategory_id', 'specialist', 'category_id'],
    'banners'       => ['banners', 'category_id', 'specialist', 'category_id'],
    'portfolio'     => ['portfolio_items', 'category_id', 'specialist', 'category_id'],
    'testimonials'  => ['testimonials', null, 'editor', null],
    'pages'         => ['posts', 'type', 'editor', null],
];
$in = json_decode((string) file_get_contents('php://input'), true) ?: [];
$key = (string) ($in['page'] ?? '');
$ids = array_values(array_unique(array_filter(array_map('intval', (array) ($in['ids'] ?? [])))));
if (!isset($map[$key]) || count($ids) < 2 || count($ids) > 500) json_response(['ok' => false, 'error' => 'طلب غير صالح.'], 422);
[$table, $scopeCol, $minRole, $catCol] = $map[$key];
if (!role_at_least($user['role'], $minRole)) json_response(['ok' => false, 'error' => 'لا تملك صلاحية الترتيب هنا.'], 403);

$ph = implode(',', array_fill(0, count($ids), '?'));
$cols = 'id, sort_order' . ($scopeCol ? ", `$scopeCol` AS scope" : '') . ($catCol && $catCol !== 'id' ? ", `$catCol` AS cat" : '');
$rows = array_column(db_all("SELECT $cols FROM `$table` WHERE id IN ($ph)", $ids), null, 'id');
if (count($rows) !== count($ids)) json_response(['ok' => false, 'error' => 'بعض العناصر غير موجودة. حدّث الصفحة.'], 409);
if ($scopeCol && count(array_unique(array_map(fn($r) => (string) $r['scope'], $rows))) > 1)
    json_response(['ok' => false, 'error' => 'لا يمكن الترتيب بين مجموعات مختلفة. اختر قسمًا/تخصصًا واحدًا من الفلتر أولًا.'], 422);
if ($catCol) foreach ($rows as $r) {
    $cid = $catCol === 'id' ? (int) $r['id'] : ($r['cat'] !== null ? (int) $r['cat'] : null);
    if ($key === 'banners' && $cid === null) { if (!role_at_least($user['role'], 'editor')) json_response(['ok' => false, 'error' => 'بنرات الرئيسية للمحرر فأعلى.'], 403); continue; }
    if (!can_manage_category($user, $cid)) json_response(['ok' => false, 'error' => 'أحد العناصر خارج نطاق صلاحياتك.'], 403);
}
$orders = array_map(fn($r) => (int) $r['sort_order'], array_values($rows));
sort($orders);
for ($i = 1; $i < count($orders); $i++) if ($orders[$i] <= $orders[$i - 1]) $orders[$i] = $orders[$i - 1] + 1;
$pdo = db();
$pdo->beginTransaction();
try {
    foreach ($ids as $i => $id) db_exec("UPDATE `$table` SET sort_order = ? WHERE id = ?", [$orders[$i], $id]);
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('[sort] ' . $e->getMessage());
    json_response(['ok' => false, 'error' => 'تعذر حفظ الترتيب.'], 500);
}
audit('reorder', $table, null, implode(',', $ids));
json_response(['ok' => true]);
