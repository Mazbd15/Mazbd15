<?php
/** تم توحيد صفحة الدخول — التحويل إلى /login */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/bootstrap.php';
redirect(route('login', ['next' => admin_url()]));
