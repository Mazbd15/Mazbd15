<?php
/**
 * العملاء (v5): عرض موحّد للعملاء من الطلبات والحسابات المسجلة ورسائل التواصل.
 * لا يُنشئ جداول جديدة — يجمع البيانات الموجودة حسب وسيلة التواصل.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('editor');

$q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100);
$like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
$where = $q !== '' ? 'WHERE (r.customer_name LIKE ? OR r.contact_value LIKE ? OR r.email LIKE ?)' : '';
$params = $q !== '' ? [$like, $like, $like] : [];

// تجميع حسب وسيلة التواصل (رقم/بريد) — العميل الواحد قد يملك عدة طلبات
$base = "FROM requests r $where GROUP BY r.contact_value";
$total = (int) db_value("SELECT COUNT(*) FROM (SELECT r.contact_value $base) x", $params);
$pg = paginate($total, 30, (int) ($_GET['page'] ?? 1));
$rows = db_all("SELECT r.contact_value, MAX(r.customer_name) name, MAX(r.email) email, MAX(r.contact_method) method, MAX(r.member_id) member_id,
        COUNT(*) orders, SUM(r.status = 'completed') done, SUM(r.status IN ('new','reviewing','awaiting_client','in_progress')) open_orders,
        MIN(r.created_at) first_at, MAX(r.created_at) last_at
    $base ORDER BY last_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);

if (isset($_GET['export'])) {
    $all = db_all("SELECT r.contact_value, MAX(r.customer_name) name, MAX(r.email) email, COUNT(*) orders, SUM(r.status = 'completed') done, MAX(r.created_at) last_at $base ORDER BY last_at DESC", $params);
    audit('export', 'customers', null, count($all) . ' rows');
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="customers-' . date('Ymd') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    $safe = fn($v) => preg_match('/^[=+\-@]/', (string) $v) ? "'" . $v : (string) $v;
    fputcsv($out, ['الاسم', 'وسيلة التواصل', 'البريد', 'عدد الطلبات', 'المكتملة', 'آخر طلب'], ',', '"', '\\');
    foreach ($all as $r) fputcsv($out, array_map($safe, [$r['name'], $r['contact_value'], $r['email'], $r['orders'], $r['done'], $r['last_at']]), ',', '"', '\\');
    fclose($out);
    exit;
}

$members = (int) db_value("SELECT COUNT(*) FROM users WHERE role = 'member'");
$repeat = (int) db_value('SELECT COUNT(*) FROM (SELECT contact_value FROM requests GROUP BY contact_value HAVING COUNT(*) > 1) x');
$msgSenders = schema_v5() ? (int) db_value('SELECT COUNT(DISTINCT COALESCE(phone, email)) FROM contact_messages WHERE deleted_at IS NULL') : 0;

admin_header('العملاء', 'customers', $user);
?>
<div class="row g-3 mb-3">
  <?php foreach ([['bi-people', 'عملاء لديهم طلبات', $total], ['bi-arrow-repeat', 'عملاء متكررون', $repeat], ['bi-person-badge', 'حسابات مسجلة', $members], ['bi-envelope', 'مرسلو رسائل', $msgSenders]] as [$ic, $lb, $v]): ?>
    <div class="col-6 col-lg-3"><div class="panel py-3 mb-0 d-flex align-items-center gap-2"><i class="bi <?= $ic ?> fs-3 text-warning"></i><div><div class="small text-muted"><?= e($lb) ?></div><strong class="fs-5"><?= (int) $v ?></strong></div></div></div>
  <?php endforeach; ?>
</div>
<div class="panel">
  <form class="d-flex gap-2 mb-3">
    <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="بحث بالاسم أو الجوال أو البريد">
    <button class="btn btn-primary"><i class="bi bi-search"></i></button>
    <a class="btn btn-outline-success" href="<?= e(admin_url('customers', array_filter(['q' => $q, 'export' => 1]))) ?>" title="تصدير CSV"><i class="bi bi-filetype-csv"></i></a>
  </form>
  <?php if (!$rows): ?><div class="text-center text-muted py-4"><i class="bi bi-people fs-1 d-block mb-2"></i>لا يوجد عملاء مطابقون. يظهر العملاء هنا عند حفظ طلباتهم بموافقتهم.</div><?php else: ?>
  <div class="table-responsive"><table class="table align-middle">
    <thead><tr><th>العميل</th><th>التواصل</th><th>الطلبات</th><th>آخر طلب</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r):
        $num = preg_replace('/\D+/', '', (string) $r['contact_value']);
        if (str_starts_with($num, '05')) $num = '966' . substr($num, 1); ?>
      <tr>
        <td><strong><?= e($r['name']) ?></strong><?php if ($r['member_id']): ?> <span class="badge bg-info-subtle text-info">حساب مسجل</span><?php endif; ?><div class="small text-muted">أول طلب: <?= e(ar_date($r['first_at'])) ?></div></td>
        <td class="small"><span dir="ltr"><?= e($r['contact_value']) ?></span><?php if ($r['email']): ?><div><?= e($r['email']) ?></div><?php endif; ?></td>
        <td><span class="badge bg-primary"><?= (int) $r['orders'] ?></span> <span class="small text-success"><?= (int) $r['done'] ?> مكتمل</span><?php if ($r['open_orders']): ?> <span class="small text-warning"><?= (int) $r['open_orders'] ?> مفتوح</span><?php endif; ?></td>
        <td class="small"><?= e(ar_date($r['last_at'], true)) ?></td>
        <td class="text-end text-nowrap">
          <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('requests', ['q' => $r['contact_value']])) ?>" title="طلباته"><i class="bi bi-inbox"></i></a>
          <?php if ($r['method'] === 'whatsapp' && strlen($num) >= 9): ?><a class="btn btn-sm btn-outline-success" href="https://wa.me/<?= e($num) ?>" target="_blank" rel="noopener" title="واتساب"><i class="bi bi-whatsapp"></i></a><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?= pagination_links($pg, array_filter(['q' => $q])) ?>
  <?php endif; ?>
  <p class="small text-muted mb-0 mt-2"><i class="bi bi-shield-lock"></i> بيانات العملاء خاصة — لا تُشارك خارج فريق العمل. عند طلب العميل حذف بياناته احذف طلباته من صفحة الطلبات.</p>
</div>
<?php admin_footer();
