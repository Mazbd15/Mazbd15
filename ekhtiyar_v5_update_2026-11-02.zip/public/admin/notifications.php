<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

// فتح إشعار: تعليمه كمقروء ثم التوجيه لرابطه (داخلي فقط)
if (isset($_GET['open'])) {
    $n = db_one('SELECT * FROM notifications WHERE id = ? AND user_id = ?', [(int) $_GET['open'], $user['id']]);
    if ($n) {
        db_exec('UPDATE notifications SET read_at = COALESCE(read_at, NOW()) WHERE id = ?', [$n['id']]);
        redirect(safe_next($n['link'], admin_url('notifications')));
    }
    redirect(admin_url('notifications'));
}
if (is_post()) {
    require_csrf();
    $a = $_POST['action'] ?? '';
    if ($a === 'read_all') db_exec('UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [$user['id']]);
    if ($a === 'clear') db_exec('DELETE FROM notifications WHERE user_id = ? AND read_at IS NOT NULL', [$user['id']]);
    if ($a === 'delete') db_exec('DELETE FROM notifications WHERE id = ? AND user_id = ?', [(int) ($_POST['id'] ?? 0), $user['id']]);
    redirect(admin_url('notifications'));
}

$total = (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [$user['id']]);
$pg = paginate($total, 30, (int) ($_GET['page'] ?? 1));
$rows = db_all("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", [$user['id']]);

admin_header('الإشعارات', 'notifications', $user);
?>
<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
  <p class="text-muted mb-0"><?= $total ?> إشعار</p>
  <div class="d-flex gap-2">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="read_all"><button class="btn btn-sm btn-outline-primary"><i class="bi bi-check2-all"></i> تعليم الكل كمقروء</button></form>
    <form method="post" data-confirm="حذف كل الإشعارات المقروءة؟"><?= csrf_field() ?><input type="hidden" name="action" value="clear"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> حذف المقروءة</button></form>
  </div>
</div>
<div class="panel p-0">
  <?php if (!$rows): ?><div class="p-4 text-center text-muted"><i class="bi bi-bell-slash fs-2 d-block mb-2"></i>لا توجد إشعارات.</div><?php endif; ?>
  <ul class="list-group list-group-flush">
  <?php foreach ($rows as $n): ?>
    <li class="list-group-item d-flex gap-3 align-items-start<?= $n['read_at'] ? '' : ' notif-unread' ?>">
      <i class="bi <?= $n['read_at'] ? 'bi-bell' : 'bi-bell-fill text-warning' ?> fs-5"></i>
      <div class="flex-grow-1">
        <a class="fw-bold text-decoration-none" href="<?= e(admin_url('notifications', ['open' => $n['id']])) ?>"><?= e($n['title']) ?></a>
        <?php if ($n['body']): ?><div class="small text-muted"><?= e($n['body']) ?></div><?php endif; ?>
        <small class="text-muted"><?= e(ar_date($n['created_at'], true)) ?></small>
      </div>
      <?= delete_button('delete', (int) $n['id'], 'حذف الإشعار؟') ?>
    </li>
  <?php endforeach; ?>
  </ul>
</div>
<?= pagination_links($pg, []) ?>
<?php admin_footer();
