<?php
/**
 * تحديث قاعدة البيانات (الترقيات الآمنة)
 * - يعرض الترقيات المطبّقة والمعلّقة.
 * - قبل التطبيق: نسخة احتياطية إلزامية لقاعدة البيانات.
 * - الترقيات إضافية فقط (جداول/أعمدة/إعدادات جديدة) ولا تحذف بيانات.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('super_admin');

$result = null;
if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'run') {
        if (empty($_POST['confirm'])) {
            flash('warning', 'يرجى تأكيد أنك تريد تطبيق التحديث.');
            redirect(admin_url('update'));
        }
        [$ok, $msg] = backup_create('pre-migration', !empty($_POST['with_files']));
        if (!$ok) {
            flash('danger', 'أُلغي التحديث لأن النسخة الاحتياطية فشلت: ' . $msg);
            redirect(admin_url('update'));
        }
        $result = migrations_run();
        $errors = array_filter($result, fn($r) => $r[0] !== 'ok');
        audit('migrate', 'database', null, 'backup=' . $msg . '; ' . implode(', ', array_map(fn($r) => $r[0] . ':' . $r[1], $result)));
        flash($errors ? 'danger' : 'success', $errors ? 'توقف التحديث عند خطأ — راجع التفاصيل. نسختك الاحتياطية: ' . $msg : 'تم تحديث قاعدة البيانات بنجاح. نسخة ما قبل التحديث: ' . $msg);
        $_SESSION['_mig_result'] = $result;
        redirect(admin_url('update'));
    }
    if ($action === 'rollback') {
        $name = (string) ($_POST['name'] ?? '');
        if (($_POST['confirm_text'] ?? '') !== 'تراجع') {
            flash('warning', 'للتراجع اكتب كلمة «تراجع» للتأكيد.');
            redirect(admin_url('update'));
        }
        [$ok, $msg] = backup_create('pre-migration', false);
        if (!$ok) { flash('danger', 'تعذر إنشاء نسخة احتياطية قبل التراجع: ' . $msg); redirect(admin_url('update')); }
        $r = migration_rollback($name);
        audit('migrate_rollback', 'database', null, $name . ' => ' . $r[0]);
        flash($r[0] === 'ok' ? 'success' : 'danger', $r[2] . ' (نسخة احتياطية: ' . $msg . ')');
        redirect(admin_url('update'));
    }
}

$result = $_SESSION['_mig_result'] ?? null;
unset($_SESSION['_mig_result']);
$all = migrations_all();
$applied = migrations_applied();
$pending = migrations_pending();

admin_header('تحديث قاعدة البيانات', 'update', $user);
?>
<div class="row g-3">
  <div class="col-lg-7">
    <div class="panel">
      <h2 class="panel-title"><i class="bi bi-database-gear"></i> حالة الترقيات</h2>
      <p class="text-muted small">الإصدار الحالي لقاعدة البيانات: <strong><?= e((string) setting('db_version', '?')) ?></strong>. الترقيات إضافية فقط: تُنشئ جداول وأعمدة وإعدادات جديدة ولا تحذف أو تستبدل أي بيانات موجودة.</p>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>الترقية</th><th>الوصف</th><th>الحالة</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($all as $name => $def): $done = isset($applied[$name]); ?>
            <tr>
              <td class="mono small"><?= e($name) ?></td>
              <td><?= e($def['title'] ?? '') ?></td>
              <td><?= $done ? '<span class="badge bg-success">مطبّقة ' . e(ar_date($applied[$name]['applied_at'] ?? null, true)) . '</span>' : '<span class="badge bg-warning text-dark">معلّقة</span>' ?></td>
              <td>
                <?php if ($done && isset($def['down'])): ?>
                  <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#rb-<?= e(md5($name)) ?>">تراجع</button>
                <?php endif; ?>
              </td>
            </tr>
            <?php if ($done && isset($def['down'])): ?>
            <tr class="collapse" id="rb-<?= e(md5($name)) ?>"><td colspan="4">
              <form method="post" class="d-flex flex-wrap gap-2 align-items-center bg-light p-2 rounded">
                <?= csrf_field() ?><input type="hidden" name="action" value="rollback"><input type="hidden" name="name" value="<?= e($name) ?>">
                <span class="small text-danger"><i class="bi bi-exclamation-triangle"></i> التراجع يحذف الجداول/الأعمدة التي أضافتها هذه الترقية (وبياناتها). تُؤخذ نسخة احتياطية أولًا.</span>
                <input class="form-control form-control-sm w-auto" name="confirm_text" placeholder="اكتب: تراجع" required>
                <button class="btn btn-sm btn-danger">تأكيد التراجع</button>
              </form>
            </td></tr>
            <?php endif; ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php if ($result): ?>
      <div class="panel">
        <h2 class="panel-title">نتيجة آخر تشغيل</h2>
        <?php foreach ($result as [$st, $n, $info]): ?>
          <div class="health-row"><i class="bi <?= $st === 'ok' ? 'bi-check-circle-fill health-ok' : 'bi-x-circle-fill health-bad' ?>"></i><span class="mono"><?= e($n) ?></span><span class="small text-muted"><?= e($info) ?></span></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
  <div class="col-lg-5">
    <div class="panel">
      <h2 class="panel-title">تطبيق التحديث</h2>
      <?php if (!$pending): ?>
        <div class="alert alert-success mb-0"><i class="bi bi-check2-circle"></i> قاعدة البيانات محدّثة — لا توجد ترقيات معلّقة.</div>
      <?php else: ?>
        <ol class="small">
          <li>تُنشأ نسخة احتياطية كاملة لقاعدة البيانات تلقائيًا (وتُحفظ في مجلد محمي).</li>
          <li>تُطبّق <?= count($pending) ?> ترقية بالترتيب، ويتوقف التنفيذ عند أول خطأ.</li>
          <li>لا يُعاد التثبيت، ولا تُستورد بيانات تجريبية، ولا يُحذف أي شيء.</li>
        </ol>
        <form method="post">
          <?= csrf_field() ?><input type="hidden" name="action" value="run">
          <div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="with_files" value="1" id="wf"><label class="form-check-label" for="wf">تضمين الصور والملفات المرفوعة في النسخة (أبطأ)</label></div>
          <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="confirm" value="1" id="cf" required><label class="form-check-label" for="cf">أؤكد تطبيق التحديث بعد أخذ النسخة الاحتياطية</label></div>
          <button class="btn btn-primary w-100"><i class="bi bi-play-circle"></i> نسخ احتياطي ثم تحديث</button>
        </form>
      <?php endif; ?>
      <hr>
      <p class="small text-muted mb-0">بديل عبر SSH: <code class="mono">php database/migrate.php</code></p>
    </div>
  </div>
</div>
<?php admin_footer();
