<?php
/**
 * إدارة المستخدمين: فريق الإدارة، المتخصصون (مع اعتماد طلبات الانضمام وتحديد الأقسام)، والأعضاء.
 * - المسؤول (admin): يدير المتخصصين والأعضاء.
 * - المدير العام (super_admin): يدير الجميع بما فيهم حسابات الإدارة.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('admin');

$tabs = [
    'pending'     => ['bi-hourglass-split', 'طلبات الانضمام'],
    'specialists' => ['bi-person-badge', 'المتخصصون'],
    'staff'       => ['bi-shield-lock', 'فريق الإدارة'],
    'members'     => ['bi-people', 'الأعضاء'],
];
$tab = isset($tabs[$_GET['tab'] ?? '']) ? $_GET['tab'] : (isset($_GET['status']) && $_GET['status'] === 'pending' ? 'pending' : 'specialists');
if ($tab === 'staff' && !can($user, 'users.staff')) $tab = 'specialists';
$back = fn(array $extra = []) => admin_url('users', array_merge(['tab' => $tab], $extra));

/** هل يحق للمستخدم الحالي إدارة الحساب المستهدف؟ */
function can_manage_target(array $me, array $t): bool
{
    if (can($me, 'users.staff')) return true;
    return in_array($t['role'], ['specialist', 'member'], true);
}
/** الأدوار التي يمكن للمستخدم الحالي منحها */
function grantable_roles(array $me): array
{
    return can($me, 'users.staff') ? ['super_admin', 'admin', 'editor', 'specialist', 'member'] : ['specialist', 'member'];
}
$superCount = fn() => (int) db_value("SELECT COUNT(*) FROM users WHERE role = 'super_admin' AND status = 'active'");
$allCats = db_all('SELECT id, name FROM categories ORDER BY sort_order, id');

$errors = [];
$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);

if (is_post()) {
    require_csrf();
    $action = (string) ($_POST['action'] ?? '');
    $id = (int) ($_POST['id'] ?? 0);
    $target = $id ? db_one('SELECT * FROM users WHERE id = ?', [$id]) : null;

    if ($action !== 'save' && (!$target || !can_manage_target($user, $target))) {
        flash('danger', 'لا تملك صلاحية إدارة هذا الحساب.');
        redirect($back());
    }
    $self = $target && (int) $target['id'] === (int) $user['id'];
    $lastSuper = $target && $target['role'] === 'super_admin' && $superCount() <= 1;

    switch ($action) {
        case 'approve':
            db_exec("UPDATE users SET status = 'active', review_note = NULL, approved_by = ?, approved_at = NOW() WHERE id = ?", [$user['id'], $id]);
            if (isset($_POST['cats'])) save_user_categories($id, (array) $_POST['cats']);
            notify($id, 'تم اعتماد حسابك 🎉', 'يمكنك الآن تسجيل الدخول وإدارة أقسامك من لوحة التحكم.', admin_url());
            audit('approve', 'user', $id, $target['email']);
            flash('success', 'تم اعتماد الحساب «' . $target['name'] . '».');
            break;
        case 'reject':
            $note = mb_substr(trim((string) ($_POST['review_note'] ?? '')), 0, 500) ?: null;
            db_exec("UPDATE users SET status = 'rejected', review_note = ? WHERE id = ?", [$note, $id]);
            audit('reject', 'user', $id, $target['email'] . ($note ? ' — ' . $note : ''));
            flash('info', 'تم رفض طلب «' . $target['name'] . '».');
            break;
        case 'suspend':
            if ($self || $lastSuper) { flash('danger', 'لا يمكن إيقاف هذا الحساب.'); break; }
            db_exec("UPDATE users SET status = 'suspended' WHERE id = ?", [$id]);
            audit('suspend', 'user', $id, $target['email']);
            flash('warning', 'تم إيقاف الحساب.');
            break;
        case 'activate':
            db_exec("UPDATE users SET status = 'active', approved_by = COALESCE(approved_by, ?), approved_at = COALESCE(approved_at, NOW()) WHERE id = ?", [$user['id'], $id]);
            audit('activate', 'user', $id, $target['email']);
            flash('success', 'تم تفعيل الحساب.');
            break;
        case 'categories':
            save_user_categories($id, (array) ($_POST['cats'] ?? []));
            notify($id, 'تم تحديث أقسامك', 'عدّلت الإدارة الأقسام المسندة إليك.', admin_url());
            audit('categories', 'user', $id, $target['email']);
            flash('success', 'تم حفظ الأقسام المسندة.');
            break;
        case 'reset_password':
            $temp = 'Ik' . random_int(1000, 9999) . bin2hex(random_bytes(3));
            db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($temp, PASSWORD_DEFAULT), $id]);
            audit('reset_password', 'user', $id, $target['email']);
            flash('success', "كلمة المرور المؤقتة لـ «{$target['name']}»: $temp — أرسلها له بشكل آمن واطلب منه تغييرها فور الدخول.");
            break;
        case 'delete':
            if ($self || $lastSuper) { flash('danger', 'لا يمكن حذف هذا الحساب.'); break; }
            db_exec('DELETE FROM users WHERE id = ?', [$id]);
            audit('delete', 'user', $id, $target['email']);
            flash('success', 'تم حذف الحساب.');
            break;
        case 'save':
            if ($target && !can_manage_target($user, $target)) { flash('danger', 'لا تملك صلاحية.'); redirect($back()); }
            $data = [
                'name'           => mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120),
                'email'          => mb_strtolower(trim((string) ($_POST['email'] ?? ''))),
                'phone'          => mb_substr(trim((string) ($_POST['phone'] ?? '')), 0, 30) ?: null,
                'role'           => (string) ($_POST['role'] ?? 'member'),
                'status'         => (string) ($_POST['status'] ?? 'active'),
                'specialization' => mb_substr(trim((string) ($_POST['specialization'] ?? '')), 0, 190) ?: null,
                'bio'            => trim((string) ($_POST['bio'] ?? '')) ?: null,
            ];
            $pw = (string) ($_POST['password'] ?? '');
            if ($data['name'] === '') $errors[] = 'الاسم مطلوب.';
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'البريد الإلكتروني غير صالح.';
            elseif (db_value('SELECT id FROM users WHERE email = ? AND id <> ?', [$data['email'], $id])) $errors[] = 'البريد مستخدم لحساب آخر.';
            if (!in_array($data['role'], grantable_roles($user), true)) $errors[] = 'لا يمكنك منح هذا الدور.';
            if (!isset(status_labels()[$data['status']])) $data['status'] = 'active';
            if (!$target && $pw === '') $errors[] = 'كلمة المرور مطلوبة للحساب الجديد.';
            if ($pw !== '' && ($p = password_problems($pw))) $errors[] = $p;
            if ($self && ($data['role'] !== $target['role'] || $data['status'] !== 'active')) $errors[] = 'لا يمكنك تغيير دورك أو حالة حسابك.';
            if ($target && $target['role'] === 'super_admin' && ($data['role'] !== 'super_admin' || $data['status'] !== 'active') && $superCount() <= 1) $errors[] = 'يجب بقاء مدير عام واحد مفعّل على الأقل.';
            if (!$errors) {
                if ($pw !== '') $data['password_hash'] = password_hash($pw, PASSWORD_DEFAULT);
                if ($data['status'] === 'active' && (!$target || $target['status'] !== 'active')) { $data['approved_by'] = $user['id']; $data['approved_at'] = date('Y-m-d H:i:s'); }
                if ($target) { db_update('users', $data, $id); audit('update', 'user', $id, $data['email'] . ' / ' . $data['role']); }
                else { $id = db_insert('users', $data); audit('create', 'user', $id, $data['email'] . ' / ' . $data['role']); }
                if ($data['role'] === 'specialist') save_user_categories($id, (array) ($_POST['cats'] ?? []));
                else db_exec('DELETE FROM user_categories WHERE user_id = ?', [$id]);
                flash('success', 'تم حفظ الحساب.');
                $tab = match ($data['role']) { 'specialist' => 'specialists', 'member' => 'members', default => 'staff' };
                redirect($back());
            }
            $editId = $id; $isNew = !$id;
            $formData = $data + ['id' => $id, 'cats' => array_map('intval', (array) ($_POST['cats'] ?? []))];
            break;
    }
    if (!$errors) redirect($back());
}

function save_user_categories(int $uid, array $cats): void
{
    db_exec('DELETE FROM user_categories WHERE user_id = ?', [$uid]);
    $valid = array_map('intval', array_column(db_all('SELECT id FROM categories'), 'id'));
    foreach (array_unique(array_map('intval', $cats)) as $c) {
        if (in_array($c, $valid, true)) db_exec('INSERT IGNORE INTO user_categories (user_id, category_id) VALUES (?, ?)', [$uid, $c]);
    }
}
function user_cat_ids(int $uid): array
{
    return array_map('intval', array_column(db_all('SELECT category_id FROM user_categories WHERE user_id = ?', [$uid]), 'category_id'));
}
function cat_picker(array $all, array $selected, string $name = 'cats[]'): string
{
    $h = '<div class="cat-picker">';
    foreach ($all as $c) {
        $h .= '<label class="cat-chip"><input type="checkbox" name="' . $name . '" value="' . (int) $c['id'] . '"' . (in_array((int) $c['id'], $selected, true) ? ' checked' : '') . '><span>' . e($c['name']) . '</span></label>';
    }
    return $h . '</div>';
}

$counts = db_one("SELECT
    SUM(status = 'pending') pending,
    SUM(role = 'specialist' AND status <> 'pending') specialists,
    SUM(role IN ('super_admin','admin','editor')) staff,
    SUM(role = 'member') members FROM users");

admin_header('المستخدمون والمتخصصون', 'users', $user);

// ---------------- نموذج إضافة / تعديل ----------------
if ($editId || $isNew):
    $u = $formData ?? ($editId ? db_one('SELECT * FROM users WHERE id = ?', [$editId]) : null);
    if ($editId && (!$u || !can_manage_target($user, $u))) { echo '<div class="alert alert-danger">لا تملك صلاحية تعديل هذا الحساب.</div>'; admin_footer(); exit; }
    $u ??= ['id' => 0, 'name' => '', 'email' => '', 'phone' => '', 'role' => ($_GET['role'] ?? 'specialist'), 'status' => 'active', 'specialization' => '', 'bio' => ''];
    if (!in_array($u['role'], grantable_roles($user), true)) $u['role'] = 'specialist';
    $selCats = $u['cats'] ?? ($editId ? user_cat_ids($editId) : []);
    ?>
    <div class="panel">
      <h2 class="panel-title"><?= $editId ? 'تعديل الحساب' : 'إضافة حساب جديد' ?></h2>
      <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
      <form method="post" autocomplete="off">
        <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">الاسم *</label><input class="form-control" name="name" required maxlength="120" value="<?= e($u['name']) ?>"></div>
          <div class="col-md-6"><label class="form-label">البريد الإلكتروني *</label><input class="form-control" type="email" name="email" required dir="ltr" value="<?= e($u['email']) ?>"></div>
          <div class="col-md-4"><label class="form-label">الجوال</label><input class="form-control" name="phone" dir="ltr" value="<?= e($u['phone'] ?? '') ?>"></div>
          <div class="col-md-4"><label class="form-label">الدور</label>
            <select class="form-select" name="role" data-role-select>
              <?php foreach (grantable_roles($user) as $r): ?><option value="<?= $r ?>"<?= selected($u['role'], $r) ?>><?= e(role_labels()[$r]) ?></option><?php endforeach; ?>
            </select></div>
          <div class="col-md-4"><label class="form-label">الحالة</label>
            <select class="form-select" name="status">
              <?php foreach (status_labels() as $k => [$l]): ?><option value="<?= $k ?>"<?= selected($u['status'], $k) ?>><?= e($l) ?></option><?php endforeach; ?>
            </select></div>
          <div class="col-md-6"><label class="form-label"><?= $editId ? 'كلمة مرور جديدة (اتركها فارغة للإبقاء)' : 'كلمة المرور *' ?></label>
            <input class="form-control" type="password" name="password" autocomplete="new-password" minlength="10" dir="ltr"><div class="form-text">10 أحرف على الأقل، حروف وأرقام.</div></div>
          <div class="col-md-6" data-specialist-only><label class="form-label">التخصص</label><input class="form-control" name="specialization" maxlength="190" value="<?= e($u['specialization'] ?? '') ?>" placeholder="مثال: هندسة مدنية، برمجة، تصميم"></div>
          <div class="col-12" data-specialist-only><label class="form-label">نبذة</label><textarea class="form-control" name="bio" rows="3"><?= e($u['bio'] ?? '') ?></textarea></div>
          <div class="col-12" data-specialist-only><label class="form-label">الأقسام المسموح بإدارتها</label><?= cat_picker($allCats, $selCats) ?>
            <div class="form-text">يستطيع المتخصص تعديل الخدمات والتفرعات والصور الإعلانية والأسئلة واستلام الطلبات في هذه الأقسام فقط.</div></div>
        </div>
        <div class="mt-4 d-flex gap-2"><button class="btn btn-primary"><i class="bi bi-check2"></i> حفظ</button><a class="btn btn-light" href="<?= e($back()) ?>">إلغاء</a></div>
      </form>
    </div>
<?php
    admin_footer();
    exit;
endif;

// ---------------- القوائم ----------------
$q = trim((string) ($_GET['q'] ?? ''));
$where = match ($tab) {
    'pending'     => "u.status = 'pending'",
    'specialists' => "u.role = 'specialist' AND u.status <> 'pending'",
    'staff'       => "u.role IN ('super_admin','admin','editor')",
    'members'     => "u.role = 'member' AND u.status <> 'pending'",
};
$params = [];
if ($q !== '') { $where .= ' AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ? OR u.specialization LIKE ?)'; $like = '%' . $q . '%'; array_push($params, $like, $like, $like, $like); }
$total = (int) db_value("SELECT COUNT(*) FROM users u WHERE $where", $params);
$pg = paginate($total, 25, (int) ($_GET['page'] ?? 1));
$rows = db_all("SELECT u.*, a.name approver,
    (SELECT GROUP_CONCAT(c.name ORDER BY c.sort_order SEPARATOR '، ') FROM user_categories uc JOIN categories c ON c.id = uc.category_id WHERE uc.user_id = u.id) cat_names,
    (SELECT COUNT(*) FROM requests r WHERE r.member_id = u.id) req_count,
    (SELECT COUNT(*) FROM requests r WHERE r.assigned_to = u.id AND r.status IN ('new','reviewing','awaiting_client')) open_assigned
    FROM users u LEFT JOIN users a ON a.id = u.approved_by WHERE $where ORDER BY u.created_at DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
?>
<ul class="nav nav-pills admin-tabs mb-3 flex-wrap">
  <?php foreach ($tabs as $k => [$ic, $label]): if ($k === 'staff' && !can($user, 'users.staff')) continue; ?>
    <li class="nav-item"><a class="nav-link<?= $tab === $k ? ' active' : '' ?>" href="<?= e(admin_url('users', ['tab' => $k])) ?>"><i class="bi <?= $ic ?>"></i> <?= e($label) ?>
      <span class="badge <?= $k === 'pending' && $counts['pending'] ? 'bg-danger' : 'bg-secondary' ?>"><?= (int) $counts[$k] ?></span></a></li>
  <?php endforeach; ?>
</ul>

<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
  <form class="d-flex gap-2" method="get"><input type="hidden" name="tab" value="<?= e($tab) ?>">
    <input class="form-control form-control-sm" name="q" value="<?= e($q) ?>" placeholder="بحث بالاسم أو البريد أو التخصص"><button class="btn btn-sm btn-outline-secondary"><i class="bi bi-search"></i></button></form>
  <div class="d-flex gap-2">
    <a class="btn btn-sm btn-primary" href="<?= e(admin_url('users', ['new' => 1, 'role' => 'specialist', 'tab' => $tab])) ?>"><i class="bi bi-person-plus"></i> متخصص جديد</a>
    <?php if (can($user, 'users.staff')): ?><a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('users', ['new' => 1, 'role' => 'editor', 'tab' => $tab])) ?>"><i class="bi bi-shield-plus"></i> حساب إداري</a><?php endif; ?>
  </div>
</div>

<?php if ($tab === 'pending'): ?>
  <?php if (!$rows): ?><div class="panel text-center text-muted py-5"><i class="bi bi-inbox fs-1 d-block mb-2"></i>لا توجد طلبات انضمام بانتظار المراجعة.</div><?php endif; ?>
  <div class="row g-3">
  <?php foreach ($rows as $r): $sel = user_cat_ids((int) $r['id']); ?>
    <div class="col-lg-6"><div class="panel h-100 join-card">
      <div class="d-flex gap-3 align-items-start mb-2">
        <span class="avatar-circle"><?= e(mb_substr($r['name'], 0, 1)) ?></span>
        <div class="flex-grow-1"><strong><?= e($r['name']) ?></strong> <span class="badge text-bg-light"><?= e(role_labels()[$r['role']]) ?></span>
          <div class="small text-muted" dir="ltr"><?= e($r['email']) ?><?= $r['phone'] ? ' · ' . e($r['phone']) : '' ?></div>
          <div class="small text-muted">تاريخ الطلب: <?= e(ar_date($r['created_at'], true)) ?></div></div>
      </div>
      <?php if ($r['specialization']): ?><div class="mb-1"><i class="bi bi-mortarboard text-warning"></i> <strong>التخصص:</strong> <?= e($r['specialization']) ?></div><?php endif; ?>
      <?php if ($r['bio']): ?><p class="small bg-light rounded p-2 mb-2"><?= nl2br(e($r['bio'])) ?></p><?php endif; ?>
      <form method="post" class="mb-2"><?= csrf_field() ?><input type="hidden" name="action" value="approve"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
        <label class="form-label small fw-bold">الأقسام المطلوبة (يمكنك تعديلها قبل الاعتماد):</label>
        <?= cat_picker($allCats, $sel) ?>
        <button class="btn btn-success btn-sm mt-2"><i class="bi bi-check-circle"></i> اعتماد الحساب</button>
      </form>
      <form method="post" class="d-flex gap-2" data-confirm="رفض طلب الانضمام؟"><?= csrf_field() ?><input type="hidden" name="action" value="reject"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
        <input class="form-control form-control-sm" name="review_note" maxlength="500" placeholder="سبب الرفض (يظهر للمتقدم عند محاولة الدخول)">
        <button class="btn btn-outline-danger btn-sm text-nowrap"><i class="bi bi-x-circle"></i> رفض</button>
      </form>
    </div></div>
  <?php endforeach; ?>
  </div>
<?php else: ?>
  <div class="panel p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
    <thead><tr><th>المستخدم</th><th><?= $tab === 'members' ? 'الطلبات' : ($tab === 'specialists' ? 'الأقسام' : 'الدور') ?></th><th>الحالة</th><th>آخر دخول</th><th class="text-end">إجراءات</th></tr></thead>
    <tbody>
    <?php if (!$rows): ?><tr><td colspan="5" class="text-center text-muted py-4">لا توجد حسابات.</td></tr><?php endif; ?>
    <?php foreach ($rows as $r): [$sl, $sc] = status_labels()[$r['status']]; $isSelf = (int) $r['id'] === (int) $user['id']; $manage = can_manage_target($user, $r); ?>
      <tr>
        <td><div class="d-flex gap-2 align-items-center"><span class="avatar-circle sm"><?= e(mb_substr($r['name'], 0, 1)) ?></span>
          <div><strong><?= e($r['name']) ?></strong><?= $isSelf ? ' <span class="badge text-bg-info">أنت</span>' : '' ?>
            <div class="small text-muted" dir="ltr"><?= e($r['email']) ?></div>
            <?php if ($r['specialization']): ?><div class="small text-muted"><?= e($r['specialization']) ?></div><?php endif; ?></div></div></td>
        <td class="small">
          <?php if ($tab === 'members'): ?><?= (int) $r['req_count'] ?> طلب
          <?php elseif ($tab === 'specialists'): ?><?= $r['cat_names'] ? e($r['cat_names']) : '<span class="text-danger">لا توجد أقسام</span>' ?>
            <?php if ($r['open_assigned']): ?><br><span class="badge text-bg-warning"><?= (int) $r['open_assigned'] ?> طلب مفتوح مسند</span><?php endif; ?>
          <?php else: ?><?= e(role_labels()[$r['role']]) ?><?php endif; ?>
        </td>
        <td><span class="badge text-bg-<?= $sc ?>"><?= e($sl) ?></span>
          <?php if ($r['status'] === 'rejected' && $r['review_note']): ?><div class="small text-muted"><?= e($r['review_note']) ?></div><?php endif; ?></td>
        <td class="small text-muted"><?= e(ar_date($r['last_login_at'], true)) ?></td>
        <td class="text-end text-nowrap">
          <?php if ($manage): ?>
            <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('users', ['edit' => $r['id'], 'tab' => $tab])) ?>" title="تعديل"><i class="bi bi-pencil"></i></a>
            <?php if (!$isSelf): ?>
              <?php if ($r['status'] === 'active'): ?>
                <form method="post" class="d-inline" data-confirm="إيقاف الحساب؟"><?= csrf_field() ?><input type="hidden" name="action" value="suspend"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-outline-warning" title="إيقاف"><i class="bi bi-pause-circle"></i></button></form>
              <?php else: ?>
                <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="activate"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-outline-success" title="تفعيل"><i class="bi bi-play-circle"></i></button></form>
              <?php endif; ?>
              <form method="post" class="d-inline" data-confirm="إنشاء كلمة مرور مؤقتة جديدة لهذا الحساب؟"><?= csrf_field() ?><input type="hidden" name="action" value="reset_password"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-outline-secondary" title="كلمة مرور مؤقتة"><i class="bi bi-key"></i></button></form>
              <?= delete_button('delete', (int) $r['id'], 'حذف الحساب «' . $r['name'] . '» نهائيًا؟ (تبقى طلباته محفوظة بدون ربط)') ?>
            <?php endif; ?>
          <?php else: ?><span class="text-muted small">—</span><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div></div>
  <?= pagination_links($pg, ['tab' => $tab, 'q' => $q]) ?>
<?php endif;
admin_footer();
