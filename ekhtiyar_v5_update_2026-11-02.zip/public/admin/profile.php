<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin();
$errors = [];
if (is_post()) {
    require_csrf();
    $row = db_one('SELECT password_hash FROM users WHERE id = ?', [$user['id']]);
    $new = (string) ($_POST['new'] ?? '');
    if (!password_verify((string) ($_POST['current'] ?? ''), $row['password_hash'])) $errors[] = 'كلمة المرور الحالية غير صحيحة.';
    if ($p = password_problems($new)) $errors[] = $p;
    if (!hash_equals($new, (string) ($_POST['confirm'] ?? ''))) $errors[] = 'تأكيد كلمة المرور غير مطابق.';
    if (!$errors) {
        db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $user['id']]);
        session_regenerate_id(true);
        audit('password_change', 'user', (int) $user['id'], 'تغيير كلمة المرور');
        flash('success', 'تم تغيير كلمة المرور بنجاح.');
        redirect(admin_url('profile'));
    }
}
admin_header('تغيير كلمة المرور', '', $user);
?>
<div class="panel" style="max-width:520px">
  <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post">
    <?= csrf_field() ?>
    <div class="mb-3"><label class="form-label">كلمة المرور الحالية</label><input class="form-control" type="password" name="current" required autocomplete="current-password"></div>
    <div class="mb-3"><label class="form-label">كلمة المرور الجديدة</label><input class="form-control" type="password" name="new" required minlength="10" autocomplete="new-password"><div class="form-text">10 أحرف على الأقل، حروف وأرقام.</div></div>
    <div class="mb-4"><label class="form-label">تأكيد كلمة المرور الجديدة</label><input class="form-control" type="password" name="confirm" required minlength="10" autocomplete="new-password"></div>
    <button class="btn btn-primary">حفظ</button>
  </form>
</div>
<?php admin_footer();
