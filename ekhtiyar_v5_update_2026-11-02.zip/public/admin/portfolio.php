<?php
/**
 * معرض الأعمال السابقة (v4)
 * - لكل عمل: قسم + تخصص + خدمة مرتبطة (اختياري)، صورة غلاف، صور متعددة، ملفات (PDF/Word/PowerPoint/Excel/ZIP/DWG).
 * - الصور عامة (public/assets/images/uploads/portfolio)، والملفات خارج المجلد العام (storage/uploads/portfolio).
 * - المتخصص يدير أعمال أقسامه فقط.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$cats = scoped_categories($user);
[$subW, $subP] = scope_sql($user, 'category_id');
$subs = db_all("SELECT id, category_id, name FROM subcategories WHERE $subW" . sd('subcategories') . " ORDER BY sort_order, id", $subP);
$subMap = array_column($subs, null, 'id');
$svcs = db_all("SELECT id, category_id, subcategory_id, name FROM services WHERE $subW" . sd('services') . " ORDER BY sort_order, id", $subP);
$svcMap = array_column($svcs, null, 'id');

$fCat = (int) ($_GET['category'] ?? 0);
$fQ = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100);
$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);
$errors = [];
$back = admin_url('portfolio', array_filter(['category' => $fCat ?: null, 'q' => $fQ ?: null]));

if (is_post()) {
    require_csrf();
    $action = (string) ($_POST['action'] ?? '');
    $id = (int) ($_POST['id'] ?? 0);
    $row = $id ? db_one('SELECT * FROM portfolio_items WHERE id = ?', [$id]) : null;
    if ($id && (!$row || !can_manage_category($user, (int) $row['category_id']))) deny_scope($back);

    if ($action === 'delete' && $row) {
        if (soft_delete('portfolio_items', $id)) {
            audit('trash', 'portfolio', $id, $row['title']);
            flash('success', 'نُقل العمل إلى سلة المحذوفات (بصوره وملفاته) ويمكن استعادته.');
        } else {
            flash('warning', 'سلة المحذوفات تحتاج تحديث قاعدة البيانات أولًا — لم يُحذف شيء. يمكنك إخفاء العمل بدلًا من الحذف.');
        }
        redirect($back);
    }
    if ($action === 'toggle' && $row) {
        db_exec('UPDATE portfolio_items SET is_active = 1 - is_active, updated_by = ? WHERE id = ?', [$user['id'], $id]);
        audit('toggle', 'portfolio', $id, $row['title']);
        redirect($back);
    }
    if ($action === 'feature' && $row) {
        db_exec('UPDATE portfolio_items SET is_featured = 1 - is_featured WHERE id = ?', [$id]);
        redirect($back);
    }
    if ($action === 'move' && $row) {
        move_item('portfolio_items', $id, ($_POST['dir'] ?? '') === 'up' ? 'up' : 'down', 'category_id');
        redirect($back);
    }
    if ($row && in_array($action, ['delete_file', 'file_meta', 'file_move', 'set_cover'], true)) {
        $f = db_one('SELECT * FROM portfolio_files WHERE id = ? AND item_id = ?', [(int) ($_POST['file_id'] ?? 0), $id]);
        if ($f) {
            if ($action === 'delete_file') {
                $f['kind'] === 'image' ? delete_public_image($f['file_path']) : delete_portfolio_doc($f['file_path']);
                db_exec('DELETE FROM portfolio_files WHERE id = ?', [$f['id']]);
                audit('delete_file', 'portfolio', $id, $f['original_name'] ?: $f['file_path']);
                flash('success', 'تم حذف الملف.');
            } elseif ($action === 'file_meta') {
                db_exec('UPDATE portfolio_files SET caption = ?, is_downloadable = ? WHERE id = ?', [mb_substr(trim((string) ($_POST['caption'] ?? '')), 0, 255) ?: null, !empty($_POST['is_downloadable']) ? 1 : 0, $f['id']]);
                flash('success', 'تم تحديث بيانات الملف.');
            } elseif ($action === 'file_move') {
                // نطاق الترتيب: نفس العمل ونفس النوع
                $all = array_column(db_all('SELECT id FROM portfolio_files WHERE item_id = ? AND kind = ? ORDER BY sort_order, id', [$id, $f['kind']]), 'id');
                $pos = array_search($f['id'], $all);
                $swap = ($_POST['dir'] ?? '') === 'up' ? $pos - 1 : $pos + 1;
                if ($pos !== false && $swap >= 0 && $swap < count($all)) {
                    [$all[$pos], $all[$swap]] = [$all[$swap], $all[$pos]];
                    foreach ($all as $i => $fid) db_exec('UPDATE portfolio_files SET sort_order = ? WHERE id = ?', [($i + 1) * 10, $fid]);
                }
            } elseif ($action === 'set_cover' && $f['kind'] === 'image') {
                // الغلاف = أول صورة في الترتيب
                $all = array_column(db_all('SELECT id FROM portfolio_files WHERE item_id = ? AND kind = "image" AND id <> ? ORDER BY sort_order, id', [$id, $f['id']]), 'id');
                array_unshift($all, $f['id']);
                foreach ($all as $i => $fid) db_exec('UPDATE portfolio_files SET sort_order = ? WHERE id = ?', [($i + 1) * 10, $fid]);
                if ($row['cover_image']) { delete_public_image($row['cover_image']); db_exec('UPDATE portfolio_items SET cover_image = NULL WHERE id = ?', [$id]); }
                flash('success', 'أصبحت هذه الصورة غلاف العمل.');
            }
        }
        redirect(admin_url('portfolio', ['edit' => $id]) . '#files');
    }

    if ($action === 'save') {
        $cid = (int) ($_POST['category_id'] ?? 0);
        $sid = (int) ($_POST['subcategory_id'] ?? 0) ?: null;
        $svid = (int) ($_POST['service_id'] ?? 0) ?: null;
        $date = (string) ($_POST['completed_at'] ?? '');
        $data = [
            'category_id'      => $cid,
            'subcategory_id'   => $sid,
            'service_id'       => $svid,
            'title'            => mb_substr(trim((string) ($_POST['title'] ?? '')), 0, 190),
            'summary'          => mb_substr(trim((string) ($_POST['summary'] ?? '')), 0, 400) ?: null,
            'description'      => trim((string) ($_POST['description'] ?? '')) ?: null,
            'tools_text'       => mb_substr(trim((string) ($_POST['tools_text'] ?? '')), 0, 400) ?: null,
            'level_text'       => mb_substr(trim((string) ($_POST['level_text'] ?? '')), 0, 120) ?: null,
            'completed_at'     => preg_match('/^\d{4}-\d{2}(-\d{2})?$/', $date) ? (strlen($date) === 7 ? $date . '-01' : $date) : null,
            'is_featured'      => !empty($_POST['is_featured']) ? 1 : 0,
            'is_active'        => !empty($_POST['is_active']) ? 1 : 0,
            'meta_title'       => mb_substr(trim((string) ($_POST['meta_title'] ?? '')), 0, 190) ?: null,
            'meta_description' => mb_substr(trim((string) ($_POST['meta_description'] ?? '')), 0, 300) ?: null,
            'updated_by'       => $user['id'],
        ];
        if ($data['title'] === '') $errors[] = 'عنوان العمل مطلوب.';
        if (!$cid || !can_manage_category($user, $cid)) $errors[] = 'اختر قسمًا ضمن صلاحياتك.';
        if ($sid && (($subMap[$sid]['category_id'] ?? 0) != $cid)) $errors[] = 'التخصص لا يتبع القسم المختار.';
        if ($svid && (($svcMap[$svid]['category_id'] ?? 0) != $cid)) $errors[] = 'الخدمة المرتبطة لا تتبع القسم المختار.';
        $data['slug'] = unique_slug('portfolio_items', slugify(trim((string) ($_POST['slug'] ?? '')) ?: $data['title']), $id ?: null);

        if (!$errors && !empty($_FILES['cover']['name'])) {
            [$ok, $res] = store_public_image($_FILES['cover'], 'portfolio');
            if ($ok) { $data['cover_image'] = $res; if ($row) delete_public_image($row['cover_image']); }
            else $errors[] = 'صورة الغلاف: ' . $res;
        }
        if (!$errors && !empty($_POST['remove_cover']) && $row && $row['cover_image'] && empty($data['cover_image'])) {
            delete_public_image($row['cover_image']); $data['cover_image'] = null;
        }

        if (!$errors) {
            if ($row) {
                if ((int) $row['category_id'] !== $cid) $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM portfolio_items WHERE category_id = ?', [$cid]);
                db_update('portfolio_items', $data, $id);
                audit('update', 'portfolio', $id, $data['title']);
            } else {
                $data['created_by'] = $user['id'];
                $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM portfolio_items WHERE category_id = ?', [$cid]);
                $id = db_insert('portfolio_items', $data);
                audit('create', 'portfolio', $id, $data['title']);
            }
            // صور المعرض
            $nextSort = (int) db_value('SELECT COALESCE(MAX(sort_order),0) FROM portfolio_files WHERE item_id = ?', [$id]);
            $imgOk = 0;
            foreach (array_slice(normalize_files($_FILES['images'] ?? []), 0, 20) as $g) {
                [$ok, $res] = store_public_image($g, 'portfolio');
                if ($ok) {
                    db_insert('portfolio_files', ['item_id' => $id, 'kind' => 'image', 'file_path' => $res, 'original_name' => clean_original_name($g['name']), 'file_size' => (int) $g['size'], 'sort_order' => $nextSort += 10]);
                    $imgOk++;
                } else flash('warning', 'صورة لم تُرفع: ' . $res);
            }
            // الملفات
            $docOk = 0;
            $dl = !empty($_POST['docs_downloadable']) ? 1 : 0;
            foreach (array_slice(normalize_files($_FILES['docs'] ?? []), 0, 10) as $d) {
                [$ok, $res, $size] = store_portfolio_doc($d);
                if ($ok) {
                    db_insert('portfolio_files', ['item_id' => $id, 'kind' => 'document', 'file_path' => $res, 'original_name' => clean_original_name($d['name']), 'file_size' => $size, 'is_downloadable' => $dl, 'sort_order' => $nextSort += 10]);
                    $docOk++;
                } else flash('warning', 'ملف لم يُرفع: ' . $res);
            }
            flash('success', 'تم حفظ العمل' . ($imgOk ? " + $imgOk صورة" : '') . ($docOk ? " + $docOk ملف" : '') . '.');
            redirect(!empty($_POST['stay']) || $imgOk || $docOk ? admin_url('portfolio', ['edit' => $id]) . ($imgOk || $docOk ? '#files' : '') : $back);
        }
        $editId = $id; $isNew = !$id;
        $formData = $data + ['id' => $id, 'cover_image' => $row['cover_image'] ?? null];
    }
}

admin_header('معرض الأعمال', 'portfolio', $user);

if ($editId || $isNew):
    $it = $formData ?? ($editId ? db_one('SELECT * FROM portfolio_items WHERE id = ?', [$editId]) : null);
    if ($editId && (!$it || !can_manage_category($user, (int) $it['category_id']))) { echo '<div class="alert alert-danger">هذا العمل غير موجود أو خارج نطاق أقسامك.</div>'; admin_footer(); exit; }
    $it ??= ['category_id' => $fCat ?: ($cats[0]['id'] ?? 0), 'subcategory_id' => null, 'service_id' => null, 'title' => '', 'slug' => '', 'summary' => '', 'description' => '', 'tools_text' => '', 'level_text' => '', 'completed_at' => null, 'cover_image' => null, 'is_featured' => 0, 'is_active' => 1, 'meta_title' => '', 'meta_description' => ''];
    $images = $editId ? portfolio_files($editId, 'image') : [];
    $docs = $editId ? portfolio_files($editId, 'document') : [];
    ?>
    <?php if (!$cats): ?><div class="alert alert-warning">لم تُسند إليك أقسام بعد.</div><?php admin_footer(); exit; endif; ?>
    <form method="post" enctype="multipart/form-data" class="row g-3">
      <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
      <div class="col-12"><?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?></div>
      <div class="col-lg-8">
        <div class="panel">
          <h2 class="panel-title">بيانات العمل</h2>
          <div class="row g-3">
            <div class="col-12"><label class="form-label">عنوان العمل *</label><input class="form-control" name="title" required maxlength="190" value="<?= e($it['title']) ?>" placeholder="مثال: تصميم فيلا سكنية دورين — مشروع تخرج عمارة"></div>
            <div class="col-md-4"><label class="form-label">القسم *</label>
              <select class="form-select" name="category_id" id="svc-cat" required><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($it['category_id'], $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
            <div class="col-md-4"><label class="form-label">التخصص</label>
              <select class="form-select" name="subcategory_id" id="svc-sub" data-selected="<?= (int) $it['subcategory_id'] ?>"><option value="">— بدون —</option></select></div>
            <div class="col-md-4"><label class="form-label">الخدمة المرتبطة</label>
              <select class="form-select" name="service_id" id="pf-svc" data-selected="<?= (int) $it['service_id'] ?>"><option value="">— بدون —</option></select>
              <div class="form-text">يظهر العمل داخل صفحة هذه الخدمة.</div></div>
            <div class="col-12"><label class="form-label">ملخص قصير (يظهر في البطاقة ونتائج البحث)</label><input class="form-control" name="summary" maxlength="400" value="<?= e($it['summary']) ?>" data-count="400"></div>
            <div class="col-12"><label class="form-label">وصف العمل</label><textarea class="form-control" name="description" rows="6" placeholder="ما المطلوب؟ ماذا نفذنا؟ ما النتيجة؟ — الوصف الغني يساعد على الظهور في محركات البحث."><?= e($it['description']) ?></textarea></div>
            <div class="col-md-6"><label class="form-label">البرامج والأدوات</label><input class="form-control" name="tools_text" maxlength="400" value="<?= e($it['tools_text']) ?>" placeholder="AutoCAD, Revit, Lumion"></div>
            <div class="col-md-3"><label class="form-label">المستوى / النوع</label><input class="form-control" name="level_text" maxlength="120" list="levels" value="<?= e($it['level_text']) ?>">
              <datalist id="levels"><option value="مشروع تخرج"><option value="مقرر جامعي"><option value="ماجستير"><option value="دكتوراه"><option value="شركة / عميل"><option value="مشروع شخصي"></datalist></div>
            <div class="col-md-3"><label class="form-label">تاريخ الإنجاز</label><input class="form-control" type="month" name="completed_at" value="<?= e($it['completed_at'] ? substr($it['completed_at'], 0, 7) : '') ?>"></div>
          </div>
        </div>

        <div class="panel mt-3" id="files">
          <h2 class="panel-title">الصور والملفات</h2>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label"><i class="bi bi-images"></i> إضافة صور (حتى 20 دفعة واحدة)</label>
              <input class="form-control" type="file" name="images[]" multiple accept=".jpg,.jpeg,.png,.webp" data-multi-preview="#img-new-prev">
              <div class="form-text">JPG/PNG/WEBP حتى 3MB للصورة. أخفِ أي بيانات شخصية قبل الرفع.</div>
              <div class="d-flex flex-wrap gap-1 mt-2" id="img-new-prev"></div></div>
            <div class="col-md-6"><label class="form-label"><i class="bi bi-file-earmark-arrow-up"></i> إضافة ملفات</label>
              <input class="form-control" type="file" name="docs[]" multiple accept=".pdf,.docx,.pptx,.xlsx,.zip,.dwg">
              <div class="form-text">PDF / Word / PowerPoint / Excel / ZIP / DWG — حتى 20MB للملف. تُحفظ خارج المجلد العام.</div>
              <label class="form-check mt-1 small"><input class="form-check-input" type="checkbox" name="docs_downloadable" value="1" checked> السماح للزوار بتنزيلها (PDF يُعرض أيضًا داخل الموقع)</label></div>
            <div class="col-md-6"><label class="form-label">صورة غلاف مخصصة (اختياري)</label><input class="form-control" type="file" name="cover" accept=".jpg,.jpeg,.png,.webp">
              <div class="form-text">إن لم ترفع غلافًا تُستخدم أول صورة في المعرض.</div>
              <?php if (!empty($it['cover_image'])): ?><div class="mt-2 d-flex align-items-center gap-2"><img src="<?= e(url($it['cover_image'])) ?>" height="56" class="rounded border" alt=""><label class="small"><input type="checkbox" name="remove_cover" value="1"> إزالة الغلاف المخصص</label></div><?php endif; ?></div>
          </div>

          <?php if ($images): ?>
            <h3 class="h6 mt-4 mb-2">صور العمل (<?= count($images) ?>) <small class="text-muted fw-normal">— الأولى هي الغلاف</small></h3>
            <div class="pf-admin-grid">
              <?php foreach ($images as $i => $f): ?>
                <figure class="pf-admin-thumb<?= $i === 0 && empty($it['cover_image']) ? ' is-cover' : '' ?>">
                  <img src="<?= e(url($f['file_path'])) ?>" alt="" loading="lazy">
                  <figcaption>
                    <button class="btn btn-sm btn-light" form="fm-<?= $f['id'] ?>-up" title="تقديم"><i class="bi bi-arrow-right"></i></button>
                    <button class="btn btn-sm btn-light" form="fm-<?= $f['id'] ?>-down" title="تأخير"><i class="bi bi-arrow-left"></i></button>
                    <button class="btn btn-sm btn-warning" form="fc-<?= $f['id'] ?>" title="اجعلها الغلاف"><i class="bi bi-star"></i></button>
                    <button class="btn btn-sm btn-danger" form="fd-<?= $f['id'] ?>" title="حذف"><i class="bi bi-trash"></i></button>
                  </figcaption>
                  <input class="form-control form-control-sm mt-1" form="fx-<?= $f['id'] ?>" name="caption" value="<?= e($f['caption']) ?>" placeholder="وصف الصورة (ALT)" maxlength="255" data-autosave>
                </figure>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if ($docs): ?>
            <h3 class="h6 mt-4 mb-2">الملفات (<?= count($docs) ?>)</h3>
            <ul class="list-group">
              <?php foreach ($docs as $f): $ext = strtolower(pathinfo($f['file_path'], PATHINFO_EXTENSION)); ?>
                <li class="list-group-item d-flex flex-wrap gap-2 align-items-center">
                  <i class="bi <?= e(file_icon($ext)) ?> fs-4"></i>
                  <div class="flex-grow-1"><strong><?= e($f['original_name']) ?></strong><br><small class="text-muted"><?= format_bytes((int) $f['file_size']) ?> • <?= (int) $f['downloads'] ?> تنزيل</small></div>
                  <input class="form-control form-control-sm" style="max-width:220px" form="fx-<?= $f['id'] ?>" name="caption" value="<?= e($f['caption']) ?>" placeholder="عنوان الملف للزوار">
                  <label class="small"><input type="checkbox" form="fx-<?= $f['id'] ?>" name="is_downloadable" value="1"<?= checked($f['is_downloadable']) ?>> متاح للزوار</label>
                  <button class="btn btn-sm btn-outline-primary" form="fx-<?= $f['id'] ?>" title="حفظ"><i class="bi bi-check2"></i></button>
                  <a class="btn btn-sm btn-light" href="<?= e(route('work_file', ['id' => $f['id']]) . ($ext === 'pdf' ? '&view=1' : '')) ?>" target="_blank" title="معاينة"><i class="bi bi-eye"></i></a>
                  <button class="btn btn-sm btn-outline-danger" form="fd-<?= $f['id'] ?>" title="حذف"><i class="bi bi-trash"></i></button>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>

        <div class="panel mt-3">
          <h2 class="panel-title">تحسين محركات البحث (SEO)</h2>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">الرابط (slug)</label><input class="form-control" name="slug" value="<?= e($it['slug']) ?>" placeholder="تلقائي من العنوان"></div>
            <div class="col-md-6"><label class="form-label">عنوان الصفحة <small class="text-muted">(50–60 حرفًا مثالي)</small></label><input class="form-control" name="meta_title" maxlength="190" value="<?= e($it['meta_title']) ?>" data-count="60"></div>
            <div class="col-12"><label class="form-label">وصف الصفحة <small class="text-muted">(140–160 حرفًا مثالي — يُولَّد تلقائيًا إن تُرك فارغًا)</small></label><input class="form-control" name="meta_description" maxlength="300" value="<?= e($it['meta_description']) ?>" data-count="160"></div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="panel sticky-lg-top" style="top:80px">
          <h2 class="panel-title">النشر</h2>
          <label class="form-check mb-2"><input class="form-check-input" type="checkbox" name="is_active" value="1"<?= checked($it['is_active']) ?>> منشور (ظاهر في الموقع)</label>
          <label class="form-check mb-3"><input class="form-check-input" type="checkbox" name="is_featured" value="1"<?= checked($it['is_featured']) ?>> عمل مميز (يظهر في الرئيسية أولًا)</label>
          <div class="alert alert-light border small"><i class="bi bi-shield-check text-success"></i> انشر فقط أعمالًا لديك حق عرضها، وأخفِ أسماء الطلاب والجامعات والبيانات الشخصية.</div>
          <div class="d-grid gap-2">
            <button class="btn btn-primary"><i class="bi bi-check2"></i> حفظ</button>
            <button class="btn btn-outline-primary" name="stay" value="1"><i class="bi bi-save"></i> حفظ ومتابعة التعديل</button>
            <a class="btn btn-light" href="<?= e($back) ?>">رجوع للقائمة</a>
            <?php if ($editId && !empty($it['slug']) && $it['is_active']): ?><a class="btn btn-link" href="<?= e(route('work', ['slug' => $it['slug']])) ?>" target="_blank"><i class="bi bi-eye"></i> معاينة في الموقع</a><?php endif; ?>
          </div>
        </div>
      </div>
    </form>
    <?php
    $hid = fn(string $a, int $fid, string $extra = '') => csrf_field() . '<input type="hidden" name="action" value="' . $a . '"><input type="hidden" name="id" value="' . (int) $editId . '"><input type="hidden" name="file_id" value="' . $fid . '">' . $extra;
    foreach (array_merge($images, $docs) as $f): ?>
      <form method="post" id="fd-<?= $f['id'] ?>" data-confirm="حذف هذا الملف نهائيًا؟" hidden><?= $hid('delete_file', (int) $f['id']) ?></form>
      <form method="post" id="fx-<?= $f['id'] ?>" hidden><?= $hid('file_meta', (int) $f['id'], $f['kind'] === 'image' ? '<input type="hidden" name="is_downloadable" value="1">' : '') ?></form>
      <?php if ($f['kind'] === 'image'): ?>
        <form method="post" id="fc-<?= $f['id'] ?>" hidden><?= $hid('set_cover', (int) $f['id']) ?></form>
        <form method="post" id="fm-<?= $f['id'] ?>-up" hidden><?= $hid('file_move', (int) $f['id'], '<input type="hidden" name="dir" value="up">') ?></form>
        <form method="post" id="fm-<?= $f['id'] ?>-down" hidden><?= $hid('file_move', (int) $f['id'], '<input type="hidden" name="dir" value="down">') ?></form>
      <?php endif; ?>
    <?php endforeach; ?>
    <script type="application/json" id="subs-data"><?= json_encode(array_values($subs), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script>
    <script type="application/json" id="svcs-data"><?= json_encode(array_values($svcs), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script>
<?php else:
    [$sw, $sp] = scope_sql($user, 'p.category_id');
    $where = [$sw . sd('portfolio_items', 'p')]; $params = $sp;
    if ($fCat) { $where[] = 'p.category_id = ?'; $params[] = $fCat; }
    if ($fQ !== '') { $where[] = 'p.title LIKE ?'; $params[] = "%$fQ%"; }
    $w = implode(' AND ', $where);
    $total = (int) db_value("SELECT COUNT(*) FROM portfolio_items p WHERE $w", $params);
    $pg = paginate($total, 24, (int) ($_GET['page'] ?? 1));
    $rows = db_all("SELECT p.*, c.name cat, s.name svc,
        (SELECT COUNT(*) FROM portfolio_files f WHERE f.item_id = p.id AND f.kind='image') imgs,
        (SELECT COUNT(*) FROM portfolio_files f WHERE f.item_id = p.id AND f.kind='document') docs,
        (SELECT f.file_path FROM portfolio_files f WHERE f.item_id = p.id AND f.kind='image' ORDER BY f.sort_order, f.id LIMIT 1) first_image
        FROM portfolio_items p JOIN categories c ON c.id = p.category_id LEFT JOIN services s ON s.id = p.service_id
        WHERE $w ORDER BY c.sort_order, p.sort_order, p.id DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $params);
    ?>
    <?php if (!portfolio_enabled()): ?><div class="alert alert-warning"><i class="bi bi-eye-slash"></i> معرض الأعمال معطّل حاليًا في الموقع. فعّله من <a href="<?= e(admin_url('settings', ['tab' => 'portfolio'])) ?>">الإعدادات ← معرض الأعمال</a>.</div><?php endif; ?>
    <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
      <form method="get" class="d-flex gap-2 flex-wrap">
        <select class="form-select form-select-sm" name="category" data-autosubmit style="max-width:240px"><option value="">كل الأقسام</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($fCat, $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select>
        <input class="form-control form-control-sm" name="q" value="<?= e($fQ) ?>" placeholder="بحث بالعنوان" style="max-width:200px">
        <button class="btn btn-sm btn-light"><i class="bi bi-search"></i></button>
      </form>
      <?php if ($cats): ?><a class="btn btn-primary" href="<?= e(admin_url('portfolio', ['new' => 1] + ($fCat ? ['category' => $fCat] : []))) ?>"><i class="bi bi-plus-lg"></i> إضافة عمل</a><?php endif; ?>
    </div>
    <?php if (!$rows): ?>
      <div class="panel text-center py-5">
        <i class="bi bi-collection fs-1 text-warning d-block mb-2"></i>
        <h2 class="h5">لا توجد أعمال بعد</h2>
        <p class="text-muted">أضف صور أعمالك السابقة وملفاتها (PDF، عروض، مخططات) لكل قسم — تظهر في صفحة القسم والخدمة وصفحة «أعمالنا»، وتساعد على الظهور في بحث Google بالصور.</p>
        <?php if ($cats): ?><a class="btn btn-primary" href="<?= e(admin_url('portfolio', ['new' => 1])) ?>"><i class="bi bi-plus-lg"></i> أضف أول عمل</a><?php endif; ?>
      </div>
    <?php endif; ?>
    <div class="row g-3">
      <?php foreach ($rows as $r): $cover = $r['cover_image'] ?: $r['first_image']; ?>
        <div class="col-sm-6 col-xl-4"><div class="panel p-0 h-100 pf-admin-card<?= $r['is_active'] ? '' : ' is-off' ?>">
          <div class="pf-admin-cover"<?= $cover ? ' style="background-image:url(\'' . e(url($cover)) . '\')"' : '' ?>>
            <?php if (!$cover): ?><i class="bi bi-image"></i><?php endif; ?>
            <span class="badge text-bg-dark"><?= e($r['cat']) ?></span>
            <?php if ($r['is_featured']): ?><span class="badge text-bg-warning pf-feat"><i class="bi bi-star-fill"></i> مميز</span><?php endif; ?>
          </div>
          <div class="p-3">
            <strong class="d-block text-truncate"><?= e($r['title']) ?></strong>
            <div class="d-flex flex-wrap gap-1 my-2 small">
              <span class="badge text-bg-light"><i class="bi bi-images"></i> <?= (int) $r['imgs'] ?></span>
              <span class="badge text-bg-light"><i class="bi bi-file-earmark"></i> <?= (int) $r['docs'] ?></span>
              <span class="badge text-bg-light"><i class="bi bi-eye"></i> <?= (int) $r['views'] ?></span>
              <?php if ($r['svc']): ?><span class="badge text-bg-light text-truncate" style="max-width:160px"><i class="bi bi-link-45deg"></i> <?= e($r['svc']) ?></span><?php endif; ?>
            </div>
            <div class="d-flex flex-wrap gap-1 align-items-center">
              <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-link p-0"><?= active_badge($r['is_active']) ?></button></form>
              <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="feature"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-sm btn-light" title="تمييز"><i class="bi <?= $r['is_featured'] ? 'bi-star-fill text-warning' : 'bi-star' ?>"></i></button></form>
              <span class="ms-auto"></span>
              <?= move_buttons((int) $r['id']) ?>
              <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('portfolio', ['edit' => $r['id']])) ?>" title="تعديل"><i class="bi bi-pencil"></i></a>
              <?php if ($r['is_active']): ?><a class="btn btn-sm btn-light" href="<?= e(route('work', ['slug' => $r['slug']])) ?>" target="_blank" title="عرض"><i class="bi bi-box-arrow-up-left"></i></a><?php endif; ?>
              <?= delete_button('delete', (int) $r['id'], 'حذف العمل «' . $r['title'] . '» وكل صوره وملفاته؟') ?>
            </div>
          </div>
        </div></div>
      <?php endforeach; ?>
    </div>
    <div class="mt-3"><?= pagination_links($pg, array_filter(['category' => $fCat ?: null, 'q' => $fQ ?: null])) ?></div>
<?php endif;
admin_footer();
