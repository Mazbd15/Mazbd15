<?php
/**
 * مركز الرسائل (v5): رسائل نموذج التواصل
 * - حالات: جديدة / مقروءة / قيد المعالجة / تمت — ردود (واتساب/بريد/ملاحظة) وملاحظات داخلية.
 * - بحث وفلترة، حذف مؤقت (سلة المحذوفات)، تصدير CSV (يفتح في Excel)، ربط بطلب عبر الرقم المرجعي.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('editor');
require_v5('الرسائل', 'messages', $user);

$statuses = message_statuses();
$cats = contact_categories();
$fStatus = (string) ($_GET['status'] ?? '');
$fCat = (string) ($_GET['category'] ?? '');
$fQ = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100);
$viewId = (int) ($_GET['view'] ?? 0);
$listQuery = array_filter(['status' => $fStatus, 'category' => $fCat, 'q' => $fQ]);

function messages_where(string $st, string $cat, string $q): array
{
    $w = ['m.deleted_at IS NULL']; $p = [];
    if (isset(message_statuses()[$st])) { $w[] = 'm.status = ?'; $p[] = $st; }
    if (isset(contact_categories()[$cat])) { $w[] = 'm.category = ?'; $p[] = $cat; }
    if ($q !== '') {
        $w[] = '(m.name LIKE ? OR m.phone LIKE ? OR m.email LIKE ? OR m.subject LIKE ? OR m.body LIKE ? OR m.request_ref LIKE ?)';
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $q) . '%';
        array_push($p, $like, $like, $like, $like, $like, $like);
    }
    return [implode(' AND ', $w), $p];
}

// تصدير CSV (UTF-8 مع BOM ليفتح بالعربية في Excel)
if (isset($_GET['export'])) {
    [$w, $p] = messages_where($fStatus, $fCat, $fQ);
    $rows = db_all("SELECT m.* FROM contact_messages m WHERE $w ORDER BY m.id DESC", $p);
    audit('export', 'messages', null, count($rows) . ' rows');
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="messages-' . date('Ymd-His') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['الرقم', 'التاريخ', 'الاسم', 'الجوال', 'البريد', 'النوع', 'الموضوع', 'الرسالة', 'رقم الطلب', 'الحالة', 'ملاحظات داخلية'], ',', '"', '\\');
    foreach ($rows as $r) {
        // منع حقن الصيغ في Excel
        $safe = fn($v) => preg_match('/^[=+\-@]/', (string) $v) ? "'" . $v : (string) $v;
        fputcsv($out, array_map($safe, [$r['id'], $r['created_at'], $r['name'], $r['phone'], $r['email'], $cats[$r['category']] ?? $r['category'], $r['subject'], $r['body'], $r['request_ref'], $statuses[$r['status']][0] ?? $r['status'], $r['internal_notes']]), ',', '"', '\\');
    }
    fclose($out);
    exit;
}

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    $msg = $id ? db_one('SELECT * FROM contact_messages WHERE id = ? AND deleted_at IS NULL', [$id]) : null;
    $backView = admin_url('messages', ['view' => $id]);
    if ($action === 'bulk') {
        $ids = array_values(array_filter(array_map('intval', (array) ($_POST['ids'] ?? []))));
        $to = (string) ($_POST['bulk_action'] ?? '');
        if ($ids && (isset($statuses[$to]) || $to === 'delete')) {
            $in = implode(',', array_fill(0, count($ids), '?'));
            if ($to === 'delete') db_exec("UPDATE contact_messages SET deleted_at = NOW() WHERE id IN ($in)", $ids);
            else db_exec("UPDATE contact_messages SET status = ? WHERE id IN ($in)", array_merge([$to], $ids));
            audit('bulk_' . $to, 'messages', null, implode(',', $ids));
            flash('success', 'تم تحديث ' . count($ids) . ' رسالة.');
        }
        redirect(admin_url('messages', $listQuery));
    }
    if (!$msg) { flash('danger', 'الرسالة غير موجودة.'); redirect(admin_url('messages')); }
    if ($action === 'status' && isset($statuses[$_POST['status'] ?? ''])) {
        db_exec('UPDATE contact_messages SET status = ? WHERE id = ?', [$_POST['status'], $id]);
        audit('status', 'message', $id, $_POST['status']);
        flash('success', 'تم تحديث الحالة.');
    } elseif ($action === 'notes') {
        db_exec('UPDATE contact_messages SET internal_notes = ?, assigned_to = ? WHERE id = ?', [mb_substr(trim((string) ($_POST['internal_notes'] ?? '')), 0, 5000) ?: null, (int) ($_POST['assigned_to'] ?? 0) ?: null, $id]);
        flash('success', 'تم حفظ الملاحظات.');
    } elseif ($action === 'link') {
        $ref = mb_substr(strtoupper(trim((string) ($_POST['request_ref'] ?? ''))), 0, 30);
        $req = $ref !== '' ? db_one('SELECT id FROM requests WHERE reference = ?', [$ref]) : null;
        if ($ref !== '' && !$req) flash('warning', 'لا يوجد طلب بهذا الرقم.');
        else { db_exec('UPDATE contact_messages SET request_ref = ?, request_id = ? WHERE id = ?', [$ref ?: null, $req['id'] ?? null, $id]); flash('success', $ref ? 'تم ربط الرسالة بالطلب.' : 'تم فك الربط.'); }
    } elseif ($action === 'reply') {
        $channel = in_array($_POST['channel'] ?? '', ['whatsapp', 'email', 'note'], true) ? $_POST['channel'] : 'note';
        $body = mb_substr(trim((string) ($_POST['body'] ?? '')), 0, 3000);
        if ($body === '') { flash('warning', 'اكتب نص الرد.'); redirect($backView); }
        db_insert('message_replies', ['message_id' => $id, 'user_id' => $user['id'], 'channel' => $channel, 'body' => $body]);
        if ($msg['status'] === 'new' || $msg['status'] === 'read') db_exec("UPDATE contact_messages SET status = 'processing' WHERE id = ?", [$id]);
        audit('reply', 'message', $id, $channel);
        // فتح واتساب/البريد برسالة الرد الجاهزة (الإرسال الفعلي يتم من تطبيق المستخدم)
        if ($channel === 'whatsapp' && $msg['phone']) {
            $num = preg_replace('/\D+/', '', $msg['phone']);
            if (str_starts_with($num, '05')) $num = '966' . substr($num, 1);
            $_SESSION['_open_link'] = 'https://wa.me/' . $num . '?text=' . rawurlencode($body);
        } elseif ($channel === 'email' && $msg['email']) {
            $_SESSION['_open_link'] = 'mailto:' . $msg['email'] . '?subject=' . rawurlencode('رد: ' . ($msg['subject'] ?: 'رسالتك إلى ' . setting('site_name'))) . '&body=' . rawurlencode($body);
        }
        flash('success', $channel === 'note' ? 'تمت إضافة الملاحظة.' : 'سُجّل الرد. اضغط زر الفتح لإرساله من تطبيقك.');
    } elseif ($action === 'delete') {
        soft_delete('contact_messages', $id);
        audit('trash', 'message', $id, $msg['name']);
        flash('success', 'نُقلت الرسالة إلى سلة المحذوفات.');
        redirect(admin_url('messages', $listQuery));
    }
    redirect($backView);
}

$counts = array_column(db_all('SELECT status, COUNT(*) n FROM contact_messages WHERE deleted_at IS NULL GROUP BY status'), 'n', 'status');

if ($viewId) {
    $m = db_one('SELECT m.*, r.status req_status, r.id req_id FROM contact_messages m LEFT JOIN requests r ON r.id = m.request_id WHERE m.id = ? AND m.deleted_at IS NULL', [$viewId]);
    if (!$m) { flash('danger', 'الرسالة غير موجودة.'); redirect(admin_url('messages')); }
    if ($m['status'] === 'new') { db_exec("UPDATE contact_messages SET status = 'read' WHERE id = ?", [$viewId]); $m['status'] = 'read'; }
    $replies = db_all('SELECT mr.*, u.name uname FROM message_replies mr LEFT JOIN users u ON u.id = mr.user_id WHERE mr.message_id = ? ORDER BY mr.id', [$viewId]);
    $staff = db_all("SELECT id, name FROM users WHERE status = 'active' AND role IN ('super_admin','admin','editor','specialist') ORDER BY name");
    $openLink = $_SESSION['_open_link'] ?? null; unset($_SESSION['_open_link']);
    $same = db_all('SELECT id, subject, created_at, status FROM contact_messages WHERE id <> ? AND deleted_at IS NULL AND ((phone IS NOT NULL AND phone = ?) OR (email IS NOT NULL AND email = ?)) ORDER BY id DESC LIMIT 5', [$viewId, $m['phone'], $m['email']]);
}

admin_header('مركز الرسائل', 'messages', $user);
$chLabels = ['whatsapp' => ['واتساب', 'bi-whatsapp', 'success'], 'email' => ['بريد', 'bi-envelope', 'primary'], 'note' => ['ملاحظة داخلية', 'bi-sticky', 'secondary']];

if ($viewId): [$sl, $sc] = $statuses[$m['status']]; ?>
  <a class="btn btn-link px-0 mb-2" href="<?= e(admin_url('messages', $listQuery)) ?>"><i class="bi bi-arrow-right"></i> كل الرسائل</a>
  <?php if ($openLink): ?><div class="alert alert-success d-flex align-items-center gap-2"><i class="bi bi-send-check"></i> الرد جاهز للإرسال. <a class="btn btn-sm btn-success ms-auto" href="<?= e($openLink) ?>" target="_blank" rel="noopener">فتح وإرسال الرد</a></div><?php endif; ?>
  <div class="row g-3">
    <div class="col-lg-8">
      <div class="panel">
        <div class="d-flex flex-wrap align-items-start gap-2">
          <div>
            <h2 class="h5 mb-1"><?= e($m['subject'] ?: ($cats[$m['category']] ?? 'رسالة')) ?></h2>
            <div class="small text-muted">#<?= (int) $m['id'] ?> — <?= e(ar_date($m['created_at'], true)) ?> — <span class="badge bg-light text-dark border"><?= e($cats[$m['category']] ?? $m['category']) ?></span></div>
          </div>
          <span class="badge bg-<?= $sc ?> ms-auto fs-6"><?= e($sl) ?></span>
        </div>
        <hr>
        <div class="fs-6" style="white-space:pre-wrap;line-height:1.9"><?= e($m['body']) ?></div>
      </div>
      <div class="panel">
        <h2 class="panel-title">الردود والملاحظات (<?= count($replies) ?>)</h2>
        <?php if (!$replies): ?><p class="text-muted small">لا توجد ردود بعد.</p><?php endif; ?>
        <ul class="timeline mb-3">
          <?php foreach ($replies as $rp): [$cl, $ci, $cc] = $chLabels[$rp['channel']]; ?>
            <li><span class="badge bg-<?= $cc ?>"><i class="bi <?= $ci ?>"></i> <?= $cl ?></span> <small><?= e($rp['uname'] ?? '—') ?> — <?= e(ar_date($rp['created_at'], true)) ?></small>
              <div style="white-space:pre-wrap"><?= e($rp['body']) ?></div></li>
          <?php endforeach; ?>
        </ul>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="reply"><input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
          <textarea class="form-control mb-2" name="body" rows="4" required placeholder="اكتب الرد أو ملاحظة داخلية…">مرحبًا <?= e($m['name']) ?>، شكرًا لتواصلك مع <?= e(setting('site_name')) ?>.
</textarea>
          <div class="d-flex flex-wrap gap-2">
            <?php if ($m['phone']): ?><button class="btn btn-success" name="channel" value="whatsapp"><i class="bi bi-whatsapp"></i> رد عبر واتساب</button><?php endif; ?>
            <?php if ($m['email']): ?><button class="btn btn-primary" name="channel" value="email"><i class="bi bi-envelope"></i> رد بالبريد</button><?php endif; ?>
            <button class="btn btn-outline-secondary" name="channel" value="note"><i class="bi bi-sticky"></i> حفظ كملاحظة داخلية</button>
          </div>
        </form>
      </div>
    </div>
    <div class="col-lg-4">
      <div class="panel">
        <h2 class="panel-title">المرسل</h2>
        <p class="mb-1"><i class="bi bi-person"></i> <strong><?= e($m['name']) ?></strong></p>
        <?php if ($m['phone']): ?><p class="mb-1"><i class="bi bi-telephone"></i> <span dir="ltr"><?= e($m['phone']) ?></span></p><?php endif; ?>
        <?php if ($m['email']): ?><p class="mb-1"><i class="bi bi-envelope"></i> <a href="mailto:<?= e($m['email']) ?>"><?= e($m['email']) ?></a></p><?php endif; ?>
        <?php if ($same): ?><hr><div class="small fw-bold mb-1">رسائل سابقة من نفس المرسل</div>
          <?php foreach ($same as $o): ?><a class="d-block small" href="<?= e(admin_url('messages', ['view' => $o['id']])) ?>">#<?= (int) $o['id'] ?> <?= e($o['subject'] ?: 'رسالة') ?> — <?= e(ar_date($o['created_at'])) ?></a><?php endforeach; ?>
        <?php endif; ?>
      </div>
      <div class="panel">
        <h2 class="panel-title">الحالة</h2>
        <form method="post" class="d-flex gap-2"><?= csrf_field() ?><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
          <select class="form-select" name="status"><?php foreach ($statuses as $k => [$l]): ?><option value="<?= $k ?>"<?= selected($m['status'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select>
          <button class="btn btn-primary">حفظ</button></form>
      </div>
      <div class="panel">
        <h2 class="panel-title">الربط بطلب</h2>
        <?php if ($m['req_id']): ?><p class="small">مرتبطة بالطلب <a href="<?= e(admin_url('request_view', ['id' => $m['req_id']])) ?>" class="mono"><?= e($m['request_ref']) ?></a> — <?= e(request_statuses()[$m['req_status']] ?? $m['req_status']) ?></p>
        <?php elseif ($m['request_ref']): ?><p class="small text-warning">رقم مرجعي مكتوب من المرسل: <span class="mono"><?= e($m['request_ref']) ?></span> (غير مطابق لطلب)</p><?php endif; ?>
        <form method="post" class="d-flex gap-2"><?= csrf_field() ?><input type="hidden" name="action" value="link"><input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
          <input class="form-control mono" name="request_ref" value="<?= e($m['request_ref'] ?? '') ?>" placeholder="IKH-..."><button class="btn btn-outline-primary">ربط</button></form>
      </div>
      <div class="panel">
        <h2 class="panel-title">ملاحظات داخلية</h2>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="notes"><input type="hidden" name="id" value="<?= (int) $m['id'] ?>">
          <label class="form-label small">المسؤول</label>
          <select class="form-select form-select-sm mb-2" name="assigned_to"><option value="">— غير محدد —</option><?php foreach ($staff as $s): ?><option value="<?= (int) $s['id'] ?>"<?= selected((string) ($m['assigned_to'] ?? ''), (string) $s['id']) ?>><?= e($s['name']) ?></option><?php endforeach; ?></select>
          <textarea class="form-control mb-2" name="internal_notes" rows="4" placeholder="لا تظهر للعميل"><?= e($m['internal_notes'] ?? '') ?></textarea>
          <button class="btn btn-sm btn-primary w-100">حفظ الملاحظات</button></form>
        <hr>
        <?= delete_button('delete', (int) $m['id'], 'نقل الرسالة إلى سلة المحذوفات؟') ?> <span class="small text-muted">نقل إلى السلة</span>
      </div>
    </div>
  </div>
<?php else:
    [$w, $p] = messages_where($fStatus, $fCat, $fQ);
    $total = (int) db_value("SELECT COUNT(*) FROM contact_messages m WHERE $w", $p);
    $pg = paginate($total, 30, (int) ($_GET['page'] ?? 1));
    $rows = db_all("SELECT m.*, (SELECT COUNT(*) FROM message_replies r WHERE r.message_id = m.id) replies FROM contact_messages m WHERE $w ORDER BY m.status = 'new' DESC, m.id DESC LIMIT {$pg['limit']} OFFSET {$pg['offset']}", $p);
?>
  <div class="row g-3 mb-3">
    <?php foreach ($statuses as $k => [$l, $c]): ?>
      <div class="col-6 col-lg-3"><a class="panel py-3 mb-0 d-flex align-items-center gap-2 text-decoration-none text-reset" href="<?= e(admin_url('messages', ['status' => $k])) ?>">
        <span class="badge bg-<?= $c ?> fs-5"><?= (int) ($counts[$k] ?? 0) ?></span><span><?= e($l) ?></span></a></div>
    <?php endforeach; ?>
  </div>
  <div class="panel">
    <form class="row g-2 align-items-end mb-3">
      <div class="col-md-4"><input class="form-control" name="q" value="<?= e($fQ) ?>" placeholder="بحث بالاسم، الجوال، البريد، النص، رقم الطلب"></div>
      <div class="col-md-3"><select class="form-select" name="status"><option value="">كل الحالات</option><?php foreach ($statuses as $k => [$l]): ?><option value="<?= $k ?>"<?= selected($fStatus, $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-3"><select class="form-select" name="category"><option value="">كل الأنواع</option><?php foreach ($cats as $k => $l): ?><option value="<?= $k ?>"<?= selected($fCat, $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
      <div class="col-md-2 d-flex gap-1"><button class="btn btn-primary flex-fill"><i class="bi bi-funnel"></i></button>
        <a class="btn btn-outline-success" href="<?= e(admin_url('messages', $listQuery + ['export' => 1])) ?>" title="تصدير CSV / Excel"><i class="bi bi-filetype-csv"></i></a></div>
    </form>
    <?php if (!$rows): ?><div class="text-center text-muted py-4"><i class="bi bi-envelope-open fs-1 d-block mb-2"></i>لا توجد رسائل مطابقة.</div><?php else: ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="bulk">
      <div class="table-responsive"><table class="table align-middle">
        <thead><tr><th><input type="checkbox" class="form-check-input" data-check-all></th><th>المرسل</th><th>الموضوع</th><th>النوع</th><th>الحالة</th><th>التاريخ</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): [$sl, $sc] = $statuses[$r['status']]; ?>
          <tr class="<?= $r['status'] === 'new' ? 'fw-bold' : '' ?>">
            <td><input type="checkbox" class="form-check-input" name="ids[]" value="<?= (int) $r['id'] ?>"></td>
            <td><a href="<?= e(admin_url('messages', ['view' => $r['id']])) ?>"><?= e($r['name']) ?></a><div class="small text-muted fw-normal" dir="ltr"><?= e($r['phone'] ?: $r['email']) ?></div></td>
            <td><?= e($r['subject'] ?: excerpt($r['body'], 50)) ?><?php if ($r['request_ref']): ?> <span class="badge bg-light text-dark border mono"><?= e($r['request_ref']) ?></span><?php endif; ?><?php if ($r['replies']): ?> <span class="badge bg-info-subtle text-info"><i class="bi bi-reply"></i> <?= (int) $r['replies'] ?></span><?php endif; ?></td>
            <td class="small"><?= e($cats[$r['category']] ?? $r['category']) ?></td>
            <td><span class="badge bg-<?= $sc ?>"><?= e($sl) ?></span></td>
            <td class="small text-nowrap fw-normal"><?= e(ar_date($r['created_at'], true)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <div class="d-flex gap-2 align-items-center">
        <select class="form-select form-select-sm w-auto" name="bulk_action"><option value="">إجراء على المحدد…</option><?php foreach ($statuses as $k => [$l]): ?><option value="<?= $k ?>">تعيين: <?= e($l) ?></option><?php endforeach; ?><option value="delete">نقل إلى السلة</option></select>
        <button class="btn btn-sm btn-outline-primary" data-confirm="تطبيق الإجراء على الرسائل المحددة؟">تطبيق</button>
        <span class="ms-auto small text-muted"><?= $total ?> رسالة</span>
      </div>
    </form>
    <?= pagination_links($pg, $listQuery) ?>
    <?php endif; ?>
  </div>
<?php endif;
admin_footer();
