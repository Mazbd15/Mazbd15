<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);
$errors = [];

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    // المتخصص لا يتعامل إلا مع أقسامه، والإنشاء/الحذف/الترتيب للإدارة
    if ($id && !can_manage_category($user, $id)) deny_scope(admin_url('categories'));
    if ((!$id && $action === 'save' && !can($user, 'categories.create')) || ($action === 'move' && !can($user, 'categories.create'))) {
        flash('danger', 'هذا الإجراء يتطلب صلاحية مسؤول.'); redirect(admin_url('categories'));
    }

    if ($action === 'move') {
        move_item('categories', $id, $_POST['dir'] === 'up' ? 'up' : 'down');
        redirect(admin_url('categories'));
    }
    if ($action === 'delete') {
        if (!can($user, 'categories.delete')) { flash('danger', 'الحذف يتطلب صلاحية مسؤول.'); redirect(admin_url('categories')); }
        $row = db_one('SELECT * FROM categories WHERE id = ?', [$id]);
        if ($row) {
            $n = (int) db_value('SELECT COUNT(*) FROM services WHERE category_id = ?' . sd('services'), [$id]);
            if ($n > 0 && empty($_POST['force'])) {
                flash('warning', "تنبيه: القسم «{$row['name']}» يحتوي على $n خدمة. لم يُحذف شيء. عطّل القسم أو انقل خدماته، أو أكّد النقل إلى السلة من زر الحذف.");
            } elseif (soft_delete('categories', $id)) {
                audit('trash', 'category', $id, $row['name'] . ($n ? " (مع $n خدمة مخفية)" : ''));
                flash('success', 'نُقل القسم إلى سلة المحذوفات. يمكنك استعادته في أي وقت.');
            } else {
                flash('warning', 'سلة المحذوفات تحتاج تحديث قاعدة البيانات أولًا — لم يُحذف شيء. يمكنك تعطيل القسم بدلًا من الحذف.');
            }
        }
        redirect(admin_url('categories'));
    }
    if ($action === 'toggle') {
        db_exec('UPDATE categories SET is_active = 1 - is_active WHERE id = ?', [$id]);
        audit('toggle', 'category', $id);
        redirect(admin_url('categories'));
    }
    if ($action === 'save') {
        $data = [
            'name'              => mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 160),
            'slug'              => trim((string) ($_POST['slug'] ?? '')),
            'icon'              => preg_replace('/[^a-z0-9\-]/', '', (string) ($_POST['icon'] ?? 'bi-grid')) ?: 'bi-grid',
            'short_description' => mb_substr(trim((string) ($_POST['short_description'] ?? '')), 0, 300),
            'description'       => trim((string) ($_POST['description'] ?? '')) ?: null,
            'notice'            => trim((string) ($_POST['notice'] ?? '')) ?: null,
            'is_featured'       => !empty($_POST['is_featured']) ? 1 : 0,
            'is_active'         => !empty($_POST['is_active']) ? 1 : 0,
            'meta_title'        => mb_substr(trim((string) ($_POST['meta_title'] ?? '')), 0, 190) ?: null,
            'meta_description'  => mb_substr(trim((string) ($_POST['meta_description'] ?? '')), 0, 300) ?: null,
        ];
        if ($data['name'] === '') $errors[] = 'اسم القسم مطلوب.';
        $data['slug'] = unique_slug('categories', slugify($data['slug'] !== '' ? $data['slug'] : $data['name']), $id ?: null);

        $old = $id ? db_one('SELECT * FROM categories WHERE id = ?', [$id]) : null;
        if (!$errors && !empty($_FILES['image']['name'])) {
            [$ok, $res] = store_public_image($_FILES['image'], 'categories');
            if ($ok) { $data['image'] = $res; if ($old) delete_public_image($old['image']); }
            else $errors[] = $res;
        }
        if (!empty($_POST['remove_image']) && $old) { delete_public_image($old['image']); $data['image'] = null; }

        if (!$errors) {
            if ($id && $old) {
                db_update('categories', $data, $id);
                audit('update', 'category', $id, $data['name']);
            } else {
                $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM categories');
                $id = db_insert('categories', $data);
                audit('create', 'category', $id, $data['name']);
            }
            flash('success', 'تم حفظ القسم بنجاح.');
            redirect(admin_url('categories'));
        }
        $editId = $id; $isNew = !$id;
        $formData = $data;
    }
}

[$sw, $sp] = scope_sql($user, 'c.id');
$rows = db_all("SELECT c.*, (SELECT COUNT(*) FROM subcategories s WHERE s.category_id = c.id" . sd('subcategories', 's') . ") subs, (SELECT COUNT(*) FROM services v WHERE v.category_id = c.id" . sd('services', 'v') . ") svcs, (SELECT COUNT(*) FROM banners b WHERE b.category_id = c.id) ads FROM categories c WHERE $sw" . sd('categories', 'c') . " ORDER BY sort_order, id", $sp);
if ($editId && !can_manage_category($user, $editId)) deny_scope(admin_url('categories'));
if ($isNew && !can($user, 'categories.create')) { flash('danger', 'إضافة الأقسام تتطلب صلاحية مسؤول.'); redirect(admin_url('categories')); }
$edit = $formData ?? ($editId ? db_one('SELECT * FROM categories WHERE id = ?', [$editId]) : null);

admin_header('الأقسام الرئيسية', 'categories', $user);

if ($editId || $isNew):
    $c = $edit ?? ['name' => '', 'slug' => '', 'icon' => 'bi-grid', 'short_description' => '', 'description' => '', 'notice' => '', 'is_featured' => 0, 'is_active' => 1, 'meta_title' => '', 'meta_description' => '', 'image' => null];
    ?>
    <div class="panel">
      <h2 class="panel-title"><?= $editId ? 'تعديل القسم' : 'إضافة قسم جديد' ?></h2>
      <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">اسم القسم *</label><input class="form-control" name="name" required maxlength="160" value="<?= e($c['name']) ?>"></div>
          <div class="col-md-6"><label class="form-label">الرابط (slug)</label><input class="form-control" name="slug" maxlength="180" value="<?= e($c['slug']) ?>" placeholder="يُنشأ تلقائيًا من الاسم"><div class="form-text">مثال: engineering — يظهر في الرابط /category/engineering</div></div>
          <div class="col-md-6">
            <label class="form-label">الأيقونة</label>
            <div class="input-group"><span class="input-group-text"><i class="bi <?= e($c['icon']) ?>" data-icon-preview></i></span>
              <input class="form-control" name="icon" list="icons" value="<?= e($c['icon']) ?>" data-icon-input dir="ltr"></div>
            <datalist id="icons"><?php foreach (icon_picker_list() as $ic): ?><option value="<?= $ic ?>"><?php endforeach; ?></datalist>
            <div class="form-text">أي أيقونة من <a href="https://icons.getbootstrap.com/" target="_blank" rel="noopener">Bootstrap Icons</a> بصيغة bi-name</div>
          </div>
          <div class="col-md-6"><label class="form-label">صورة القسم (اختياري)</label><input class="form-control" type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
            <div class="form-text">JPG / PNG / WEBP حتى 3MB — المقاس المقترح 1200×675. إن لم ترفع صورة تُستخدم الصورة الافتراضية للقسم.</div>
            <?php $prev = category_image($c); if ($prev): ?><div class="mt-2 d-flex align-items-center gap-2"><img src="<?= e(img_src($prev)) ?>" alt="" height="56" class="rounded border"><?php if (!empty($c['image'])): ?><label class="small"><input type="checkbox" name="remove_image" value="1"> إزالة الصورة المرفوعة</label><?php else: ?><small class="text-muted">صورة افتراضية</small><?php endif; ?></div><?php endif; ?>
          </div>
          <div class="col-12"><label class="form-label">وصف مختصر (يظهر في البطاقات)</label><input class="form-control" name="short_description" maxlength="300" value="<?= e($c['short_description']) ?>"></div>
          <div class="col-12"><label class="form-label">الوصف التفصيلي</label><textarea class="form-control" name="description" rows="4"><?= e($c['description']) ?></textarea></div>
          <div class="col-12"><label class="form-label">تنبيه خاص بالقسم</label><textarea class="form-control" name="notice" rows="3" placeholder="مثل تنبيه اعتماد المهندس المؤهل في القسم الهندسي"><?= e($c['notice']) ?></textarea></div>
          <div class="col-md-6"><label class="form-label">عنوان SEO</label><input class="form-control" name="meta_title" maxlength="190" value="<?= e($c['meta_title']) ?>"></div>
          <div class="col-md-6"><label class="form-label">وصف SEO</label><input class="form-control" name="meta_description" maxlength="300" value="<?= e($c['meta_description']) ?>"></div>
          <div class="col-12 d-flex gap-4">
            <label class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1"<?= checked($c['is_active']) ?>> مفعّل</label>
            <label class="form-check"><input class="form-check-input" type="checkbox" name="is_featured" value="1"<?= checked($c['is_featured']) ?>> قسم مميز</label>
          </div>
        </div>
        <div class="mt-4 d-flex gap-2"><button class="btn btn-primary"><i class="bi bi-check2"></i> حفظ</button><a class="btn btn-light" href="<?= e(admin_url('categories')) ?>">إلغاء</a></div>
      </form>
    </div>
<?php else: ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
      <p class="text-muted mb-0"><?= count($rows) ?> قسم — استخدم الأسهم لتغيير الترتيب في الموقع.</p>
      <?php if (can($user, 'categories.create')): ?><a class="btn btn-primary" href="<?= e(admin_url('categories', ['new' => 1])) ?>"><i class="bi bi-plus-lg"></i> قسم جديد</a><?php endif; ?>
    </div>
    <div class="panel p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
      <thead><tr><th>الترتيب</th><th>القسم</th><th>التفرعات</th><th>الخدمات</th><th>الإعلانات</th><th>الحالة</th><th class="text-end">إجراءات</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= can($user, 'categories.create') ? move_buttons((int) $r['id']) : '—' ?></td>
          <td><?php $ti = category_image($r); if ($ti): ?><img src="<?= e(img_src($ti)) ?>" alt="" width="52" height="30" class="rounded me-1 object-fit-cover"><?php endif; ?><i class="bi <?= e($r['icon']) ?> text-warning"></i> <strong><?= e($r['name']) ?></strong> <?= $r['is_featured'] ? '<span class="badge text-bg-warning">مميز</span>' : '' ?><br><small class="text-muted" dir="ltr">/category/<?= e($r['slug']) ?></small></td>
          <td><a href="<?= e(admin_url('subcategories', ['category' => $r['id']])) ?>"><?= (int) $r['subs'] ?></a></td>
          <td><a href="<?= e(admin_url('services', ['category' => $r['id']])) ?>"><?= (int) $r['svcs'] ?></a></td>
          <td><a href="<?= e(admin_url('banners', ['category' => $r['id']])) ?>"><i class="bi bi-images"></i> <?= (int) $r['ads'] ?></a></td>
          <td>
            <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-link p-0"><?= active_badge($r['is_active']) ?></button></form>
          </td>
          <td class="text-end text-nowrap">
            <a class="btn btn-sm btn-outline-secondary" href="<?= e(route('category', ['slug' => $r['slug']])) ?>" target="_blank" title="عرض"><i class="bi bi-eye"></i></a>
            <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('categories', ['edit' => $r['id']])) ?>" title="تعديل"><i class="bi bi-pencil"></i></a>
            <?php if (can($user, 'categories.delete')) echo (int) $r['svcs'] > 0
                ? delete_button('delete', (int) $r['id'], '⚠️ تنبيه: القسم «' . $r['name'] . '» يحتوي على ' . (int) $r['svcs'] . ' خدمة و' . (int) $r['subs'] . ' تخصص.' . "\n" . 'سيُنقل القسم إلى سلة المحذوفات وستختفي خدماته من الموقع معه (دون حذف أي بيانات)، ويمكنك استعادته لاحقًا.' . "\n" . 'هل تريد المتابعة؟', '<input type="hidden" name="force" value="1">')
                : delete_button('delete', (int) $r['id'], 'نقل القسم «' . $r['name'] . '» إلى سلة المحذوفات؟'); ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div></div>
<?php endif;
admin_footer();
