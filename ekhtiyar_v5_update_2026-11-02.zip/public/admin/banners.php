<?php
/**
 * الصور الإعلانية (بنرات) لكل قسم + الصفحة الرئيسية.
 * - المتخصص: بنرات أقسامه فقط.
 * - المحرر فأعلى: كل الأقسام + بنرات الصفحة الرئيسية.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$cats = scoped_categories($user);
$canHome = role_at_least($user['role'], 'editor');
$filter = $_GET['category'] ?? '';
$back = admin_url('banners', $filter !== '' ? ['category' => $filter] : []);

/** هل يحق للمستخدم إدارة بنر بهذا القسم؟ (null = الرئيسية) */
$canBanner = function (?int $cid) use ($user, $canHome): bool {
    return $cid === null ? $canHome : can_manage_category($user, $cid);
};

$errors = [];
$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);

if (is_post()) {
    require_csrf();
    $action = (string) ($_POST['action'] ?? '');
    $id = (int) ($_POST['id'] ?? 0);
    $row = $id ? db_one('SELECT * FROM banners WHERE id = ?', [$id]) : null;
    if ($row && !$canBanner($row['category_id'] !== null ? (int) $row['category_id'] : null)) deny_scope($back);

    if ($action === 'delete' && $row) {
        db_exec('DELETE FROM banners WHERE id = ?', [$id]);
        delete_public_image($row['image']);
        if (!empty($row['mobile_image'])) delete_public_image($row['mobile_image']);
        audit('delete', 'banner', $id, $row['title']);
        flash('success', 'تم حذف الإعلان وصورته.');
        redirect($back);
    }
    if ($action === 'toggle' && $row) {
        db_exec('UPDATE banners SET is_active = 1 - is_active, updated_by = ? WHERE id = ?', [$user['id'], $id]);
        audit('toggle', 'banner', $id, $row['title']);
        redirect($back);
    }
    if ($action === 'move' && $row) {
        move_item('banners', $id, ($_POST['dir'] ?? '') === 'up' ? 'up' : 'down', 'category_id');
        redirect($back);
    }
    if ($action === 'save') {
        $cidRaw = (string) ($_POST['category_id'] ?? '');
        $cid = $cidRaw === 'home' ? null : (int) $cidRaw;
        $link = trim((string) ($_POST['link_url'] ?? ''));
        $data = [
            'category_id' => $cid,
            'title'       => mb_substr(trim((string) ($_POST['title'] ?? '')), 0, 160),
            'subtitle'    => mb_substr(trim((string) ($_POST['subtitle'] ?? '')), 0, 300) ?: null,
            'link_url'    => mb_substr($link, 0, 500) ?: null,
            'button_text' => mb_substr(trim((string) ($_POST['button_text'] ?? '')), 0, 60) ?: null,
            'starts_at'   => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($_POST['starts_at'] ?? '')) ? $_POST['starts_at'] : null,
            'ends_at'     => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($_POST['ends_at'] ?? '')) ? $_POST['ends_at'] : null,
            'is_active'   => !empty($_POST['is_active']) ? 1 : 0,
            'updated_by'  => $user['id'],
            'badge_text'  => mb_substr(trim((string) ($_POST['badge_text'] ?? '')), 0, 40) ?: null,
            'theme'       => isset(banner_themes()[$_POST['theme'] ?? '']) ? $_POST['theme'] : 'navy',
            'icon'        => preg_replace('/[^a-z0-9\-]/', '', (string) ($_POST['icon'] ?? '')) ?: null,
        ];
        if ($cidRaw === '' || ($cid !== null && !db_value('SELECT id FROM categories WHERE id = ?', [$cid])) || !$canBanner($cid)) $errors[] = 'اختر قسمًا ضمن صلاحياتك.';
        if ($data['title'] === '') $errors[] = 'عنوان الإعلان مطلوب.';
        if ($link !== '' && !preg_match('#^(https?://|/)#i', $link)) $errors[] = 'الرابط يجب أن يبدأ بـ https:// أو / (رابط داخلي).';
        if ($data['starts_at'] && $data['ends_at'] && $data['ends_at'] < $data['starts_at']) $errors[] = 'تاريخ الانتهاء قبل تاريخ البدء.';
        if (!$errors && !empty($_FILES['image']['name'])) {
            [$ok, $res] = store_public_image($_FILES['image'], 'banners');
            if ($ok) { $data['image'] = $res; if ($row) delete_public_image($row['image']); }
            else $errors[] = $res;
        }
        if (!$errors && !empty($_POST['remove_image']) && $row && $row['image'] && empty($data['image'])) { delete_public_image($row['image']); $data['image'] = null; }
        // v5: صورة مستقلة للجوال (اختيارية)
        if (!$errors && has_col('banners', 'mobile_image')) {
            if (!empty($_FILES['mobile_image']['name'])) {
                [$ok, $res] = store_public_image($_FILES['mobile_image'], 'banners');
                if ($ok) { $data['mobile_image'] = $res; if ($row && !empty($row['mobile_image'])) delete_public_image($row['mobile_image']); }
                else $errors[] = $res;
            } elseif (!empty($_POST['remove_mobile_image']) && $row && !empty($row['mobile_image'])) { delete_public_image($row['mobile_image']); $data['mobile_image'] = null; }
        }
        if (!$errors) {
            if ($row) {
                if (($row['category_id'] === null ? null : (int) $row['category_id']) !== $cid) {
                    $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM banners WHERE ' . ($cid === null ? 'category_id IS NULL' : 'category_id = ' . (int) $cid));
                }
                db_update('banners', $data, $id);
                audit('update', 'banner', $id, $data['title']);
            } else {
                $data['created_by'] = $user['id'];
                $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM banners WHERE ' . ($cid === null ? 'category_id IS NULL' : 'category_id = ' . (int) $cid));
                $id = db_insert('banners', $data);
                audit('create', 'banner', $id, $data['title']);
            }
            flash('success', 'تم حفظ الإعلان.');
            redirect(admin_url('banners', ['category' => $cid === null ? 'home' : $cid]));
        }
        $editId = $id; $isNew = !$id;
        $formData = $data + ['id' => $id, 'image' => $row['image'] ?? null, 'mobile_image' => $row['mobile_image'] ?? null];
    }
}

admin_header('الصور الإعلانية', 'banners', $user);

if ($editId || $isNew):
    $b = $formData ?? ($editId ? db_one('SELECT * FROM banners WHERE id = ?', [$editId]) : null);
    if ($editId && (!$b || !$canBanner($b['category_id'] !== null ? (int) $b['category_id'] : null))) { echo '<div class="alert alert-danger">لا تملك صلاحية تعديل هذا الإعلان.</div>'; admin_footer(); exit; }
    $b ??= ['category_id' => ($filter === 'home' ? null : ((int) $filter ?: ($cats[0]['id'] ?? null))), 'title' => '', 'subtitle' => '', 'link_url' => '', 'button_text' => '', 'starts_at' => null, 'ends_at' => null, 'is_active' => 1, 'image' => null, 'badge_text' => '', 'theme' => 'navy', 'icon' => 'bi-stars'];
    $curCat = $b['category_id'] === null ? ($editId || $filter === 'home' ? 'home' : '') : (string) $b['category_id'];
    ?>
    <div class="panel">
      <h2 class="panel-title"><?= $editId ? 'تعديل الإعلان' : 'إضافة صورة إعلانية' ?></h2>
      <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
      <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
        <div class="row g-3">
          <div class="col-md-6"><label class="form-label">مكان العرض *</label>
            <select class="form-select" name="category_id" required>
              <option value="">— اختر —</option>
              <?php if ($canHome): ?><option value="home"<?= selected($curCat, 'home') ?>>🏠 الصفحة الرئيسية</option><?php endif; ?>
              <?php foreach ($cats as $c): ?><option value="<?= (int) $c['id'] ?>"<?= selected($curCat, (string) $c['id']) ?>>قسم: <?= e($c['name']) ?></option><?php endforeach; ?>
            </select>
            <div class="form-text">يظهر الإعلان أعلى صفحة القسم وفي صفحات خدماته.</div></div>
          <div class="col-md-6"><label class="form-label">صورة (اختيارية)</label>
            <input class="form-control" type="file" name="image" accept=".jpg,.jpeg,.png,.webp" data-image-preview="#banner-preview">
            <div class="form-text">بدون صورة؟ سيظهر بنر مصمم بالألوان والأيقونة. المقاس المثالي للصورة 1200×400 (3:1)، حتى 3MB.</div>
            <?php if (!empty($b['image'])): ?><label class="small mt-1"><input type="checkbox" name="remove_image" value="1"> إزالة الصورة والعودة للتصميم الملون</label><?php endif; ?></div>
          <?php if (has_col('banners', 'mobile_image')): ?>
          <div class="col-md-6"><label class="form-label">صورة للجوال (اختيارية)</label>
            <input class="form-control" type="file" name="mobile_image" accept=".jpg,.jpeg,.png,.webp" data-img-preview="mobile-prev">
            <div class="form-text">تظهر على الشاشات الصغيرة بدل الصورة الأساسية. المقاس المفضل 800×600 (4:3).</div>
            <div id="mobile-prev" class="mt-1"><?php if (!empty($b['mobile_image'])): ?><img src="<?= e(media_url($b['mobile_image'], true)) ?>" alt="" class="img-thumbnail" style="max-height:90px"><?php endif; ?></div>
            <?php if (!empty($b['mobile_image'])): ?><label class="small mt-1"><input type="checkbox" name="remove_mobile_image" value="1"> إزالة صورة الجوال</label><?php endif; ?></div>
          <?php endif; ?>
          <div class="col-12">
            <label class="form-label">لون البنر (عند عدم وجود صورة)</label>
            <div class="theme-picker">
              <?php foreach (banner_themes() as $tk => $tl): ?>
                <label class="theme-chip theme-<?= $tk ?>"><input type="radio" name="theme" value="<?= $tk ?>"<?= checked(($b['theme'] ?? 'navy') === $tk) ?> data-theme-input><span><?= e($tl) ?></span></label>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="col-md-6"><label class="form-label">الأيقونة الزخرفية</label>
            <div class="input-group"><span class="input-group-text"><i class="bi <?= e(($b['icon'] ?? '') ?: 'bi-stars') ?>" data-icon-preview></i></span>
              <input class="form-control" name="icon" list="icons" value="<?= e($b['icon'] ?? '') ?>" data-icon-input data-preview-icon dir="ltr" placeholder="bi-stars"></div>
            <datalist id="icons"><?php foreach (icon_picker_list() as $ic): ?><option value="<?= $ic ?>"><?php endforeach; ?></datalist></div>
          <div class="col-md-6"><label class="form-label">شارة صغيرة فوق العنوان</label><input class="form-control" name="badge_text" maxlength="40" value="<?= e($b['badge_text'] ?? '') ?>" placeholder="مثل: جديد، عرض الأسبوع، هندسي" data-preview-input="badge"></div>
          <div class="col-12"><label class="form-label">معاينة مباشرة</label>
            <div class="banner-preview offer-slide is-active theme-<?= e(($b['theme'] ?? '') ?: 'navy') ?><?= $b['image'] ? ' has-image' : '' ?>" id="banner-preview"<?= $b['image'] ? ' style="background-image:url(\'' . e(media_url($b['image'])) . '\')"' : '' ?>>
              <span class="offer-deco" aria-hidden="true"><i></i><i></i><i></i></span>
              <span class="offer-icon" aria-hidden="true"><i class="bi <?= e(($b['icon'] ?? '') ?: 'bi-stars') ?>" data-preview-iconel></i></span>
              <div class="offer-body">
                <span class="offer-badge" data-preview-badge<?= empty($b['badge_text']) ? ' hidden' : '' ?>><i class="bi bi-lightning-charge-fill"></i> <span><?= e($b['badge_text'] ?? '') ?></span></span>
                <h3 class="offer-title" data-preview-title><?= e($b['title'] ?: 'عنوان الإعلان') ?></h3>
                <p class="offer-text" data-preview-sub><?= e($b['subtitle'] ?? '') ?></p>
                <span class="btn offer-btn" data-preview-btn><?= e(($b['button_text'] ?? '') ?: 'اعرف المزيد') ?> <i class="bi bi-arrow-left"></i></span>
              </div>
            </div></div>
          <div class="col-md-6"><label class="form-label">العنوان *</label><input class="form-control" name="title" required maxlength="160" value="<?= e($b['title']) ?>" data-preview-input="title"></div>
          <div class="col-md-6"><label class="form-label">نص فرعي</label><input class="form-control" name="subtitle" maxlength="300" value="<?= e($b['subtitle'] ?? '') ?>" data-preview-input="sub"></div>
          <div class="col-md-8"><label class="form-label">رابط عند الضغط (اختياري)</label><input class="form-control" name="link_url" dir="ltr" maxlength="500" value="<?= e($b['link_url'] ?? '') ?>" placeholder="/service/... أو https://..."></div>
          <div class="col-md-4"><label class="form-label">نص الزر</label><input class="form-control" name="button_text" maxlength="60" value="<?= e($b['button_text'] ?? '') ?>" placeholder="اطلب الآن" data-preview-input="btn"></div>
          <div class="col-md-4"><label class="form-label">يبدأ في</label><input class="form-control" type="date" name="starts_at" value="<?= e($b['starts_at'] ?? '') ?>"></div>
          <div class="col-md-4"><label class="form-label">ينتهي في</label><input class="form-control" type="date" name="ends_at" value="<?= e($b['ends_at'] ?? '') ?>"></div>
          <div class="col-md-4 d-flex align-items-end"><label class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1"<?= checked($b['is_active']) ?>> مفعّل</label></div>
        </div>
        <div class="mt-4 d-flex gap-2"><button class="btn btn-primary"><i class="bi bi-check2"></i> حفظ</button><a class="btn btn-light" href="<?= e($back) ?>">إلغاء</a></div>
      </form>
    </div>
<?php
    admin_footer();
    exit;
endif;

// القائمة
[$sw, $sp] = scope_sql($user, 'b.category_id');
$where = $canHome ? "($sw OR b.category_id IS NULL)" : $sw;
$params = $sp;
if ($filter === 'home') { $where .= ' AND b.category_id IS NULL'; }
elseif ($filter !== '') { $where .= ' AND b.category_id = ?'; $params[] = (int) $filter; }
$rows = db_all("SELECT b.*, c.name cat_name, u.name editor_name FROM banners b LEFT JOIN categories c ON c.id = b.category_id LEFT JOIN users u ON u.id = COALESCE(b.updated_by, b.created_by)
    WHERE $where ORDER BY (b.category_id IS NOT NULL), c.sort_order, b.sort_order, b.id", $params);
$today = date('Y-m-d');
?>
<div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-3">
  <form method="get" class="d-flex gap-2">
    <select class="form-select form-select-sm" name="category" data-autosubmit>
      <option value="">كل الأماكن</option>
      <?php if ($canHome): ?><option value="home"<?= selected($filter, 'home') ?>>الصفحة الرئيسية</option><?php endif; ?>
      <?php foreach ($cats as $c): ?><option value="<?= (int) $c['id'] ?>"<?= selected($filter, (string) $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?>
    </select>
  </form>
  <?php if ($cats || $canHome): ?><a class="btn btn-primary" href="<?= e(admin_url('banners', ['new' => 1] + ($filter !== '' ? ['category' => $filter] : []))) ?>"><i class="bi bi-plus-lg"></i> إعلان جديد</a><?php endif; ?>
</div>
<?php if (!$cats && !$canHome): ?><div class="alert alert-warning">لم تُسند إليك أقسام بعد. تواصل مع الإدارة.</div><?php endif; ?>
<?php if (!$rows): ?><div class="panel text-center text-muted py-5"><i class="bi bi-images fs-1 d-block mb-2"></i>لا توجد صور إعلانية بعد. أضف أول إعلان ليظهر أعلى صفحة القسم.</div><?php endif; ?>
<div class="row g-3">
<?php foreach ($rows as $r):
    $expired = $r['ends_at'] && $r['ends_at'] < $today;
    $scheduled = $r['starts_at'] && $r['starts_at'] > $today;
    ?>
  <div class="col-md-6 col-xl-4"><div class="panel p-0 h-100 banner-card<?= $r['is_active'] && !$expired ? '' : ' is-off' ?>">
    <div class="banner-thumb<?= $r['image'] ? '' : ' theme-' . e($r['theme'] ?: 'navy') ?>"<?= $r['image'] ? ' style="background-image:url(\'' . e(media_url($r['image'], true)) . '\')"' : '' ?>>
      <?php if (!$r['image']): ?><i class="bi <?= e($r['icon'] ?: 'bi-stars') ?> banner-thumb-ic"></i><strong class="banner-thumb-title"><?= e($r['title']) ?></strong><?php endif; ?>
      <span class="badge text-bg-dark"><?= $r['category_id'] ? e($r['cat_name']) : '🏠 الرئيسية' ?></span>
    </div>
    <div class="p-3">
      <strong><?= e($r['title']) ?></strong>
      <?php if ($r['subtitle']): ?><div class="small text-muted text-truncate"><?= e($r['subtitle']) ?></div><?php endif; ?>
      <div class="d-flex flex-wrap gap-1 my-2 small">
        <?php if ($expired): ?><span class="badge text-bg-secondary">منتهي</span><?php elseif ($scheduled): ?><span class="badge text-bg-info">مجدول من <?= e($r['starts_at']) ?></span><?php endif; ?>
        <?php if ($r['ends_at'] && !$expired): ?><span class="badge text-bg-light">حتى <?= e($r['ends_at']) ?></span><?php endif; ?>
        <?php if (isset($r['views'])): ?><span class="badge text-bg-light" title="مرات الظهور"><i class="bi bi-eye"></i> <?= (int) $r['views'] ?></span><?php endif; ?>
        <span class="badge text-bg-light"><i class="bi bi-cursor"></i> <?= (int) $r['clicks'] ?> نقرة</span>
        <?php if (!empty($r['views'])): ?><span class="badge text-bg-light" title="نسبة النقر">CTR <?= round((int) $r['clicks'] / max(1, (int) $r['views']) * 100, 1) ?>%</span><?php endif; ?>
        <?php if (!empty($r['mobile_image'])): ?><span class="badge text-bg-light"><i class="bi bi-phone"></i> صورة جوال</span><?php endif; ?>
        <?php if ($r['editor_name']): ?><span class="badge text-bg-light"><i class="bi bi-person"></i> <?= e($r['editor_name']) ?></span><?php endif; ?>
      </div>
      <div class="d-flex flex-wrap gap-1 align-items-center">
        <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-link p-0"><?= active_badge($r['is_active']) ?></button></form>
        <span class="ms-auto"></span>
        <?= move_buttons((int) $r['id']) ?>
        <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('banners', ['edit' => $r['id']] + ($filter !== '' ? ['category' => $filter] : []))) ?>" title="تعديل"><i class="bi bi-pencil"></i></a>
        <?= delete_button('delete', (int) $r['id'], 'حذف الإعلان «' . $r['title'] . '» وصورته؟') ?>
      </div>
    </div>
  </div></div>
<?php endforeach; ?>
</div>
<?php admin_footer();
