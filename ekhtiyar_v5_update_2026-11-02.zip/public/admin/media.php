<?php
/**
 * ملفات وصور الموقع (v5): مكتبة وسائط لمجلد الرفع العام.
 * - تصفح حسب المجلد، معرفة أين تُستخدم كل صورة، رفع متعدد مع معاينة قبل الحفظ، نسخ الرابط.
 * - الحذف آمن: يُرفض إن كانت الصورة مستخدمة، وإلا تُنقل لسلة الوسائط (قابلة للاستعادة).
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('editor');

$folders = ['all' => 'الكل', 'categories' => 'الأقسام', 'subcategories' => 'التخصصات', 'services' => 'الخدمات', 'banners' => 'البنرات', 'portfolio' => 'معرض الأعمال', 'testimonials' => 'آراء العملاء', 'posts' => 'المقالات', 'branding' => 'الهوية', 'library' => 'المكتبة العامة'];
$folder = isset($folders[$_GET['folder'] ?? '']) ? $_GET['folder'] : 'all';
$filter = (string) ($_GET['filter'] ?? '');
$back = admin_url('media', array_filter(['folder' => $folder !== 'all' ? $folder : null, 'filter' => $filter ?: null]));

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'upload') {
        $files = normalize_files($_FILES['files'] ?? []);
        $ok = 0; $errs = [];
        foreach (array_slice($files, 0, 20) as $f) {
            if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) continue;
            [$good, $res] = store_public_image($f, 'library');
            $good ? $ok++ : $errs[] = $res;
        }
        audit('upload', 'media', null, "$ok files");
        if ($ok) flash('success', "تم رفع $ok صورة إلى المكتبة العامة (WebP مضغوطة + مصغرات).");
        foreach (array_slice($errs, 0, 5) as $er) flash('danger', strip_tags($er));
        redirect(admin_url('media', ['folder' => 'library']));
    }
    if ($action === 'delete') {
        $rel = ltrim((string) ($_POST['rel'] ?? ''), '/');
        $n = media_ref_count($rel);
        if ($n > 0) flash('warning', "لا يمكن حذف الصورة لأنها مستخدمة في $n موضع. استبدلها من صفحة العنصر أولًا.");
        elseif (media_trash($rel)) { audit('trash', 'media', null, $rel); flash('success', 'نُقلت الصورة إلى سلة الوسائط (يمكن استعادتها من سلة المحذوفات).'); }
        else flash('danger', 'تعذر نقل الملف.');
    }
    if ($action === 'thumb') {
        $rel = ltrim((string) ($_POST['rel'] ?? ''), '/');
        flash(str_starts_with($rel, MEDIA_UPLOAD_BASE . '/') && media_make_thumb($rel) ? 'success' : 'warning', 'تمت إعادة توليد المصغرة.');
    }
    redirect($back);
}

$base = PUBLIC_PATH . '/' . MEDIA_UPLOAD_BASE;
$files = $folder === 'all' ? media_scan($base, MEDIA_UPLOAD_BASE) : media_scan($base . '/' . $folder, MEDIA_UPLOAD_BASE . '/' . $folder);
$refs = media_all_refs();
if ($filter === 'unused') $files = array_diff_key($files, $refs);
if ($filter === 'used') $files = array_intersect_key($files, $refs);
uasort($files, fn($a, $b) => $b['mtime'] <=> $a['mtime']);
$totalSize = array_sum(array_column($files, 'size'));
$pg = paginate(count($files), 48, (int) ($_GET['page'] ?? 1));
$pageFiles = array_slice($files, $pg['offset'], $pg['limit'], true);
$srcLabels = ['categories.image' => 'قسم', 'subcategories.image' => 'تخصص', 'services.image' => 'خدمة', 'service_files.file_path' => 'معرض خدمة', 'banners.image' => 'بنر', 'banners.mobile_image' => 'بنر (جوال)',
    'portfolio_items.cover_image' => 'غلاف عمل', 'portfolio_files.file_path' => 'صورة عمل', 'site_settings.setting_value' => 'إعدادات', 'testimonials.avatar' => 'رأي (صورة)', 'testimonials.bg_image' => 'رأي (خلفية)', 'testimonials.attachment' => 'رأي (مرفق)', 'posts.cover_image' => 'مقال'];

admin_header('ملفات وصور الموقع', 'media', $user);
?>
<div class="panel">
  <form method="post" enctype="multipart/form-data" class="row g-2 align-items-end">
    <?= csrf_field() ?><input type="hidden" name="action" value="upload">
    <div class="col-md-8"><label class="form-label">رفع صور إلى المكتبة العامة (حتى 20 صورة)</label>
      <input type="file" class="form-control" name="files[]" multiple accept="image/jpeg,image/png,image/webp" data-img-preview="lib-prev" required></div>
    <div class="col-md-4"><button class="btn btn-primary w-100"><i class="bi bi-cloud-arrow-up"></i> رفع</button></div>
    <div class="col-12" id="lib-prev"></div>
    <div class="col-12 form-text">JPG/PNG/WEBP — تُرفض الملفات التنفيذية والأنواع الأخرى، وتُحوّل الصور إلى WebP مع مصغرات. يمكن استخدام رابط الصورة داخل المقالات.</div>
  </form>
</div>
<div class="d-flex flex-wrap gap-2 align-items-center mb-3">
  <ul class="nav nav-pills flex-wrap">
    <?php foreach ($folders as $k => $l): ?><li class="nav-item"><a class="nav-link py-1<?= $folder === $k ? ' active' : '' ?>" href="<?= e(admin_url('media', array_filter(['folder' => $k !== 'all' ? $k : null, 'filter' => $filter ?: null]))) ?>"><?= e($l) ?></a></li><?php endforeach; ?>
  </ul>
  <select class="form-select form-select-sm w-auto ms-auto" data-nav-select>
    <?php foreach (['' => 'كل الصور', 'used' => 'المستخدمة', 'unused' => 'غير المستخدمة'] as $k => $l): ?><option value="<?= e(admin_url('media', array_filter(['folder' => $folder !== 'all' ? $folder : null, 'filter' => $k ?: null]))) ?>"<?= $filter === $k ? ' selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?>
  </select>
  <span class="small text-muted"><?= count($files) ?> ملف — <?= round($totalSize / 1048576, 1) ?> م.ب</span>
</div>
<?php if (!$pageFiles): ?><div class="panel text-center text-muted py-5"><i class="bi bi-images fs-1 d-block mb-2"></i>لا توجد صور هنا.</div><?php endif; ?>
<div class="row g-3">
  <?php foreach ($pageFiles as $rel => $info): $used = $refs[$rel] ?? []; ?>
    <div class="col-6 col-md-4 col-xl-2"><div class="panel p-2 h-100 mb-0 small">
      <a href="<?= e(media_url($rel)) ?>" target="_blank" rel="noopener"><img src="<?= e(media_url($rel, true)) ?>" alt="" loading="lazy" class="w-100 rounded mb-1" style="height:110px;object-fit:cover"></a>
      <div class="text-truncate mono" title="<?= e($rel) ?>"><?= e(basename($rel)) ?></div>
      <div class="text-muted"><?= round($info['size'] / 1024) ?> ك.ب · <?= e(ar_date(date('Y-m-d', $info['mtime']))) ?></div>
      <div class="my-1"><?php if ($used): foreach (array_unique($used) as $u): ?><span class="badge bg-success-subtle text-success"><?= e($srcLabels[$u] ?? $u) ?></span> <?php endforeach; else: ?><span class="badge bg-secondary-subtle text-secondary">غير مستخدمة</span><?php endif; ?></div>
      <div class="d-flex gap-1">
        <input class="form-control form-control-sm mono" value="<?= e(absolute_url($rel)) ?>" readonly data-copy title="انقر لتحديد الرابط">
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="thumb"><input type="hidden" name="rel" value="<?= e($rel) ?>"><button class="btn btn-sm btn-light" title="إعادة توليد المصغرة"><i class="bi bi-arrow-repeat"></i></button></form>
        <?php if (!$used): ?><form method="post" data-confirm="نقل الصورة إلى سلة الوسائط؟"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="rel" value="<?= e($rel) ?>"><button class="btn btn-sm btn-outline-danger" title="نقل للسلة"><i class="bi bi-trash"></i></button></form><?php endif; ?>
      </div>
    </div></div>
  <?php endforeach; ?>
</div>
<div class="mt-3"><?= pagination_links($pg, array_filter(['folder' => $folder !== 'all' ? $folder : null, 'filter' => $filter ?: null])) ?></div>
<?php admin_footer();
