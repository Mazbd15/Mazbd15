<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$isSpec = user_category_scope($user) !== null;
[$cw, $cp] = scope_sql($user, 'id');
[$sw, $sp] = scope_sql($user, 'category_id');
[$rw, $rp] = requests_scope_sql($user);

$stats = [
    ['bi-grid', $isSpec ? 'أقسامي' : 'الأقسام الرئيسية', (int) db_value("SELECT COUNT(*) FROM categories WHERE $cw" . sd('categories'), $cp), admin_url('categories'), 'navy'],
    ['bi-diagram-3', 'الأقسام الفرعية', (int) db_value("SELECT COUNT(*) FROM subcategories WHERE $sw" . sd('subcategories'), $sp), admin_url('subcategories'), 'sky'],
    ['bi-briefcase', 'الخدمات', (int) db_value("SELECT COUNT(*) FROM services WHERE $sw" . sd('services'), $sp), admin_url('services'), 'gold'],
    ['bi-collection', 'معرض الأعمال', (int) db_value('SELECT COUNT(*) FROM portfolio_items WHERE ' . ($isSpec ? $sw : '1=1'), $isSpec ? $sp : []), admin_url('portfolio'), 'sky'],
    ['bi-images', 'الصور الإعلانية', (int) db_value('SELECT COUNT(*) FROM banners WHERE ' . ($isSpec ? $sw : '1=1'), $isSpec ? $sp : []), admin_url('banners'), 'green'],
];

$reqBy = array_column(db_all("SELECT r.status, COUNT(*) c FROM requests r WHERE $rw GROUP BY r.status", $rp), 'c', 'status');
$totalReq = array_sum($reqBy);
$last30 = (int) db_value("SELECT COUNT(*) FROM requests r WHERE $rw AND r.created_at > ?", array_merge($rp, [date('Y-m-d H:i:s', time() - 30 * 86400)]));
$recent = db_all("SELECT r.*, c.name AS category_name, u.name assignee FROM requests r LEFT JOIN categories c ON c.id = r.category_id LEFT JOIN users u ON u.id = r.assigned_to WHERE $rw ORDER BY r.created_at DESC LIMIT 6", $rp);
$mineOpen = (int) db_value("SELECT COUNT(*) FROM requests WHERE assigned_to = ? AND status IN ('new','reviewing','awaiting_client')", [$user['id']]);
$unassigned = (int) db_value("SELECT COUNT(*) FROM requests r WHERE $rw AND r.assigned_to IS NULL AND r.status IN ('new','reviewing')", $rp);

$pending = can($user, 'users.manage') ? db_all("SELECT id, name, specialization, created_at FROM users WHERE status = 'pending' ORDER BY created_at LIMIT 5") : [];
$teamStats = can($user, 'users.manage') ? db_one("SELECT SUM(role = 'specialist' AND status = 'active') specs, SUM(role = 'member') members FROM users") : null;

$topViewed = db_all("SELECT s.name, s.slug, s.views, c.name AS cat FROM services s JOIN categories c ON c.id = s.category_id WHERE " . str_replace('category_id', 's.category_id', $sw) . ' ORDER BY s.views DESC LIMIT 6', $sp);
$byCat = db_all("SELECT c.name, COUNT(s.id) n FROM categories c LEFT JOIN services s ON s.category_id = c.id WHERE " . str_replace('id', 'c.id', $cw) . ' GROUP BY c.id ORDER BY c.sort_order', $cp);
$maxN = max(1, ...array_map(fn($r) => (int) $r['n'], $byCat ?: [['n' => 1]]));
$topBanners = db_all('SELECT b.title, b.clicks, c.name cat FROM banners b LEFT JOIN categories c ON c.id = b.category_id WHERE ' . ($isSpec ? str_replace('category_id', 'b.category_id', $sw) : '1=1') . ' ORDER BY b.clicks DESC LIMIT 5', $isSpec ? $sp : []);

// v5: مؤشرات العملاء والتواصل (للمحرر فأعلى)
$v5dash = schema_v5() && role_at_least($user['role'], 'editor');
$monthly = [];
for ($i = 5; $i >= 0; $i--) { $k = date('Y-m', strtotime("first day of -$i month")); $monthly[$k] = ['req' => 0, 'msg' => 0]; }
foreach (db_all("SELECT DATE_FORMAT(r.created_at, '%Y-%m') m, COUNT(*) n FROM requests r WHERE $rw AND r.created_at >= ? GROUP BY m", array_merge($rp, [array_key_first($monthly) . '-01'])) as $row) if (isset($monthly[$row['m']])) $monthly[$row['m']]['req'] = (int) $row['n'];
if ($v5dash) {
    foreach (db_all("SELECT DATE_FORMAT(created_at, '%Y-%m') m, COUNT(*) n FROM contact_messages WHERE deleted_at IS NULL AND created_at >= ? GROUP BY m", [array_key_first($monthly) . '-01']) as $row) if (isset($monthly[$row['m']])) $monthly[$row['m']]['msg'] = (int) $row['n'];
    $msgNew = (int) db_value("SELECT COUNT(*) FROM contact_messages WHERE status = 'new' AND deleted_at IS NULL");
    $revStats = db_one("SELECT SUM(status = 'approved') pub, SUM(status = 'pending') pend, AVG(CASE WHEN status = 'approved' THEN rating END) avg FROM testimonials WHERE deleted_at IS NULL");
    $customers = (int) db_value('SELECT COUNT(DISTINCT contact_value) FROM requests');
    $latestMsgs = db_all('SELECT id, name, subject, body, status, created_at FROM contact_messages WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 5');
    $latestRevs = db_all('SELECT id, name, rating, body, status, created_at FROM testimonials WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 5');
    $stats[] = ['bi-person-vcard', 'العملاء', $customers, admin_url('customers'), 'navy'];
    $stats[] = ['bi-envelope', 'رسائل جديدة', $msgNew, admin_url('messages', ['status' => 'new']), $msgNew ? 'gold' : 'green'];
}
$maxMonthly = max(1, ...array_values(array_map(fn($m) => max($m['req'], $m['msg']), $monthly)));

admin_header('لوحة المؤشرات', 'index', $user);
?>
<p class="text-muted">مرحبًا <?= e($user['name']) ?> 👋 — <?= $isSpec ? 'هذه مؤشرات أقسامك والطلبات المسندة إليك.' : 'هذه نظرة سريعة على المنصة.' ?></p>

<?php if ($isSpec && !user_category_scope($user)): ?>
  <div class="alert alert-warning"><i class="bi bi-exclamation-triangle"></i> لم تُسند إليك أي أقسام بعد. ستتمكن من إدارة المحتوى بعد أن تحدد الإدارة أقسامك.</div>
<?php endif; ?>

<?php if ($pending): ?>
<div class="panel mb-4 border-warning join-alert">
  <div class="d-flex justify-content-between align-items-center"><h2 class="panel-title mb-2"><i class="bi bi-person-plus text-warning"></i> طلبات انضمام متخصصين بانتظار موافقتك (<?= count($pending) ?>)</h2>
    <a class="btn btn-sm btn-warning" href="<?= e(admin_url('users', ['tab' => 'pending'])) ?>">مراجعة الطلبات</a></div>
  <ul class="list-unstyled mb-0 small">
    <?php foreach ($pending as $p): ?><li class="py-1 border-bottom"><strong><?= e($p['name']) ?></strong> — <?= e($p['specialization'] ?: 'بدون تخصص') ?> <span class="text-muted">(<?= ar_date($p['created_at']) ?>)</span></li><?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<div class="row g-3 mb-4">
  <?php foreach ($stats as [$ic, $label, $n, $link, $color]): ?>
    <div class="col-6 col-md-4 col-xl">
      <a class="stat-card stat-<?= $color ?>" href="<?= e($link) ?>">
        <i class="bi <?= $ic ?>"></i>
        <div><strong><?= number_format($n) ?></strong><span><?= e($label) ?></span></div>
      </a>
    </div>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-4">
  <div class="col-lg-4">
    <div class="panel h-100">
      <h2 class="panel-title"><?= $isSpec ? 'طلبات أقسامي' : 'الطلبات المسجلة' ?></h2>
      <p class="display-6 fw-bold mb-1"><?= number_format($totalReq) ?></p>
      <p class="text-muted small"><?= $last30 ?> طلب خلال آخر 30 يومًا</p>
      <div class="d-flex gap-2 mb-2 flex-wrap">
        <a class="badge text-bg-primary text-decoration-none" href="<?= e(admin_url('requests', ['mine' => 1])) ?>"><i class="bi bi-person-check"></i> مسندة لي (مفتوحة): <?= $mineOpen ?></a>
        <?php if ($unassigned): ?><span class="badge text-bg-warning"><i class="bi bi-hourglass"></i> بلا مسؤول: <?= $unassigned ?></span><?php endif; ?>
      </div>
      <ul class="list-unstyled mb-0">
        <?php foreach (request_statuses() as $k => [$l, $c]): ?>
          <li class="d-flex justify-content-between py-1 border-bottom"><a href="<?= e(admin_url('requests', ['status' => $k])) ?>"><span class="badge text-bg-<?= $c ?>"><?= e($l) ?></span></a><strong><?= (int) ($reqBy[$k] ?? 0) ?></strong></li>
        <?php endforeach; ?>
      </ul>
      <p class="small text-muted mt-2 mb-0"><i class="bi bi-info-circle"></i> تُسجَّل الطلبات فقط عند موافقة العميل على الحفظ.</p>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="panel h-100">
      <div class="d-flex justify-content-between"><h2 class="panel-title">أحدث الطلبات</h2><a href="<?= e(admin_url('requests')) ?>" class="small">عرض الكل</a></div>
      <?php if (!$recent): ?>
        <p class="text-muted text-center py-4 mb-0">لا توجد طلبات مسجلة بعد.</p>
      <?php else: ?>
        <div class="table-responsive"><table class="table table-sm align-middle mb-0">
          <thead><tr><th>المرجع</th><th>العميل</th><th>الخدمة</th><th>المسؤول</th><th>الحالة</th><th>التاريخ</th></tr></thead>
          <tbody>
          <?php foreach ($recent as $r): [$sl, $sc] = request_statuses()[$r['status']]; ?>
            <tr><td><a href="<?= e(admin_url('request_view', ['id' => $r['id']])) ?>"><?= e($r['reference_code']) ?></a></td><td><?= e($r['customer_name']) ?></td><td class="small"><?= e(excerpt($r['service_label'], 40)) ?></td><td class="small"><?= e($r['assignee'] ?? '—') ?></td><td><span class="badge text-bg-<?= $sc ?>"><?= e($sl) ?></span></td><td class="small text-muted"><?= ar_date($r['created_at']) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table></div>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-lg-<?= $v5dash ? '4' : '12' ?>">
    <div class="panel h-100">
      <h2 class="panel-title">إحصائيات آخر 6 أشهر</h2>
      <?php foreach ($monthly as $m => $v): ?>
        <div class="bar-row"><span><?= e(ar_month($m . '-01')) ?></span><div class="bar"><i style="width:<?= round($v['req'] / $maxMonthly * 100) ?>%"></i></div><b title="طلبات"><?= $v['req'] ?></b></div>
        <?php if ($v5dash): ?><div class="bar-row small text-muted"><span></span><div class="bar"><i style="width:<?= round($v['msg'] / $maxMonthly * 100) ?>%;background:#38bdf8"></i></div><b title="رسائل"><?= $v['msg'] ?></b></div><?php endif; ?>
      <?php endforeach; ?>
      <p class="small text-muted mb-0 mt-2"><span class="badge" style="background:#c9a24d">&nbsp;</span> الطلبات<?php if ($v5dash): ?> · <span class="badge" style="background:#38bdf8">&nbsp;</span> الرسائل<?php endif; ?></p>
    </div>
  </div>
  <?php if ($v5dash): ?>
  <div class="col-lg-4">
    <div class="panel h-100">
      <div class="d-flex justify-content-between"><h2 class="panel-title">أحدث الرسائل</h2><a class="small" href="<?= e(admin_url('messages')) ?>">الكل</a></div>
      <?php if (!$latestMsgs): ?><p class="text-muted small mb-0">لا توجد رسائل بعد.</p><?php endif; ?>
      <ul class="list-unstyled mb-0 small">
        <?php foreach ($latestMsgs as $m): [$ml, $mc] = message_statuses()[$m['status']]; ?>
          <li class="py-1 border-bottom"><a href="<?= e(admin_url('messages', ['view' => $m['id']])) ?>" class="<?= $m['status'] === 'new' ? 'fw-bold' : '' ?>"><?= e($m['name']) ?></a> <span class="badge bg-<?= $mc ?>"><?= e($ml) ?></span><div class="text-muted text-truncate"><?= e($m['subject'] ?: excerpt($m['body'], 60)) ?></div></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="panel h-100">
      <div class="d-flex justify-content-between"><h2 class="panel-title">آراء العملاء</h2><a class="small" href="<?= e(admin_url('testimonials')) ?>">الكل</a></div>
      <div class="d-flex gap-3 mb-2 small">
        <div><strong class="fs-4"><?= $revStats['avg'] ? number_format((float) $revStats['avg'], 1) : '—' ?></strong> <i class="bi bi-star-fill text-warning"></i><div class="text-muted">متوسط التقييم</div></div>
        <div><strong class="fs-4"><?= (int) $revStats['pub'] ?></strong><div class="text-muted">منشور</div></div>
        <div><strong class="fs-4 <?= (int) $revStats['pend'] ? 'text-warning' : '' ?>"><?= (int) $revStats['pend'] ?></strong><div class="text-muted">بانتظار المراجعة</div></div>
      </div>
      <ul class="list-unstyled mb-0 small">
        <?php foreach ($latestRevs as $t): ?>
          <li class="py-1 border-bottom"><a href="<?= e(admin_url('testimonials', ['edit' => $t['id']])) ?>"><?= e($t['name']) ?></a> <?= render_stars((int) $t['rating']) ?><?php if ($t['status'] === 'pending'): ?> <span class="badge bg-warning text-dark">مراجعة</span><?php endif; ?><div class="text-muted text-truncate"><?= e(excerpt($t['body'], 60)) ?></div></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
  <?php endif; ?>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="panel h-100">
      <h2 class="panel-title">توزيع الخدمات على الأقسام</h2>
      <?php foreach ($byCat as $r): ?>
        <div class="bar-row"><span><?= e($r['name']) ?></span><div class="bar"><i style="width:<?= round($r['n'] / $maxN * 100) ?>%"></i></div><b><?= (int) $r['n'] ?></b></div>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="panel h-100">
      <h2 class="panel-title">الخدمات الأكثر مشاهدة</h2>
      <ol class="mb-0">
        <?php foreach ($topViewed as $t): ?>
          <li class="py-1"><a href="<?= e(route('service', ['slug' => $t['slug']])) ?>" target="_blank"><?= e($t['name']) ?></a> <small class="text-muted">(<?= (int) $t['views'] ?>)</small></li>
        <?php endforeach; ?>
      </ol>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="panel h-100">
      <h2 class="panel-title">أداء الصور الإعلانية</h2>
      <?php if (!$topBanners): ?><p class="text-muted small">لا توجد إعلانات بعد. <a href="<?= e(admin_url('banners', ['new' => 1])) ?>">أضف إعلانًا</a></p><?php endif; ?>
      <ul class="list-unstyled mb-0">
        <?php foreach ($topBanners as $b): ?><li class="d-flex justify-content-between py-1 border-bottom small"><span><?= e($b['title']) ?> <span class="text-muted">— <?= e($b['cat'] ?? 'الرئيسية') ?></span></span><strong><?= (int) $b['clicks'] ?> <i class="bi bi-cursor"></i></strong></li><?php endforeach; ?>
      </ul>
      <?php if ($teamStats): ?>
        <hr><div class="d-flex justify-content-around text-center small">
          <div><strong class="fs-5 d-block"><?= (int) $teamStats['specs'] ?></strong>متخصص نشط</div>
          <div><strong class="fs-5 d-block"><?= (int) $teamStats['members'] ?></strong>عضو مسجل</div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php admin_footer(); ?>
