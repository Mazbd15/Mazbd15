<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$cats = scoped_categories($user);
$catMap = array_column($cats, 'name', 'id');
[$subW, $subP] = scope_sql($user, 'category_id');
$subs = db_all("SELECT id, category_id, name FROM subcategories WHERE $subW" . sd('subcategories') . " ORDER BY sort_order, id", $subP);
$subMap = [];
foreach ($subs as $s) $subMap[$s['id']] = $s;

$fCat = (int) ($_GET['category'] ?? 0);
$fSub = (int) ($_GET['sub'] ?? 0);
$fQ = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 100);
$fFlag = (string) ($_GET['flag'] ?? '');
$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);
$errors = [];
$listQuery = array_filter(['category' => $fCat ?: null, 'sub' => $fSub ?: null, 'q' => $fQ ?: null, 'flag' => $fFlag ?: null, 'page' => $_GET['page'] ?? null]);
$back = admin_url('services', $listQuery);

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    // التحقق من أن الخدمة ضمن أقسام المستخدم
    if ($id) {
        $own = db_value('SELECT category_id FROM services WHERE id = ?', [$id]);
        if (!$own || !can_manage_category($user, (int) $own)) deny_scope($back);
    }

    if ($action === 'move') { move_item('services', $id, $_POST['dir'] === 'up' ? 'up' : 'down', 'subcategory_id'); redirect($back); }
    if (in_array($action, ['toggle', 'popular', 'featured'], true)) {
        $col = ['toggle' => 'is_active', 'popular' => 'is_popular', 'featured' => 'is_featured'][$action];
        db_exec("UPDATE services SET $col = 1 - $col WHERE id = ?", [$id]);
        audit($action, 'service', $id);
        redirect($back);
    }
    if ($action === 'delete') {
        if (!can($user, 'services.delete')) { flash('danger', 'لا تملك صلاحية الحذف.'); redirect($back); }
        $row = db_one('SELECT * FROM services WHERE id = ?', [$id]);
        if ($row) {
            if (soft_delete('services', $id)) {
                audit('trash', 'service', $id, $row['name']);
                flash('success', 'نُقلت الخدمة إلى سلة المحذوفات (بصورها وبياناتها) ويمكن استعادتها.');
            } else {
                flash('warning', 'سلة المحذوفات تحتاج تحديث قاعدة البيانات أولًا — لم يُحذف شيء. يمكنك إخفاء الخدمة بدلًا من الحذف.');
            }
        }
        redirect($back);
    }
    if ($action === 'delete_file') {
        $fid = (int) ($_POST['file_id'] ?? 0);
        $f = db_one('SELECT * FROM service_files WHERE id = ? AND service_id = ?', [$fid, $id]);
        if ($f) { delete_public_image($f['file_path']); db_exec('DELETE FROM service_files WHERE id = ?', [$fid]); audit('delete_file', 'service', $id); }
        redirect(admin_url('services', ['edit' => $id]));
    }
    if ($action === 'bulk') {
        $ids = array_map('intval', (array) ($_POST['ids'] ?? []));
        $op = (string) ($_POST['bulk_op'] ?? '');
        $map = ['activate' => 'is_active = 1', 'deactivate' => 'is_active = 0', 'popular' => 'is_popular = 1', 'unpopular' => 'is_popular = 0', 'feature' => 'is_featured = 1', 'unfeature' => 'is_featured = 0'];
        // استبعاد أي خدمة خارج نطاق المستخدم
        if ($ids) {
            [$bw, $bp] = scope_sql($user, 'category_id');
            $ids = array_map('intval', array_column(db_all('SELECT id FROM services WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ") AND $bw", array_merge($ids, $bp)), 'id'));
        }
        if ($ids && isset($map[$op])) {
            $ph = implode(',', array_fill(0, count($ids), '?'));
            db_exec("UPDATE services SET {$map[$op]} WHERE id IN ($ph)", $ids);
            audit('bulk_' . $op, 'service', null, implode(',', $ids));
            flash('success', 'تم تحديث ' . count($ids) . ' خدمة.');
        }
        redirect($back);
    }
    if ($action === 'save') {
        $t = fn($k, $max = 0) => ($v = trim((string) ($_POST[$k] ?? ''))) === '' ? null : ($max ? mb_substr($v, 0, $max) : $v);
        $data = [
            'category_id'       => (int) ($_POST['category_id'] ?? 0),
            'subcategory_id'    => (int) ($_POST['subcategory_id'] ?? 0) ?: null,
            'name'              => (string) $t('name', 200),
            'slug'              => (string) $t('slug', 200),
            'icon'              => preg_replace('/[^a-z0-9\-]/', '', (string) ($_POST['icon'] ?? '')) ?: null,
            'short_description' => $t('short_description', 400),
            'description'       => $t('description'),
            'includes_text'     => $t('includes_text'),
            'requirements_text' => $t('requirements_text'),
            'tools_text'        => $t('tools_text'),
            'duration_text'     => $t('duration_text', 160),
            'price_text'        => $t('price_text', 160),
            'keywords'          => $t('keywords', 500),
            'service_type'      => isset(service_types()[$_POST['service_type'] ?? '']) ? $_POST['service_type'] : 'task',
            'is_featured'       => !empty($_POST['is_featured']) ? 1 : 0,
            'is_popular'        => !empty($_POST['is_popular']) ? 1 : 0,
            'is_active'         => !empty($_POST['is_active']) ? 1 : 0,
            'meta_title'        => $t('meta_title', 190),
            'meta_description'  => $t('meta_description', 300),
        ];
        if ($data['name'] === '') $errors[] = 'اسم الخدمة مطلوب.';
        if (!isset($catMap[$data['category_id']])) $errors[] = 'اختر القسم الرئيسي.';
        if ($data['subcategory_id'] && (($subMap[$data['subcategory_id']]['category_id'] ?? 0) != $data['category_id'])) $errors[] = 'التخصص الفرعي لا يتبع القسم المختار.';
        $data['slug'] = unique_slug('services', slugify($data['slug'] ?: $data['name']), $id ?: null);
        $old = $id ? db_one('SELECT * FROM services WHERE id = ?', [$id]) : null;

        if (!$errors && !empty($_FILES['image']['name'])) {
            [$ok, $res] = store_public_image($_FILES['image'], 'services');
            if ($ok) { $data['image'] = $res; if ($old) delete_public_image($old['image']); } else $errors[] = 'الصورة الرئيسية: ' . $res;
        }
        if (!empty($_POST['remove_image']) && $old) { delete_public_image($old['image']); $data['image'] = null; }

        if (!$errors) {
            if ($id && $old) {
                db_update('services', $data, $id);
                audit('update', 'service', $id, $data['name']);
            } else {
                $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM services WHERE subcategory_id <=> ?', [$data['subcategory_id']]);
                $id = db_insert('services', $data);
                audit('create', 'service', $id, $data['name']);
            }
            // صور المعرض
            $gallery = normalize_files($_FILES['gallery'] ?? []);
            foreach (array_slice($gallery, 0, 8) as $g) {
                [$ok, $res] = store_public_image($g, 'services');
                if ($ok) db_insert('service_files', ['service_id' => $id, 'file_path' => $res, 'file_type' => 'image', 'alt_text' => $data['name']]);
                else flash('warning', 'صورة معرض لم تُرفع: ' . $res);
            }
            flash('success', 'تم حفظ الخدمة بنجاح.');
            redirect(!empty($_POST['stay']) ? admin_url('services', ['edit' => $id]) : $back);
        }
        $editId = $id; $isNew = !$id; $formData = $data + ['image' => $old['image'] ?? null];
    }
}

admin_header('الخدمات', 'services', $user);

if ($editId || $isNew):
    $sv = $formData ?? ($editId ? db_one('SELECT * FROM services WHERE id = ?', [$editId]) : null);
    if ($editId && $sv && !can_manage_category($user, (int) $sv['category_id'])) { echo '<div class="alert alert-danger">هذه الخدمة خارج نطاق أقسامك.</div>'; admin_footer(); exit; }
    if ($editId && !$sv) { echo '<div class="alert alert-warning">الخدمة غير موجودة.</div>'; admin_footer(); exit; }
    $sv ??= ['category_id' => $fCat, 'subcategory_id' => $fSub, 'name' => '', 'slug' => '', 'icon' => '', 'short_description' => '', 'description' => '', 'includes_text' => '', 'requirements_text' => '', 'tools_text' => '', 'duration_text' => '', 'price_text' => '', 'keywords' => '', 'service_type' => 'task', 'is_featured' => 0, 'is_popular' => 0, 'is_active' => 1, 'meta_title' => '', 'meta_description' => '', 'image' => null];
    $files = $editId ? db_all('SELECT * FROM service_files WHERE service_id = ? ORDER BY sort_order, id', [$editId]) : [];
    ?>
    <form method="post" enctype="multipart/form-data" class="row g-3">
      <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
      <div class="col-12"><?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?></div>
      <div class="col-lg-8">
        <div class="panel">
          <h2 class="panel-title">بيانات الخدمة</h2>
          <div class="row g-3">
            <div class="col-12"><label class="form-label">اسم الخدمة *</label><input class="form-control" name="name" required maxlength="200" value="<?= e($sv['name']) ?>"></div>
            <div class="col-md-6"><label class="form-label">القسم الرئيسي *</label>
              <select class="form-select" name="category_id" id="svc-cat" required><option value="">—</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($sv['category_id'], $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
            <div class="col-md-6"><label class="form-label">التخصص الفرعي</label>
              <select class="form-select" name="subcategory_id" id="svc-sub" data-selected="<?= (int) $sv['subcategory_id'] ?>"><option value="">— بدون —</option></select></div>
            <div class="col-12"><label class="form-label">وصف مختصر</label><input class="form-control" name="short_description" maxlength="400" value="<?= e($sv['short_description']) ?>"></div>
            <div class="col-12"><label class="form-label">الوصف التفصيلي</label><textarea class="form-control" name="description" rows="4"><?= e($sv['description']) ?></textarea></div>
            <div class="col-md-6"><label class="form-label">ماذا تشمل الخدمة؟ <small class="text-muted">(سطر لكل بند)</small></label><textarea class="form-control" name="includes_text" rows="6"><?= e($sv['includes_text']) ?></textarea></div>
            <div class="col-md-6"><label class="form-label">المتطلبات من العميل <small class="text-muted">(سطر لكل بند)</small></label><textarea class="form-control" name="requirements_text" rows="6"><?= e($sv['requirements_text']) ?></textarea></div>
            <div class="col-md-6"><label class="form-label">البرامج / الملفات المطلوبة <small class="text-muted">(سطر لكل بند)</small></label><textarea class="form-control" name="tools_text" rows="4"><?= e($sv['tools_text']) ?></textarea></div>
            <div class="col-md-6"><label class="form-label">كلمات بحث بديلة <small class="text-muted">(مفصولة بفواصل)</small></label><textarea class="form-control" name="keywords" rows="4" placeholder="ريبورت, report, تقرير"><?= e($sv['keywords']) ?></textarea></div>
          </div>
        </div>
        <div class="panel mt-3">
          <h2 class="panel-title">الصور</h2>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">الصورة الرئيسية</label><input class="form-control" type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
              <?php if (!empty($sv['image'])): ?><div class="mt-2 d-flex gap-2 align-items-center"><img src="<?= e(url($sv['image'])) ?>" height="60" class="rounded" alt=""><label class="small"><input type="checkbox" name="remove_image" value="1"> إزالة</label></div><?php endif; ?></div>
            <div class="col-md-6"><label class="form-label">صور المعرض (حتى 8)</label><input class="form-control" type="file" name="gallery[]" multiple accept=".jpg,.jpeg,.png,.webp"><div class="form-text">JPG / PNG / WEBP — حتى 3MB لكل صورة</div></div>
          </div>
          <?php if ($files): ?>
            <div class="d-flex flex-wrap gap-2 mt-3">
              <?php foreach ($files as $f): ?>
                <div class="thumb"><img src="<?= e(url($f['file_path'])) ?>" alt="">
                  <button class="btn btn-sm btn-danger" form="del-file-<?= (int) $f['id'] ?>" title="حذف"><i class="bi bi-x"></i></button>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
        <div class="panel mt-3">
          <h2 class="panel-title">تحسين محركات البحث (SEO)</h2>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">الرابط (slug)</label><input class="form-control" name="slug" value="<?= e($sv['slug']) ?>" placeholder="تلقائي من الاسم"></div>
            <div class="col-md-6"><label class="form-label">عنوان الصفحة</label><input class="form-control" name="meta_title" maxlength="190" value="<?= e($sv['meta_title']) ?>"></div>
            <div class="col-12"><label class="form-label">وصف الصفحة</label><input class="form-control" name="meta_description" maxlength="300" value="<?= e($sv['meta_description']) ?>"></div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <div class="panel sticky-lg-top" style="top:80px">
          <h2 class="panel-title">النشر والتسعير</h2>
          <div class="mb-3"><label class="form-label">السعر التقديري</label><input class="form-control" name="price_text" maxlength="160" value="<?= e($sv['price_text']) ?>" placeholder="اتركه فارغًا = يحدد بعد مراجعة المتطلبات"></div>
          <div class="mb-3"><label class="form-label">المدة التقديرية</label><input class="form-control" name="duration_text" maxlength="160" value="<?= e($sv['duration_text']) ?>"></div>
          <div class="mb-3"><label class="form-label">نوع الخدمة</label><select class="form-select" name="service_type"><?php foreach (service_types() as $k => $l): ?><option value="<?= $k ?>"<?= selected($sv['service_type'], $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
          <div class="mb-3"><label class="form-label">أيقونة خاصة (اختياري)</label><div class="input-group"><span class="input-group-text"><i class="bi <?= e($sv['icon'] ?: 'bi-grid') ?>" data-icon-preview></i></span><input class="form-control" name="icon" list="icons" value="<?= e($sv['icon']) ?>" data-icon-input dir="ltr" placeholder="أيقونة القسم"></div>
            <datalist id="icons"><?php foreach (icon_picker_list() as $ic): ?><option value="<?= $ic ?>"><?php endforeach; ?></datalist></div>
          <label class="form-check mb-2"><input class="form-check-input" type="checkbox" name="is_active" value="1"<?= checked($sv['is_active']) ?>> مفعّلة (ظاهرة في الموقع)</label>
          <label class="form-check mb-2"><input class="form-check-input" type="checkbox" name="is_popular" value="1"<?= checked($sv['is_popular']) ?>> الأكثر طلبًا (تظهر في الرئيسية)</label>
          <label class="form-check mb-3"><input class="form-check-input" type="checkbox" name="is_featured" value="1"<?= checked($sv['is_featured']) ?>> خدمة مميزة</label>
          <div class="d-grid gap-2">
            <button class="btn btn-primary"><i class="bi bi-check2"></i> حفظ والعودة</button>
            <button class="btn btn-outline-primary" name="stay" value="1"><i class="bi bi-save"></i> حفظ ومتابعة التعديل</button>
            <a class="btn btn-light" href="<?= e($back) ?>">إلغاء</a>
            <?php if ($editId && !empty($sv['slug'])): ?><a class="btn btn-link" href="<?= e(route('service', ['slug' => $sv['slug']])) ?>" target="_blank"><i class="bi bi-eye"></i> معاينة في الموقع</a><?php endif; ?>
          </div>
        </div>
      </div>
    </form>
    <?php foreach ($files as $f): ?>
      <form method="post" id="del-file-<?= (int) $f['id'] ?>" data-confirm="حذف الصورة؟"><?= csrf_field() ?><input type="hidden" name="action" value="delete_file"><input type="hidden" name="id" value="<?= (int) $editId ?>"><input type="hidden" name="file_id" value="<?= (int) $f['id'] ?>"></form>
    <?php endforeach; ?>
    <script type="application/json" id="subs-data"><?= json_encode(array_values($subs), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?></script>
<?php else:
    [$sw0, $sp0] = scope_sql($user, 's.category_id');
    $where = [$sw0 . sd('services', 's')]; $params = $sp0;
    if ($fCat) { $where[] = 's.category_id = ?'; $params[] = $fCat; }
    if ($fSub) { $where[] = 's.subcategory_id = ?'; $params[] = $fSub; }
    if ($fQ !== '') { $where[] = '(s.name LIKE ? OR s.keywords LIKE ?)'; $params[] = "%$fQ%"; $params[] = "%$fQ%"; }
    $flags = ['popular' => 's.is_popular = 1', 'featured' => 's.is_featured = 1', 'inactive' => 's.is_active = 0'];
    if (isset($flags[$fFlag])) $where[] = $flags[$fFlag];
    $w = implode(' AND ', $where);
    $total = (int) db_value("SELECT COUNT(*) FROM services s WHERE $w", $params);
    $p = paginate($total, 30, (int) ($_GET['page'] ?? 1));
    $rows = db_all("SELECT s.*, c.name AS cat, sc.name AS sub FROM services s JOIN categories c ON c.id = s.category_id LEFT JOIN subcategories sc ON sc.id = s.subcategory_id WHERE $w ORDER BY c.sort_order, sc.sort_order, s.sort_order, s.id LIMIT {$p['limit']} OFFSET {$p['offset']}", $params);
    ?>
    <form class="panel mb-3" method="get">
      <div class="row g-2 align-items-end">
        <div class="col-md-3"><label class="form-label small">بحث</label><input class="form-control" name="q" value="<?= e($fQ) ?>" placeholder="اسم الخدمة أو كلمة مفتاحية"></div>
        <div class="col-md-3"><label class="form-label small">القسم</label><select class="form-select" name="category"><option value="">الكل</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($fCat, $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-3"><label class="form-label small">التخصص</label><select class="form-select" name="sub"><option value="">الكل</option><?php foreach ($subs as $s): if ($fCat && $s['category_id'] != $fCat) continue; ?><option value="<?= $s['id'] ?>"<?= selected($fSub, $s['id']) ?>><?= e($s['name']) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-2"><label class="form-label small">تصفية</label><select class="form-select" name="flag"><option value="">الكل</option><option value="popular"<?= selected($fFlag, 'popular') ?>>الأكثر طلبًا</option><option value="featured"<?= selected($fFlag, 'featured') ?>>المميزة</option><option value="inactive"<?= selected($fFlag, 'inactive') ?>>المعطلة</option></select></div>
        <div class="col-md-1 d-grid"><button class="btn btn-secondary"><i class="bi bi-funnel"></i></button></div>
      </div>
    </form>
    <div class="d-flex justify-content-between align-items-center mb-2">
      <p class="text-muted mb-0"><?= $total ?> خدمة<?= $fSub ? ' — الترتيب متاح داخل التخصص' : '' ?></p>
      <a class="btn btn-primary" href="<?= e(admin_url('services', ['new' => 1, 'category' => $fCat ?: null, 'sub' => $fSub ?: null])) ?>"><i class="bi bi-plus-lg"></i> خدمة جديدة</a>
    </div>
    <form method="post" id="bulk-form">
      <?= csrf_field() ?><input type="hidden" name="action" value="bulk">
      <div class="panel p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0">
        <thead><tr><th><input type="checkbox" class="form-check-input" data-check-all></th><?php if ($fSub): ?><th>الترتيب</th><?php endif; ?><th>الخدمة</th><th>القسم / التخصص</th><th>السعر</th><th>علامات</th><th>المشاهدات</th><th class="text-end">إجراءات</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): ?>
          <tr class="<?= $r['is_active'] ? '' : 'table-secondary' ?>">
            <td><input type="checkbox" class="form-check-input" name="ids[]" value="<?= (int) $r['id'] ?>"></td>
            <?php if ($fSub): ?><td class="text-nowrap"><button class="btn btn-sm btn-light" form="mv-<?= $r['id'] ?>-up"><i class="bi bi-arrow-up"></i></button><button class="btn btn-sm btn-light" form="mv-<?= $r['id'] ?>-down"><i class="bi bi-arrow-down"></i></button></td><?php endif; ?>
            <td><strong><?= e($r['name']) ?></strong><?= $r['is_active'] ? '' : ' <span class="badge text-bg-secondary">معطلة</span>' ?></td>
            <td class="small"><?= e($r['cat']) ?><br><span class="text-muted"><?= e($r['sub'] ?? '—') ?></span></td>
            <td class="small"><?= e($r['price_text'] ?: 'بعد المراجعة') ?></td>
            <td class="text-nowrap">
              <button class="btn btn-sm <?= $r['is_popular'] ? 'btn-warning' : 'btn-outline-secondary' ?>" form="fl-<?= $r['id'] ?>-popular" title="الأكثر طلبًا"><i class="bi bi-fire"></i></button>
              <button class="btn btn-sm <?= $r['is_featured'] ? 'btn-info' : 'btn-outline-secondary' ?>" form="fl-<?= $r['id'] ?>-featured" title="مميزة"><i class="bi bi-star"></i></button>
              <button class="btn btn-sm <?= $r['is_active'] ? 'btn-success' : 'btn-outline-secondary' ?>" form="fl-<?= $r['id'] ?>-toggle" title="تفعيل/تعطيل"><i class="bi bi-power"></i></button>
            </td>
            <td class="small"><?= (int) $r['views'] ?></td>
            <td class="text-end text-nowrap">
              <a class="btn btn-sm btn-outline-secondary" href="<?= e(route('service', ['slug' => $r['slug']])) ?>" target="_blank"><i class="bi bi-eye"></i></a>
              <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('services', ['edit' => $r['id']] + $listQuery)) ?>"><i class="bi bi-pencil"></i></a>
              <?php if (can($user, 'services.delete')): ?><button class="btn btn-sm btn-outline-danger" form="del-<?= $r['id'] ?>"><i class="bi bi-trash"></i></button><?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="8" class="text-center text-muted py-4">لا توجد خدمات مطابقة.</td></tr><?php endif; ?>
        </tbody>
      </table></div></div>
      <div class="d-flex gap-2 align-items-center mt-2">
        <select class="form-select form-select-sm w-auto" name="bulk_op"><option value="">إجراء جماعي على المحدد…</option><option value="activate">تفعيل</option><option value="deactivate">تعطيل</option><option value="popular">تمييز كالأكثر طلبًا</option><option value="unpopular">إلغاء الأكثر طلبًا</option><option value="feature">تمييز كخدمة مميزة</option><option value="unfeature">إلغاء التمييز</option></select>
        <button class="btn btn-sm btn-secondary">تطبيق</button>
      </div>
    </form>
    <?php
    // نماذج منفصلة للأزرار الفردية (لتجنب تداخل النماذج)
    $hidden = fn($a, $id, $extra = '') => csrf_field() . '<input type="hidden" name="action" value="' . $a . '"><input type="hidden" name="id" value="' . $id . '">' . $extra;
    foreach ($rows as $r) {
        foreach (['popular', 'featured', 'toggle'] as $a) echo '<form method="post" id="fl-' . $r['id'] . '-' . $a . '" hidden>' . $hidden($a, $r['id']) . '</form>';
        echo '<form method="post" id="del-' . $r['id'] . '" data-confirm="حذف الخدمة «' . e($r['name']) . '» نهائيًا؟" hidden>' . $hidden('delete', $r['id']) . '</form>';
        if ($fSub) foreach (['up', 'down'] as $d) echo '<form method="post" id="mv-' . $r['id'] . '-' . $d . '" hidden>' . $hidden('move', $r['id'], '<input type="hidden" name="dir" value="' . $d . '">') . '</form>';
    }
    echo pagination_links($p, $listQuery);
endif;
admin_footer();
