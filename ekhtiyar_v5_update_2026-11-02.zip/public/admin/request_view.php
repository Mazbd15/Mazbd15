<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$id = (int) ($_GET['id'] ?? 0);
$r = db_one('SELECT r.*, c.name AS category_name, sc.name AS sub_name, s.slug AS service_slug FROM requests r LEFT JOIN categories c ON c.id = r.category_id LEFT JOIN subcategories sc ON sc.id = r.subcategory_id LEFT JOIN services s ON s.id = r.service_id WHERE r.id = ?', [$id]);
if (!$r) { flash('warning', 'الطلب غير موجود.'); redirect(admin_url('requests')); }
if (!can_view_request($user, $r)) { flash('danger', 'هذا الطلب خارج نطاق صلاحياتك.'); redirect(admin_url('requests')); }
$self = admin_url('request_view', ['id' => $id]);
$memberLink = route('account', ['tab' => 'requests']);

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'update') {
        $status = isset(request_statuses()[$_POST['status'] ?? '']) ? $_POST['status'] : $r['status'];
        $notes = mb_substr(trim((string) ($_POST['admin_notes'] ?? '')), 0, 5000) ?: null;
        db_exec('UPDATE requests SET admin_notes = ? WHERE id = ?', [$notes, $id]);
        $statusNote = mb_substr(trim((string) ($_POST['status_note'] ?? '')), 0, 500) ?: null;
        request_set_status($r, $status, (int) $user['id'], $statusNote);
        audit('update', 'request', $id, 'الحالة: ' . $status);
        flash('success', 'تم حفظ التحديثات.');
        redirect(admin_url('request_view', ['id' => $id]));
    }
    if ($action === 'note') {
        $body = mb_substr(trim((string) ($_POST['body'] ?? '')), 0, 3000);
        $internal = !empty($_POST['is_internal']) ? 1 : 0;
        if ($body !== '') {
            db_insert('request_notes', ['request_id' => $id, 'user_id' => $user['id'], 'body' => $body, 'is_internal' => $internal]);
            audit('note', 'request', $id, $internal ? 'ملاحظة داخلية' : 'رد للعميل');
            if (!$internal && $r['member_id']) notify((int) $r['member_id'], 'رد جديد على طلبك ' . $r['reference_code'], excerpt($body, 120), $memberLink);
            if ($r['assigned_to'] && (int) $r['assigned_to'] !== (int) $user['id']) notify((int) $r['assigned_to'], 'ملاحظة جديدة على الطلب ' . $r['reference_code'], excerpt($body, 120), $self);
            flash('success', $internal ? 'تمت إضافة الملاحظة الداخلية.' : ($r['member_id'] ? 'تم إرسال الرد وسيظهر للعميل في حسابه.' : 'تم حفظ الرد (العميل غير مسجل؛ راسله عبر واتساب).'));
        }
        redirect($self . '#notes');
    }
    if ($action === 'assign' && can($user, 'requests.assign')) {
        $to = (int) ($_POST['assigned_to'] ?? 0) ?: null;
        if ($to && !db_value("SELECT id FROM users WHERE id = ? AND status = 'active' AND role IN ('super_admin','admin','editor','specialist')", [$to])) $to = null;
        db_exec('UPDATE requests SET assigned_to = ? WHERE id = ?', [$to, $id]);
        audit('assign', 'request', $id, $to ? 'إسناد للمستخدم #' . $to : 'إلغاء الإسناد');
        if ($to && $to !== (int) $user['id']) notify($to, 'تم إسناد طلب إليك: ' . $r['reference_code'], $r['service_label'], $self);
        flash('success', $to ? 'تم إسناد الطلب.' : 'تم إلغاء الإسناد.');
        redirect($self);
    }
    if ($action === 'claim' && !$r['assigned_to']) {
        db_exec('UPDATE requests SET assigned_to = ? WHERE id = ? AND assigned_to IS NULL', [$user['id'], $id]);
        audit('claim', 'request', $id, 'استلام الطلب');
        flash('success', 'استلمت هذا الطلب، وأصبح مسندًا إليك.');
        redirect($self);
    }
    if ($action === 'delete_attachment') {
        if (!can($user, 'requests.delete')) { flash('danger', 'حذف المرفقات للمسؤولين فقط.'); redirect($self); }
        $att = db_one('SELECT * FROM request_attachments WHERE id = ? AND request_id = ?', [(int) $_POST['att_id'], $id]);
        if ($att) {
            $p = config('uploads.path') . '/requests/' . basename($att['stored_name']);
            if (is_file($p)) @unlink($p);
            db_exec('DELETE FROM request_attachments WHERE id = ?', [$att['id']]);
            audit('delete_attachment', 'request', $id, $att['original_name']);
            flash('success', 'تم حذف المرفق.');
        }
        redirect(admin_url('request_view', ['id' => $id]));
    }
}
$atts = db_all('SELECT * FROM request_attachments WHERE request_id = ? ORDER BY id', [$id]);
$notesList = db_all('SELECT n.*, u.name, u.role FROM request_notes n LEFT JOIN users u ON u.id = n.user_id WHERE n.request_id = ? ORDER BY n.created_at, n.id', [$id]);
$assignee = $r['assigned_to'] ? db_one('SELECT id, name, role FROM users WHERE id = ?', [$r['assigned_to']]) : null;
$member = $r['member_id'] ? db_one('SELECT id, name, email FROM users WHERE id = ?', [$r['member_id']]) : null;
$assignable = [];
if (can($user, 'requests.assign')) {
    // المتخصصون المرتبطون بقسم الطلب أولًا ثم بقية فريق العمل
    $assignable = db_all("SELECT u.id, u.name, u.role, u.specialization,
        EXISTS(SELECT 1 FROM user_categories uc WHERE uc.user_id = u.id AND uc.category_id = ?) in_cat,
        (SELECT COUNT(*) FROM requests x WHERE x.assigned_to = u.id AND x.status IN ('new','reviewing','awaiting_client')) open_cnt
        FROM users u WHERE u.status = 'active' AND u.role IN ('super_admin','admin','editor','specialist')
        ORDER BY in_cat DESC, (u.role = 'specialist') DESC, u.name", [(int) $r['category_id']]);
}
$history = db_all('SELECT a.*, u.name FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE a.entity_type = "request" AND a.entity_id = ? ORDER BY a.created_at DESC LIMIT 20', [$id]);
[$sl, $sc] = request_statuses()[$r['status']];
// رابط واتساب للرد على العميل (إن كانت وسيلة التواصل واتساب/هاتف)
$replyLink = null;
if (in_array($r['contact_method'], ['whatsapp', 'phone'], true)) {
    $num = preg_replace('/\D+/', '', $r['contact_value']);
    if (str_starts_with($num, '05')) $num = '966' . substr($num, 1);
    if (strlen($num) >= 9) $replyLink = 'https://wa.me/' . $num . '?text=' . rawurlencode("مرحبًا {$r['customer_name']}، بخصوص طلبك رقم {$r['reference_code']} في منصة " . setting('site_name') . ':');
}

admin_header('الطلب ' . $r['reference_code'], 'requests', $user);
?>
<a class="btn btn-sm btn-light mb-3" href="<?= e(admin_url('requests')) ?>"><i class="bi bi-arrow-right"></i> كل الطلبات</a>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="panel">
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div><h2 class="h5 mb-1"><?= e($r['service_label']) ?></h2><small class="text-muted"><?= e($r['category_name'] ?? '') ?><?= $r['sub_name'] ? ' › ' . e($r['sub_name']) : '' ?></small></div>
        <span class="badge text-bg-<?= $sc ?> fs-6"><?= e($sl) ?></span>
      </div>
      <dl class="row detail-list mb-0">
        <dt class="col-sm-3">العميل</dt><dd class="col-sm-9"><?= e($r['customer_name']) ?>
          <?= $member ? ' <span class="badge text-bg-info"><i class="bi bi-person-check"></i> عضو مسجل</span>' : ' <span class="badge text-bg-light">زائر</span>' ?></dd>
        <dt class="col-sm-3">التواصل</dt><dd class="col-sm-9"><?= e(contact_methods()[$r['contact_method']] ?? '') ?>: <span dir="ltr"><?= e($r['contact_value']) ?></span></dd>
        <dt class="col-sm-3">البريد</dt><dd class="col-sm-9"><?= $r['email'] ? '<a href="mailto:' . e($r['email']) . '">' . e($r['email']) . '</a>' : '—' ?></dd>
        <dt class="col-sm-3">التخصص</dt><dd class="col-sm-9"><?= e($r['specialization'] ?: '—') ?></dd>
        <dt class="col-sm-3">البرنامج</dt><dd class="col-sm-9"><?= e($r['software'] ?: '—') ?></dd>
        <dt class="col-sm-3">الموعد النهائي</dt><dd class="col-sm-9"><?= ar_date($r['deadline']) ?></dd>
        <dt class="col-sm-3">تاريخ الطلب</dt><dd class="col-sm-9"><?= ar_date($r['created_at'], true) ?></dd>
        <dt class="col-sm-3">الوصف</dt><dd class="col-sm-9"><div class="pre-text"><?= nl2br(e($r['description'])) ?></div></dd>
        <dt class="col-sm-3">ملاحظات العميل</dt><dd class="col-sm-9"><?= $r['notes'] ? nl2br(e($r['notes'])) : '—' ?></dd>
      </dl>
    </div>
    <div class="panel mt-3">
      <h2 class="panel-title"><i class="bi bi-paperclip"></i> المرفقات (<?= count($atts) ?>)</h2>
      <?php if (!$atts): ?><p class="text-muted mb-0">لا توجد مرفقات مرفوعة عبر الموقع.</p><?php endif; ?>
      <ul class="list-group">
        <?php foreach ($atts as $a): ?>
          <li class="list-group-item d-flex justify-content-between align-items-center">
            <span><i class="bi bi-file-earmark"></i> <?= e($a['original_name']) ?> <small class="text-muted">(<?= format_bytes((int) $a['file_size']) ?>)</small></span>
            <span class="text-nowrap">
              <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('download', ['id' => $a['id']])) ?>"><i class="bi bi-download"></i> تنزيل</a>
              <?php if (can($user, 'requests.delete')): ?><form method="post" class="d-inline" data-confirm="حذف المرفق نهائيًا؟"><?= csrf_field() ?><input type="hidden" name="action" value="delete_attachment"><input type="hidden" name="att_id" value="<?= (int) $a['id'] ?>"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form><?php endif; ?>
            </span>
          </li>
        <?php endforeach; ?>
      </ul>
      <p class="small text-muted mt-2 mb-0"><i class="bi bi-shield-lock"></i> المرفقات مخزنة خارج المجلد العام ولا تُفتح إلا بالتنزيل من هنا.</p>
    </div>
    <div class="panel mt-3" id="notes">
      <h2 class="panel-title"><i class="bi bi-chat-dots"></i> المحادثة والملاحظات (<?= count($notesList) ?>)</h2>
      <div class="chat mb-3">
        <?php if (!$notesList): ?><p class="text-muted small mb-0">لا توجد ملاحظات بعد.</p><?php endif; ?>
        <?php foreach ($notesList as $n): $fromClient = $n['role'] === 'member' || ($r['member_id'] && (int) $n['user_id'] === (int) $r['member_id']); ?>
          <div class="chat-msg<?= $fromClient ? '' : ' mine' ?><?= $n['is_internal'] ? ' internal' : '' ?>">
            <div class="chat-meta"><strong><?= e($n['name'] ?? 'مستخدم محذوف') ?></strong>
              <?= $fromClient ? '<span class="badge text-bg-light">العميل</span>' : '' ?>
              <?= $n['is_internal'] ? '<span class="badge text-bg-warning"><i class="bi bi-lock"></i> داخلية</span>' : '' ?>
              <span class="text-muted"><?= ar_date($n['created_at'], true) ?></span></div>
            <div><?= nl2br(e($n['body'])) ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="note">
        <textarea class="form-control mb-2" name="body" rows="3" maxlength="3000" required placeholder="اكتب ردًا للعميل أو ملاحظة داخلية للفريق..."></textarea>
        <div class="d-flex flex-wrap gap-2 align-items-center">
          <label class="form-check mb-0"><input class="form-check-input" type="checkbox" name="is_internal" value="1"<?= $member ? '' : ' checked' ?>> ملاحظة داخلية (لا تظهر للعميل)</label>
          <button class="btn btn-primary btn-sm ms-auto"><i class="bi bi-send"></i> إرسال</button>
        </div>
        <?php if (!$member): ?><div class="form-text">العميل غير مسجل في الموقع، لذا لن يرى الردود؛ استخدم واتساب للتواصل معه.</div><?php endif; ?>
      </form>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="panel mb-3">
      <h2 class="panel-title"><i class="bi bi-person-check"></i> المسؤول عن التنفيذ</h2>
      <?php if ($assignee): ?>
        <p class="mb-2"><strong><?= e($assignee['name']) ?></strong> <span class="badge text-bg-light"><?= e(role_labels()[$assignee['role']] ?? '') ?></span></p>
      <?php else: ?><p class="text-muted mb-2">غير مسند لأحد بعد.</p><?php endif; ?>
      <?php if (can($user, 'requests.assign')): ?>
        <form method="post" class="d-flex gap-2"><?= csrf_field() ?><input type="hidden" name="action" value="assign">
          <select class="form-select form-select-sm" name="assigned_to"><option value="">— بدون إسناد —</option>
            <?php foreach ($assignable as $a): ?><option value="<?= (int) $a['id'] ?>"<?= selected($r['assigned_to'], $a['id']) ?>><?= $a['in_cat'] ? '★ ' : '' ?><?= e($a['name']) ?> (<?= e(role_labels()[$a['role']]) ?><?= $a['open_cnt'] ? ' · ' . (int) $a['open_cnt'] . ' مفتوح' : '' ?>)</option><?php endforeach; ?>
          </select><button class="btn btn-sm btn-outline-primary">إسناد</button></form>
        <div class="form-text">★ = متخصص في قسم هذا الطلب.</div>
      <?php elseif (!$assignee): ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="claim"><button class="btn btn-sm btn-outline-primary w-100"><i class="bi bi-hand-index"></i> استلام الطلب</button></form>
      <?php endif; ?>
    </div>
    <div class="panel">
      <h2 class="panel-title">إدارة الطلب</h2>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="update">
        <label class="form-label">الحالة</label>
        <select class="form-select mb-2" name="status"><?php foreach (request_statuses() as $k => [$l]): ?><option value="<?= $k ?>"<?= selected($r['status'], $k) ?>><?= $l ?></option><?php endforeach; ?></select>
        <input class="form-control form-control-sm mb-3" name="status_note" maxlength="500" placeholder="ملاحظة مع تغيير الحالة (تظهر للعميل في صفحة التتبع)">
        <label class="form-label">ملاحظات داخلية</label>
        <textarea class="form-control mb-3" name="admin_notes" rows="5" placeholder="السعر المتفق عليه، المنفذ، التسليم..."><?= e($r['admin_notes']) ?></textarea>
        <button class="btn btn-primary w-100">حفظ</button>
      </form>
      <?php if ($replyLink): ?><a class="btn btn-success w-100 mt-2" href="<?= e($replyLink) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> مراسلة العميل عبر واتساب</a><?php endif; ?>
      <?php if (can($user, 'requests.delete')): ?>
      <hr>
      <form method="post" action="<?= e(admin_url('requests')) ?>" data-confirm="حذف الطلب وجميع مرفقاته نهائيًا؟ لا يمكن التراجع.">
        <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int) $id ?>">
        <button class="btn btn-outline-danger w-100"><i class="bi bi-trash"></i> حذف الطلب نهائيًا</button>
      </form>
      <p class="small text-muted mt-2 mb-0">استخدم الحذف عند طلب العميل حذف بياناته.</p>
      <?php endif; ?>
    </div>
    <?php $statusHist = request_status_history($id); if ($statusHist): ?>
    <div class="panel mt-3">
      <h2 class="panel-title"><i class="bi bi-clock-history"></i> سجل الحالات</h2>
      <ul class="timeline small mb-0">
        <?php foreach ($statusHist as $h): ?><li><strong><?= e(request_statuses()[$h['new_status']][0] ?? $h['new_status']) ?></strong><?php if ($h['old_status']): ?> <span class="text-muted">(من: <?= e(request_statuses()[$h['old_status']][0] ?? $h['old_status']) ?>)</span><?php endif; ?>
          <br><small><?= e($h['uname'] ?? 'العميل/النظام') ?> — <?= e(ar_date($h['created_at'], true)) ?></small><?php if ($h['note']): ?><div><?= e($h['note']) ?></div><?php endif; ?></li><?php endforeach; ?>
      </ul>
      <a class="small" href="<?= e(route('track', ['ref' => $r['reference_code']])) ?>" target="_blank">صفحة التتبع العامة <i class="bi bi-box-arrow-up-left"></i></a>
    </div>
    <?php endif; ?>
    <?php if ($history): ?>
    <div class="panel mt-3">
      <h2 class="panel-title">سجل الطلب</h2>
      <ul class="list-unstyled small mb-0">
        <?php foreach ($history as $h): ?><li class="border-bottom py-1"><strong><?= e($h['name'] ?? 'نظام') ?></strong> — <?= e($h['action']) ?> <?= e($h['details']) ?><br><span class="text-muted"><?= ar_date($h['created_at'], true) ?></span></li><?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php admin_footer();
