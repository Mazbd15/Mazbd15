<?php
/** الصفحات الثابتة — نفس منطق المقالات بنوع «page» */
declare(strict_types=1);
const POSTS_TYPE = 'page';
require __DIR__ . '/posts.php';
