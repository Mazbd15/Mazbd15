<?php
/**
 * النسخ الاحتياطي: إنشاء يدوي، نسخ تلقائية دورية، تنزيل، استعادة بعد التأكيد، حذف، وسجل.
 * النسخ تُحفظ في storage/backups (خارج المجلد العام ومحمية بـ .htaccess).
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('admin');

if (($_GET['download'] ?? '') !== '') {
    $p = backup_path((string) $_GET['download']);
    if (!$p) { flash('danger', 'النسخة غير موجودة.'); redirect(admin_url('backups')); }
    backup_log('download', basename($p), (int) filesize($p));
    audit('download', 'backup', null, basename($p));
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($p) . '"');
    header('Content-Length: ' . filesize($p));
    header('X-Content-Type-Options: nosniff');
    readfile($p);
    exit;
}

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        [$ok, $msg] = backup_create('manual', !empty($_POST['with_files']));
        audit('create', 'backup', null, $msg);
        flash($ok ? 'success' : 'danger', $ok ? "تم إنشاء النسخة: $msg" : "فشل إنشاء النسخة: $msg");
    } elseif ($action === 'delete') {
        $p = backup_path((string) ($_POST['name'] ?? ''));
        if ($p && ($_POST['confirm_text'] ?? '') === 'حذف') {
            $size = (int) filesize($p);
            @unlink($p);
            backup_log('delete', basename($p), $size);
            audit('delete', 'backup', null, basename($p));
            flash('success', 'تم حذف النسخة.');
        } else flash('warning', 'لم يتم الحذف — اكتب «حذف» للتأكيد.');
    } elseif ($action === 'restore') {
        if (!role_at_least($user['role'], 'super_admin')) { flash('danger', 'الاستعادة متاحة للمدير العام فقط.'); redirect(admin_url('backups')); }
        $name = (string) ($_POST['name'] ?? '');
        if (($_POST['confirm_text'] ?? '') !== 'استعادة') { flash('warning', 'للاستعادة اكتب كلمة «استعادة» للتأكيد.'); redirect(admin_url('backups')); }
        $withDb = !empty($_POST['restore_db']);
        $withFiles = !empty($_POST['restore_files']);
        if (!$withDb && !$withFiles) { flash('warning', 'اختر ما تريد استعادته.'); redirect(admin_url('backups')); }
        $uid = $user['id'];
        [$ok, $msg] = backup_restore($name, $withDb, $withFiles);
        // بعد استعادة قاعدة البيانات قد تتغير الجلسة؛ نسجل العملية بعدها
        try { audit('restore', 'backup', null, $name . ' => ' . ($ok ? 'ok' : 'fail')); } catch (Throwable $e) {}
        flash($ok ? 'success' : 'danger', $msg);
    } elseif ($action === 'settings') {
        foreach (['backup_keep' => [2, 100], 'backup_auto_days' => [0, 90]] as $k => [$min, $max]) {
            $v = max($min, min($max, (int) ($_POST[$k] ?? 0)));
            db_exec('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', [(string) $v, $k]);
        }
        db_exec('UPDATE site_settings SET setting_value = ? WHERE setting_key = ?', [!empty($_POST['backup_include_files']) ? '1' : '0', 'backup_include_files']);
        audit('update', 'settings', null, 'backup settings');
        flash('success', 'تم حفظ إعدادات النسخ الاحتياطي.');
    }
    redirect(admin_url('backups'));
}

$list = backup_list();
$log = mig_table_exists('backups_log') ? db_all('SELECT b.*, u.name uname FROM backups_log b LEFT JOIN users u ON u.id = b.user_id ORDER BY b.id DESC LIMIT 30') : [];
$kinds = ['manual' => ['يدوية', 'primary'], 'auto' => ['تلقائية', 'info'], 'pre-migration' => ['قبل التحديث', 'warning'], 'pre-restore' => ['قبل الاستعادة', 'secondary']];
$actions = ['create' => 'إنشاء', 'restore' => 'استعادة', 'delete' => 'حذف', 'download' => 'تنزيل'];
$fmt = fn(int $b) => $b > 1048576 ? round($b / 1048576, 1) . ' م.ب' : round($b / 1024) . ' ك.ب';
$isSuper = role_at_least($user['role'], 'super_admin');

admin_header('النسخ الاحتياطي', 'backups', $user);
?>
<div class="row g-3">
  <div class="col-lg-8">
    <div class="panel">
      <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
        <h2 class="panel-title mb-0">النسخ المتوفرة (<?= count($list) ?>)</h2>
        <form method="post" class="ms-auto d-flex gap-2 align-items-center">
          <?= csrf_field() ?><input type="hidden" name="action" value="create">
          <div class="form-check mb-0"><input class="form-check-input" type="checkbox" name="with_files" value="1" id="wf" <?= setting('backup_include_files', '1') === '1' ? 'checked' : '' ?>><label class="form-check-label small" for="wf">مع الصور والملفات</label></div>
          <button class="btn btn-primary btn-sm"><i class="bi bi-plus-circle"></i> نسخة جديدة الآن</button>
        </form>
      </div>
      <?php if (!$list): ?><div class="alert alert-info">لا توجد نسخ بعد. أنشئ أول نسخة الآن.</div><?php endif; ?>
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>الملف</th><th>النوع</th><th>الحجم</th><th>التاريخ</th><th class="text-end">إجراءات</th></tr></thead>
          <tbody>
          <?php foreach ($list as $b): $k = $kinds[$b['kind']] ?? $kinds['manual']; $rid = md5($b['name']); ?>
            <tr>
              <td class="mono small"><?= e($b['name']) ?></td>
              <td><span class="badge bg-<?= $k[1] ?>"><?= $k[0] ?></span></td>
              <td><?= $fmt((int) $b['size']) ?></td>
              <td class="small"><?= e(ar_date(date('Y-m-d H:i:s', $b['mtime']), true)) ?></td>
              <td class="text-end text-nowrap">
                <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('backups', ['download' => $b['name']])) ?>" title="تنزيل"><i class="bi bi-download"></i></a>
                <?php if ($isSuper): ?><button class="btn btn-sm btn-outline-warning" data-bs-toggle="collapse" data-bs-target="#rs-<?= $rid ?>" title="استعادة"><i class="bi bi-arrow-counterclockwise"></i></button><?php endif; ?>
                <button class="btn btn-sm btn-outline-danger" data-bs-toggle="collapse" data-bs-target="#dl-<?= $rid ?>" title="حذف"><i class="bi bi-trash"></i></button>
              </td>
            </tr>
            <?php if ($isSuper): ?>
            <tr class="collapse" id="rs-<?= $rid ?>"><td colspan="5">
              <form method="post" class="bg-light rounded p-3">
                <?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="name" value="<?= e($b['name']) ?>">
                <div class="small text-danger mb-2"><i class="bi bi-exclamation-triangle-fill"></i> الاستعادة تستبدل بيانات قاعدة البيانات الحالية بمحتوى هذه النسخة. ستُنشأ نسخة «قبل الاستعادة» تلقائيًا أولًا لتتمكن من الرجوع.</div>
                <div class="d-flex flex-wrap gap-3 align-items-center">
                  <div class="form-check"><input class="form-check-input" type="checkbox" name="restore_db" value="1" id="rdb<?= $rid ?>" checked><label class="form-check-label" for="rdb<?= $rid ?>">قاعدة البيانات</label></div>
                  <div class="form-check"><input class="form-check-input" type="checkbox" name="restore_files" value="1" id="rf<?= $rid ?>"><label class="form-check-label" for="rf<?= $rid ?>">الصور والملفات (إن وُجدت في النسخة — لا تحذف الملفات الحالية)</label></div>
                  <input class="form-control form-control-sm w-auto" name="confirm_text" placeholder="اكتب: استعادة" required>
                  <button class="btn btn-sm btn-warning">تأكيد الاستعادة</button>
                </div>
              </form>
            </td></tr>
            <?php endif; ?>
            <tr class="collapse" id="dl-<?= $rid ?>"><td colspan="5">
              <form method="post" class="d-flex flex-wrap gap-2 align-items-center bg-light rounded p-2">
                <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="name" value="<?= e($b['name']) ?>">
                <span class="small">حذف هذه النسخة نهائيًا؟</span>
                <input class="form-control form-control-sm w-auto" name="confirm_text" placeholder="اكتب: حذف" required>
                <button class="btn btn-sm btn-danger">حذف</button>
              </form>
            </td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="panel">
      <h2 class="panel-title">سجل النسخ الاحتياطي</h2>
      <?php if (!$log): ?><p class="text-muted small mb-0">لا توجد عمليات مسجلة.</p><?php endif; ?>
      <div class="table-responsive"><table class="table table-sm small">
        <?php foreach ($log as $l): ?>
          <tr><td><?= e($actions[$l['action']] ?? $l['action']) ?></td><td class="mono"><?= e($l['file_name']) ?></td><td><?= e($kinds[$l['kind']][0] ?? $l['kind']) ?></td>
            <td><?= e($l['uname'] ?? 'النظام') ?></td><td><?= e($l['note'] ?? '') ?></td><td class="text-nowrap"><?= e(ar_date($l['created_at'], true)) ?></td></tr>
        <?php endforeach; ?>
      </table></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="panel">
      <h2 class="panel-title">الإعدادات</h2>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="settings">
        <label class="form-label">عدد النسخ المحتفظ بها</label>
        <input type="number" class="form-control mb-3" name="backup_keep" min="2" max="100" value="<?= (int) setting('backup_keep', '10') ?>">
        <label class="form-label">نسخة تلقائية كل (يوم) — 0 للإيقاف</label>
        <input type="number" class="form-control mb-1" name="backup_auto_days" min="0" max="90" value="<?= (int) setting('backup_auto_days', '7') ?>">
        <div class="form-text mb-3">تُنفذ النسخة التلقائية عند أول زيارة للوحة التحكم من مدير بعد انقضاء المدة (لا تحتاج Cron).</div>
        <div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="backup_include_files" value="1" id="bif" <?= setting('backup_include_files', '1') === '1' ? 'checked' : '' ?>><label class="form-check-label" for="bif">تضمين الصور والملفات المرفوعة</label></div>
        <button class="btn btn-primary w-100">حفظ</button>
      </form>
    </div>
    <div class="panel small">
      <h2 class="panel-title">معلومات</h2>
      <ul class="mb-0">
        <li>مكان الحفظ: <code class="mono">storage/backups</code> (غير متاح للزوار).</li>
        <li>تشمل: قاعدة البيانات كاملة + صور الموقع المرفوعة + مرفقات الطلبات وملفات المعرض.</li>
        <li>الضغط: <?= class_exists('ZipArchive') ? 'ZIP' : 'TAR (ZipArchive غير متوفر)' ?>.</li>
        <li>آخر نسخة: <?= ($t = backup_last_time()) ? e(ar_date(date('Y-m-d H:i:s', $t), true)) : '—' ?></li>
        <li>يُنصح بتنزيل نسخة دورية والاحتفاظ بها خارج الاستضافة.</li>
      </ul>
    </div>
  </div>
</div>
<?php admin_footer();
