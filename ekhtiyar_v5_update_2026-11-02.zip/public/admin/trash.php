<?php
/**
 * سلة المحذوفات: استعادة الأقسام والتخصصات والخدمات والأعمال والآراء والرسائل والمقالات،
 * واستعادة الصور التي نُقلت إلى سلة الوسائط. الحذف النهائي للمدير العام فقط وبتأكيد مكتوب.
 */
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('admin');
require_v5('سلة المحذوفات', 'trash', $user);

$tables = trash_tables();
$tab = (string) ($_GET['tab'] ?? 'categories');
if ($tab !== 'media' && !isset($tables[$tab])) $tab = 'categories';
$back = admin_url('trash', ['tab' => $tab]);
$isSuper = role_at_least($user['role'], 'super_admin');

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $table = (string) ($_POST['table'] ?? '');
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'restore' && isset($tables[$table])) {
        $row = db_one("SELECT * FROM `$table` WHERE id = ?", [$id]);
        if ($row) {
            // استعادة التخصص/الخدمة تحت قسم محذوف تُعيد القسم أولًا لتظهر فعلًا
            if (in_array($table, ['subcategories', 'services', 'portfolio_items'], true) && !empty($row['category_id'])) {
                $cat = db_one('SELECT id, deleted_at FROM categories WHERE id = ?', [$row['category_id']]);
                if ($cat && $cat['deleted_at']) { soft_restore('categories', (int) $cat['id']); flash('info', 'أُعيد القسم الأب أيضًا لأنه كان في السلة.'); }
            }
            if ($table === 'services' && !empty($row['subcategory_id'])) {
                $sub = db_one('SELECT id, deleted_at FROM subcategories WHERE id = ?', [$row['subcategory_id']]);
                if ($sub && $sub['deleted_at']) soft_restore('subcategories', (int) $sub['id']);
            }
            if ($table === 'testimonials' || $table === 'contact_messages' || $table === 'posts') {
                db_exec("UPDATE `$table` SET deleted_at = NULL WHERE id = ?", [$id]);
            } else {
                soft_restore($table, $id);
            }
            audit('restore', $table, $id, (string) ($row[$tables[$table][1]] ?? ''));
            flash('success', 'تمت الاستعادة.');
        }
    } elseif ($action === 'purge' && isset($tables[$table])) {
        if (!$isSuper) { flash('danger', 'الحذف النهائي للمدير العام فقط.'); redirect($back); }
        if (($_POST['confirm_text'] ?? '') !== 'حذف نهائي') { flash('warning', 'اكتب «حذف نهائي» للتأكيد.'); redirect($back); }
        $row = db_one("SELECT * FROM `$table` WHERE id = ? AND deleted_at IS NOT NULL", [$id]);
        if ($row) {
            $block = '';
            if ($table === 'categories') {
                $n = (int) db_value('SELECT COUNT(*) FROM services WHERE category_id = ?', [$id]);
                if ($n) $block = "لا يمكن الحذف النهائي لقسم مرتبط بـ $n خدمة (حتى المحذوفة). احذف خدماته نهائيًا أو انقلها أولًا.";
            }
            if ($table === 'subcategories' && (int) db_value('SELECT COUNT(*) FROM services WHERE subcategory_id = ?', [$id])) $block = 'التخصص مرتبط بخدمات — انقلها أولًا.';
            if ($table === 'services' && (int) db_value('SELECT COUNT(*) FROM requests WHERE service_id = ?', [$id])) $block = 'الخدمة مرتبطة بطلبات عملاء — لا تُحذف نهائيًا حفاظًا على سجل الطلبات (تبقى في السلة).';
            if ($block) { flash('warning', $block); redirect($back); }
            // الصور تُنقل لسلة الوسائط تلقائيًا فقط إن لم يعد يستخدمها أي سجل
            $imgs = [];
            foreach (['image', 'cover_image', 'avatar', 'bg_image', 'attachment', 'mobile_image'] as $c) if (!empty($row[$c])) $imgs[] = $row[$c];
            if ($table === 'services') foreach (db_all('SELECT file_path FROM service_files WHERE service_id = ?', [$id]) as $f) $imgs[] = $f['file_path'];
            if ($table === 'portfolio_items') { delete_portfolio_item($id); }
            else db_exec("DELETE FROM `$table` WHERE id = ?", [$id]);
            foreach ($imgs as $im) delete_public_image($im);
            audit('purge', $table, $id, (string) ($row[$tables[$table][1]] ?? ''));
            flash('success', 'تم الحذف النهائي. الصور غير المستخدمة نُقلت لسلة الوسائط.');
        }
    } elseif ($action === 'media_restore') {
        $rel = (string) ($_POST['rel'] ?? '');
        $ok = media_trash_restore($rel);
        flash($ok ? 'success' : 'danger', $ok ? 'تمت استعادة الصورة إلى مكانها.' : 'تعذرت الاستعادة (قد يوجد ملف بنفس الاسم في الموقع).');
        audit('restore', 'media', null, $rel);
    }
    redirect($back);
}

$counts = [];
foreach ($tables as $t => $_) $counts[$t] = mig_table_exists($t) && has_col($t, 'deleted_at') ? (int) db_value("SELECT COUNT(*) FROM `$t` WHERE deleted_at IS NOT NULL") : 0;
$mediaFiles = media_scan(media_trash_dir() . '/' . MEDIA_UPLOAD_BASE, MEDIA_UPLOAD_BASE);
$counts['media'] = count($mediaFiles);

admin_header('سلة المحذوفات', 'trash', $user);
?>
<p class="text-muted small">العناصر المحذوفة مخفية من الموقع ولوحة التحكم مع الاحتفاظ بكل بياناتها وصورها. يمكن استعادتها بضغطة. الحذف النهائي للمدير العام فقط.</p>
<ul class="nav nav-pills mb-3 flex-wrap gap-1">
  <?php foreach ($tables as $t => [$label]): ?>
    <li class="nav-item"><a class="nav-link<?= $tab === $t ? ' active' : '' ?>" href="<?= e(admin_url('trash', ['tab' => $t])) ?>"><?= e($label) ?> <span class="badge bg-light text-dark"><?= $counts[$t] ?></span></a></li>
  <?php endforeach; ?>
  <li class="nav-item"><a class="nav-link<?= $tab === 'media' ? ' active' : '' ?>" href="<?= e(admin_url('trash', ['tab' => 'media'])) ?>">الصور <span class="badge bg-light text-dark"><?= $counts['media'] ?></span></a></li>
</ul>

<div class="panel">
<?php if ($tab === 'media'): ?>
  <?php if (!$mediaFiles): ?><p class="text-muted mb-0">لا توجد صور في السلة.</p><?php endif; ?>
  <div class="row g-2">
  <?php foreach ($mediaFiles as $rel => $info): ?>
    <div class="col-6 col-md-3 col-xl-2"><div class="border rounded p-2 small text-center h-100">
      <div class="bg-light rounded mb-1 d-flex align-items-center justify-content-center" style="height:80px"><i class="bi bi-file-image fs-2 text-muted"></i></div>
      <div class="text-truncate mono" title="<?= e($rel) ?>"><?= e(basename($rel)) ?></div>
      <div class="text-muted"><?= round($info['size'] / 1024) ?> ك.ب — <?= e(ar_date(date('Y-m-d H:i:s', $info['mtime']))) ?></div>
      <form method="post" class="mt-1"><?= csrf_field() ?><input type="hidden" name="action" value="media_restore"><input type="hidden" name="rel" value="<?= e($rel) ?>">
        <button class="btn btn-sm btn-outline-success w-100"><i class="bi bi-arrow-counterclockwise"></i> استعادة</button></form>
    </div></div>
  <?php endforeach; ?>
  </div>
<?php else:
    [$label, $nameCol] = $tables[$tab];
    $rows = $counts[$tab] ? db_all("SELECT * FROM `$tab` WHERE deleted_at IS NOT NULL ORDER BY deleted_at DESC LIMIT 300") : [];
    $catNames = array_column(db_all('SELECT id, name FROM categories'), 'name', 'id');
?>
  <?php if (!$rows): ?><p class="text-muted mb-0">لا توجد عناصر محذوفة في «<?= e($label) ?>».</p><?php else: ?>
  <div class="table-responsive"><table class="table align-middle">
    <thead><tr><th>العنصر</th><th>القسم</th><th>تاريخ الحذف</th><th class="text-end">إجراءات</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): $rid = $tab . $r['id']; ?>
      <tr>
        <td><strong><?= e((string) ($r[$nameCol] ?? ('#' . $r['id']))) ?></strong><?php if ($tab === 'contact_messages'): ?><div class="small text-muted"><?= e($r['name']) ?></div><?php endif; ?></td>
        <td class="small"><?= e($catNames[$r['category_id'] ?? 0] ?? '—') ?></td>
        <td class="small"><?= e(ar_date($r['deleted_at'], true)) ?></td>
        <td class="text-end text-nowrap">
          <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="table" value="<?= e($tab) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
            <button class="btn btn-sm btn-success"><i class="bi bi-arrow-counterclockwise"></i> استعادة</button></form>
          <?php if ($isSuper): ?><button class="btn btn-sm btn-outline-danger" data-bs-toggle="collapse" data-bs-target="#pg-<?= e($rid) ?>">حذف نهائي</button><?php endif; ?>
        </td>
      </tr>
      <?php if ($isSuper): ?>
      <tr class="collapse" id="pg-<?= e($rid) ?>"><td colspan="4">
        <form method="post" class="d-flex flex-wrap gap-2 align-items-center bg-light rounded p-2"><?= csrf_field() ?>
          <input type="hidden" name="action" value="purge"><input type="hidden" name="table" value="<?= e($tab) ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
          <span class="small text-danger"><i class="bi bi-exclamation-octagon"></i> لا يمكن التراجع عن الحذف النهائي (إلا من نسخة احتياطية).</span>
          <input class="form-control form-control-sm w-auto" name="confirm_text" placeholder="اكتب: حذف نهائي" required>
          <button class="btn btn-sm btn-danger">تأكيد</button>
        </form>
      </td></tr>
      <?php endif; ?>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
<?php endif; ?>
</div>
<?php admin_footer();
