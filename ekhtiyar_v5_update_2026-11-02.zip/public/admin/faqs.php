<?php
declare(strict_types=1);
require dirname(__DIR__, 2) . '/includes/admin.php';
$user = require_admin('specialist');

$cats = scoped_categories($user);
$canGeneral = can($user, 'faqs.general');
$scope = (string) ($_GET['scope'] ?? ($canGeneral ? 'general' : 'category'));
if (!$canGeneral && $scope === 'general') $scope = 'category';

/** القسم الفعلي للسؤال (null = سؤال عام) */
function faq_category(?int $categoryId, ?int $serviceId): ?int
{
    if ($serviceId) return (int) db_value('SELECT category_id FROM services WHERE id = ?', [$serviceId]) ?: -1;
    return $categoryId ?: null;
}
$canFaq = fn(?int $cid): bool => $cid === null ? $canGeneral : ($cid > 0 && can_manage_category($user, $cid));
$editId = (int) ($_GET['edit'] ?? 0);
$isNew = isset($_GET['new']);
$errors = [];

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    $back = admin_url('faqs', ['scope' => $_POST['scope'] ?? $scope]);
    if ($id) {
        $cur = db_one('SELECT category_id, service_id FROM faqs WHERE id = ?', [$id]);
        if (!$cur || !$canFaq(faq_category($cur['category_id'] ? (int) $cur['category_id'] : null, $cur['service_id'] ? (int) $cur['service_id'] : null))) deny_scope($back);
    }
    if ($action === 'home' && !$canGeneral) deny_scope($back);
    if ($action === 'move') {
        $row = db_one('SELECT category_id, service_id FROM faqs WHERE id = ?', [$id]);
        if ($row) move_item('faqs', $id, $_POST['dir'] === 'up' ? 'up' : 'down', $row['service_id'] ? 'service_id' : 'category_id');
        redirect($back);
    }
    if ($action === 'toggle') { db_exec('UPDATE faqs SET is_active = 1 - is_active WHERE id = ?', [$id]); redirect($back); }
    if ($action === 'home') { db_exec('UPDATE faqs SET show_on_home = 1 - show_on_home WHERE id = ?', [$id]); redirect($back); }
    if ($action === 'delete') {
        db_exec('DELETE FROM faqs WHERE id = ?', [$id]);
        audit('delete', 'faq', $id);
        flash('success', 'تم حذف السؤال.');
        redirect($back);
    }
    if ($action === 'save') {
        $type = $_POST['faq_scope'] ?? 'general';
        $data = [
            'question'     => mb_substr(trim((string) ($_POST['question'] ?? '')), 0, 400),
            'answer'       => trim((string) ($_POST['answer'] ?? '')),
            'category_id'  => $type === 'category' ? ((int) ($_POST['category_id'] ?? 0) ?: null) : null,
            'service_id'   => $type === 'service' ? ((int) ($_POST['service_id'] ?? 0) ?: null) : null,
            'show_on_home' => $type === 'general' && !empty($_POST['show_on_home']) ? 1 : 0,
            'is_active'    => !empty($_POST['is_active']) ? 1 : 0,
        ];
        if ($data['question'] === '' || $data['answer'] === '') $errors[] = 'السؤال والإجابة مطلوبان.';
        if ($type === 'category' && !$data['category_id']) $errors[] = 'اختر القسم.';
        if ($type === 'service' && (!$data['service_id'] || !db_value('SELECT id FROM services WHERE id = ?', [$data['service_id']]))) $errors[] = 'اختر خدمة صحيحة.';
        if (!$errors && !$canFaq(faq_category($data['category_id'], $data['service_id']))) $errors[] = 'لا تملك صلاحية إضافة سؤال في هذا المكان.';
        if (!$errors) {
            if ($id) { db_update('faqs', $data, $id); audit('update', 'faq', $id); }
            else { $data['sort_order'] = (int) db_value('SELECT COALESCE(MAX(sort_order),0)+10 FROM faqs'); $id = db_insert('faqs', $data); audit('create', 'faq', $id); }
            flash('success', 'تم حفظ السؤال.');
            redirect(admin_url('faqs', ['scope' => $type]));
        }
        $editId = $id; $isNew = !$id; $formData = $data + ['_scope' => $type];
    }
}

admin_header('الأسئلة الشائعة', 'faqs', $user);
if ($editId || $isNew):
    $f = $formData ?? ($editId ? db_one('SELECT * FROM faqs WHERE id = ?', [$editId]) : null) ?? ['question' => '', 'answer' => '', 'category_id' => null, 'service_id' => null, 'show_on_home' => 0, 'is_active' => 1];
    if ($editId && !$formData && !$canFaq(faq_category($f['category_id'] ? (int) $f['category_id'] : null, $f['service_id'] ? (int) $f['service_id'] : null))) { echo '<div class="alert alert-danger">هذا السؤال خارج نطاق صلاحياتك.</div>'; admin_footer(); exit; }
    $fs = $f['_scope'] ?? ($f['service_id'] ? 'service' : ($f['category_id'] ? 'category' : ($isNew ? $scope : 'general')));
    [$fsw, $fsp] = scope_sql($user, 's.category_id');
    $services = db_all("SELECT s.id, s.name, c.name cat FROM services s JOIN categories c ON c.id = s.category_id WHERE $fsw ORDER BY c.sort_order, s.sort_order", $fsp);
    ?>
    <div class="panel">
      <h2 class="panel-title"><?= $editId ? 'تعديل سؤال' : 'إضافة سؤال' ?></h2>
      <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
      <form method="post">
        <?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int) $editId ?>">
        <div class="row g-3">
          <div class="col-md-4"><label class="form-label">مكان الظهور</label>
            <select class="form-select" name="faq_scope" id="faq-scope">
              <?php if ($canGeneral): ?><option value="general"<?= selected($fs, 'general') ?>>عام (صفحة الأسئلة/الرئيسية)</option><?php endif; ?>
              <option value="category"<?= selected($fs, 'category') ?>>قسم رئيسي محدد</option>
              <option value="service"<?= selected($fs, 'service') ?>>خدمة محددة</option>
            </select></div>
          <div class="col-md-8" data-scope="category"><label class="form-label">القسم</label><select class="form-select" name="category_id"><option value="">—</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>"<?= selected($f['category_id'], $c['id']) ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-8" data-scope="service"><label class="form-label">الخدمة</label><select class="form-select" name="service_id"><option value="">—</option><?php $lc = null; foreach ($services as $s): if ($lc !== $s['cat']) { if ($lc !== null) echo '</optgroup>'; echo '<optgroup label="' . e($s['cat']) . '">'; $lc = $s['cat']; } ?><option value="<?= $s['id'] ?>"<?= selected($f['service_id'], $s['id']) ?>><?= e($s['name']) ?></option><?php endforeach; if ($lc !== null) echo '</optgroup>'; ?></select></div>
          <div class="col-12"><label class="form-label">السؤال *</label><input class="form-control" name="question" maxlength="400" required value="<?= e($f['question']) ?>"></div>
          <div class="col-12"><label class="form-label">الإجابة *</label><textarea class="form-control" name="answer" rows="5" required><?= e($f['answer']) ?></textarea></div>
          <div class="col-12 d-flex gap-4">
            <label class="form-check"><input class="form-check-input" type="checkbox" name="is_active" value="1"<?= checked($f['is_active']) ?>> مفعّل</label>
            <label class="form-check" data-scope="general"><input class="form-check-input" type="checkbox" name="show_on_home" value="1"<?= checked($f['show_on_home']) ?>> إظهار في الصفحة الرئيسية</label>
          </div>
        </div>
        <div class="mt-4 d-flex gap-2"><button class="btn btn-primary">حفظ</button><a class="btn btn-light" href="<?= e(admin_url('faqs', ['scope' => $fs])) ?>">إلغاء</a></div>
      </form>
    </div>
<?php else:
    $sql = ['general' => 'f.category_id IS NULL AND f.service_id IS NULL', 'category' => 'f.category_id IS NOT NULL AND f.service_id IS NULL', 'service' => 'f.service_id IS NOT NULL'];
    if (!isset($sql[$scope])) $scope = 'general';
    if (!$canGeneral && $scope === 'general') $scope = 'category';
    [$lw, $lp] = scope_sql($user, 'COALESCE(f.category_id, s.category_id)');
    $rows = db_all("SELECT f.*, c.name cat, s.name svc FROM faqs f LEFT JOIN categories c ON c.id = f.category_id LEFT JOIN services s ON s.id = f.service_id WHERE {$sql[$scope]} AND $lw ORDER BY c.sort_order, f.service_id, f.sort_order, f.id", $lp);
    ?>
    <div class="d-flex flex-wrap justify-content-between gap-2 mb-3">
      <ul class="nav nav-pills">
        <?php foreach (['general' => 'عامة', 'category' => 'حسب القسم', 'service' => 'حسب الخدمة'] as $k => $l): if ($k === 'general' && !$canGeneral) continue; ?>
          <li class="nav-item"><a class="nav-link<?= $scope === $k ? ' active' : '' ?>" href="<?= e(admin_url('faqs', ['scope' => $k])) ?>"><?= $l ?></a></li>
        <?php endforeach; ?>
      </ul>
      <a class="btn btn-primary" href="<?= e(admin_url('faqs', ['new' => 1, 'scope' => $scope])) ?>"><i class="bi bi-plus-lg"></i> سؤال جديد</a>
    </div>
    <div class="panel p-0"><div class="table-responsive"><table class="table align-middle mb-0">
      <thead><tr><th>الترتيب</th><th>السؤال</th><?php if ($scope !== 'general'): ?><th>مرتبط بـ</th><?php endif; ?><th>الحالة</th><th class="text-end">إجراءات</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= move_buttons((int) $r['id']) ?></td>
          <td><strong><?= e($r['question']) ?></strong><br><small class="text-muted"><?= e(excerpt($r['answer'], 110)) ?></small></td>
          <?php if ($scope !== 'general'): ?><td class="small"><?= e($r['svc'] ?? $r['cat']) ?></td><?php endif; ?>
          <td class="text-nowrap">
            <form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="scope" value="<?= e($scope) ?>"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-link p-0"><?= active_badge($r['is_active']) ?></button></form>
            <?php if ($scope === 'general'): ?><form method="post" class="d-inline"><?= csrf_field() ?><input type="hidden" name="scope" value="general"><input type="hidden" name="action" value="home"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-link p-0"><span class="badge <?= $r['show_on_home'] ? 'text-bg-warning' : 'text-bg-light' ?>"><i class="bi bi-house"></i> الرئيسية</span></button></form><?php endif; ?>
          </td>
          <td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('faqs', ['edit' => $r['id']])) ?>"><i class="bi bi-pencil"></i></a> <?= delete_button('delete', (int) $r['id'], 'حذف هذا السؤال؟', '<input type="hidden" name="scope" value="' . e($scope) . '">') ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="5" class="text-center text-muted py-4">لا توجد أسئلة.</td></tr><?php endif; ?>
      </tbody>
    </table></div></div>
<?php endif;
admin_footer();
