<?php
/** «حسابي» للأعضاء (والمتاح أيضًا لفريق العمل لإدارة ملفهم الشخصي) */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
$user = require_member();
$tab = in_array($_GET['tab'] ?? '', ['requests', 'notifications', 'profile', 'password'], true) ? $_GET['tab'] : 'requests';
$errors = [];

if (is_post()) {
    require_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'profile') {
        $name = mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120);
        $phone = mb_substr(trim((string) ($_POST['phone'] ?? '')), 0, 30);
        $spec = mb_substr(trim((string) ($_POST['specialization'] ?? '')), 0, 190);
        if (mb_strlen($name) < 3) $errors[] = 'الاسم قصير جدًا.';
        if ($phone !== '' && !preg_match('/^\+?[0-9\s\-()]{8,20}$/', $phone)) $errors[] = 'رقم الجوال غير صالح.';
        if (!$errors) {
            db_exec('UPDATE users SET name = ?, phone = ?, specialization = ? WHERE id = ?', [$name, $phone ?: null, $spec ?: null, $user['id']]);
            flash('success', 'تم تحديث بياناتك.');
            redirect(route('account', ['tab' => 'profile']));
        }
        $tab = 'profile';
    }
    if ($action === 'password') {
        $row = db_one('SELECT password_hash FROM users WHERE id = ?', [$user['id']]);
        $new = (string) ($_POST['new'] ?? '');
        if (!password_verify((string) ($_POST['current'] ?? ''), $row['password_hash'])) $errors[] = 'كلمة المرور الحالية غير صحيحة.';
        if ($p = password_problems($new)) $errors[] = $p;
        if (!hash_equals($new, (string) ($_POST['confirm'] ?? ''))) $errors[] = 'تأكيد كلمة المرور غير مطابق.';
        if (!$errors) {
            db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            session_regenerate_id(true);
            flash('success', 'تم تغيير كلمة المرور.');
            redirect(route('account', ['tab' => 'password']));
        }
        $tab = 'password';
    }
    if ($action === 'reply') {
        $rid = (int) ($_POST['request_id'] ?? 0);
        $body = mb_substr(trim((string) ($_POST['body'] ?? '')), 0, 2000);
        $req = db_one('SELECT id, reference_code, category_id, assigned_to FROM requests WHERE id = ? AND member_id = ?', [$rid, $user['id']]);
        if ($req && mb_strlen($body) >= 2 && !rate_limited('reply', 10, 600)) {
            db_insert('request_notes', ['request_id' => $rid, 'user_id' => $user['id'], 'body' => $body, 'is_internal' => 0]);
            $link = admin_url('request_view', ['id' => $rid]);
            if ($req['assigned_to']) notify((int) $req['assigned_to'], 'رد جديد من العميل على ' . $req['reference_code'], excerpt($body, 120), $link);
            else notify_staff('admin', 'رد جديد من العميل على ' . $req['reference_code'], excerpt($body, 120), $link);
            flash('success', 'تم إرسال رسالتك للفريق.');
        }
        redirect(route('account', ['tab' => 'requests', 'r' => $rid]) . '#req-' . $rid);
    }
    if ($action === 'read_all') {
        db_exec('UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [$user['id']]);
        redirect(route('account', ['tab' => 'notifications']));
    }
}

$full = db_one('SELECT * FROM users WHERE id = ?', [$user['id']]);
$requests = db_all('SELECT r.*, c.name AS category_name, s.slug AS service_slug FROM requests r LEFT JOIN categories c ON c.id = r.category_id LEFT JOIN services s ON s.id = r.service_id WHERE r.member_id = ? ORDER BY r.created_at DESC', [$user['id']]);
$notes = [];
if ($requests) {
    $ids = array_column($requests, 'id');
    foreach (db_all('SELECT n.*, u.name, u.role FROM request_notes n LEFT JOIN users u ON u.id = n.user_id WHERE n.is_internal = 0 AND n.request_id IN (' . implode(',', array_map('intval', $ids)) . ') ORDER BY n.created_at', []) as $n) {
        $notes[$n['request_id']][] = $n;
    }
}
$notifications = db_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', [$user['id']]);
$unread = count(array_filter($notifications, fn($n) => !$n['read_at']));
if ($tab === 'notifications' && $unread) db_exec('UPDATE notifications SET read_at = NOW() WHERE user_id = ? AND read_at IS NULL', [$user['id']]);
$openReq = (int) ($_GET['r'] ?? 0);

$page_title = 'حسابي';
$page_description = 'لوحة حسابك في منصة اختيارك.';
$noindex = true;
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero text-start">
  <div class="container d-flex flex-wrap align-items-center gap-3">
    <span class="avatar-lg"><?= e(mb_substr($full['name'], 0, 1)) ?></span>
    <div>
      <h1 class="mb-0">مرحبًا، <?= e($full['name']) ?></h1>
      <p class="mb-0"><?= e(role_labels()[$full['role']] ?? '') ?> · عضو منذ <?= ar_date($full['created_at']) ?></p>
    </div>
    <div class="ms-auto d-flex gap-2 flex-wrap">
      <?php if (in_array($full['role'], staff_roles(), true)): ?><a class="btn btn-gold" href="<?= e(admin_url()) ?>"><i class="bi bi-speedometer2"></i> لوحة التحكم</a><?php endif; ?>
      <a class="btn btn-outline-light" href="<?= e(route('order')) ?>"><i class="bi bi-plus-lg"></i> طلب جديد</a>
    </div>
  </div>
</section>
<section class="section pt-4">
  <div class="container">
    <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
    <div class="row g-4">
      <aside class="col-lg-3">
        <nav class="side-nav sticky-lg-top" aria-label="قائمة الحساب">
          <a class="side-link<?= $tab === 'requests' ? ' active' : '' ?>" href="<?= e(route('account', ['tab' => 'requests'])) ?>"><i class="bi bi-inbox"></i> طلباتي <span><?= count($requests) ?></span></a>
          <a class="side-link<?= $tab === 'notifications' ? ' active' : '' ?>" href="<?= e(route('account', ['tab' => 'notifications'])) ?>"><i class="bi bi-bell"></i> الإشعارات <?= $unread ? '<span class="bg-warning text-dark">' . $unread . '</span>' : '' ?></a>
          <a class="side-link<?= $tab === 'profile' ? ' active' : '' ?>" href="<?= e(route('account', ['tab' => 'profile'])) ?>"><i class="bi bi-person-gear"></i> بياناتي</a>
          <a class="side-link<?= $tab === 'password' ? ' active' : '' ?>" href="<?= e(route('account', ['tab' => 'password'])) ?>"><i class="bi bi-key"></i> كلمة المرور</a>
          <form method="post" action="<?= e(route('logout')) ?>"><?= csrf_field() ?><button class="side-link w-100 border-0 bg-transparent text-danger"><i class="bi bi-box-arrow-right"></i> تسجيل الخروج</button></form>
        </nav>
      </aside>
      <div class="col-lg-9">
      <?php if ($tab === 'requests'): ?>
        <?php if (!$requests): ?>
          <div class="empty-state"><i class="bi bi-inbox"></i><h2>لا توجد طلبات بعد</h2><p>عند إرسال طلب وأنت مسجل الدخول مع الموافقة على حفظه، سيظهر هنا لتتابع حالته ورسائل الفريق.</p><a class="btn btn-navy" href="<?= e(route('order')) ?>">أرسل أول طلب</a></div>
        <?php else: foreach ($requests as $r): [$sl, $sc] = request_statuses()[$r['status']]; ?>
          <article class="content-card req-card" id="req-<?= (int) $r['id'] ?>">
            <div class="d-flex flex-wrap justify-content-between gap-2 align-items-start">
              <div><h2 class="h6 mb-1"><?= e($r['service_label']) ?></h2><small class="text-muted"><?= e($r['reference_code']) ?> · <?= e($r['category_name'] ?? '') ?> · <?= ar_date($r['created_at'], true) ?></small></div>
              <span class="badge text-bg-<?= $sc ?> fs-6"><?= e($sl) ?></span>
            </div>
            <ol class="status-track">
              <?php $order = ['new', 'reviewing', 'awaiting_client', 'completed']; $pos = array_search($r['status'], $order, true);
              foreach (['new' => 'استلام', 'reviewing' => 'مراجعة', 'awaiting_client' => 'بانتظارك', 'completed' => 'مكتمل'] as $k => $l): $i = array_search($k, $order, true); ?>
                <li class="<?= $r['status'] === 'cancelled' ? '' : ($pos !== false && $i <= $pos ? 'done' : '') ?>"><?= $l ?></li>
              <?php endforeach; ?>
            </ol>
            <details<?= $openReq === (int) $r['id'] ? ' open' : '' ?>>
              <summary class="small fw-bold">التفاصيل والرسائل (<?= count($notes[$r['id']] ?? []) ?>)</summary>
              <p class="small mt-2 mb-2 pre-text"><?= nl2br(e($r['description'])) ?></p>
              <div class="chat">
                <?php foreach ($notes[$r['id']] ?? [] as $n): $mine = (int) $n['user_id'] === (int) $user['id']; ?>
                  <div class="chat-msg<?= $mine ? ' mine' : '' ?>"><strong><?= $mine ? 'أنت' : 'فريق اختيارك' ?></strong><p class="mb-0"><?= nl2br(e($n['body'])) ?></p><small><?= ar_date($n['created_at'], true) ?></small></div>
                <?php endforeach; ?>
              </div>
              <?php if (!in_array($r['status'], ['completed', 'cancelled'], true)): ?>
                <form method="post" class="d-flex gap-2 mt-2"><?= csrf_field() ?><input type="hidden" name="action" value="reply"><input type="hidden" name="request_id" value="<?= (int) $r['id'] ?>">
                  <input class="form-control" name="body" maxlength="2000" required placeholder="اكتب رسالة للفريق..."><button class="btn btn-navy"><i class="bi bi-send"></i></button></form>
              <?php endif; ?>
              <a class="btn btn-sm btn-whatsapp mt-2" href="<?= e(wa_link('السلام عليكم، بخصوص طلبي رقم ' . $r['reference_code'] . ' في منصة ' . setting('site_name') . '.')) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> متابعة عبر واتساب</a>
            </details>
          </article>
        <?php endforeach; endif; ?>
      <?php elseif ($tab === 'notifications'): ?>
        <div class="content-card">
          <h2><i class="bi bi-bell"></i> الإشعارات</h2>
          <?php if (!$notifications): ?><p class="text-muted mb-0">لا توجد إشعارات.</p><?php endif; ?>
          <ul class="list-unstyled mb-0">
            <?php foreach ($notifications as $n): ?>
              <li class="notif-item<?= $n['read_at'] ? '' : ' unread' ?>"><strong><?= e($n['title']) ?></strong><?php if ($n['body']): ?><p class="mb-0 small"><?= e($n['body']) ?></p><?php endif; ?><small class="text-muted"><?= ar_date($n['created_at'], true) ?></small></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php elseif ($tab === 'profile'): ?>
        <form class="form-card" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="profile">
          <h2 class="h5 mb-3">بياناتي</h2>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">الاسم</label><input class="form-control" name="name" required maxlength="120" value="<?= e($full['name']) ?>"></div>
            <div class="col-md-6"><label class="form-label">البريد الإلكتروني</label><input class="form-control" value="<?= e($full['email']) ?>" dir="ltr" disabled><div class="form-text">لتغيير البريد تواصل مع الإدارة.</div></div>
            <div class="col-md-6"><label class="form-label">رقم الجوال</label><input class="form-control" name="phone" dir="ltr" value="<?= e($full['phone']) ?>"></div>
            <div class="col-md-6"><label class="form-label">التخصص</label><input class="form-control" name="specialization" maxlength="190" value="<?= e($full['specialization']) ?>"></div>
          </div>
          <button class="btn btn-navy mt-3">حفظ</button>
        </form>
      <?php else: ?>
        <form class="form-card" method="post" style="max-width:520px"><?= csrf_field() ?><input type="hidden" name="action" value="password">
          <h2 class="h5 mb-3">تغيير كلمة المرور</h2>
          <div class="mb-3"><label class="form-label">كلمة المرور الحالية</label><input class="form-control" type="password" name="current" required autocomplete="current-password"></div>
          <div class="mb-3"><label class="form-label">الجديدة</label><input class="form-control" type="password" name="new" minlength="10" required autocomplete="new-password"><div class="form-text">10 أحرف على الأقل، حروف وأرقام.</div></div>
          <div class="mb-3"><label class="form-label">تأكيد الجديدة</label><input class="form-control" type="password" name="confirm" minlength="10" required autocomplete="new-password"></div>
          <button class="btn btn-navy">حفظ</button>
        </form>
      <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
