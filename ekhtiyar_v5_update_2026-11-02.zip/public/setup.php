<?php
/**
 * صفحة الإعداد الأولى — لإنشاء أول حساب مسؤول عبر المتصفح (لمن لا يملك سطر أوامر على الاستضافة).
 * شروط العمل:
 *   1) أن يكون SETUP_KEY مضبوطًا في ملف .env (قيمة طويلة عشوائية).
 *   2) ألا يوجد أي حساب مسؤول في قاعدة البيانات.
 * بعد إنشاء الحساب تتعطل الصفحة تلقائيًا. يُفضّل حذف هذا الملف بعد الاستخدام.
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

header('X-Robots-Tag: noindex, nofollow');
$setupKey = (string) config('app.setup_key', '');
$hasUsers = (int) db_value('SELECT COUNT(*) FROM users') > 0;

if ($setupKey === '' || strlen($setupKey) < 16 || $hasUsers) {
    not_found();
}

$errors = [];
$done = false;
if (is_post()) {
    require_csrf();
    if (rate_limited('setup', 5, 600)) {
        $errors[] = 'محاولات كثيرة، حاول لاحقًا.';
    } elseif (!hash_equals($setupKey, (string) ($_POST['setup_key'] ?? ''))) {
        $errors[] = 'مفتاح الإعداد غير صحيح.';
    } else {
        $name = trim((string) ($_POST['name'] ?? ''));
        $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
        $pass = (string) ($_POST['password'] ?? '');
        if ($name === '' || mb_strlen($name) > 120) $errors[] = 'الاسم مطلوب.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'البريد الإلكتروني غير صالح.';
        if ($p = password_problems($pass)) $errors[] = $p;
        if (!hash_equals($pass, (string) ($_POST['password_confirm'] ?? ''))) $errors[] = 'كلمتا المرور غير متطابقتين.';
        if (!$errors) {
            $id = db_insert('users', ['name' => $name, 'email' => $email, 'password_hash' => password_hash($pass, PASSWORD_DEFAULT), 'role' => 'super_admin']);
            $_SESSION['uid'] = $id; // لتسجيل العملية باسمه
            audit('setup', 'user', $id, 'إنشاء أول حساب مسؤول عبر صفحة الإعداد');
            unset($_SESSION['uid']);
            $done = true;
        }
    }
}
?><!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>الإعداد الأولي | اختيارك</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
<link rel="stylesheet" href="<?= asset('css/admin.css') ?>">
</head>
<body class="auth-body">
<main class="auth-card">
  <h1 class="h4 mb-1">الإعداد الأولي للمنصة</h1>
  <p class="text-muted small mb-4">إنشاء أول حساب «مدير عام».</p>
  <?php if ($done): ?>
    <div class="alert alert-success">تم إنشاء الحساب بنجاح. تعطلت صفحة الإعداد تلقائيًا. يُنصح بحذف ملف <code>public/setup.php</code> وإفراغ <code>SETUP_KEY</code>.</div>
    <a class="btn btn-primary w-100" href="<?= e(admin_url('login')) ?>">الانتقال لتسجيل الدخول</a>
  <?php else: ?>
    <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <div class="mb-3"><label class="form-label">مفتاح الإعداد (SETUP_KEY)</label><input type="password" name="setup_key" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">الاسم</label><input name="name" class="form-control" maxlength="120" required value="<?= e($_POST['name'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label">البريد الإلكتروني</label><input type="email" name="email" class="form-control" dir="ltr" required value="<?= e($_POST['email'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label">كلمة المرور</label><input type="password" name="password" class="form-control" minlength="10" required autocomplete="new-password"><div class="form-text">10 أحرف على الأقل وتحتوي حروفًا وأرقامًا.</div></div>
      <div class="mb-4"><label class="form-label">تأكيد كلمة المرور</label><input type="password" name="password_confirm" class="form-control" minlength="10" required autocomplete="new-password"></div>
      <button class="btn btn-primary w-100">إنشاء الحساب</button>
    </form>
  <?php endif; ?>
</main>
</body>
</html>
