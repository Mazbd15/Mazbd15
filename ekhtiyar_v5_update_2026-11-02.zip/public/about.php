<?php
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
$active_nav = 'about';
$page_title = 'من نحن';
$page_description = 'تعرّف على منصة اختيارك للخدمات الطلابية: رؤيتنا وقيمنا وطريقة عملنا في تقديم الدعم الأكاديمي والهندسي والتقني.';
$breadcrumbs = [['من نحن', null]];
$stats = stats_public();
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero">
  <div class="container"><h1>من نحن</h1><p><?= e(setting('site_tagline')) ?></p></div>
</section>
<section class="section pt-4">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-7">
        <article class="content-card">
          <h2><i class="bi bi-building"></i> قصتنا</h2>
          <?php foreach (preg_split('/\n\s*\n/', (string) setting('about_text')) as $p): ?><p><?= nl2br(e(trim($p))) ?></p><?php endforeach; ?>
        </article>
      </div>
      <div class="col-lg-5">
        <ul class="about-stats">
          <li><strong><?= $stats['categories'] ?></strong><span>أقسام رئيسية</span></li>
          <li><strong><?= $stats['subs'] ?></strong><span>تخصص فرعي</span></li>
          <li><strong><?= $stats['services'] ?>+</strong><span>خدمة</span></li>
          <li><strong>24/7</strong><span>استقبال الطلبات</span></li>
        </ul>
      </div>
    </div>
    <div class="row g-4 mt-2">
      <?php foreach ([
        ['bi-eye', 'رؤيتنا', 'أن نكون الخيار الأول للطالب العربي الباحث عن دعم أكاديمي وتقني موثوق.'],
        ['bi-bullseye', 'رسالتنا', 'تقديم خدمات احترافية واضحة تعزز فهم الطالب وتساعده على التميز، بأسلوب أخلاقي يحترم الأنظمة.'],
        ['bi-gem', 'قيمنا', 'الجودة، الأمانة، الخصوصية، الوضوح، والالتزام بالمواعيد.'],
      ] as [$ic, $t, $d]): ?>
        <div class="col-md-4"><article class="feature-card h-100"><span class="feature-icon"><i class="bi <?= $ic ?>"></i></span><h3><?= e($t) ?></h3><p><?= e($d) ?></p></article></div>
      <?php endforeach; ?>
    </div>
    <?= render_notice('نؤمن بالنزاهة الأكاديمية: خدماتنا تهدف إلى الشرح والتوجيه والمراجعة وتحسين الجودة. الأعمال الهندسية نماذج تعليمية لا تُعد مخططات تنفيذية معتمدة، ولا نقدم أي وثائق رسمية أو طبية.', 'bi-shield-check') ?>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
