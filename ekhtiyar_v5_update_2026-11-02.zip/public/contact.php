<?php
/** صفحة التواصل: تحفظ الرسالة في مركز الرسائل (v5) ثم تتيح المتابعة عبر واتساب */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$errors = [];
$saved = null;
$msgCats = contact_categories();
$canSave = schema_v5() && setting('messages_save', '1') === '1';
if (is_post()) {
    require_csrf();
    $name = mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 100);
    $phone = mb_substr(preg_replace('/[^\d+\s\-]/', '', (string) ($_POST['phone'] ?? '')), 0, 30);
    $email = mb_substr(trim((string) ($_POST['email'] ?? '')), 0, 190);
    $subject = mb_substr(trim((string) ($_POST['subject'] ?? '')), 0, 150);
    $cat = isset($msgCats[$_POST['category'] ?? '']) ? $_POST['category'] : 'inquiry';
    $ref = mb_substr(strtoupper(trim((string) ($_POST['request_ref'] ?? ''))), 0, 30);
    $msg = mb_substr(trim((string) ($_POST['message'] ?? '')), 0, 2000);
    if (trim((string) ($_POST['website'] ?? '')) !== '') redirect(route('contact'));
    if (mb_strlen($name) < 2) $errors[] = 'يرجى كتابة الاسم.';
    if (mb_strlen($msg) < 5) $errors[] = 'يرجى كتابة رسالتك.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'البريد الإلكتروني غير صحيح.';
    if ($canSave && $phone === '' && $email === '') $errors[] = 'اكتب رقم جوالك أو بريدك حتى نتمكن من الرد عليك.';
    if (!$errors && $canSave && rate_limited('contact', 5, 3600)) $errors[] = 'أرسلت عدة رسائل مؤخرًا. تواصل معنا عبر واتساب مباشرة.';
    if (!$errors) {
        $text = "السلام عليكم، لدي استفسار من خلال منصة " . setting('site_name') . ".\n\n- الاسم: $name\n- الموضوع: " . ($subject ?: $msgCats[$cat]) . ($ref ? "\n- رقم الطلب: $ref" : '') . "\n- الرسالة: $msg";
        if (!$canSave) redirect(wa_link($text));
        $req = $ref !== '' ? db_one('SELECT id FROM requests WHERE reference = ?', [$ref]) : null;
        $id = db_insert('contact_messages', ['name' => $name, 'phone' => $phone ?: null, 'email' => $email ?: null, 'subject' => $subject ?: null,
            'body' => $msg, 'category' => $cat, 'request_ref' => $ref ?: null, 'request_id' => $req['id'] ?? null, 'ip_hash' => ip_hash()]);
        notify_staff('editor', 'رسالة تواصل جديدة: ' . ($subject ?: $msgCats[$cat]), $name . ' — ' . excerpt($msg, 90), admin_url('messages', ['view' => $id]));
        $saved = ['id' => $id, 'wa' => setting('messages_whatsapp_after', '1') === '1' ? wa_link($text . "\n- رقم الرسالة: #$id") : null];
        $_POST = [];
    }
}
$active_nav = 'contact';
$page_title = 'تواصل معنا';
$page_description = 'تواصل مع منصة اختيارك للخدمات الطلابية عبر واتساب للاستفسار أو طلب خدمة.';
$breadcrumbs = [['تواصل معنا', null]];
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero"><div class="container"><h1>تواصل معنا</h1><p>واتساب هو أسرع وسيلة للتواصل والحجز.</p></div></section>
<section class="section pt-4">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-5">
        <div class="contact-card">
          <span class="feature-icon"><i class="bi bi-whatsapp"></i></span>
          <h2 class="h5">واتساب</h2>
          <p class="fs-5 fw-bold mb-3" dir="ltr"><?= e(setting('whatsapp_display', '+' . whatsapp_number())) ?></p>
          <a class="btn btn-whatsapp w-100" href="<?= e(wa_general_link()) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> ابدأ المحادثة</a>
        </div>
        <div class="contact-card mt-3">
          <ul class="footer-contact mb-0 dark">
            <li><i class="bi bi-clock"></i> <?= e(setting('working_hours')) ?></li>
            <?php if ($em = setting('contact_email')): ?><li><i class="bi bi-envelope"></i> <a href="mailto:<?= e($em) ?>"><?= e($em) ?></a></li><?php endif; ?>
            <li><i class="bi bi-ui-checks"></i> <a href="<?= e(route('order')) ?>">نموذج طلب خدمة مفصل</a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-7">
        <?php if ($saved): ?>
        <div class="form-card text-center" id="contact-success">
          <span class="feature-icon mx-auto"><i class="bi bi-check2-circle"></i></span>
          <h2 class="h5 mt-3">وصلتنا رسالتك (رقم #<?= (int) $saved['id'] ?>)</h2>
          <p class="text-muted">سنرد عليك في أقرب وقت عبر الوسيلة التي تركتها.</p>
          <?php if ($saved['wa']): ?><a class="btn btn-whatsapp" href="<?= e($saved['wa']) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> تابع مباشرة عبر واتساب (أسرع)</a><?php endif; ?>
        </div>
        <?php else: ?>
        <form class="form-card" method="post" action="<?= e(route('contact')) ?>">
          <?= csrf_field() ?>
          <div class="hp-field" aria-hidden="true"><label>اترك هذا الحقل فارغًا<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
          <h2 class="h5 mb-3">أرسل رسالتك</h2>
          <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2"><?= e($er) ?></div><?php endforeach; ?>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label" for="c-name">الاسم *</label><input class="form-control" id="c-name" name="name" maxlength="100" required value="<?= e($_POST['name'] ?? '') ?>"></div>
            <div class="col-md-6"><label class="form-label" for="c-cat">نوع الرسالة</label><select class="form-select" id="c-cat" name="category"><?php foreach ($msgCats as $k => $l): ?><option value="<?= e($k) ?>"<?= selected($_POST['category'] ?? 'inquiry', $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
            <?php if ($canSave): ?>
            <div class="col-md-6"><label class="form-label" for="c-phone">الجوال / واتساب</label><input class="form-control" id="c-phone" name="phone" maxlength="30" dir="ltr" inputmode="tel" value="<?= e($_POST['phone'] ?? '') ?>" placeholder="05xxxxxxxx"></div>
            <div class="col-md-6"><label class="form-label" for="c-email">البريد الإلكتروني</label><input class="form-control" id="c-email" type="email" name="email" maxlength="190" dir="ltr" value="<?= e($_POST['email'] ?? '') ?>"></div>
            <?php endif; ?>
            <div class="col-md-8"><label class="form-label" for="c-sub">الموضوع</label><input class="form-control" id="c-sub" name="subject" maxlength="150" value="<?= e($_POST['subject'] ?? '') ?>"></div>
            <div class="col-md-4"><label class="form-label" for="c-ref">رقم الطلب (إن وُجد)</label><input class="form-control" id="c-ref" name="request_ref" maxlength="30" dir="ltr" value="<?= e($_POST['request_ref'] ?? '') ?>" placeholder="IKH-..."></div>
            <div class="col-12"><label class="form-label" for="c-msg">الرسالة *</label><textarea class="form-control" id="c-msg" name="message" rows="5" maxlength="2000" required><?= e($_POST['message'] ?? '') ?></textarea></div>
          </div>
          <button class="btn btn-navy mt-3"><i class="bi bi-send"></i> <?= $canSave ? 'إرسال الرسالة' : 'متابعة عبر واتساب' ?></button>
          <p class="small text-muted mt-2 mb-0"><?= $canSave ? 'تُحفظ رسالتك لدى فريقنا ونرد عليك، ويمكنك متابعتها عبر واتساب بعد الإرسال.' : 'ستُفتح محادثة واتساب برسالتك، ولن تُرسل إلا بعد تأكيدك.' ?></p>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
