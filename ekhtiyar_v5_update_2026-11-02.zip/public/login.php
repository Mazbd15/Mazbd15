<?php
/**
 * صفحة تسجيل الدخول الموحّدة:
 *  - الإدارة والمحررون والمتخصصون ← لوحة التحكم
 *  - الأعضاء (الزوار المسجلون) ← صفحة «حسابي»
 * تسجيل الدخول اختياري للزوار؛ يمكن طلب أي خدمة بدون حساب.
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$dest = fn(array $u) => in_array($u['role'], staff_roles(), true) ? admin_url() : route('account');
if ($u = current_user()) redirect(safe_next($_GET['next'] ?? '', $dest($u)));

$error = '';
$next = (string) ($_POST['next'] ?? $_GET['next'] ?? '');
if (is_post()) {
    if (!csrf_valid()) {
        $error = 'انتهت صلاحية الصفحة، حاول مرة أخرى.';
    } else {
        $email = (string) ($_POST['email'] ?? '');
        $pass = (string) ($_POST['password'] ?? '');
        if ($email === '' || $pass === '') {
            $error = 'يرجى إدخال البريد الإلكتروني وكلمة المرور.';
        } else {
            [$ok, $msg, $user] = attempt_login($email, $pass);
            if ($ok) {
                // لا نسمح للعضو بالعودة إلى مسار لوحة التحكم
                $fallback = $dest($user);
                $target = safe_next($next, $fallback);
                if (!in_array($user['role'], staff_roles(), true) && str_contains($target, '/admin/')) $target = $fallback;
                redirect($target);
            }
            $error = $msg;
            usleep(random_int(200000, 450000));
        }
    }
}

$page_title = 'تسجيل الدخول';
$page_description = 'تسجيل الدخول إلى حسابك في منصة اختيارك للخدمات الطلابية.';
$noindex = true;
$body_class = 'auth-page';
require ROOT_PATH . '/includes/header.php';
?>
<section class="section auth-section">
  <div class="container">
    <div class="row justify-content-center g-4 align-items-stretch">
      <div class="col-lg-5">
        <div class="form-card h-100">
          <div class="text-center mb-4">
            <span class="feature-icon"><i class="bi bi-person-lock"></i></span>
            <h1 class="h3 mb-1">تسجيل الدخول</h1>
            <p class="text-muted small mb-0">للإدارة والمتخصصين والأعضاء</p>
          </div>
          <?php if ($error): ?><div class="alert alert-danger py-2 small" role="alert"><?= e($error) ?></div><?php endif; ?>
          <form method="post" action="<?= e(route('login')) ?>" novalidate>
            <?= csrf_field() ?>
            <input type="hidden" name="next" value="<?= e($next) ?>">
            <div class="mb-3">
              <label class="form-label" for="l-email">البريد الإلكتروني</label>
              <input class="form-control" id="l-email" type="email" name="email" dir="ltr" required autocomplete="username" value="<?= e($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-2">
              <label class="form-label" for="l-pass">كلمة المرور</label>
              <div class="input-group">
                <input class="form-control" id="l-pass" type="password" name="password" dir="ltr" required autocomplete="current-password">
                <button class="btn btn-outline-secondary" type="button" data-toggle-pass="#l-pass" aria-label="إظهار كلمة المرور"><i class="bi bi-eye"></i></button>
              </div>
            </div>
            <div class="d-flex justify-content-end mb-4"><a class="small" href="<?= e(route('forgot')) ?>">نسيت كلمة المرور؟</a></div>
            <button class="btn btn-navy btn-lg w-100"><i class="bi bi-box-arrow-in-left"></i> دخول</button>
          </form>
          <hr class="my-4">
          <a class="btn btn-outline-navy w-100" href="<?= e(route('order')) ?>"><i class="bi bi-person-walking"></i> المتابعة كزائر بدون تسجيل</a>
          <p class="small text-muted text-center mt-2 mb-0">التسجيل اختياري تمامًا — يمكنك طلب أي خدمة مباشرة عبر واتساب.</p>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="auth-side h-100">
          <h2 class="h5">ليس لديك حساب؟</h2>
          <?php if (setting('allow_member_signup', '1') === '1'): ?>
          <a class="auth-option" href="<?= e(route('register', ['type' => 'member'])) ?>">
            <i class="bi bi-person-plus"></i>
            <span><strong>حساب طالب / زائر</strong><small>تابع طلباتك وحالتها ورسائل الفريق من مكان واحد، وتعبئة أسرع للنماذج.</small></span>
          </a>
          <?php endif; ?>
          <?php if (setting('allow_specialist_signup', '1') === '1'): ?>
          <a class="auth-option" href="<?= e(route('register', ['type' => 'specialist'])) ?>">
            <i class="bi bi-person-badge"></i>
            <span><strong>انضم كمتخصص</strong><small>للمهندسين والمبرمجين والمصممين والأكاديميين — يُفعّل الحساب بعد موافقة الإدارة.</small></span>
          </a>
          <?php endif; ?>
          <ul class="auth-perks">
            <li><i class="bi bi-shield-check"></i> كلمات مرور مشفرة وحماية من محاولات التخمين</li>
            <li><i class="bi bi-bell"></i> إشعارات بتحديثات طلباتك</li>
            <li><i class="bi bi-whatsapp"></i> الحجز والدفع يبقيان عبر واتساب</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
