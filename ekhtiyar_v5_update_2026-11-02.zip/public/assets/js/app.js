/* =====================================================================
   اختيارك للخدمات الطلابية — سكربت الواجهة العامة
   ===================================================================== */
(function () {
  'use strict';
  var body = document.body;
  var base = body.getAttribute('data-base') || '';

  /* ---------- الوضع الداكن ---------- */
  var toggle = document.getElementById('theme-toggle');
  function setIcon() {
    if (!toggle) return;
    var dark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
    toggle.innerHTML = dark ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon-stars"></i>';
  }
  setIcon();
  if (toggle) toggle.addEventListener('click', function () {
    var next = document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-bs-theme', next);
    try { localStorage.setItem('ikh-theme', next); } catch (e) {}
    setIcon();
  });

  /* ---------- الرأس والعودة للأعلى ---------- */
  var header = document.getElementById('site-header');
  var backTop = document.getElementById('back-top');
  function onScroll() {
    var y = window.scrollY;
    if (header) header.classList.toggle('scrolled', y > 10);
    if (backTop) backTop.classList.toggle('show', y > 600);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  if (backTop) backTop.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  /* ---------- الظهور التدريجي ---------- */
  var reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -40px 0px' });
    reveals.forEach(function (el) { io.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- القائمة الضخمة: فتح صفحة الخدمات عند النقر المزدوج على سطح المكتب ---------- */
  document.querySelectorAll('.mega > .nav-link').forEach(function (a) {
    a.addEventListener('dblclick', function () { window.location.href = a.getAttribute('href'); });
  });

  /* ---------- البحث الفوري مع الاقتراحات ---------- */
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; });
  }
  function highlight(text, q) {
    var safe = escapeHtml(text);
    var words = q.trim().split(/\s+/).filter(function (w) { return w.length > 1; }).map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); });
    if (!words.length) return safe;
    try { return safe.replace(new RegExp('(' + words.map(escapeHtml).join('|') + ')', 'gi'), '<mark>$1</mark>'); } catch (e) { return safe; }
  }
  document.querySelectorAll('form[data-suggest]').forEach(function (form) {
    var input = form.querySelector('input[name=q]');
    var list = form.querySelector('.suggest-list');
    if (!input || !list) return;
    var timer = null, ctrl = null, active = -1, cache = {};

    function close() { list.hidden = true; input.setAttribute('aria-expanded', 'false'); active = -1; }
    function render(data, q) {
      var items = data.items || [];
      if (!items.length) {
        list.innerHTML = '<li class="suggest-empty">لا توجد اقتراحات — اضغط «بحث» لعرض كل النتائج</li>';
      } else {
        list.innerHTML = items.map(function (it, i) {
          var ic = it.type === 'sub' ? 'bi-diagram-3' : 'bi-arrow-up-left-circle';
          return '<li role="option" id="' + input.id + '-opt-' + i + '"><a href="' + escapeHtml(it.url) + '"><i class="bi ' + ic + '"></i><span>' + highlight(it.name, q) + '<small>' + escapeHtml(it.meta || '') + '</small></span></a></li>';
        }).join('') + '<li class="suggest-all"><a href="' + escapeHtml(data.all) + '">عرض كل النتائج لـ «' + escapeHtml(q) + '»</a></li>';
      }
      list.hidden = false;
      input.setAttribute('aria-expanded', 'true');
      active = -1;
    }
    function fetchSuggest(q) {
      if (cache[q]) return render(cache[q], q);
      if (ctrl && ctrl.abort) ctrl.abort();
      ctrl = window.AbortController ? new AbortController() : null;
      list.hidden = false;
      list.innerHTML = '<li class="suggest-empty"><span class="spinner-border spinner-border-sm"></span> جارٍ البحث...</li>';
      fetch(base + '/api/suggest.php?q=' + encodeURIComponent(q), { headers: { 'Accept': 'application/json' }, signal: ctrl ? ctrl.signal : undefined })
        .then(function (r) { return r.json(); })
        .then(function (d) { if (d && d.ok) { cache[q] = d; if (input.value.trim() === q) render(d, q); } else close(); })
        .catch(function (e) { if (e.name !== 'AbortError') close(); });
    }
    input.addEventListener('input', function () {
      var q = input.value.trim();
      clearTimeout(timer);
      if (q.length < 2) { close(); return; }
      timer = setTimeout(function () { fetchSuggest(q); }, 220);
    });
    input.addEventListener('keydown', function (e) {
      var opts = list.querySelectorAll('li a');
      if (list.hidden || !opts.length) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        active = e.key === 'ArrowDown' ? (active + 1) % opts.length : (active - 1 + opts.length) % opts.length;
        list.querySelectorAll('li').forEach(function (li) { li.classList.remove('active'); });
        opts[active].parentNode.classList.add('active');
        input.setAttribute('aria-activedescendant', opts[active].parentNode.id || '');
      } else if (e.key === 'Enter' && active >= 0) {
        e.preventDefault();
        window.location.href = opts[active].getAttribute('href');
      } else if (e.key === 'Escape') { close(); }
    });
    document.addEventListener('click', function (e) { if (!form.contains(e.target)) close(); });
    form.addEventListener('submit', function (e) { if (!input.value.trim()) { e.preventDefault(); input.focus(); } });
  });

  /* ---------- فلاتر صفحة الخدمات: تحديث التخصصات حسب المجال ---------- */
  var catalogEl = document.getElementById('catalog-data');
  var fCat = document.getElementById('f-cat');
  var fSub = document.getElementById('f-sub');
  if (catalogEl && fCat && fSub) {
    var cats = JSON.parse(catalogEl.textContent || '[]');
    fCat.addEventListener('change', function () {
      var c = cats.find(function (x) { return String(x.id) === fCat.value; });
      fSub.innerHTML = '<option value="">كل التخصصات</option>' + (c ? c.subs.map(function (s) { return '<option value="' + s.id + '">' + escapeHtml(s.name) + '</option>'; }).join('') : '');
    });
    ['f-cat', 'f-sub', 'f-type'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener('change', function () { if (id !== 'f-cat') document.getElementById('filters-form').submit(); });
    });
  }

  /* ---------- تصفية محلية سريعة داخل صفحة القسم ---------- */
  function norm(s) {
    return String(s || '').toLowerCase()
      .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
      .replace(/\s+/g, ' ').trim();
  }
  document.querySelectorAll('[data-local-filter]').forEach(function (input) {
    var sel = input.getAttribute('data-local-filter');
    var empty = document.querySelector('.local-empty');
    input.addEventListener('input', function () {
      var q = norm(input.value), shown = 0;
      document.querySelectorAll(sel).forEach(function (col) {
        var ok = !q || norm(col.getAttribute('data-text') + ' ' + col.textContent).indexOf(q) !== -1;
        col.hidden = !ok; if (ok) shown++;
      });
      document.querySelectorAll('.services-group').forEach(function (g) {
        var any = g.querySelector(sel + ':not([hidden])');
        g.hidden = !any;
      });
      if (empty) empty.hidden = shown > 0;
    });
  });

  /* ---------- مشاركة ---------- */
  document.querySelectorAll('[data-share]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var data = { title: btn.getAttribute('data-title') || document.title, url: window.location.href };
      if (navigator.share) { navigator.share(data).catch(function () {}); return; }
      if (navigator.clipboard) navigator.clipboard.writeText(data.url).then(function () {
        var t = btn.innerHTML; btn.innerHTML = '<i class="bi bi-check2"></i> تم نسخ الرابط';
        setTimeout(function () { btn.innerHTML = t; }, 2000);
      });
    });
  });
})();

/* v2: إظهار/إخفاء كلمة المرور */
(function () {
  'use strict';
  document.querySelectorAll('[data-toggle-pass]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var inp = document.querySelector(btn.getAttribute('data-toggle-pass'));
      if (!inp) return;
      var show = inp.type === 'password';
      inp.type = show ? 'text' : 'password';
      btn.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
      btn.setAttribute('aria-label', show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
    });
  });
})();

/* =====================================================================
   v3: سلايدر العروض، البحث الشامل، شريط الإعلان، شريط الطلب الثابت، العدادات
   ===================================================================== */
(function () {
  'use strict';
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- سلايدر آراء العملاء (v5) ---------- */
  document.querySelectorAll('[data-tslider]').forEach(function (root) {
    var track = root.querySelector('[data-ttrack]');
    if (!track) return;
    var ms = parseInt(root.getAttribute('data-interval'), 10) || 6000, timer = null;
    function step(dir) {
      var slide = track.querySelector('.t-slide');
      if (!slide) return;
      var w = slide.getBoundingClientRect().width + 19;
      var max = track.scrollWidth - track.clientWidth;
      var pos = Math.abs(track.scrollLeft);
      // RTL: scrollLeft سالب في أغلب المتصفحات
      var sign = getComputedStyle(track).direction === 'rtl' ? -1 : 1;
      if (dir > 0 && pos >= max - 5) track.scrollTo({ left: 0, behavior: reduce ? 'auto' : 'smooth' });
      else track.scrollBy({ left: sign * dir * w, behavior: reduce ? 'auto' : 'smooth' });
    }
    function play() { stop(); if (!reduce) timer = setInterval(function () { step(1); }, ms); }
    function stop() { if (timer) clearInterval(timer); timer = null; }
    var n = root.querySelector('[data-tnext]'), p = root.querySelector('[data-tprev]');
    if (n) n.addEventListener('click', function () { step(1); play(); });
    if (p) p.addEventListener('click', function () { step(-1); play(); });
    root.addEventListener('mouseenter', stop);
    root.addEventListener('mouseleave', play);
    root.addEventListener('focusin', stop);
    track.addEventListener('touchstart', stop, { passive: true });
    if ('IntersectionObserver' in window) new IntersectionObserver(function (en) { en[0].isIntersecting ? play() : stop(); }).observe(root);
    else play();
  });

  /* ---------- سلايدر العروض ---------- */
  document.querySelectorAll('[data-slider]').forEach(function (root) {
    var slides = root.querySelectorAll('.offer-slide');
    var dots = root.querySelectorAll('[data-dot]');
    if (slides.length < 2) return;
    var idx = 0, timer = null, ms = parseInt(root.getAttribute('data-interval'), 10) || 6000;
    root.style.setProperty('--slide-ms', ms + 'ms');
    function go(n) {
      idx = (n + slides.length) % slides.length;
      slides.forEach(function (s, i) {
        var on = i === idx;
        s.classList.toggle('is-active', on);
        s.setAttribute('aria-hidden', on ? 'false' : 'true');
        s.querySelectorAll('a').forEach(function (a) { a.tabIndex = on ? 0 : -1; });
      });
      dots.forEach(function (d, i) {
        d.classList.toggle('active', i === idx);
        d.setAttribute('aria-selected', i === idx ? 'true' : 'false');
        // إعادة تشغيل شريط التقدم
        var sp = d.querySelector('span'); if (sp) { sp.style.animation = 'none'; void sp.offsetWidth; sp.style.animation = ''; }
      });
    }
    function play() { stop(); if (!reduce) timer = setInterval(function () { go(idx + 1); }, ms); root.classList.remove('paused'); }
    function stop() { if (timer) clearInterval(timer); timer = null; }
    function pause() { stop(); root.classList.add('paused'); }
    var nx = root.querySelector('[data-next]'), pv = root.querySelector('[data-prev]');
    if (nx) nx.addEventListener('click', function () { go(idx + 1); play(); });
    if (pv) pv.addEventListener('click', function () { go(idx - 1); play(); });
    dots.forEach(function (d) { d.addEventListener('click', function () { go(parseInt(d.getAttribute('data-dot'), 10)); play(); }); });
    root.addEventListener('mouseenter', pause);
    root.addEventListener('mouseleave', play);
    root.addEventListener('focusin', pause);
    root.addEventListener('focusout', play);
    // السحب باللمس (RTL: السحب لليسار = التالي)
    var x0 = null, y0 = null;
    root.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; pause(); }, { passive: true });
    root.addEventListener('touchend', function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) go(dx < 0 ? idx + 1 : idx - 1);
      x0 = null; play();
    });
    // إيقاف عند خروج السلايدر من الشاشة أو إخفاء التبويب
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) { en[0].isIntersecting ? play() : stop(); }).observe(root);
    } else play();
    document.addEventListener('visibilitychange', function () { document.hidden ? stop() : play(); });
  });

  /* ---------- البحث الشامل ---------- */
  var overlay = document.getElementById('search-overlay');
  var lastFocus = null;
  function openSearch(e) {
    if (!overlay) return;
    if (e) e.preventDefault();
    lastFocus = document.activeElement;
    overlay.hidden = false;
    document.body.classList.add('search-open');
    var inp = overlay.querySelector('input[name=q]');
    setTimeout(function () { if (inp) inp.focus(); }, 30);
  }
  function closeSearch() {
    if (!overlay || overlay.hidden) return;
    overlay.hidden = true;
    document.body.classList.remove('search-open');
    if (lastFocus) lastFocus.focus();
  }
  document.querySelectorAll('[data-open-search]').forEach(function (b) { b.addEventListener('click', openSearch); });
  document.querySelectorAll('[data-close-search]').forEach(function (b) { b.addEventListener('click', closeSearch); });
  if (overlay) overlay.addEventListener('click', function (e) { if (e.target === overlay) closeSearch(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeSearch();
    var t = e.target.tagName;
    if (e.key === '/' && t !== 'INPUT' && t !== 'TEXTAREA' && t !== 'SELECT' && !e.target.isContentEditable) openSearch(e);
  });

  /* ---------- إخفاء شريط الإعلان (يُتذكر لنفس النص) ---------- */
  var ann = document.querySelector('[data-announce]');
  if (ann) {
    var key = 'ikh-ann-' + ann.getAttribute('data-announce');
    try { if (localStorage.getItem(key)) ann.remove(); } catch (e) {}
    var cl = ann.querySelector('.announce-close');
    if (cl) cl.addEventListener('click', function () { ann.remove(); try { localStorage.setItem(key, '1'); } catch (e) {} });
  }

  /* ---------- شريط الطلب الثابت في صفحة الخدمة (يظهر بعد تجاوز الواجهة) ---------- */
  var sticky = document.querySelector('.sticky-order');
  var heroEl = document.querySelector('.page-hero');
  if (sticky && heroEl && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (en) { sticky.classList.toggle('show', !en[0].isIntersecting); }).observe(heroEl);
  }

  /* ---------- عدّاد الأرقام ---------- */
  var counters = document.querySelectorAll('[data-count]');
  if (counters.length && 'IntersectionObserver' in window && !reduce) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        var el = en.target, to = parseInt(el.getAttribute('data-count'), 10) || 0, suf = el.getAttribute('data-suffix') || '', t0 = null;
        function step(ts) {
          if (!t0) t0 = ts;
          var p = Math.min((ts - t0) / 1200, 1);
          el.textContent = Math.round(to * (1 - Math.pow(1 - p, 3))) + suf;
          if (p < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
        cio.unobserve(el);
      });
    }, { threshold: .6 });
    counters.forEach(function (c) { cio.observe(c); });
  }
})();

/* v4: نسخ الرابط */
(function () {
  'use strict';
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-copy]');
    if (!b) return;
    var txt = b.getAttribute('data-copy');
    var done = function () { b.classList.add('copied'); b.setAttribute('title', 'تم النسخ'); setTimeout(function () { b.classList.remove('copied'); }, 1600); };
    if (navigator.clipboard) navigator.clipboard.writeText(txt).then(done, function () {});
    else { var t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); done(); } catch (x) {} t.remove(); }
  });
})();
