/* عارض صور مكبّر خفيف (بدون مكتبات): أسهم، سحب باللمس، Esc، عدّاد */
(function () {
  'use strict';
  document.querySelectorAll('[data-lightbox]').forEach(function (root) {
    var items = Array.prototype.slice.call(root.querySelectorAll('[data-lb-item]'));
    if (!items.length) return;
    var idx = 0, lb, img, cap, cnt;
    function build() {
      lb = document.createElement('div');
      lb.className = 'lb'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'عارض الصور');
      lb.innerHTML = '<button class="lb-close" type="button" aria-label="إغلاق"><i class="bi bi-x-lg"></i></button>' +
        '<button class="lb-nav lb-prev" type="button" aria-label="السابقة"><i class="bi bi-chevron-right"></i></button>' +
        '<figure class="lb-fig"><img alt=""><figcaption><span class="lb-cap"></span><span class="lb-cnt"></span></figcaption></figure>' +
        '<button class="lb-nav lb-next" type="button" aria-label="التالية"><i class="bi bi-chevron-left"></i></button>';
      document.body.appendChild(lb);
      img = lb.querySelector('img'); cap = lb.querySelector('.lb-cap'); cnt = lb.querySelector('.lb-cnt');
      lb.querySelector('.lb-close').addEventListener('click', close);
      lb.querySelector('.lb-prev').addEventListener('click', function () { show(idx - 1); });
      lb.querySelector('.lb-next').addEventListener('click', function () { show(idx + 1); });
      lb.addEventListener('click', function (e) { if (e.target === lb) close(); });
      var sx = null;
      lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
      lb.addEventListener('touchend', function (e) {
        if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; sx = null;
        if (Math.abs(dx) > 40) show(dx > 0 ? idx + 1 : idx - 1);
      });
    }
    function show(i) {
      idx = (i + items.length) % items.length;
      var a = items[idx];
      img.src = a.getAttribute('href'); img.alt = a.getAttribute('data-caption') || '';
      cap.textContent = a.getAttribute('data-caption') || ''; cnt.textContent = (idx + 1) + ' / ' + items.length;
      lb.classList.toggle('lb-single', items.length < 2);
    }
    function key(e) {
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowLeft') show(idx + 1);
      else if (e.key === 'ArrowRight') show(idx - 1);
    }
    function open(i) {
      if (!lb) build();
      show(i); lb.classList.add('open'); document.body.style.overflow = 'hidden';
      document.addEventListener('keydown', key); lb.querySelector('.lb-close').focus();
    }
    function close() {
      lb.classList.remove('open'); document.body.style.overflow = '';
      document.removeEventListener('keydown', key); items[idx].focus();
    }
    items.forEach(function (a, i) { a.addEventListener('click', function (e) { e.preventDefault(); open(i); }); });
  });
})();
