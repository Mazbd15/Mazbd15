/* Google Analytics 4 (يُحمّل فقط عند إدخال المعرّف في الإعدادات) */
(function () {
  var el = document.getElementById('ga-config'); var id = el && el.getAttribute('data-ga');
  if (!id) return;
  window.dataLayer = window.dataLayer || [];
  function gtag() { window.dataLayer.push(arguments); }
  window.gtag = gtag; gtag('js', new Date()); gtag('config', id, { anonymize_ip: true });
  // تتبع نقرات واتساب كتحويل
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href*="wa.me"]');
    if (a) gtag('event', 'whatsapp_click', { link_url: location.pathname });
  });
})();
