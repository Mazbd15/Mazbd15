/* =====================================================================
   نموذج طلب الخدمة: قوائم متسلسلة، تحقق، رفع ملفات، وفتح واتساب
   ===================================================================== */
(function () {
  'use strict';
  var form = document.getElementById('order-form');
  if (!form) return;

  var catalog = JSON.parse((document.getElementById('order-catalog') || {}).textContent || '[]');
  var limits = JSON.parse((document.getElementById('order-limits') || {}).textContent || '{}');
  var selCat = document.getElementById('o-cat');
  var selSub = document.getElementById('o-sub');
  var selSvc = document.getElementById('o-svc');
  var alertBox = form.querySelector('.form-alert');
  var submitBtn = document.getElementById('order-submit');
  var spinner = submitBtn.querySelector('.spinner-border');

  function esc(s) { var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
  function findCat() { return catalog.find(function (c) { return String(c.id) === selCat.value; }); }

  /* ---------- القوائم المتسلسلة: القسم ← التخصص ← الخدمة ---------- */
  function fillSubs(selected) {
    var c = findCat();
    selSub.innerHTML = '<option value="">كل التخصصات</option>' + (c ? c.subs.map(function (s) {
      return '<option value="' + s.id + '"' + (String(s.id) === String(selected) ? ' selected' : '') + '>' + esc(s.name) + '</option>';
    }).join('') : '');
    selSub.disabled = !c;
  }
  function fillServices(selected) {
    var c = findCat();
    if (!c) { selSvc.innerHTML = '<option value="">— اختر القسم أولًا —</option>'; selSvc.disabled = true; return; }
    var subId = selSub.value;
    var list = c.services.filter(function (s) { return !subId || String(s.sub) === subId; });
    var html = '<option value="">— اختر الخدمة (' + list.length + ') —</option>';
    if (!subId) {
      // تجميع حسب التخصص
      c.subs.forEach(function (sb) {
        var items = list.filter(function (s) { return s.sub === sb.id; });
        if (!items.length) return;
        html += '<optgroup label="' + esc(sb.name) + '">' + items.map(function (s) {
          return '<option value="' + s.id + '"' + (String(s.id) === String(selected) ? ' selected' : '') + '>' + esc(s.name) + '</option>';
        }).join('') + '</optgroup>';
      });
      var orphan = list.filter(function (s) { return !s.sub; });
      if (orphan.length) html += '<optgroup label="أخرى">' + orphan.map(function (s) { return '<option value="' + s.id + '">' + esc(s.name) + '</option>'; }).join('') + '</optgroup>';
    } else {
      html += list.map(function (s) {
        return '<option value="' + s.id + '"' + (String(s.id) === String(selected) ? ' selected' : '') + '>' + esc(s.name) + '</option>';
      }).join('');
    }
    selSvc.innerHTML = html;
    selSvc.disabled = false;
  }
  selCat.addEventListener('change', function () { fillSubs(''); fillServices(''); clearErr(selCat); });
  selSub.addEventListener('change', function () { fillServices(selSvc.value); });
  selSvc.addEventListener('change', function () {
    clearErr(selSvc);
    // مزامنة التخصص مع الخدمة المختارة
    var c = findCat(); if (!c) return;
    var s = c.services.find(function (x) { return String(x.id) === selSvc.value; });
    if (s && s.sub && selSub.value !== String(s.sub)) { selSub.value = String(s.sub); fillServices(s.id); }
  });
  fillSubs(selSub.getAttribute('data-selected'));
  fillServices(selSvc.getAttribute('data-selected'));

  /* ---------- عداد الأحرف ---------- */
  document.querySelectorAll('.char-count').forEach(function (el) {
    var t = document.getElementById(el.getAttribute('data-for'));
    var max = t.getAttribute('maxlength');
    var upd = function () { el.textContent = t.value.length + ' / ' + max; };
    t.addEventListener('input', upd); upd();
  });

  /* ---------- رفع الملفات ---------- */
  var store = document.getElementById('o-store');
  var zone = document.getElementById('upload-zone');
  var fileInput = document.getElementById('o-files');
  var fileList = document.getElementById('file-list');
  var dt = window.DataTransfer ? new DataTransfer() : null;

  function fmt(b) { return b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.round(b / 1024) + ' KB'; }
  function checkFile(f) {
    var ext = (f.name.split('.').pop() || '').toLowerCase();
    if ((limits.ext || []).indexOf(ext) === -1) return 'امتداد غير مسموح';
    if (/\.(php\d?|phtml|phar|exe|js|html?|svg|sh|bat)(\.|$)/i.test(f.name)) return 'نوع غير مسموح';
    if (f.size > (limits.maxMb || 10) * 1048576) return 'أكبر من ' + limits.maxMb + 'MB';
    return null;
  }
  function renderFiles() {
    if (!fileList) return;
    var files = fileInput.files;
    fileList.innerHTML = '';
    Array.prototype.forEach.call(files, function (f, i) {
      var err = checkFile(f);
      var li = document.createElement('li');
      if (err) li.className = 'bad';
      li.innerHTML = '<span><i class="bi bi-file-earmark"></i> ' + esc(f.name) + ' <small class="text-muted">(' + fmt(f.size) + ')</small>' + (err ? ' — <strong>' + err + '</strong>' : '') + '</span>' +
        (dt ? '<button type="button" aria-label="إزالة الملف" data-i="' + i + '"><i class="bi bi-x-circle"></i></button>' : '');
      fileList.appendChild(li);
    });
    if (files.length > limits.maxFiles) {
      var li = document.createElement('li'); li.className = 'bad'; li.textContent = 'الحد الأقصى ' + limits.maxFiles + ' ملفات.'; fileList.appendChild(li);
    }
  }
  if (store && fileInput) {
    var syncStore = function () {
      fileInput.disabled = !store.checked;
      zone.classList.toggle('enabled', store.checked);
      if (!store.checked) { fileInput.value = ''; if (dt) dt = new DataTransfer(); renderFiles(); }
    };
    store.addEventListener('change', syncStore); syncStore();
    fileInput.addEventListener('change', function () {
      if (dt) {
        Array.prototype.forEach.call(fileInput.files, function (f) { dt.items.add(f); });
        fileInput.files = dt.files;
      }
      renderFiles();
    });
    if (fileList) fileList.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-i]'); if (!b || !dt) return;
      dt.items.remove(parseInt(b.getAttribute('data-i'), 10));
      fileInput.files = dt.files; renderFiles();
    });
    ['dragenter', 'dragover'].forEach(function (ev) { zone.addEventListener(ev, function (e) { if (!fileInput.disabled) { e.preventDefault(); zone.classList.add('dragover'); } }); });
    ['dragleave', 'drop'].forEach(function (ev) { zone.addEventListener(ev, function () { zone.classList.remove('dragover'); }); });
  }

  /* ---------- التحقق ---------- */
  function setErr(el, msg) {
    if (!el) return;
    el.classList.add('is-invalid');
    var fb = el.parentNode.querySelector('.invalid-feedback') || (el.closest('.col-12, .col-md-6, .col-md-7, .form-check') || el.parentNode).querySelector('.invalid-feedback');
    if (fb) { fb.textContent = msg; fb.classList.add('d-block'); }
  }
  function clearErr(el) {
    if (!el) return;
    el.classList.remove('is-invalid');
    var wrap = el.closest('.col-12, .col-md-6, .col-md-7, .col-md-5, .form-check') || el.parentNode;
    var fb = wrap.querySelector('.invalid-feedback');
    if (fb) { fb.textContent = ''; fb.classList.remove('d-block'); }
  }
  form.querySelectorAll('input, select, textarea').forEach(function (el) {
    el.addEventListener('input', function () { clearErr(el); });
  });

  function validate() {
    var ok = true;
    var name = form.elements.name, cv = form.elements.contact_value, cm = form.elements.contact_method, desc = form.elements.description;
    var email = form.elements.email, dl = form.elements.deadline, priv = form.elements.privacy;
    if (name.value.trim().length < 2) { setErr(name, 'يرجى كتابة الاسم أو اسم مستعار.'); ok = false; }
    var v = cv.value.trim();
    if (!v) { setErr(cv, 'يرجى كتابة بيانات التواصل.'); ok = false; }
    else if ((cm.value === 'whatsapp' || cm.value === 'phone') && !/^\+?[0-9\s\-()]{8,20}$/.test(v)) { setErr(cv, 'رقم الجوال غير صالح.'); ok = false; }
    else if (cm.value === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { setErr(cv, 'البريد الإلكتروني غير صالح.'); ok = false; }
    if (email.value.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) { setErr(email, 'البريد الإلكتروني غير صالح.'); ok = false; }
    if (!selCat.value) { setErr(selCat, 'يرجى اختيار القسم الرئيسي.'); ok = false; }
    if (!selSvc.value) { setErr(selSvc, 'يرجى اختيار الخدمة المطلوبة.'); ok = false; }
    if (desc.value.trim().length < 10) { setErr(desc, 'يرجى وصف طلبك بشكل أوضح (10 أحرف على الأقل).'); ok = false; }
    if (dl.value && dl.value < dl.getAttribute('min')) { setErr(dl, 'الموعد النهائي يجب أن يكون اليوم أو بعده.'); ok = false; }
    if (!priv.checked) { setErr(priv, 'يجب الموافقة على سياسة الخصوصية.'); ok = false; }
    if (fileInput && !fileInput.disabled && fileInput.files.length) {
      var bad = Array.prototype.some.call(fileInput.files, function (f) { return checkFile(f); });
      if (bad || fileInput.files.length > limits.maxFiles) {
        var fb = document.querySelector('[data-for="attachments"]');
        if (fb) { fb.textContent = 'يرجى إزالة الملفات غير الصالحة.'; fb.classList.add('d-block'); }
        ok = false;
      }
    }
    if (!ok) {
      var first = form.querySelector('.is-invalid');
      if (first) { first.scrollIntoView({ behavior: 'smooth', block: 'center' }); first.focus({ preventScroll: true }); }
    }
    return ok;
  }

  /* ---------- الإرسال ---------- */
  function loading(on) {
    submitBtn.disabled = on;
    spinner.hidden = !on;
  }
  function showAlert(msg) { alertBox.textContent = msg; alertBox.hidden = false; alertBox.scrollIntoView({ behavior: 'smooth', block: 'center' }); }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    alertBox.hidden = true;
    if (!validate()) return;
    if (!window.fetch || !window.FormData) { form.submit(); return; }

    // فتح نافذة مسبقًا لتجنب حظر النوافذ المنبثقة على الجوال
    var waWin = null;
    try { waWin = window.open('', '_blank'); } catch (er) {}
    if (waWin) { try { waWin.document.write('<p style="font-family:sans-serif;text-align:center;margin-top:40px" dir="rtl">جارٍ فتح واتساب...</p>'); } catch (er) {} }

    loading(true);
    fetch(form.action, { method: 'POST', body: new FormData(form), headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (r) { return r.json().catch(function () { return { ok: false, errors: { _: 'استجابة غير متوقعة من الخادم.' } }; }); })
      .then(function (d) {
        loading(false);
        if (d.ok) {
          var link = document.getElementById('order-wa-link');
          link.href = d.whatsapp;
          document.getElementById('order-ref').textContent = d.reference ? 'رقم الطلب المرجعي: ' + d.reference + ' (تم حفظ طلبك بموافقتك)' : 'لم يُحفظ أي شيء في الموقع.';
          var copyBtn = document.getElementById('order-copy');
          copyBtn.onclick = function () {
            if (navigator.clipboard) navigator.clipboard.writeText(d.message).then(function () { copyBtn.innerHTML = '<i class="bi bi-check2"></i> تم النسخ'; });
          };
          form.hidden = true;
          document.getElementById('order-success').hidden = false;
          window.scrollTo({ top: document.getElementById('order-success').offsetTop - 120, behavior: 'smooth' });
          if (waWin && !waWin.closed) { waWin.location.href = d.whatsapp; }
          else { window.location.href = d.whatsapp; }
        } else {
          if (waWin) waWin.close();
          var errs = d.errors || {};
          Object.keys(errs).forEach(function (k) {
            if (k === '_') return;
            var el = k === 'attachments' ? null : form.elements[k];
            if (el) setErr(el, errs[k]);
            else if (k === 'attachments') { var fb = document.querySelector('[data-for="attachments"]'); if (fb) { fb.textContent = errs[k]; fb.classList.add('d-block'); } }
          });
          showAlert(errs._ || 'يرجى مراجعة الحقول المظللة وتصحيحها.');
        }
      })
      .catch(function () {
        loading(false);
        if (waWin) waWin.close();
        showAlert('تعذر الاتصال بالخادم. تحقق من اتصالك بالإنترنت أو تواصل معنا عبر واتساب مباشرة.');
      });
  });
})();
