/* لوحة التحكم — سلوكيات مشتركة */
(function () {
  'use strict';
  // تأكيد قبل الإجراءات الحساسة
  document.addEventListener('submit', function (e) {
    var f = e.target;
    var msg = f.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  }, true);
  // الأزرار التي تُرسل نماذج خارجية (form=) ذات data-confirm
  document.querySelectorAll('button[form]').forEach(function (b) {
    b.addEventListener('click', function (e) {
      var f = document.getElementById(b.getAttribute('form'));
      var msg = f && f.getAttribute('data-confirm');
      if (msg && !window.confirm(msg)) { e.preventDefault(); return; }
      if (f) { e.preventDefault(); f.submit(); }
    });
  });
  // معاينة الأيقونة
  document.querySelectorAll('[data-icon-input]').forEach(function (inp) {
    var prev = inp.parentNode.querySelector('[data-icon-preview]');
    inp.addEventListener('input', function () { if (prev) prev.className = 'bi ' + inp.value.replace(/[^a-z0-9\-]/g, ''); });
  });
  // تحديد الكل
  document.querySelectorAll('[data-check-all]').forEach(function (all) {
    all.addEventListener('change', function () {
      var g = all.getAttribute('data-check-all');
      var sel = g ? 'input[data-group="' + g + '"]' : 'input[name="ids[]"]';
      document.querySelectorAll(sel).forEach(function (c) { c.checked = all.checked; });
    });
  });
  // قوائم القسم/التخصص في نموذج الخدمة
  var subsData = document.getElementById('subs-data');
  var cat = document.getElementById('svc-cat'), sub = document.getElementById('svc-sub');
  if (subsData && cat && sub) {
    var subs = JSON.parse(subsData.textContent || '[]');
    var fill = function (sel) {
      sub.innerHTML = '<option value="">— بدون —</option>';
      subs.filter(function (s) { return String(s.category_id) === cat.value; }).forEach(function (s) {
        var o = document.createElement('option'); o.value = s.id; o.textContent = s.name;
        if (String(s.id) === String(sel)) o.selected = true; sub.appendChild(o);
      });
    };
    cat.addEventListener('change', function () { fill(''); });
    fill(sub.getAttribute('data-selected'));
  }
  // إظهار حقول نطاق السؤال الشائع
  var scope = document.getElementById('faq-scope');
  if (scope) {
    var upd = function () {
      document.querySelectorAll('[data-scope]').forEach(function (el) { el.hidden = el.getAttribute('data-scope') !== scope.value; });
    };
    scope.addEventListener('change', upd); upd();
  }
})();

/* v2: إرسال تلقائي، معاينة البنر، حقول المتخصص */
(function () {
  'use strict';
  document.addEventListener('change', function (e) {
    var el = e.target;
    if (el.matches && el.matches('[data-autosubmit]') && el.form) el.form.submit();
  });
  // معاينة صورة البنر ونصوصه قبل الحفظ
  document.querySelectorAll('[data-image-preview]').forEach(function (inp) {
    var box = document.querySelector(inp.getAttribute('data-image-preview'));
    inp.addEventListener('change', function () {
      var f = inp.files && inp.files[0];
      if (!f || !box) return;
      var r = new FileReader();
      r.onload = function () { box.style.backgroundImage = 'url(' + r.result + ')'; };
      r.readAsDataURL(f);
    });
  });
  document.querySelectorAll('[data-preview-input]').forEach(function (inp) {
    var k = inp.getAttribute('data-preview-input');
    if (k !== 'title' && k !== 'sub') return;
    var t = document.querySelector(k === 'title' ? '[data-preview-title]' : '[data-preview-sub]');
    inp.addEventListener('input', function () { if (t) t.textContent = inp.value; });
  });
  // إظهار حقول المتخصص فقط عند اختيار دور "متخصص"
  var role = document.querySelector('[data-role-select]');
  if (role) {
    var upd = function () {
      document.querySelectorAll('[data-specialist-only]').forEach(function (el) { el.hidden = role.value !== 'specialist'; });
    };
    role.addEventListener('change', upd); upd();
  }
})();

/* v3: معاينة البنر المصمم مباشرة */
(function () {
  'use strict';
  var box = document.getElementById('banner-preview');
  if (!box) return;
  document.querySelectorAll('[data-theme-input]').forEach(function (r) {
    r.addEventListener('change', function () {
      box.className = box.className.replace(/\btheme-[a-z]+\b/g, '').trim() + ' theme-' + r.value;
    });
  });
  var ic = document.querySelector('[data-preview-icon]'), icEl = box.querySelector('[data-preview-iconel]');
  if (ic && icEl) ic.addEventListener('input', function () { icEl.className = 'bi ' + (ic.value.replace(/[^a-z0-9\-]/g, '') || 'bi-stars'); });
  var badge = document.querySelector('[data-preview-input="badge"]'), bEl = box.querySelector('[data-preview-badge]');
  if (badge && bEl) badge.addEventListener('input', function () { bEl.hidden = !badge.value.trim(); bEl.querySelector('span').textContent = badge.value; });
  var btn = document.querySelector('[data-preview-input="btn"]'), btnEl = box.querySelector('[data-preview-btn]');
  if (btn && btnEl) btn.addEventListener('input', function () { btnEl.firstChild.nodeValue = (btn.value || 'اعرف المزيد') + ' '; });
  var file = document.querySelector('input[type=file][data-image-preview]');
  if (file) file.addEventListener('change', function () { if (file.files && file.files[0]) box.classList.add('has-image'); });
})();

/* v4: معرض الأعمال — الخدمات حسب القسم/التخصص، معاينة الصور المتعددة، عدّاد الأحرف، حفظ وصف الصور */
(function () {
  'use strict';
  var svcData = document.getElementById('svcs-data');
  var cat = document.getElementById('svc-cat'), sub = document.getElementById('svc-sub'), svc = document.getElementById('pf-svc');
  if (svcData && cat && svc) {
    var svcs = JSON.parse(svcData.textContent || '[]');
    var fillSvc = function (sel) {
      svc.innerHTML = '<option value="">— بدون —</option>';
      svcs.filter(function (s) {
        return String(s.category_id) === cat.value && (!sub || !sub.value || String(s.subcategory_id) === sub.value);
      }).forEach(function (s) {
        var o = document.createElement('option'); o.value = s.id; o.textContent = s.name;
        if (String(s.id) === String(sel)) o.selected = true; svc.appendChild(o);
      });
    };
    cat.addEventListener('change', function () { fillSvc(''); });
    if (sub) sub.addEventListener('change', function () { fillSvc(svc.value); });
    // انتظر تعبئة التخصصات أولًا
    setTimeout(function () { fillSvc(svc.getAttribute('data-selected')); }, 0);
  }
  document.querySelectorAll('[data-multi-preview]').forEach(function (inp) {
    var box = document.querySelector(inp.getAttribute('data-multi-preview'));
    inp.addEventListener('change', function () {
      if (!box) return; box.innerHTML = '';
      Array.prototype.slice.call(inp.files || [], 0, 20).forEach(function (f) {
        if (!/^image\//.test(f.type)) return;
        var img = document.createElement('img'); img.className = 'pf-new-thumb'; img.alt = '';
        img.src = URL.createObjectURL(f); box.appendChild(img);
      });
    });
  });
  document.querySelectorAll('[data-count]').forEach(function (inp) {
    var max = parseInt(inp.getAttribute('data-count'), 10);
    var hint = document.createElement('div'); hint.className = 'form-text text-end char-count';
    inp.insertAdjacentElement('afterend', hint);
    var upd = function () {
      var n = inp.value.length; hint.textContent = n + ' / ' + max;
      hint.classList.toggle('text-danger', n > max); hint.classList.toggle('text-success', n >= max * 0.7 && n <= max);
    };
    inp.addEventListener('input', upd); upd();
  });
  document.querySelectorAll('[data-autosave]').forEach(function (inp) {
    inp.addEventListener('change', function () { var f = inp.form; if (f) f.submit(); });
  });
})();

/* ---------- v5: معاينة بطاقة الرأي مباشرة ---------- */
(function () {
  var wrap = document.getElementById('t-preview');
  var form = document.getElementById('t-form');
  if (!wrap || !form) return;
  var themes = JSON.parse(wrap.getAttribute('data-themes') || '[]');
  var card = function () { return wrap.querySelector('.t-card'); };
  var q = function (n) { return form.querySelector('[data-pv="' + n + '"]'); };
  function update() {
    var c = card(); if (!c) return;
    themes.forEach(function (t) { c.classList.remove('t-' + t); });
    c.classList.add('t-' + (q('theme').value || 'white'));
    var nameEl = c.querySelector('.t-name');
    if (nameEl) {
      nameEl.textContent = q('name').value || 'عميل';
      if (q('verified').checked) nameEl.insertAdjacentHTML('beforeend', ' <i class="bi bi-patch-check-fill t-verified"></i>');
    }
    var ini = c.querySelector('.t-initial'); if (ini) ini.textContent = (q('name').value || 'ع').charAt(0);
    var spec = c.querySelector('.t-spec');
    if (!spec && q('spec').value) { spec = document.createElement('span'); spec.className = 't-spec'; c.querySelector('.t-who').appendChild(spec); }
    if (spec) spec.textContent = q('spec').value;
    var body = c.querySelector('.t-body'); if (body) body.textContent = q('body').value || 'نص الرأي يظهر هنا…';
    var sel = q('service'), svc = sel.value ? sel.options[sel.selectedIndex].text.split(' ← ').pop() : q('service_label').value;
    var foot = c.querySelector('.t-foot'), svEl = c.querySelector('.t-service');
    if (!svEl && svc) { svEl = document.createElement('span'); svEl.className = 't-service'; foot.insertBefore(svEl, foot.firstChild); }
    if (svEl) { svEl.textContent = ''; if (svc) { svEl.innerHTML = '<i class="bi bi-briefcase"></i> '; svEl.appendChild(document.createTextNode(svc)); } }
    var r = form.querySelector('input[name="rating"]:checked'), n = r ? parseInt(r.value, 10) : 5;
    c.querySelectorAll('.t-stars i').forEach(function (s, i) { s.className = 'bi ' + (i < n ? 'bi-star-fill' : 'bi-star'); });
    var icon = c.querySelector('.t-icon'); if (icon) icon.className = 'bi ' + q('icon').value + ' t-icon';
    if (q('use_colors').checked) { c.style.setProperty('--t-bg', q('bg').value); c.style.setProperty('--t-fg', q('fg').value); }
    else { c.style.removeProperty('--t-bg'); c.style.removeProperty('--t-fg'); }
  }
  form.addEventListener('input', update);
  form.addEventListener('change', update);
  form.querySelectorAll('[data-preview-file]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var f = inp.files && inp.files[0]; if (!f || !/^image\//.test(f.type)) return;
      var url = URL.createObjectURL(f), c = card(), kind = inp.getAttribute('data-preview-file');
      if (kind === 'avatar') {
        var av = c.querySelector('.t-avatar'), img = document.createElement('img');
        img.className = 't-avatar'; img.src = url; img.alt = ''; av.replaceWith(img);
      } else if (kind === 'bg_image') c.style.setProperty('--t-img', 'url("' + url + '")');
    });
  });
})();

/* ---------- v5: معاينة الصور قبل الرفع (data-img-preview) ---------- */
document.querySelectorAll('input[type=file][data-img-preview]').forEach(function (inp) {
  inp.addEventListener('change', function () {
    var box = document.getElementById(inp.getAttribute('data-img-preview'));
    if (!box) return;
    box.innerHTML = '';
    Array.prototype.slice.call(inp.files || [], 0, 12).forEach(function (f) {
      if (!/^image\//.test(f.type)) return;
      var img = document.createElement('img');
      img.src = URL.createObjectURL(f); img.alt = ''; img.className = 'img-thumbnail me-1 mb-1'; img.style.maxHeight = '90px';
      box.appendChild(img);
    });
  });
});

/* ---------- v5: قائمة التخصص الأب تتبع القسم المختار ---------- */
(function () {
  var par = document.getElementById('sub-parent');
  var cat = par && par.form ? par.form.querySelector('select[name="category_id"]') : null;
  if (!par || !cat) return;
  function filter() {
    Array.prototype.forEach.call(par.options, function (o) {
      if (!o.value) return;
      var ok = o.getAttribute('data-cat') === cat.value;
      o.hidden = !ok; o.disabled = !ok;
      if (!ok && o.selected) par.value = '';
    });
  }
  cat.addEventListener('change', filter); filter();
})();

/* ---------- v5: تنقل عبر قائمة منسدلة + تحديد رابط للنسخ ---------- */
document.querySelectorAll('select[data-nav-select]').forEach(function (s) {
  s.addEventListener('change', function () { if (s.value) window.location.href = s.value; });
});
document.querySelectorAll('input[data-copy]').forEach(function (inp) {
  inp.addEventListener('click', function () {
    inp.select();
    if (navigator.clipboard) navigator.clipboard.writeText(inp.value).then(function () { inp.classList.add('is-valid'); setTimeout(function () { inp.classList.remove('is-valid'); }, 1200); });
  });
});

/* ---------- v5: الترتيب بالسحب والإفلات ----------
   يكتشف تلقائيًا أي قائمة فيها أزرار «أعلى/أسفل» ويجعلها قابلة للسحب،
   ثم يحفظ الترتيب عبر admin/sort.php (CSRF). الأزرار القديمة تبقى تعمل كبديل. */
(function () {
  var body = document.body, page = body.getAttribute('data-page');
  var allowed = ['categories', 'subcategories', 'services', 'banners', 'portfolio', 'testimonials', 'pages'];
  if (!window.Sortable || allowed.indexOf(page) < 0) return;
  var groups = new Map();
  document.querySelectorAll('form input[name="action"][value="move"]').forEach(function (inp) {
    var form = inp.form, idInp = form.querySelector('input[name="id"]');
    var item = form.closest('tr') || form.closest('[class*="col-"]');
    if (!item || !idInp || item.hasAttribute('data-sort-id')) return;
    item.setAttribute('data-sort-id', idInp.value);
    var parent = item.parentElement;
    if (!groups.has(parent)) groups.set(parent, true);
    var cell = item.tagName === 'TR' ? item.querySelector('td') : item.querySelector('.panel, .p-3') || item;
    var h = document.createElement('span');
    h.className = 'drag-handle me-1'; h.title = 'اسحب لإعادة الترتيب'; h.innerHTML = '<i class="bi bi-grip-vertical"></i>';
    cell.insertBefore(h, cell.firstChild);
  });
  function toast(msg, ok) {
    var t = document.createElement('div');
    t.className = 'alert alert-' + (ok ? 'success' : 'danger') + ' position-fixed bottom-0 start-0 m-3 shadow';
    t.style.zIndex = 2000; t.textContent = msg; body.appendChild(t);
    setTimeout(function () { t.remove(); }, ok ? 1800 : 5000);
  }
  groups.forEach(function (_, parent) {
    Sortable.create(parent, {
      handle: '.drag-handle', draggable: '[data-sort-id]', animation: 150, ghostClass: 'sortable-ghost',
      onEnd: function (ev) {
        if (ev.oldIndex === ev.newIndex) return;
        var ids = Array.prototype.map.call(parent.querySelectorAll(':scope > [data-sort-id]'), function (el) { return el.getAttribute('data-sort-id'); });
        fetch(body.getAttribute('data-sort-url'), {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': body.getAttribute('data-csrf'), 'Accept': 'application/json' },
          body: JSON.stringify({ page: page, ids: ids })
        }).then(function (r) { return r.json().then(function (d) { return [r.ok, d]; }); })
          .then(function (x) { if (x[0] && x[1].ok) toast('تم حفظ الترتيب ✓', true); else { toast(x[1].error || 'تعذر الحفظ', false); setTimeout(function () { location.reload(); }, 1500); } })
          .catch(function () { toast('تعذر الاتصال بالخادم', false); });
      }
    });
  });
})();
