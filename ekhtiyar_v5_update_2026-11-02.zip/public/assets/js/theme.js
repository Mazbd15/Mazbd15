/* تطبيق الوضع الداكن مبكرًا لتجنب الوميض (يحترم الوضع الافتراضي من لوحة التحكم) */
(function () {
  try {
    var root = document.documentElement;
    var def = root.getAttribute('data-default-theme') || 'auto';
    var t = localStorage.getItem('ikh-theme');
    if (!t) t = def === 'auto' ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : def;
    root.setAttribute('data-bs-theme', t);
  } catch (e) {}
})();
