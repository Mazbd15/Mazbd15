<?php
/**
 * نسيت كلمة المرور: الموقع لا يرسل بريدًا (لا يوجد SMTP)، لذلك تتم الاستعادة بأمان
 * عبر التحقق من الهوية بواسطة الإدارة على واتساب، ثم تعيّن الإدارة كلمة مرور مؤقتة من لوحة التحكم.
 */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
$page_title = 'استعادة كلمة المرور';
$noindex = true;
require ROOT_PATH . '/includes/header.php';
$msg = 'السلام عليكم، أرغب في استعادة كلمة المرور لحسابي في منصة ' . setting('site_name') . ".\n- البريد المسجل: \n- الاسم: ";
?>
<section class="section auth-section">
  <div class="container" style="max-width:560px">
    <div class="form-card text-center">
      <span class="feature-icon"><i class="bi bi-key"></i></span>
      <h1 class="h4">استعادة كلمة المرور</h1>
      <p class="text-muted">لحماية حسابك، تتم الاستعادة بعد التحقق من هويتك عبر واتساب. أرسل بريدك المسجل وسيقوم فريق الإدارة بتعيين كلمة مرور مؤقتة لك، ثم غيّرها من صفحة «حسابي».</p>
      <a class="btn btn-whatsapp btn-lg" href="<?= e(wa_link($msg)) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> طلب الاستعادة عبر واتساب</a>
      <p class="small mt-3 mb-0"><a href="<?= e(route('login')) ?>">العودة لتسجيل الدخول</a></p>
    </div>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
