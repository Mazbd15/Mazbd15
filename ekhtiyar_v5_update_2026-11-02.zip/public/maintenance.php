<?php /** صفحة وضع الصيانة — تُعرض من bootstrap */
if (!defined('IKH_BOOTSTRAPPED')) { // فتح الملف مباشرة: نحمّل التطبيق؛ وإن لم يكن وضع الصيانة مفعّلًا نعود للرئيسية
    require dirname(__DIR__) . '/includes/bootstrap.php';
    if (setting('maintenance_mode', '0') !== '1') redirect(route('home'));
} ?><!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>الموقع تحت الصيانة | <?= e(setting('site_name')) ?></title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;800&display=swap">
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;font-family:Cairo,Tahoma,sans-serif;background:radial-gradient(700px 300px at 85% 0,rgba(56,189,248,.25),transparent 60%),linear-gradient(150deg,#0b1f3a,#13315c);color:#fff;text-align:center;padding:20px}
main{max-width:560px}h1{color:#e3c477;margin:.6rem 0}p{opacity:.85;line-height:1.9}a{display:inline-block;margin-top:14px;background:#25d366;color:#fff;padding:12px 24px;border-radius:14px;text-decoration:none;font-weight:800}</style></head>
<body><main><img src="<?= e(url('assets/images/logo.svg')) ?>" width="84" height="84" alt=""><h1>الموقع تحت الصيانة</h1><p><?= nl2br(e(setting('maintenance_message'))) ?></p><a href="<?= e(wa_general_link()) ?>">تواصل معنا عبر واتساب</a></main></body></html>
