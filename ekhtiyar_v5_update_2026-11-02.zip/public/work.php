<?php
/** صفحة عمل واحد من معرض الأعمال: صور بعارض مكبّر + ملفات + خدمة مرتبطة + طلب عمل مشابه */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';

$slug = (string) ($_GET['slug'] ?? '');
$w = $slug !== '' ? portfolio_by_slug($slug) : null;
if (!$w) not_found();
portfolio_track_view((int) $w['id']);

$images = portfolio_files((int) $w['id'], 'image');
$allowDl = setting('portfolio_allow_downloads', '1') === '1';
$docs = array_values(array_filter(portfolio_files((int) $w['id'], 'document'), fn($d) => $allowDl && (int) $d['is_downloadable'] === 1));
$cover = portfolio_cover($w);
$gallery = $images;
if ($w['cover_image'] && is_file(PUBLIC_PATH . '/' . $w['cover_image'])) array_unshift($gallery, ['file_path' => $w['cover_image'], 'caption' => $w['title']]);
$tools = csv_items($w['tools_text']);
$related = portfolio_list(['category' => $w['category_id'], 'exclude' => $w['id']], 3);
$service = $w['service_id'] ? service_by_slug((string) $w['service_slug']) : null;

$abs = fn(string $u) => absolute_url(ltrim(substr($u, strlen(base_path())), '/'));
$active_nav = 'portfolio';
$page_title = $w['meta_title'] ?: $w['title'] . ' — ' . ($w['subcategory_name'] ?: $w['category_name']);
$page_description = $w['meta_description'] ?: seo_description($w['summary'] ?: '', $w['description'] ?: '', $tools ? 'باستخدام ' . implode('، ', $tools) . '.' : '', 'من أعمال ' . setting('site_name') . '.');
$page_type = 'article';
$page_canonical = $abs(route('work', ['slug' => $w['slug']]));
if ($cover) $page_image = preg_match('~^https?://~', $cover) ? $cover : absolute_url($cover);
$breadcrumbs = [['أعمالنا', route('portfolio')], [$w['category_name'], route('portfolio', ['category' => $w['category_slug']])], [$w['title'], null]];
$json_ld = [array_filter([
    '@context' => 'https://schema.org', '@type' => 'CreativeWork', 'name' => $w['title'], 'headline' => $w['title'],
    'description' => $page_description, 'url' => $page_canonical, 'inLanguage' => 'ar',
    'genre' => $w['subcategory_name'] ?: $w['category_name'], 'keywords' => implode(', ', array_merge($tools, [$w['category_name']])),
    'dateCreated' => $w['completed_at'] ?: null, 'dateModified' => date('c', strtotime($w['updated_at'])),
    'image' => array_map(fn($g) => ['@type' => 'ImageObject', 'contentUrl' => absolute_url($g['file_path']), 'caption' => $g['caption'] ?: $w['title']], array_slice($gallery, 0, 10)) ?: null,
    'creator' => ['@type' => 'Organization', 'name' => setting('site_name'), 'url' => absolute_url()],
    'about' => $service ? ['@type' => 'Service', 'name' => $service['name'], 'url' => $abs(route('service', ['slug' => $service['slug']]))] : null,
])];
$waSimilar = wa_link(wa_order_message([
    'category' => $w['category_name'], 'specialization' => $w['subcategory_name'] ?: '', 'service' => $w['service_name'] ?: '',
    'description' => 'أرغب في عمل مشابه لـ «' . $w['title'] . '» (' . $page_canonical . ')',
]));
$wa_float_link = $waSimilar;
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero work-hero tone-<?= e(category_tone($w['category_slug'])) ?>">
  <div class="container">
    <div class="d-flex flex-wrap gap-2 mb-3">
      <a class="chip" href="<?= e(route('portfolio', ['category' => $w['category_slug']])) ?>"><?= icon($w['category_icon']) ?> <?= e($w['category_name']) ?></a>
      <?php if ($w['subcategory_name']): ?><a class="chip" href="<?= e(route('category', ['slug' => $w['category_slug'], 'sub' => $w['subcategory_slug']])) ?>"><?= e($w['subcategory_name']) ?></a><?php endif; ?>
      <?php if ($w['level_text']): ?><span class="chip chip-muted"><?= e($w['level_text']) ?></span><?php endif; ?>
    </div>
    <h1><?= e($w['title']) ?></h1>
    <?php if ($w['summary']): ?><p class="mb-0"><?= e($w['summary']) ?></p><?php endif; ?>
  </div>
</section>

<section class="section pt-4">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <?php if ($gallery): ?>
          <div class="work-gallery" data-lightbox>
            <a class="wg-main" href="<?= e(url($gallery[0]['file_path'])) ?>" data-lb-item data-caption="<?= e($gallery[0]['caption'] ?: $w['title']) ?>">
              <img src="<?= e(url($gallery[0]['file_path'])) ?>" alt="<?= e($gallery[0]['caption'] ?: $w['title']) ?>" fetchpriority="high">
              <span class="wg-zoom"><i class="bi bi-arrows-fullscreen"></i> تكبير</span>
            </a>
            <?php if (count($gallery) > 1): ?>
              <div class="wg-thumbs">
                <?php foreach (array_slice($gallery, 1) as $i => $g): ?>
                  <a href="<?= e(media_url($g['file_path'])) ?>" data-lb-item data-caption="<?= e($g['caption'] ?: $w['title'] . ' — صورة ' . ($i + 2)) ?>">
                    <img src="<?= e(media_url($g['file_path'], true)) ?>" alt="<?= e($g['caption'] ?: $w['title'] . ' — صورة ' . ($i + 2)) ?>" loading="lazy">
                  </a>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        <?php elseif ($cover): ?>
          <img class="service-cover" src="<?= e(img_src($cover)) ?>" alt="<?= e($w['title']) ?>">
        <?php endif; ?>

        <?php if ($w['description']): ?>
          <article class="content-card mt-4"><h2 class="h5">عن هذا العمل</h2><div class="lead-text mb-0"><?= nl2br(e($w['description'])) ?></div></article>
        <?php endif; ?>

        <?php if ($docs): ?>
          <section class="content-card mt-4" aria-labelledby="docs-title">
            <h2 class="h5" id="docs-title"><i class="bi bi-paperclip"></i> ملفات العمل</h2>
            <ul class="work-docs">
              <?php foreach ($docs as $d): $ext = strtolower(pathinfo($d['file_path'], PATHINFO_EXTENSION)); ?>
                <li>
                  <i class="bi <?= e(file_icon($ext)) ?>"></i>
                  <div><strong><?= e($d['caption'] ?: $d['original_name']) ?></strong><small><?= strtoupper(e($ext)) ?> • <?= format_bytes((int) $d['file_size']) ?></small></div>
                  <?php if ($ext === 'pdf'): ?><a class="btn btn-sm btn-outline-navy" href="<?= e(route('work_file', ['id' => $d['id']]) . '&view=1') ?>" target="_blank" rel="noopener nofollow"><i class="bi bi-eye"></i> عرض</a><?php endif; ?>
                  <a class="btn btn-sm btn-navy" href="<?= e(route('work_file', ['id' => $d['id']])) ?>" rel="nofollow"><i class="bi bi-download"></i> تنزيل</a>
                </li>
              <?php endforeach; ?>
            </ul>
          </section>
        <?php endif; ?>
        <?php if ($dis = setting('portfolio_disclaimer')): ?><p class="work-disclaimer mt-3"><i class="bi bi-info-circle"></i> <?= e($dis) ?></p><?php endif; ?>
        <?php if ($w['category_slug'] === 'engineering'): ?><?= render_notice('الأعمال الهندسية المعروضة نماذج أكاديمية وتعليمية، وليست مخططات تنفيذية معتمدة.', 'bi-cone-striped') ?><?php endif; ?>
      </div>

      <aside class="col-lg-4">
        <div class="order-box sticky-lg-top" style="top:90px">
          <h2 class="h5"><i class="bi bi-stars"></i> تريد عملًا مشابهًا؟</h2>
          <p class="small text-muted">أرسل الطلب عبر واتساب وسيصل لنا رابط هذا العمل تلقائيًا لنفهم ما تريده بالضبط.</p>
          <a class="btn btn-whatsapp w-100 mb-2" href="<?= e($waSimilar) ?>" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> اطلب عملًا مشابهًا</a>
          <?php if ($service): ?><a class="btn btn-outline-navy w-100 mb-3" href="<?= e(route('service', ['slug' => $service['slug']])) ?>"><i class="bi bi-briefcase"></i> تفاصيل خدمة: <?= e(excerpt($service['name'], 30)) ?></a><?php endif; ?>
          <dl class="work-facts">
            <div><dt>القسم</dt><dd><?= e($w['category_name']) ?></dd></div>
            <?php if ($w['subcategory_name']): ?><div><dt>التخصص</dt><dd><?= e($w['subcategory_name']) ?></dd></div><?php endif; ?>
            <?php if ($w['level_text']): ?><div><dt>النوع</dt><dd><?= e($w['level_text']) ?></dd></div><?php endif; ?>
            <?php if ($w['completed_at']): ?><div><dt>تاريخ الإنجاز</dt><dd><?= e(ar_month($w['completed_at'])) ?></dd></div><?php endif; ?>
            <div><dt>المحتوى</dt><dd><?= count($gallery) ?> صورة<?= $docs ? ' • ' . count($docs) . ' ملف' : '' ?></dd></div>
          </dl>
          <?php if ($tools): ?><div class="mb-3"><span class="small fw-bold d-block mb-1">البرامج والأدوات</span><ul class="work-tools"><?php foreach ($tools as $t): ?><li><?= e($t) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
          <?= render_share_buttons($page_canonical, $w['title']) ?>
        </div>
      </aside>
    </div>

    <?php if ($related): ?>
      <div class="mt-5"><?= render_portfolio_section($related, 'أعمال أخرى في ' . $w['category_name'], null, route('portfolio', ['category' => $w['category_slug']]), 'related-works') ?></div>
    <?php endif; ?>
  </div>
</section>
<?php $page_scripts = ['js/lightbox.js']; require ROOT_PATH . '/includes/footer.php';
