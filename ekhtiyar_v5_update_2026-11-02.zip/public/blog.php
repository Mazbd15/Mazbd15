<?php
/** المدونة: قائمة المقالات المنشورة (v5) */
declare(strict_types=1);
require dirname(__DIR__) . '/includes/bootstrap.php';
if (!articles_enabled()) not_found();

$perPage = 12;
$total = posts_count('article');
$pages = max(1, (int) ceil($total / $perPage));
$page = min(max(1, (int) ($_GET['page'] ?? 1)), $pages);
$posts = posts_published('article', $perPage, ($page - 1) * $perPage);

$active_nav = 'blog';
$page_title = 'المقالات والنصائح' . ($page > 1 ? " — صفحة $page" : '');
$page_description = 'مقالات ونصائح أكاديمية للطلاب والباحثين من ' . setting('site_name') . '.';
$breadcrumbs = [['المقالات', null]];
$page_canonical = absolute_url(ltrim(substr(route('blog', $page > 1 ? ['page' => $page] : []), strlen(base_path())), '/'));
require ROOT_PATH . '/includes/header.php';
?>
<section class="page-hero"><div class="container"><h1>المقالات والنصائح</h1><p>إرشادات عملية تساعدك في دراستك وأبحاثك ومسيرتك المهنية.</p></div></section>
<section class="section pt-4">
  <div class="container">
    <?php if (!$posts): ?>
      <div class="text-center text-muted py-5"><i class="bi bi-newspaper fs-1 d-block mb-2"></i>لا توجد مقالات منشورة بعد.</div>
    <?php else: ?>
      <div class="row g-4">
        <?php foreach ($posts as $p): ?><div class="col-sm-6 col-lg-4 reveal"><?= render_post_card($p) ?></div><?php endforeach; ?>
      </div>
      <?php if ($pages > 1): ?>
        <nav class="mt-4" aria-label="صفحات المقالات"><ul class="pagination justify-content-center flex-wrap">
          <?php for ($i = 1; $i <= $pages; $i++): ?><li class="page-item<?= $i === $page ? ' active' : '' ?>"><a class="page-link" href="<?= e(route('blog', $i > 1 ? ['page' => $i] : [])) ?>"><?= $i ?></a></li><?php endfor; ?>
        </ul></nav>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
<?php require ROOT_PATH . '/includes/footer.php'; ?>
